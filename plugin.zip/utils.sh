function run_func_plugin_list() {
    script_name=`echo $(basename $0)|awk -F"." '{print $1}'`
    log_path_prefix=${log_dir}/${day}/${script_name}
    mkdir $log_dir/${day}
    mkdir ${log_path_prefix}

    for i in "${!func_plugin_list[@]}";
    do
        func_info=${func_plugin_list[$i]}
        plugin_alive=`echo ${func_info}|awk '{print $NF}'`
        func_name=`echo ${func_info}|awk '{print $1}'`
        params=`echo ${func_info}|cut -d ' ' -f 2-|awk 'NF--'`
        if [ "${plugin_alive}" == "1" ];then
            echo -e "$i Notice: run plugin_function ${func_name}(${params})\n"
            ${func_name} ${params} > ${log_path_prefix}/${func_name}.$i.${hour}.log 2>&1
        elif [ "${plugin_alive}" == "2" ];then
            echo -e "$i Notice: parallel run plugin_function ${func_name}(${params})\n"
            ${func_name} ${params} &> ${log_path_prefix}/${func_name}.$i.${hour}.log &
        else
            echo -e "$i Notice: plugin_function ${func_name}() is disabled\n"
        fi
        if [ $? -ne 0 ];then
            echo "FATAL: run $i ${func_name}(${params}) failed! please check!"
            exit -1
        fi
    done;
}

function retrieve_adv()
{
    day=$1
    vecfile=$2
    vecfile_path=$3
    local LOCAL_INPUT1=$4
    local LOCAL_OUTPUT_PREFIX=$5
    local retr_thd=$6
    local retr_num=$7
    local vec_len=$8
    local vec_path_prefix=`tail -1 ${vecfile_path}/done_file`
    echo $*
    local LOCAL_OUTPUT=${LOCAL_OUTPUT_PREFIX}
    HADOOP=${wuge_bin}

    echo ${retr_thd}
    echo ${retr_num}
    echo ${vecfile_path}
    echo ${vecfile}
    ${HADOOP} fs -rmr ${LOCAL_OUTPUT}
    ${HADOOP} streaming \
        -jobconf mapred.job.name=${FUNCNAME}_${day} \
        -jobconf mapred.job.priority=VERY_HIGH \
        -jobconf mapred.job.map.capacity=1024 \
        -jobconf mapred.reduce.tasks=1024 \
        -jobconf mapred.job.reduce.capacity=1024 \
        -file ${common_utils_dir}/gen.sh \
        -file ${common_utils_dir}/reshape.sh \
        -file ${HOME}/ernie_model_qt/feedas_embcos_max \
        -file ${vec_path_prefix}/${vecfile} \
        -mapper 'sh reshape.sh' \
        -reducer "sh gen.sh ${vecfile} ${vec_len} ${retr_thd} ${retr_num}"  \
        -input ${LOCAL_INPUT1} \
        -output ${LOCAL_OUTPUT}

    if [ $? -ne 0 ];then
        echo "${FUNCNAME} failed! please check!"
        exit 1
    else
        echo "${FUNCNAME} run successfully!"
    fi
}

function prepare_input_data() {
    local input_path_1=$1
    local output_path=$2
    HADOOP=${yinglong_bin}

    ${HADOOP} fs -rmr ${output_path}
    ${HADOOP} streaming \
        -jobconf mapred.job.name=${FUNCNAME} \
        -jobconf mapred.job.priority=VERY_HIGH \
        -jobconf mapred.job.map.capacity=1024 \
        -jobconf mapred.reduce.tasks=1024 \
        -jobconf mapred.job.reduce.capacity=1024 \
        -jobconf stream.memory.limit=8000 \
        -file ${common_utils_dir}/prepare_it_data.sh \
        -mapper 'sh prepare_it_data.sh' \
        -reducer "uniq"  \
        -input ${input_path_1} \
        -output ${output_path}

    if [ $? -ne 0 ];then
        echo "${FUNCNAME} run failed! please check!"
        exit -1
    fi
}

function predict_it() {
    local input_path_1=$1
    local output_path=$2

    HADOOP=${yinglong_bin}
    ${HADOOP} fs -test -e ${output_path}
    if [ $? -ne 0 ]; then
        ${HADOOP} fs -mkdir ${output_path}
        ${HADOOP} fs -touchz ${output_path}/done_file
    fi
    output_path_day=${output_path}/${day}
    ${HADOOP} fs -rmr ${output_path_day}
    ${HADOOP} streaming \
        -D mapred.map.tasks=1024 \
        -D mapred.job.map.capacity=500 \
        -D mapred.reduce.tasks=512 \
        -D mapred.job.reduce.capacity=500 \
        -D stream.memory.limit.0=8000 \
        -D stream.memory.limit.1=2000 \
        -D mapred.job.name=${FUNCNAME} \
        -D mapred.min.split.size=50000000 \
        -D mapred.max.split.size=5000000000 \
        -D mapred.job.priority=VERY_HIGH \
        -D mapred.reduce.slowstart.completed.maps=0.99 \
        -D abaci.appmaster.memory.bytes.per.task=35000 \
        -D mapred.textoutputformat.ignoreseparator=true \
        -file ${common_utils_dir}/run_interest_multi_label_pred.sh \
        -file ${common_utils_dir}/run_reduce.sh \
        -file ${common_utils_dir}/term2id.py \
        -file ${adv_title_it_data_dir}/idict.sort.100w \
        -input ${input_path_1} \
        -output ${output_path_day} \
        -inputformat org.apache.hadoop.mapred.TextInputFormat \
        -outputformat org.apache.hadoop.mapred.TextOutputFormat \
        -mapper 'cd wordrank_spa && chmod +x wordrank && ./wordrank 0 1 2>/dev/null' \
        -reducer 'sh run_reduce.sh' \
        -cacheArchive ${MODEL_PATH} \
        -cacheArchive ${PYTHON36} \
        -cacheArchive ${PYTHON_URI} \
        -cacheArchive ${SPA_PATH} \
        -cacheArchive ${GCC_PAKAGE}

    if [ $? -eq 0 ]; then
        record_done_file ${HADOOP} ${output_path_day} ${output_path}/done_file ${log_dir}/.predict_it_done_file
        clear_hadoop_data ${yinglong_bin} ${output_path} 8
    else
        echo "${FUNCNAME} failed! please check!"
        exit -1
    fi
}

function join_query_with_it() {
    local input_path_1=$1
    local input_path_2=$2
    local output_path=$3
    local adv_it_label=$4
    adv_title_it_path=`tail -1 ${adv_title_it_data_dir}/done_file`
    HADOOP=${wuge_bin}

    ${HADOOP} fs -rmr ${output_path}
    ${HADOOP} streaming \
        -jobconf mapred.job.name=${FUNCNAME} \
        -jobconf mapred.job.priority=VERY_HIGH \
        -jobconf mapred.job.map.capacity=1024 \
        -jobconf mapred.reduce.tasks=1024 \
        -jobconf mapred.job.reduce.capacity=1024 \
        -jobconf stream.memory.limit=8000 \
        -file ${common_utils_dir}/py_utils/join_query_with_it.py \
        -file ${adv_title_it_path}/${adv_it_label} \
        -mapper "python/bin/python join_query_with_it.py map ${adv_it_label}" \
        -reducer "python/bin/python join_query_with_it.py reduce" \
        -input ${input_path_1} \
        -input ${input_path_2} \
        -output ${output_path} \
        -cacheArchive ${shaolin_py_env}#python
    if [ $? -ne 0 ];then
        echo "${FUNCNAME} run failed! please check!"
        exit -1
    fi
}

function generate_full_xbox_index() {
    local adv_file=$1
    local adv_path_prefix=$2
    local input_path_1=$3
    local output_path=$4
    local ann_thd=$5
    local index_tag=$6
    local print_sign_flag=$7
    echo $*
    HADOOP=${wuge_bin}
    local adv_path_prefix=`tail -1 ${adv_path_prefix}/done_file`

    ${HADOOP} fs -rmr ${output_path}
    ${HADOOP} streaming \
        -jobconf mapred.job.name=chenyunan_at_${FUNCNAME}_${day} \
        -jobconf mapred.map.capacity.per.tasktracker=4 \
        -jobconf mapred.reduce.capacity.per.tasktracker=4 \
        -jobconf mapred.max.map.failures.percent=1 \
        -jobconf mapred.max.reduce.failures.percent=1 \
        -jobconf mapred.job.priority=VERY_HIGH \
        -jobconf mapred.job.map.capacity=1024 \
        -jobconf mapred.reduce.tasks=1024 \
        -jobconf mapred.job.reduce.capacity=1024 \
        -jobconf stream.memory.limit=8000 \
        -jobconf mapred.reduce.slowstart.completed.maps=0.99 \
        -mapper 'cat' \
        -reducer "python/bin/python generate_xbox_full_index.py reduce ${ann_thd} ${index_tag} ${print_sign_flag} ${adv_file}" \
        -input ${input_path_1} \
        -output ${output_path} \
        -file ${common_utils_dir}/py_utils/generate_xbox_full_index.py \
        -file ${adv_path_prefix}/${adv_file} \
        -cacheArchive ${shaolin_py_env}#python

    if [ $? -ne 0 ];then
        echo "${FUNCNAME} fail! please check!"
        exit -1
    fi
}

function cut_xbox_index() {
    local day=$1
    local input_path_1=$2
    local input_path_2=$3
    local output_path=$4
    local map_task_name=$5
    local thd=$6
    local print_flag=$7
    local quota=$8
    HADOOP=${wuge_bin}

    ${HADOOP} fs -test -e ${output_path}
    if [ $? -ne 0 ]; then
        ${HADOOP} fs -mkdir ${output_path}
        ${HADOOP} fs -touchz ${output_path}/done_file
    fi
    output_path_day=${output_path}/${day}${hour}
    ${HADOOP} fs -rmr ${output_path_day}
    $HADOOP streaming \
        -jobconf mapred.job.name=chenyunan_at_${FUNCNAME}_${day} \
        -input ${input_path_1} \
        -input ${input_path_2} \
        -output ${output_path_day} \
        -file ${common_utils_dir}/py_utils/cut_index.py \
        -mapper "python/bin/python cut_index.py ${map_task_name} ${thd} ${print_flag} ${quota}" \
        -reducer "python/bin/python cut_index.py xbox_index_uniq" \
        -jobconf mapred.job.priority="VERY_HIGH" \
        -jobconf mapred.job.map.capacity=500 \
        -jobconf mapred.job.reduce.capacity=1000 \
        -jobconf mapred.job.tasks=1000 \
        -jobconf mapred.reduce.tasks=1024 \
        -cacheArchive ${shaolin_py_env}#python \
        -jobconf mapred.max.reduce.failures.percent=1

    if [ $? -eq 0 ]; then
        record_done_file ${HADOOP} ${output_path_day} ${output_path}/done_file .${map_task_name}_base_done_file
        clear_hadoop_data ${yinglong_bin} ${output_path} 3
    else
        echo "${FUNCNAME} ${map_task_name} failed! please check!"
        exit -1
    fi
}

function produce_base_index() {
    local day=$1
    local title_index_input=$2
    local unit_index_input=$3
    local output_path=$4
    local map_task_name=$5
    local thd=$6
    local print_flag=$7
    local quota=$8
    cut_xbox_index ${day} ${title_index_input} ${unit_index_input} ${output_path} ${map_task_name} ${thd} ${print_flag} ${quota}
}

function produce_thd_cut_index() {
    local day=$1
    local title_index_input=$2
    local unit_index_input=$3
    local output_path=$4
    local map_task_name=$5
    local thd=$6
    local print_flag=$7
    local quota=$8
    cut_xbox_index ${day} ${title_index_input} ${unit_index_input} ${output_path} ${map_task_name} ${thd} ${print_flag} ${quota}
}

function produce_variety_index() {
    local day=$1
    local title_index_input=$2
    local unit_index_input=$3
    local output_path=$4
    local map_task_name=$5
    local thd=$6
    local print_flag=$7
    local quota=$8
    cut_xbox_index ${day} ${title_index_input} ${unit_index_input} ${output_path} ${map_task_name} ${thd} ${print_flag} ${quota}
}

function merge_xbox_index_two_way() {
    local input_path_1=$1
    local input_path_2=$2
    local output_path=$3
    local quota=$4
    local is_title_merge=$5
    local py_script_name=$6
    echo $input_path_1
    echo $input_path_2
    echo $output_path
    local adv_path=`tail -1 ${base_adv_dir}/done_file`
    HADOOP=${wuge_bin}
    input_path_1=`${HADOOP} fs -cat ${input_path_1}/done_file|tail -1`
    input_path_2=`${HADOOP} fs -cat ${input_path_2}/done_file|tail -1`

    ${HADOOP} fs -test -e ${output_path}
    if [ $? -ne 0 ]; then
        ${HADOOP} fs -mkdir ${output_path}
        ${HADOOP} fs -touchz ${output_path}/done_file
    fi

    output_path_day=${output_path}/${day}${hour}
    ${HADOOP} fs -rmr ${output_path_day}
    $HADOOP streaming \
        -jobconf mapred.job.name=${FUNCNAME}_${day} \
        -input ${input_path_1} \
        -input ${input_path_2} \
        -output ${output_path_day} \
        -file ${common_utils_dir}/py_utils/${py_script_name} \
        -file ${adv_path}/all_adv \
        -mapper 'cat' \
        -reducer "python/bin/python ${py_script_name} reduce all_adv ${quota} ${is_title_merge}"  \
        -jobconf mapred.job.priority=VERY_HIGH \
        -jobconf mapred.job.map.capacity=500 \
        -jobconf mapred.job.reduce.capacity=1000 \
        -jobconf mapred.job.tasks=1000 \
        -jobconf mapred.reduce.tasks=1024 \
        -cacheArchive ${shaolin_py_env}#python \
        -jobconf mapred.max.reduce.failures.percent=1

    if [ $? -eq 0 ]; then
        record_done_file ${HADOOP} ${output_path_day} ${output_path}/done_file ${log_dir}/.merge_index_done_file
        clear_hadoop_data ${yinglong_bin} ${output_path} 60
    else
        echo "${FUNCNAME} failed! please check!"
        exit -1
    fi
}

function merge_xbox_index_with_existed_adv() {
    local input_path_1=$1
    local output_path=$2
    local quota=$3
    local is_title_merge=$4
    local py_script_name=$5
    query_merge_xbox ${input_path_1} ${existed_query2ad_prefix_path} ${output_path} ${quota} ${is_title_merge} ${py_script_name}
}

function gen_ernie_emb() {
    HADOOP=${wuge_bin}
    local input_path_1=$1
    # input_path_1=`${HADOOP} fs -cat ${input_path_1}/done_file|tail -1`
    local output_path=$2
    $HADOOP dfs -rmr ${output_path}
    $HADOOP streaming \
        -jobconf mapred.job.name=chenyunan_at_${FUNCNAME}_${day} \
        -jobconf stream.memory.limit=7000 \
        -input ${input_path_1} \
        -output ${output_path} \
        -mapper "sh predict.sh sk_task_map" \
        -reducer "sh predict.sh reduce" \
        -jobconf mapred.job.priority="VERY_HIGH" \
        -jobconf mapred.job.map.capacity=500 \
        -jobconf mapred.job.reduce.capacity=1000 \
        -jobconf mapred.job.tasks=1000 \
        -jobconf mapred.reduce.tasks=512 \
        -jobconf mapred.max.reduce.failures.percent=1 \
        -cacheArchive ${shaolin_prefix}/user/nad-offline/chenyunan/tools/old_ernie_model.tar.gz \
        -cacheArchive ${shaolin_prefix}/user/nad-offline/chenyunan/tools/package.tar.gz \
        -cacheArchive ${shaolin_prefix}/user/nad-offline/chenyunan/tools/torch_package.tar.gz

    if [ $? -ne 0 ];then
        echo "${FUNCNAME} failed! please check!"
        exit -1
    fi
        # -file ${SRC_PATH}/predict.py \
        # -file ${SRC_PATH}/predict.sh \
        # -file ${SRC_PATH}/modeling.py \
        # -file ${SRC_PATH}/bert_config.json \
        # -file ${SRC_PATH}/pytorch_model.bin \
        # -file ${SRC_PATH}/vocab.txt \
        # -file ${SRC_PATH}/tokenization.py \
}


function generate_two_end_adv_index() {
    local input_path_1=$1
    local output_path=$2
    local adv_file=$3
    local adv_file_path=$4
    local quota=$5
    local tag=$6
    HADOOP=${yinglong_bin}

    ${HADOOP} fs -rmr ${output_path}/${day}
    ${HADOOP} streaming \
        -jobconf mapred.job.name=${FUNCNAME} \
        -jobconf mapred.job.priority=VERY_HIGH \
        -jobconf mapred.job.map.capacity=1024 \
        -jobconf mapred.reduce.tasks=0 \
        -jobconf mapred.job.reduce.capacity=1024 \
        -jobconf stream.memory.limit=8000 \
        -file ${common_utils_dir}/py_utils/make_end_expand_index.py \
        -mapper "python/bin/python make_end_expand_index.py make_index ${adv_file} ${quota} ${tag}" \
        -reducer "cat" \
        -input ${input_path_1} \
        -output ${output_path}/${day} \
        -file ${common_utils_dir}/py_utils/make_end_expand_index.py \
        -file ${adv_file_path} \
        -cacheArchive /app/ecom/fcr/share/python2.7.tar.gz#python

    if [ $? -ne 0 ];then
        echo "${FUNCNAME} run failed! please check!"
        exit -1
    else
        record_done_file ${yinglong_bin} ${output_path}/${day} ${output_path}/done_file .two_end_ext_done_file
        clear_hadoop_data ${yinglong_bin} ${output_path} 10
    fi
}

function gen_ocpc_adv_index() {
    local adv_file=$1
    local adv_path_prefix=$2
    local input_path_1=$3
    local output_path=$4
    local ann_thd=$5
    local index_tag=$6
    local print_sign_flag=$7
    local quota=$8
    HADOOP=${yinglong_bin}
    local adv_path_prefix=`tail -1 ${adv_path_prefix}/done_file`

    ${HADOOP} fs -rmr ${output_path}
    ${HADOOP} streaming \
        -jobconf mapred.job.name=${FUNCNAME}_${day} \
        -jobconf mapred.map.capacity.per.tasktracker=4 \
        -jobconf mapred.reduce.capacity.per.tasktracker=4 \
        -jobconf mapred.max.map.failures.percent=1 \
        -jobconf mapred.max.reduce.failures.percent=1 \
        -jobconf mapred.job.priority=VERY_HIGH \
        -jobconf mapred.job.map.capacity=1024 \
        -jobconf mapred.reduce.tasks=1024 \
        -jobconf mapred.job.reduce.capacity=1024 \
        -jobconf stream.memory.limit=10000 \
        -jobconf mapred.reduce.slowstart.completed.maps=0.99 \
        -mapper 'cat' \
        -reducer "python/bin/python gen_ocpc_adv_index.py reduce ${ann_thd} ${index_tag} ${print_sign_flag} ${adv_file} ${quota}" \
        -input ${input_path_1} \
        -output ${output_path} \
        -file ${common_utils_dir}/py_utils/gen_ocpc_adv_index.py \
        -file ${adv_path_prefix}/${adv_file} \
        -cacheArchive ${shaolin_py_env}#python

    if [ $? -ne 0 ];then
        echo "${FUNCNAME} fail! please check!"
        exit -1
    fi
}

function query_merge_xbox() {
    local input_path_1=$1
    local input_path_2=$2
    local output_path=$3
    local quota=$4
    local is_title_merge=$5
    echo $input_path_1
    echo $input_path_2
    echo $output_path
    local adv_path=`tail -1 ${base_adv_dir}/done_file`
    HADOOP=${yinglong_bin}
    input_path_1=`${HADOOP} fs -cat ${input_path_1}/done_file|tail -1`
    input_path_2=`${HADOOP} fs -cat ${input_path_2}/done_file|tail -1`

    ${HADOOP} fs -test -e ${output_path}
    if [ $? -ne 0 ]; then
        ${HADOOP} fs -mkdir ${output_path}
        ${HADOOP} fs -touchz ${output_path}/done_file
    fi

    output_path_day=${output_path}/${day}${hour}
    ${HADOOP} fs -rmr ${output_path_day}
    $HADOOP streaming \
        -jobconf mapred.job.name=${FUNCNAME}_${day} \
        -input ${input_path_1} \
        -input ${input_path_2} \
        -output ${output_path_day} \
        -file ${common_utils_dir}/py_utils/query_merge_xbox.py \
        -file ${adv_path}/all_adv \
        -mapper 'python/bin/python query_merge_xbox.py map' \
        -reducer "python/bin/python query_merge_xbox.py reduce all_adv ${quota} ${is_title_merge}"  \
        -jobconf mapred.job.priority=VERY_HIGH \
        -jobconf mapred.job.map.capacity=500 \
        -jobconf mapred.job.reduce.capacity=1000 \
        -jobconf mapred.job.tasks=1000 \
        -jobconf mapred.reduce.tasks=1024 \
        -cacheArchive /app/ecom/fcr/chenyunan/Python-2.7.5.tar.gz#python \
        -jobconf mapred.max.reduce.failures.percent=1

    if [ $? -eq 0 ]; then
        record_done_file ${HADOOP} ${output_path_day} ${output_path}/done_file .merge_index_done_file
        clear_hadoop_data ${yinglong_bin} ${output_path} 10
    else
        echo "${FUNCNAME} failed! please check!"
        exit -1
    fi
}

function priority_merge() {
    local input_path_1=$1
    local input_path_2=$2
    local output_path=$3
    local quota=$4
    local is_title_merge=$5
    local path_name=$6
    echo $input_path_1
    echo $input_path_2
    echo $output_path
    echo $path_name
    local adv_path=`tail -1 ${base_adv_dir}/done_file`
    HADOOP=${wuge_bin}
    input_path_1=`${HADOOP} fs -cat ${input_path_1}/done_file|tail -1`
    input_path_2=`${HADOOP} fs -cat ${input_path_2}/done_file|tail -1`

    ${HADOOP} fs -test -e ${output_path}
    if [ $? -ne 0 ]; then
        ${HADOOP} fs -mkdir ${output_path}
        ${HADOOP} fs -touchz ${output_path}/done_file
    fi

    output_path_day=${output_path}/${day}${hour}
    ${HADOOP} fs -rmr ${output_path_day}
    $HADOOP streaming \
        -jobconf mapred.job.name=chenyunan_${FUNCNAME}_${day} \
        -input ${input_path_1} \
        -input ${input_path_2} \
        -output ${output_path_day} \
        -file ${common_utils_dir}/py_utils/priority_merge.py \
        -file ${adv_path}/all_adv \
        -mapper "python/bin/python priority_merge.py map ${path_name}" \
        -reducer "python/bin/python priority_merge.py reduce all_adv ${quota} ${is_title_merge}"  \
        -jobconf mapred.job.priority=VERY_HIGH \
        -jobconf mapred.job.map.capacity=500 \
        -jobconf mapred.job.reduce.capacity=1000 \
        -jobconf mapred.job.tasks=1000 \
        -jobconf mapred.reduce.tasks=1024 \
        -cacheArchive ${shaolin_py_env}#python \
        -jobconf mapred.max.reduce.failures.percent=1

    if [ $? -eq 0 ]; then
        record_done_file ${HADOOP} ${output_path_day} ${output_path}/done_file ${log_dir}/.merge_index_done_file
        clear_hadoop_data ${yinglong_bin} ${output_path} 4
    else
        echo "${FUNCNAME} failed! please check!"
        exit -1
    fi
}


function group_word_vec() {
    local input_path_1=$1
    local output_path=$2
    local shitu_day=$3
    local task_name=$4
    HADOOP=${yinglong_bin}

    output_path_day=${output_path}/${shitu_day}
    ${HADOOP} fs -rmr ${output_path_day}
    $HADOOP streaming \
        -jobconf mapred.job.name=${FUNCNAME}_${task_name}_${day} \
        -input ${input_path_1} \
        -output ${output_path_day} \
        -mapper 'sh reshape.sh' \
        -reducer "python/bin/python group_word_vec.py reduce"  \
        -jobconf mapred.job.priority=VERY_HIGH \
        -jobconf mapred.job.map.capacity=500 \
        -jobconf mapred.job.reduce.capacity=1000 \
        -jobconf mapred.job.tasks=1000 \
        -jobconf mapred.reduce.tasks=1024 \
        -cacheArchive ${shaolin_py_env}#python \
        -file ${common_utils_dir}/reshape.sh \
        -file ${common_utils_dir}/py_utils/group_word_vec.py \
        -jobconf mapred.max.reduce.failures.percent=1

    if [ $? -eq 0 ]; then
        record_done_file ${HADOOP} ${output_path_day} ${output_path}/done_file ${log_dir}/.${task_name}_done_file
        clear_hadoop_data ${yinglong_bin} ${output_path} 4
    else
        echo "${FUNCNAME} failed! please check!"
        exit -1
    fi
}

function flat_query_adv() {
    HADOOP=${wuge_bin}
    local seed_query_adv_index=$1
    local input_path_1=`${HADOOP} fs -cat ${seed_query_adv_index}/done_file|tail -1`
    local input_path_2=$2
    local output_path=$3

    ${HADOOP} fs -rmr ${output_path}
    ${HADOOP} streaming \
        -jobconf mapred.job.name=${FUNCNAME} \
        -jobconf mapred.job.priority=VERY_HIGH \
        -jobconf mapred.job.map.capacity=1024 \
        -jobconf mapred.reduce.tasks=1024 \
        -jobconf mapred.job.reduce.capacity=1024 \
        -partitioner org.apache.hadoop.mapred.lib.KeyFieldBasedPartitioner \
        -jobconf mapred.output.key.comparator.class=org.apache.hadoop.mapred.lib.KeyFieldBasedComparator \
        -mapper "python/bin/python hadoop_query_join_adv.py map" \
        -reducer "python/bin/python hadoop_query_join_adv.py reduce" \
        -input ${input_path_1} \
        -input ${input_path_2} \
        -output ${output_path} \
        -cacheArchive ${shaolin_py_env}#python \
        -jobconf num.key.fields.for.partition=1 \
        -jobconf stream.num.map.output.key.fields=1 \
        -jobconf mapred.textoutputformat.ignoreseparator=true \
        -jobconf mapred.output.compress=false \
        -file ${common_utils_dir}/py_utils/hadoop_query_join_adv.py \
        -jobconf mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec

    if [ $? -ne 0 ];then
        echo "${FUNCNAME} run failed! please check!"
        exit -1
    fi
}

function query_join_adv() {
    local input_path_1=$1
    local input_path_2=$2
    local output_path=$3
    local adv_file=$4
    local adv_file_path=$5
    local index_tag=$6
    HADOOP=${yinglong_bin}

    ${HADOOP} fs -rmr ${output_path}
    ${HADOOP} streaming \
        -jobconf mapred.job.name=${FUNCNAME} \
        -jobconf mapred.job.priority=VERY_HIGH \
        -jobconf mapred.job.map.capacity=1024 \
        -jobconf mapred.reduce.tasks=2048 \
        -jobconf mapred.job.reduce.capacity=2048 \
        -jobconf stream.memory.limit=8000 \
        -mapper 'cat' \
        -reducer "python/bin/python hadoop_query_join_adv.py groupby_query ${adv_file} ${index_tag}" \
        -input ${input_path_1} \
        -input ${input_path_2} \
        -output ${output_path} \
        -cacheArchive ${shaolin_py_env}#python \
        -file ${common_utils_dir}/py_utils/hadoop_query_join_adv.py \
        -file ${adv_file_path}

    if [ $? -ne 0 ];then
        echo "${FUNCNAME} run failed! please check!"
        exit -1
    fi
}

function retrieve_seed_query() {
    day=$1
    vecfile=$2
    vecfile_path=$3
    local index_path=$4
    local output_path=$5
    local retr_thd=$6
    local retr_num=$7
    local vec_dim=$8
    retrieve_adv_specify_file ${day} ${vecfile} ${vecfile_path} ${index_path} ${output_path} ${retr_thd} ${retr_num} ${vec_dim}
}

function cpm_sort_index() {
    local adv_file=$1
    local adv_path_prefix=$2
    local input_path_1=$3
    local output_path=$4
    local ann_thd=$5
    local index_tag=$6
    local print_sign_flag=$7
    local cpm_file=$8
    local cpm_file_prefix=$9
    HADOOP=${yinglong_bin}
    local adv_path_prefix=`tail -1 ${adv_path_prefix}/done_file`
    local cpm_file_prefix=`tail -1 ${cpm_file_prefix}/done_file`

    ${HADOOP} fs -rmr ${output_path}
    ${HADOOP} streaming \
        -jobconf mapred.job.name=${FUNCNAME}_${day} \
        -jobconf mapred.map.capacity.per.tasktracker=4 \
        -jobconf mapred.reduce.capacity.per.tasktracker=4 \
        -jobconf mapred.max.map.failures.percent=1 \
        -jobconf mapred.max.reduce.failures.percent=1 \
        -jobconf mapred.job.priority=VERY_HIGH \
        -jobconf mapred.job.map.capacity=1024 \
        -jobconf mapred.reduce.tasks=1024 \
        -jobconf mapred.job.reduce.capacity=1024 \
        -jobconf stream.memory.limit=8000 \
        -jobconf mapred.reduce.slowstart.completed.maps=0.99 \
        -mapper 'cat' \
        -reducer "python/bin/python cpm_sort_xbox_index.py reduce ${ann_thd} ${index_tag} ${print_sign_flag} ${adv_file} ${cpm_file}" \
        -input ${input_path_1} \
        -output ${output_path} \
        -file ${common_utils_dir}/py_utils/cpm_sort_xbox_index.py \
        -file ${adv_path_prefix}/${adv_file} \
        -file ${cpm_file_prefix}/${cpm_file} \
        -cacheArchive /app/ecom/fcr/chenyunan/Python-2.7.5.tar.gz#python

    if [ $? -ne 0 ];then
        echo "${FUNCNAME} fail! please check!"
        exit -1
    fi
}

function gen_small_ernie_emb() {
    HADOOP=${wuge_bin}
    local input_path_1=$1
    local output_path=$2
    $HADOOP dfs -rmr ${output_path}
    $HADOOP streaming \
        -jobconf mapred.job.name=chenyunan_at_${FUNCNAME}_${day} \
        -jobconf stream.memory.limit=7000 \
        -input ${input_path_1} \
        -output ${output_path} \
        -mapper "sh predict.sh sk_task_map" \
        -reducer "sh predict.sh reduce" \
        -jobconf mapred.job.priority="VERY_HIGH" \
        -jobconf mapred.job.map.capacity=500 \
        -jobconf mapred.job.reduce.capacity=1000 \
        -jobconf mapred.job.tasks=1000 \
        -jobconf mapred.reduce.tasks=512 \
        -jobconf mapred.max.reduce.failures.percent=1 \
        -cacheArchive ${shaolin_prefix}/user/nad-offline/chenyunan/tools/se_ernie_model.tar.gz \
        -cacheArchive ${shaolin_prefix}/user/nad-offline/chenyunan/tools/gcc482_package.tar.gz \
        -cacheArchive ${shaolin_prefix}/user/nad-offline/chenyunan/tools/python36.tar.gz

    if [ $? -ne 0 ];then
        echo "${FUNCNAME} failed! please check!"
        exit -1
    fi
}

function process_bes_index() {
    local adv_file=$1
    local adv_path_prefix=$2
    local input_path_1=$3
    local input_path_2=$4
    local output_path=$5
    local map_task_name=$6
    local index_tag=$7
    HADOOP=${yinglong_bin}
    local adv_path_prefix=`tail -1 ${adv_path_prefix}/done_file`

    ${HADOOP} fs -rmr ${output_path}
    ${HADOOP} streaming \
        -jobconf mapred.job.name=${FUNCNAME}_${day} \
        -jobconf mapred.map.capacity.per.tasktracker=4 \
        -jobconf mapred.reduce.capacity.per.tasktracker=4 \
        -jobconf mapred.max.map.failures.percent=1 \
        -jobconf mapred.max.reduce.failures.percent=1 \
        -jobconf mapred.job.priority=VERY_HIGH \
        -jobconf mapred.job.map.capacity=1024 \
        -jobconf mapred.reduce.tasks=0 \
        -jobconf mapred.job.reduce.capacity=1024 \
        -jobconf stream.memory.limit=8000 \
        -jobconf mapred.reduce.slowstart.completed.maps=0.99 \
        -mapper "python/bin/python post_process_index.py ${map_task_name} ${adv_file} ${index_tag}" \
        -reducer "cat" \
        -input ${input_path_1} \
        -input ${input_path_2} \
        -output ${output_path} \
        -file ${common_utils_dir}/py_utils/post_process_index.py \
        -file ${adv_path_prefix}/${adv_file} \
        -cacheArchive /app/ecom/fcr/chenyunan/Python-2.7.5.tar.gz#python

    if [ $? -ne 0 ];then
        echo "${FUNCNAME} fail! please check!"
        exit -1
    fi
}

function xbox_full_index() {
    local adv_file=$1
    local adv_path_prefix=$2
    local input_path_1=$3
    local output_path=$4
    local ann_thd=$5
    local index_tag=$6
    local print_sign_flag=$7
    local script_file=$8
    HADOOP=${yinglong_bin}
    local adv_path_prefix=`tail -1 ${adv_path_prefix}/done_file`

    ${HADOOP} fs -rmr ${output_path}
    ${HADOOP} streaming \
        -jobconf mapred.job.name=${FUNCNAME}_${day} \
        -jobconf mapred.map.capacity.per.tasktracker=4 \
        -jobconf mapred.reduce.capacity.per.tasktracker=4 \
        -jobconf mapred.max.map.failures.percent=1 \
        -jobconf mapred.max.reduce.failures.percent=1 \
        -jobconf mapred.job.priority=VERY_HIGH \
        -jobconf mapred.job.map.capacity=1024 \
        -jobconf mapred.reduce.tasks=1024 \
        -jobconf mapred.job.reduce.capacity=1024 \
        -jobconf stream.memory.limit=9000 \
        -jobconf mapred.reduce.slowstart.completed.maps=0.99 \
        -mapper 'cat' \
        -reducer "python/bin/python ${script_file} reduce ${ann_thd} ${index_tag} ${print_sign_flag} ${adv_file}" \
        -input ${input_path_1} \
        -output ${output_path} \
        -file ${common_utils_dir}/py_utils/${script_file} \
        -file ${adv_path_prefix}/${adv_file} \
        -cacheArchive ${khan_prefix}/app/ecom/fcr/share/python2.7.tar.gz#python

    if [ $? -ne 0 ];then
        echo "${FUNCNAME} fail! please check!"
        exit -1
    fi
}

function merge_xbox_index_triplet() {
    local input_path_1=$1
    local input_path_2=$2
    local input_path_3=$3
    local output_path=$4
    local quota=$5
    local is_title_merge=$6
    local py_script_name=$7
    local index_have_score=$8
    echo $input_path_1
    echo $input_path_2
    echo $input_path_3
    echo $output_path
    local adv_path=`tail -1 ${base_adv_dir}/done_file`
    HADOOP=${yinglong_bin}
    input_path_1=`${HADOOP} fs -cat ${input_path_1}/done_file|tail -1`
    input_path_2=`${HADOOP} fs -cat ${input_path_2}/done_file|tail -1`
    input_path_3=`${HADOOP} fs -cat ${input_path_3}/done_file|tail -1`

    ${HADOOP} fs -rmr ${output_path}
    $HADOOP streaming \
        -jobconf mapred.job.name=${FUNCNAME}_${day} \
        -input ${input_path_1} \
        -input ${input_path_2} \
        -input ${input_path_3} \
        -output ${output_path} \
        -file ${common_utils_dir}/py_utils/${py_script_name} \
        -file ${adv_path}/all_adv \
        -mapper 'cat' \
        -reducer "python/bin/python ${py_script_name} reduce all_adv ${quota} ${is_title_merge} ${index_have_score}" \
        -jobconf mapred.job.priority=VERY_HIGH \
        -jobconf mapred.job.map.capacity=500 \
        -jobconf mapred.job.reduce.capacity=1000 \
        -jobconf mapred.job.tasks=1000 \
        -jobconf mapred.reduce.tasks=1024 \
        -cacheArchive /app/ecom/fcr/chenyunan/Python-2.7.5.tar.gz#python \
        -jobconf mapred.max.reduce.failures.percent=1

    if [ $? -eq 0 ]; then
        echo "${FUNCNAME} run successfully!"
        exit 0
    else
        echo "${FUNCNAME} failed! please check!"
        exit -1
    fi
}

function haokan_mingtou() {
    local input_path_1=$1
    local input_path_2=$2
    local input_path_3=$3
    local output_path=$4
    local index_have_score=$5
    local shoubai_tag=$6
    local haokan_tag=$7
    local quota=$8
    local ann_thd=$9
    local adv_file=${10}
    local adv_path=`tail -1 ${11}/done_file`
    echo $*
    HADOOP=${yinglong_bin}

    ${HADOOP} fs -rmr ${output_path}
    $HADOOP streaming \
        -jobconf mapred.job.name=${FUNCNAME}_${day} \
        -input ${input_path_1} \
        -input ${input_path_2} \
        -input ${input_path_3} \
        -output ${output_path} \
        -file ${common_utils_dir}/py_utils/haokan_mingtou.py \
        -file ${adv_path}/${adv_file} \
        -mapper "python/bin/python haokan_mingtou.py mapper" \
        -reducer "python/bin/python haokan_mingtou.py reducer ${index_have_score} ${adv_file} ${shoubai_tag} ${haokan_tag} ${quota} ${ann_thd}" \
        -jobconf mapred.job.priority=VERY_HIGH \
        -jobconf mapred.job.map.capacity=500 \
        -jobconf mapred.job.reduce.capacity=1000 \
        -jobconf mapred.job.tasks=1000 \
        -jobconf mapred.reduce.tasks=1024 \
        -cacheArchive /app/ecom/fcr/chenyunan/Python-2.7.5.tar.gz#python \
        -jobconf mapred.max.reduce.failures.percent=1

    if [ $? -eq 0 ]; then
        echo "${FUNCNAME} run successfully!"
    else
        echo "${FUNCNAME} failed! please check!"
        exit -1
    fi
}

function make_adv_variety() {
    local input_path_1=$1
    local input_path_2=$2
    local output_path=$3
    local quota=$4
    local is_title_merge=$5
    local index_have_score=$6
    local ann_thd=$7
    local index_tag=$8
    local adv_path=`tail -1 ${base_adv_dir}/done_file`
    echo $adv_path
    echo $*
    HADOOP=${yinglong_bin}
    ${HADOOP} fs -rmr ${output_path}
    $HADOOP streaming \
        -jobconf mapred.job.name=${FUNCNAME}_${day} \
        -input ${input_path_1} \
        -input ${input_path_2} \
        -output ${output_path} \
        -file ${common_utils_dir}/py_utils/merge_xbox_index_no_limit.py \
        -file ${adv_path}/all_adv \
        -mapper "python/bin/python merge_xbox_index_no_limit.py mapper" \
        -reducer "python/bin/python merge_xbox_index_no_limit.py reducer all_adv ${quota} ${is_title_merge} ${index_have_score} ${ann_thd} ${index_tag}" \
        -jobconf mapred.job.priority=VERY_HIGH \
        -jobconf mapred.job.map.capacity=500 \
        -jobconf mapred.job.reduce.capacity=1000 \
        -jobconf mapred.job.tasks=1000 \
        -jobconf mapred.reduce.tasks=1024 \
        -cacheArchive /app/ecom/fcr/chenyunan/Python-2.7.5.tar.gz#python \
        -jobconf mapred.max.reduce.failures.percent=1

    if [ $? -eq 0 ]; then
        echo "${FUNCNAME} run successfully!"
    else
        echo "${FUNCNAME} failed! please check!"
        exit -1
    fi
}

function parallel_run_wait() {
    echo "wait parallel running function plugins!"
    wait
    echo "parallel running function plugins runs successfully!"
}

function cut_raw_index() {
    local day=$1
    local input_path_1=$2
    local input_path_2=$3
    local output_path=$4
    local map_task_name=$5
    local print_flag=$6
    local quota=$7
    echo $*
    HADOOP=${yinglong_bin}

    ${HADOOP} fs -test -e ${output_path}
    if [ $? -ne 0 ]; then
        ${HADOOP} fs -mkdir ${output_path}
        ${HADOOP} fs -touchz ${output_path}/done_file
    fi
    output_path_day=${output_path}/${day}
    ${HADOOP} fs -rmr ${output_path_day}
    $HADOOP streaming \
        -jobconf mapred.job.name=${FUNCNAME}_${day} \
        -input ${input_path_1} \
        -input ${input_path_2} \
        -output ${output_path_day} \
        -file ${common_utils_dir}/py_utils/cut_index.py \
        -mapper "python/bin/python cut_index.py ${map_task_name} ${print_flag} ${quota}" \
        -reducer "python/bin/python cut_index.py xbox_index_uniq" \
        -jobconf mapred.job.priority="VERY_HIGH" \
        -jobconf mapred.job.map.capacity=500 \
        -jobconf mapred.job.reduce.capacity=1000 \
        -jobconf mapred.job.tasks=1000 \
        -jobconf mapred.reduce.tasks=1024 \
        -cacheArchive /app/ecom/fcr/chenyunan/Python-2.7.5.tar.gz#python \
        -jobconf mapred.max.reduce.failures.percent=1

    if [ $? -eq 0 ]; then
        record_done_file ${HADOOP} ${output_path_day} ${output_path}/done_file .${map_task_name}_base_done_file
        clear_hadoop_data ${yinglong_bin} ${output_path} 3
    else
        echo "${FUNCNAME} ${map_task_name} failed! please check!"
        exit -1
    fi
}

function group_multi_source_data() {
    HADOOP=${wuge_bin}
    input_path_1=$1
    output_path=$2
    ${HADOOP} fs -rmr ${output_path}
    $HADOOP streaming \
        -jobconf mapred.job.name=chenyunan_at_${FUNCNAME}_${day} \
        -input ${input_path_1} \
        -output ${output_path} \
        -file ${common_utils_dir}/py_utils/group_multi_source_data.py \
        -mapper "python/bin/python group_multi_source_data.py map" \
        -reducer "python/bin/python group_multi_source_data.py reduce" \
        -jobconf mapred.job.priority="VERY_HIGH" \
        -jobconf mapred.job.map.capacity=500 \
        -jobconf mapred.job.reduce.capacity=1000 \
        -jobconf mapred.job.tasks=1000 \
        -jobconf mapred.reduce.tasks=1024 \
        -cacheArchive ${shaolin_py_env}#python \
        -jobconf mapred.max.reduce.failures.percent=1

    if [ $? -ne 0 ];then
        echo "group_multiday_data failed! please check group_multiday_data!"
        exit -1
    fi
}

function index_convert() {
    local input_path_1=$1
    local output_path=$2
    echo $*
    HADOOP=${yinglong_bin}

    ${HADOOP} fs -test -e ${output_path}
    if [ $? -ne 0 ]; then
        ${HADOOP} fs -mkdir ${output_path}
        ${HADOOP} fs -touchz ${output_path}/done_file
    fi
    output_path_day=${output_path}/${day}
    ${HADOOP} fs -rmr ${output_path_day}
    $HADOOP streaming \
        -jobconf mapred.job.name=${FUNCNAME}_${day} \
        -input ${input_path_1} \
        -output ${output_path_day} \
        -file ${common_utils_dir}/py_utils/index_convert.py \
        -mapper "python/bin/python index_convert.py q2ad_index_convert" \
        -reducer "cat" \
        -jobconf mapred.job.priority="VERY_HIGH" \
        -jobconf mapred.job.map.capacity=500 \
        -jobconf mapred.job.reduce.capacity=1000 \
        -jobconf mapred.job.tasks=1000 \
        -jobconf mapred.reduce.tasks=0 \
        -cacheArchive /app/ecom/fcr/chenyunan/Python-2.7.5.tar.gz#python \
        -jobconf mapred.max.reduce.failures.percent=1

    if [ $? -eq 0 ]; then
        record_done_file ${HADOOP} ${output_path_day} ${output_path}/done_file ${log_dir}/.index_convert_done_file
        clear_hadoop_data ${yinglong_bin} ${output_path} 3
    else
        echo "${FUNCNAME} ${map_task_name} failed! please check!"
        exit -1
    fi
}

function retrieve_adv_map()
{
    day=$1
    vecfile=$2
    vecfile_path=$3
    local input_path=$4
    local output_path=$5
    local retr_thd=$6
    local retr_num=$7
    local vec_len=$8
    echo $*
    HADOOP=${yinglong_bin}
    local vec_path_prefix=`tail -1 ${vecfile_path}/done_file`

    echo $input_path
    echo ${retr_thd}
    echo ${retr_num}
    echo ${vec_path_prefix}
    echo ${vecfile}
    ${HADOOP} fs -rmr ${output_path}
    ${HADOOP} streaming \
        -jobconf mapred.job.name=chenyunan_at_${FUNCNAME}_${day} \
        -jobconf mapred.job.priority=VERY_HIGH \
        -jobconf mapred.job.map.capacity=1024 \
        -jobconf mapred.job.reduce.capacity=1024 \
        -jobconf mapred.reduce.tasks=2048 \
        -jobconf stream.memory.limit=5000 \
        -file ${vec_path_prefix}/${vecfile} \
        -file ${common_utils_dir}/gen.sh \
        -file ${HOME}/ernie_model_qt/feedas_embcos_max \
        -mapper "sh gen.sh ${vecfile} ${vec_len} ${retr_thd} ${retr_num}"  \
        -reducer "cat" \
        -input ${input_path} \
        -output ${output_path}

    if [ $? -ne 0 ];then
        echo "${FUNCNAME} failed! please check!"
        exit 1
    else
        echo "${FUNCNAME} run successfully!"
    fi
}

function retrieve_adv_reduce()
{
    day=$1
    vecfile=$2
    vecfile_path=$3
    local input_path=$4
    local output_path=$5
    local retr_thd=$6
    local retr_num=$7
    local vec_len=$8
    echo $*
    HADOOP=${wuge_bin}
    local vec_path_prefix=`tail -1 ${vecfile_path}/done_file`

    echo $input_path
    echo ${retr_thd}
    echo ${retr_num}
    echo ${vec_path_prefix}
    echo ${vecfile}
    ${HADOOP} fs -rmr ${output_path}
    ${HADOOP} streaming \
        -jobconf mapred.job.name=chenyunan_at_${FUNCNAME}_${day} \
        -jobconf mapred.job.priority=VERY_HIGH \
        -jobconf mapred.job.map.capacity=1024 \
        -jobconf mapred.job.reduce.capacity=1024 \
        -jobconf mapred.reduce.tasks=1024 \
        -jobconf stream.memory.limit=8000 \
        -file ${vec_path_prefix}/${vecfile} \
        -file ${common_utils_dir}/gen.sh \
        -file ${common_utils_dir}/vec_strip.sh \
        -file ${HOME}/ernie_model_qt/feedas_embcos_max \
        -mapper 'sh vec_strip.sh' \
        -reducer "sh gen.sh ${vecfile} ${vec_len} ${retr_thd} ${retr_num}"  \
        -input ${input_path} \
        -output ${output_path}

    if [ $? -ne 0 ];then
        echo "${FUNCNAME} failed! please check!"
        exit 1
    else
        echo "${FUNCNAME} run successfully!"
    fi
}

function past_day_list()
{
    path=$1
    date_list=$2
    days=$3
    ${yinglong_bin} fs -ls ${path}|grep -v done_file | tail -$days | awk -F"/" '{print $NF}' > "$date_list"
    cnt=0
    cat "$date_list" | while read line
    do
        if [ $cnt -eq 0 ]; then
            past_day_str=$line
        else
            past_day_str=${past_day_str}",$line"
        fi
        let cnt++
        if [ "$cnt" -eq "$days" ]; then
            echo $past_day_str
        fi
    done
    rm -rf "$date_list"
    return 0
}

function retrieve_adv_specify_file()
{
    day=$1
    vecfile=$2
    vecfile_path=$3
    local LOCAL_INPUT1=$4
    local LOCAL_OUTPUT_PREFIX=$5
    local retr_thd=$6
    local retr_num=$7
    local vec_len=$8
    echo $*
    local LOCAL_OUTPUT=${LOCAL_OUTPUT_PREFIX}
    HADOOP=${yinglong_bin}

    echo ${retr_thd}
    echo ${retr_num}
    echo ${vecfile_path}
    echo ${vecfile}
    ${HADOOP} fs -rmr ${LOCAL_OUTPUT}
    ${HADOOP} streaming \
        -jobconf mapred.job.name=${FUNCNAME}_${day} \
        -jobconf mapred.job.priority=VERY_HIGH \
        -jobconf mapred.job.map.capacity=1024 \
        -jobconf mapred.reduce.tasks=1024 \
        -jobconf mapred.job.reduce.capacity=1024 \
        -file ${common_utils_dir}/gen.sh \
        -file ${common_utils_dir}/reshape.sh \
        -file ${HOME}/ernie_model_qt/feedas_embcos_max \
        -file ${vecfile_path} \
        -mapper 'sh reshape.sh' \
        -reducer "sh gen.sh ${vecfile} ${vec_len} ${retr_thd} ${retr_num}"  \
        -input ${LOCAL_INPUT1} \
        -output ${LOCAL_OUTPUT}

    if [ $? -ne 0 ];then
        echo "${FUNCNAME} failed! please check!"
        exit 1
    else
        echo "${FUNCNAME} run successfully!"
    fi
}


