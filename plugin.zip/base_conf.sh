#!/bin/bash
day=`date "+%Y%m%d"`
hour=`date "+%H"`
work_dir=`pwd`
log_dir="${work_dir}/log"

taihang_prefix="hdfs://nmg01-taihang-hdfs.dmop.baidu.com:54310"
khan_prefix="hdfs://nmg01-khan-hdfs.dmop.baidu.com:54310"
tianqi_prefix="afs://tianqi.afs.baidu.com:9902"
tianqi_personal_dir="afs://tianqi.afs.baidu.com:9902/app/ecom/native-ad/chenyunan"
yinglong_prefix="afs://yinglong.afs.baidu.com:9902"
shaolin_prefix="afs://shaolin.afs.baidu.com:9902"

common_utils_dir="${work_dir}/../common_utils"
common_data_dir="${work_dir}/../data"
base_adv_dir="${work_dir}/../data/base_adv"
moonlight_ad2ad="${work_dir}/../data/moonlight_ad2ad"
moonlight_local_new_ad2ad="${work_dir}/../data/moonlight_new_ad2ad"
conv_adv_dir="${work_dir}/../data/randne_adv"
idea_cpm_data_dir="${work_dir}/../data/idea_cpm_data_dir"
feed_query_sk_dir="${work_dir}/../data/feed_query_sk_dir"
ocpc_lab_adv_dir="${work_dir}/../data/ocpc_lab_adv"
adv_title_it_data_dir="${work_dir}/../data/adv_title_it"
khan_bin="/home/users/chenyunan/hadoop/hadoop-client_khan_fcr/hadoop/bin/hadoop"
kh_bin="/home/users/chenyunan/hadoop/hadoop-client_khan/hadoop/bin/hadoop"
turing_client="/home/users/chenyunan/hadoop/turing-client/hadoop/bin/hadoop"
wutai_bin="/home/users/chenyunan/hadoop/hadoop-client_wutai/hadoop/bin/hadoop"
wuge_bin="/home/chenyunan/hadoop/hadoop-client_wuge/hadoop/bin/hadoop"
wuge_bin_tmp="/home/chenyunan/hadoop/tmp/hadoop-client_wuge/hadoop/bin/hadoop"
tianqi_bin="/home/users/chenyunan/hadoop/hadoop-client_tianqi/hadoop/bin/hadoop"
yinglong_bin="/home/users/chenyunan/hadoop/hadoop-client_yinglong/hadoop/bin/hadoop"
tianqi_nad_ad_bin="/home/users/chenyunan/hadoop/hadoop-client_tianqi/hadoop/bin/hadoop --config /home/users/chenyunan/hadoop/hadoop-client_tianqi/hadoop/native_ad_conf/"
patianqi_bin="/home/users/chenyunan/hadoop/hadoop-client_tianqi/hadoop/bin/hadoop --config /home/users/chenyunan/hadoop/hadoop-client_tianqi/hadoop/pa_conf"
tianqi_at_project_path="${tianqi_prefix}/app/ecom/native-ad/chenyunan"
tianqi_python_tool=${tianqi_prefix}/app/ecom/native-ad/chenyunan/tools/Python-2.7.5.tar.gz
yinglong_py_env=${yinglong_prefix}/user/nad-offline/chenyunan/tools/Python-2.7.5.tar.gz
shaolin_py_env=${shaolin_prefix}/user/nad-offline/chenyunan/tools/Python-2.7.5.tar.gz
seg_env=${shaolin_prefix}/user/nad-offline/chenyunan/tools/seg_v8.tar.gz
q_t_seg_data=${shaolin_prefix}/user/nad-offline/chenyunan/tools/q_t_seg.tar.gz
new_q_t_seg_data=${shaolin_prefix}/user/nad-offline/chenyunan/tools/new_q_t_seg.tar.gz
a2a_q_t_seg_data=${shaolin_prefix}/user/nad-offline/chenyunan/tools/a2a_q_t_seg.tar.gz
random_q_t2t_seg_data=${shaolin_prefix}/user/nad-offline/chenyunan/tools/random_q_t2t_seg_data.tar.gz

hnsw_env=${shaolin_prefix}/user/nad-offline/chenyunan/tools/hnsw_retr.tar.gz
python27_hnsw_env=${shaolin_prefix}/user/nad-offline/chenyunan/tools/python27-gensim.tar

taihang_project_path="/app/ecom/native-ad/chenyun09/chenyunan/"
shaolin_project_path="/user/nad-offline/chenyunan/"

ocpc_fast_log=afs://tianqi.afs.baidu.com:9902/app/ecom/nativeads_data/output/ocpc_click_charge
ocpm_fast_log=afs://tianqi.afs.baidu.com:9902/app/ecom/nativeads_data/output/ocpm_eshow_charge

at_adv_dump_path=afs://yinglong.afs.baidu.com:9902/user/nad-offline/yaoyujin01/dump_at

dump_adv_path=${shaolin_prefix}/user/feed_search_online/feedbs_dump_file/
# =================================function================================
function record_done_file() {
    HADOOP=$1
    record_data_path=$2
    done_file_path=$3
    local_done_file_name=$4
    ${HADOOP} fs -test -e ${done_file_path}
    if [ $? -ne 0 ];then
        ${HADOOP} fs -touchz ${done_file_path}
    fi
    ${HADOOP} fs -cat $done_file_path > $local_done_file_name
    echo $record_data_path >> $local_done_file_name
    ${HADOOP} fs -touchz ${record_data_path}/to.hadoop.done
    ${HADOOP} fs -rm $done_file_path
    ${HADOOP} fs -put ${local_done_file_name} ${done_file_path}
    if [ $? -ne 0 ];then
        echo "record done file failed!"
        exit -1
    fi
}

function clear_hadoop_data() {
    HADOOP=$1
    monitor_hadoop_path=$2
    max_dir_num=$3
    cur_dir_num=`${HADOOP} fs -ls ${monitor_hadoop_path}|grep -v Found|grep -v done|wc -l`
    if [ ${cur_dir_num} -ge ${max_dir_num} ];then
        delete_dir_post_tag=`${HADOOP} fs -ls ${monitor_hadoop_path}|grep -v Found|grep -v done|head -1|awk -F"/" '{print $NF}'`
        ${HADOOP} fs -rmr ${monitor_hadoop_path}/${delete_dir_post_tag}
        echo "this time delete "${monitor_hadoop_path}/${delete_dir_post_tag}
    fi
}

function send_email() {
    content=$1
    python ${common_utils_dir}/py_utils/mail_sender.py ${content}
}

function change_xbox_done_file() {
    HADOOP=$1
    record_data_path_prefix=$2
    xbox_done_file=$3
    local_xbox_done_file=$4
    target_str=$5
    record_data_path=`${HADOOP} fs -cat ${record_data_path_prefix}/done_file|tail -1`
    xbox_data_size=`${HADOOP} fs -ls ${record_data_path}|awk 'BEGIN{size=0}{size+=$5}END{print size}'`
    if [ ${xbox_data_size} -eq 0 ];then
        echo "${record_data_path} xbox data size is 0, please check!"
        send_email "${record_data_path}_data_error_"${day}${hour}
        exit -1
    fi
    ${HADOOP} fs -cat ${xbox_done_file}|tail -1 > ${local_xbox_done_file}
    python ${common_utils_dir}/py_utils/change_xbox_done_file.py ${record_data_path} ${target_str} ${local_xbox_done_file}
    if [ $? -ne 0 ];then
        echo "change xbox done file fail"
        exit -1
    fi
    ${HADOOP} fs -rm ${xbox_done_file}
    ${HADOOP} fs -put ${local_xbox_done_file}_new ${xbox_done_file}
    if [ $? -ne 0 ];then
        echo "change xbox done file fail"
        exit -1
    fi
    echo "change xbox done file success"
}

function delete_dir() {
    dir_path=$1
    target_preifx=$2
    limit_num=$3
    file_num=`ls -l ${dir_path}|grep ${target_preifx}|wc -l`
    if [ ${file_num} -ge ${limit_num} ];then
        delete_file=`ls -l ${dir_path}|grep ${target_preifx}|head -1|awk '{print $NF}'`
        echo "this time delete ${dir_path}/${delete_file}"
        rm -rf ${dir_path}/${delete_file}
    fi
}

function check_hadoop_data() {
    HADOOP=$1
    record_data_path=$2
    hadoop_data_size=`${HADOOP} fs -ls ${record_data_path}|grep part|awk 'BEGIN{size=0}{size+=$5}END{print size}'`
    if [ ${hadoop_data_size} -eq 0 ];then
        echo "${record_data_path} hadoop data size is 0, please check!"
        send_email "${record_data_path}_data_error_"${day}${hour}
        exit -1
    fi
}

# =================================tools================================
PYTHON36=${shaolin_prefix}/user/nad-offline/chenyunan/tools/python36.tar#python36
PYTHON_URI=${shaolin_prefix}/user/nad-offline/chenyunan/tools/python27-gensim.tar#python27
MODEL_PATH=${shaolin_prefix}/user/nad-offline/chenyunan/tools/model_pred_interest_v2.tar.gz#interest_multi_label
GCC_PAKAGE=${shaolin_prefix}/user/nad-offline/chenyunan/tools/gcc482_package.tar#gcc482_package
SPA_PATH=${shaolin_prefix}/user/nad-offline/chenyunan/tools/wordrank_spa.tar.gz#wordrank_spa

# =================================adv================================
AUTOTARGET_AD_DONE_FILE="/home/users/chenyunan/autotarget_unit/done_file"
WORDRANK_DIR="/home/users/chenyunan/wordrank/"
PREDICT_INTEREST_V1_DIR="/home/users/chenyunan/model_pred_interest_v1/mains"

# =================================common path================================
hadoop_empty_dir=${shaolin_prefix}/user/nad-offline/chenyunan/hadoop_empty_dir

# =================================xbox donefile path================================
feed_query_target=${shaolin_prefix}/user/nad-offline/native-ad/gaoyongzhen/xbox/feed-query-target/donefile
pa_feed_kt_table=${shaolin_prefix}/user/nad-offline/at_xbox_done_file/xbox_base_done_file.txt
user2ad=${shaolin_prefix}/user/nad-offline/native-ad/gaoyongzhen/xbox/User2Ad/donefile
ann_exploit_query=${shaolin_prefix}/user/nad-offline/native-ad/gaoyongzhen/xbox/ann-exploit-query/donefile
kg_to_query=${shaolin_prefix}/user/nad-offline/native-ad/gaoyongzhen/xbox/kg-to-query/donefile
at_ocpclab=${shaolin_prefix}/user/nad-offline/chenyunan/xbox_done/gcn_cuid2ad/gcn_cuid2ad_done_file
cuid2unit=${shaolin_prefix}/user/nad-offline/chenyunan/xbox_done/cuid2unit/cuid2unit_done_file
huadie=${shaolin_prefix}/user/fcr-tianqi-d/yaoyujin01/xbox_donefile/game-tag-for-cuid2ad.donefile

# =================================graph init title query================================
graph_seed_data=${taihang_prefix}/app/ecom/native-ad/chenyun09/chenyunan/graph_extension/graph_seed_data
graph_seed_vec=${taihang_prefix}/app/ecom/native-ad/chenyun09/chenyunan/graph_extension/graph_seed_vec
seed_title_vec=${taihang_prefix}/app/ecom/native-ad/chenyun09/chenyunan/graph_extension/graph_seed_vec/seed_title_vec
seed_query_vec=${taihang_prefix}/app/ecom/native-ad/chenyun09/chenyunan/graph_extension/graph_seed_vec/seed_query_vec
seed_query_semantic_vec=${taihang_prefix}/app/ecom/native-ad/chenyun09/chenyunan/graph_extension/graph_seed_vec/seed_query_semantic_vec
seed_title_2_ad=${shaolin_prefix}/user/nad-offline/chenyunan/graph_extension/seed_title_2_ad
seed_query_2_ad=${taihang_prefix}/app/ecom/native-ad/chenyun09/chenyunan/graph_extension/seed_query_2_ad
conv_query_title=${taihang_prefix}/app/ecom/native-ad/chenyun09/chenyunan/graph_extension/conv_query_title
xbox_query_adv=${taihang_prefix}/app/ecom/native-ad/chenyun09/chenyunan/graph_extension/xbox_query_adv
graph_conv_query_2_title=${taihang_prefix}/app/ecom/native-ad/chenyun09/chenyunan/graph_extension/graph_conv_query_2_title
query_ann_pair=${taihang_prefix}/app/ecom/native-ad/chenyun09/chenyunan/graph_extension/query_ann_pair
final_query_2_title=${shaolin_prefix}/user/nad-offline/chenyunan/graph_extension/final_query_2_title
seed_query_adv_index=${shaolin_prefix}/user/nad-offline/chenyunan/graph_extension/seed_query_adv_index

seed_title_2_ocpc_lab=${taihang_prefix}/app/ecom/native-ad/chenyun09/chenyunan/graph_extension/seed_title_2_ocpc_lab
seed_query_ocpclab_index=${taihang_prefix}/app/ecom/native-ad/chenyun09/chenyunan/graph_extension/seed_query_ocpclab_index

# =================================ocpc lab adv================================
ocpc_lab_adv=${shaolin_prefix}/user/nad-offline/chenyun09/ads_with_ocpc_lab/ads_info
ocpc_lab_adv_vec=${shaolin_prefix}/user/nad-offline/chenyunan/ocpc_lab_index/ocpc_adv_vec

# =================================shitu data path================================
shitu_path=${taihang_prefix}/app/ecom/fcr/offline-shitu/cpc/
sk_word_dir=${shaolin_prefix}/${shaolin_project_path}/shitu_data/sk_word_dir
sk_word_se_dir=${taihang_prefix}/${taihang_project_path}/shitu_data/sk_word_se_dir
query_word_dir=${shaolin_prefix}/${shaolin_project_path}/shitu_data/query_word_dir
sk_word_vec=${shaolin_prefix}/${shaolin_project_path}/shitu_data/sk_word_vec
query_word_vec=${shaolin_prefix}/${shaolin_project_path}/shitu_data/query_word_vec
group_sk_vec=${shaolin_prefix}/${shaolin_project_path}/shitu_data/group_sk_vec
group_query_vec=${shaolin_prefix}/${shaolin_project_path}/shitu_data/group_query_vec
group_query_sk_vec=${taihang_prefix}/${taihang_project_path}/shitu_data/group_query_sk_vec

# =================================turing data path================================
idea_cpm_turing_path=userpath.get_skword
feed_query_sk_path=userpath.query_sk_word

# =================================turing data path================================
thread_title_path=${khan_prefix}/app/ecom/fcr/liuyanming/Eureka/thread_unit/threads/
thread_title_vec=${taihang_prefix}/${taihang_project_path}/shitu_data/title_vec

# =================================query2ad conv title path================================
q2ad_conv_title=${taihang_prefix}/app/ecom/native-ad/chenyun09/q2ads/1/xbox/

# =================================all adv emb================================
AUTOTARGET_AD_DONE_FILE=${HOME}/autotarget_unit/done_file
AUTOTARGET_AD_PATH=${HOME}/autotarget_unit/dump_data
small_ernie_path=${HOME}/small_ernie
adv_title_hadoop=${shaolin_prefix}/${shaolin_project_path}/adv_data/all_feed_adv/adv_title_hadoop
adv_title_se_emb=${taihang_prefix}/${taihang_project_path}/adv_data/all_feed_adv/adv_title_se_vec
adv_title_emb=${shaolin_prefix}/${shaolin_project_path}/adv_title_emb
adv_title_se_emb=${shaolin_prefix}/${shaolin_project_path}/adv_title_se_emb
unit_title_emb=${taihang_prefix}/${taihang_project_path}/unit_title_emb
thread_title_se_emb=${taihang_prefix}/${taihang_project_path}/thread_title_se_emb
thread_title_emb=${taihang_prefix}/${taihang_project_path}/thread_title_emb

# =================================at adv emb================================
feed_adv_path=${shaolin_prefix}/user/nad-offline/chenyunan/feed_adv
feed_adv_se_path=${shaolin_prefix}/user/nad-offline/chenyunan/feed_adv_se
title_emb_path=${shaolin_prefix}/user/nad-offline/chenyunan/shitu_thread_title_emb

cuid_eshow=${shaolin_prefix}/user/ark/ecom/common/dataflow/userpath/publish/10/08/65/cuid_eshow/

sk2q_path_done_file=${tianqi_prefix}/app/ecom/native-ad/yangying16/donefile/searchkeyword2query.donefile
sk_ext_query=${shaolin_prefix}/${shaolin_project_path}/shitu_data/sk_ext_query
sk_ext_query_vec=${shaolin_prefix}/${shaolin_project_path}/shitu_data/sk_ext_query_vec

moonlight_ad2ad_hadoop=${shaolin_prefix}/${shaolin_project_path}/moonlight_ad2ad
moonlight_new_ad2ad=${shaolin_prefix}/${shaolin_project_path}/moonlight_new_ad2ad
moonlight_ideavec=${shaolin_prefix}/${shaolin_project_path}/moonlight_ideavec
adv_idea_title_info=${shaolin_prefix}/${shaolin_project_path}/adv_idea_title_info
cuid_title_idea_emb=${shaolin_prefix}/${shaolin_project_path}/cuid_title_idea_emb
merged_ideavec=${shaolin_prefix}/${shaolin_project_path}/merged_ideavec
a2a_pooling_xbox_data=${shaolin_prefix}/user/nad-offline/chenyunan/model/ad2ad/a2a_pooling_xbox_data
new_a2a_pooling_xbox_data=${shaolin_prefix}/user/nad-offline/chenyunan/model/ad2ad/new_a2a_pooling_xbox_data
title2ad_se_base_index=${shaolin_prefix}/user/nad-offline/chenyunan/title2ad/title2ad_se_base_index

group_train_data_path=${shaolin_prefix}/user/nad-offline/chenyunan/model/cuid_title_model/group_shitu_data
group_infer_raw_data=${shaolin_prefix}/user/nad-offline/chenyunan/model/cuid_title_model/group_infer_raw_data
# =================================usercf================================
user_vec=${tianqi_prefix}/app/ecom/native-ad/chensitong03/entity_recall//user_vec

OCPC_PATH="afs://tianqi.afs.baidu.com:9902/app/ecom/native-ad/ROI/new_roi_shitu_log"
OCPM_PATH="afs://tianqi.afs.baidu.com:9902/app/ecom/native-ad/ROI/cpm_roi_shitu_log"

