import ego
import tensorflow as tf
from models.base import BaseModel
from tools.loss import cross_entropy_loss
from utils.get_emb import get_item_embs 
from utils.get_emb import get_item_attention_embs
from utils.get_emb import get_item_long_seq_att_embs
from utils.sum_log import summary_vector
from utils.sum_log import summary_scalar
from utils.fat import FAT
from utils.fat import get_act_op
from utils.fat import get_init_op
from utils.get_emb import aggregator_function

# region split

@tf.custom_gradient
def ignore_grad(x):
    def grad(upstream):
        return upstream * 0.0

    return x, grad

class HiNetModel(BaseModel):
    def __init__(self, fm, **kwargs):
        super().__init__(fm, **kwargs)
        self.num_blocks = 2
        self.debug_nodes = []
        self.scalar_tensor = []
        self.mode = ego.is_training_mode()
        ego.config_feature_admission_evict(slots=[8900,8901,12900,12901,12910,12911,12920,12921,12906,12907], create_clk_prob=0, create_nonclk_prob=0, delete_after_unseen_days=24*366)
        self.fat_input_list = []

    def build_inputs(self):
        super().build_inputs()

    def _get_cache_emb(self, _emb, cache_name):
        item_cache_sum = tf.reduce_sum(tf.abs(_emb), axis = -1, keepdims=True)
        mode = float(self.mode)
        one_flag = tf.cast(tf.ones_like(item_cache_sum), dtype = tf.float32) - mode * 0.001
        zero_flag = tf.cast(tf.zeros_like(item_cache_sum), dtype = tf.float32)
        item_cache_flag = tf.where(item_cache_sum > 0.00001, one_flag, zero_flag)
        label, weight = ego.get_label_weight(cache_name, label_idx=0)
        ego.Target(name=cache_name, pred=item_cache_flag, label=label, weight=weight, loss=None)
        self.debug_nodes.append(cache_name)

    def get_tb_log(self, group_input_map):
        from utils.sum_log import summary_vector
        from utils.sum_log import summary_scalar

        ego.config_dump_tensor(with_sample_id=False)

        _scalar_tensor = []
        with tf.variable_scope(f"Group_EMBED"):
            for name in sorted(group_input_map.keys()):
                if not name.endswith("_seq"):
                    print(f"[item!!! {name}]", group_input_map[name])
                    res= summary_vector(group_input_map[name][0], name=name)
                else:
                    _, seq_len = group_input_map[name]
                    res = summary_scalar(seq_len, vals=[0, 10],  val_names=["eq0", "lt10"] , name=f"{name}_length", use_std=False, use_cv=False)
                _scalar_tensor.extend(res)

        print("*" * 10, f"len(_scalar_tensor) = {len(_scalar_tensor)}", "*" * 40)

        # scalar_tensor += _scalar_tensor

        return _scalar_tensor
    

    def get_seq_tb_log(self, group_input_map, seq_names_, att_wgts, seq_index=[0, 1, 2]):
        res_all = []
        for _idx, seq_name in enumerate(seq_names_):
                print(f"[{seq_name} USE_ATTENTION]", group_input_map[seq_name])
                seq_tensors, _ = group_input_map[seq_name]
                _din_weights = att_wgts[_idx]
                with tf.variable_scope(f"DIN_{seq_name}_attention_weights"):
                    for idx in seq_index:
                        tensor = _din_weights[:, idx]
                        res = summary_scalar(tensor, vals=[], val_names=[], name=f"seq{idx}_att_w", use_std=False, use_cv=False)
                        res_all.extend(res)

                with tf.variable_scope(f"DIN_{seq_name}_seq_embed"):
                    for idx in seq_index:
                        tensor_emb = seq_tensors[:, idx, :]
                        res = summary_vector(tenosr=tensor_emb, name=f"seq{idx}_emb")
                        res_all.extend(res)
                del _din_weights
        return res_all

    def prepare_simtier(self, group_input_map, q, seq_names):
        q_emb, q_emb_list, q_dims = group_input_map[q]
        score, att_weights = get_item_attention_embs(group_input_map, item_query_emb = q_emb, seq_keys = seq_names,tiers=[5,20], op_name="get_item_attention_" + q)

        for seq, att_wgt in zip(seq_names, att_weights):
            # seq_tensors, length = self.group_input_map[seq]
            print(f"[seq] {seq}, {att_wgt}")
            for seq_idx in [0, 1]:
                tensor_emb = att_wgt[:, seq_idx: seq_idx + 1]
                c_name = f"{seq}{seq_idx}_cache_flag"
                print(f"[cache info] seq = {seq}, c_name = {c_name}, tensor_emb = {tensor_emb}")
                # _get_cache_emb(tensor_emb, c_name)
                self._get_cos(tensor_emb, c_name)
                del tensor_emb, c_name, seq_idx
                

        if self.mode:
            self._get_cache_emb(q_emb, q + '_cache_flag')
            seq_tb = self.get_seq_tb_log(group_input_map, seq_names, att_weights)
            self.scalar_tensor += seq_tb
        return score


    def prepare_long_simtier(self, group_input_map, q, seq_names):
        q_emb, q_emb_list, q_dims = group_input_map[q]

        print("[!!! USE_LONG_SEQ]")
        score, att_weights = get_item_long_seq_att_embs(group_input_map, item_query_emb=q_emb, seq_keys=seq_names, tiers=[20, 80], use_sim=False, use_simtier=True, op_name="get_item_long_seq_att_embs_img")
        print("[!!! USE_LONG_SEQ]", score, att_weights)


        for seq, att_wgt in zip(seq_names, att_weights):
            # seq_tensors, length = self.group_input_map[seq]
            print(f"[seq] {seq}, {att_wgt}")
            for seq_idx in [0, 499]:
                tensor_emb = att_wgt[:, seq_idx: seq_idx + 1]
                c_name = f"{seq}{seq_idx}_cache_flag"
                print(f"[cache info] seq = {seq}, c_name = {c_name}, tensor_emb = {tensor_emb}")
                # _get_cache_emb(tensor_emb, c_name)
                self._get_cos(tensor_emb, c_name)
                del tensor_emb, c_name, seq_idx

        if self.mode:
            # self._get_cache_emb(q_emb, q + '_cache_flag')
            seq_tb = self.get_seq_tb_log(group_input_map, seq_names, att_weights, seq_index=[0, 1, 2, 300, 498, 499])
            self.scalar_tensor += seq_tb
        return score
    
    def fuse_score(self, fuse_weight, scores):
        fuse_weight_dim = fuse_weight.get_shape().as_list()[1]
        scores_dim = scores.get_shape().as_list()[1]
        score = tf.reduce_sum(fuse_weight * scores, axis=-1, keepdims=True)
        return score

    def _get_cos(self, _emb, cache_name):
        label, weight = ego.get_label_weight(cache_name, label_idx=0)
        ego.Target(name=cache_name, pred=_emb, label=label, weight=weight, loss=None)
        self.debug_nodes.append(cache_name)

    def make_fat_input(self, emb, name, dim):
        rm_input = 2.0 * ego.DenseTower(name=f"{name}_fat_input_nn",
                                output_dims=[dim],
                                kernel_initializers=[self.param_initializer],
                                bias_initializers=[self.param_initializer],
                                activations=[tf.nn.leaky_relu],
                                norms=[True]
                                )(emb)
        return rm_input
    
    def build_network(self):
        self.fat_input_dim = 256
        ctx_fat_input = self.make_fat_input(self.ctx_emb, "context", self.fat_input_dim)
        self.fat_input_list.append(ctx_fat_input) # sim like gate for uid and bundle

        uid_fat_input = self.make_fat_input(self.uid_emb, "uid", self.fat_input_dim)
        self.fat_input_list.append(uid_fat_input) # sim like gate for uid and bundle

        if self.mode:
            ego.config_dump_tensor(with_sample_id=False)
        img_score = self.prepare_simtier(self.group_input_map, self.q_img, self.img_seq_names)
        title_score  = self.prepare_simtier(self.group_input_map, self.q_title, self.title_seq_names)
        img_long_score = self.prepare_long_simtier(self.group_input_map, self.q_img, self.img_long_seq_names)

        img_fat_input = self.make_fat_input(img_score, "img", self.fat_input_dim)
        title_fat_input = self.make_fat_input(title_score, "title", self.fat_input_dim)
        long_fat_input = self.make_fat_input(img_long_score, "img_long", self.fat_input_dim)
        self.fat_input_list += [img_fat_input, title_fat_input, long_fat_input] # 3 simiter



        tb = self.get_tb_log(self.group_input_map)
        self.scalar_tensor += tb

        # ****_input sparse特征
        tower1_input = {True: [tf.concat([self.shared_onehot_input, self.shared_dense_input, self.shared_emb], axis=-1),
            tf.concat([self.iterable_onehot_input, self.iterable_dense_input, self.iterable_emb], axis=-1)],
            False: [tf.concat([self.shared_onehot_input, self.shared_dense_input, self.shared_emb], axis=-1)]}

        nn_inputs = [tower1_input]


        for i, phase in enumerate(self.phases):
            user_base_emb = ego.DenseTower(name="user_{}_{}".format(phase["name"], 'shared_bottom'),
                                output_dims=[256, self.fat_input_dim],
                                kernel_initializers=[self.param_initializer] * 2,
                                bias_initializers=[self.param_initializer] * 2,
                                activations=[tf.nn.leaky_relu] * 2,
                                norms=[False, True],
                                )(nn_inputs[i][self.mode][0])
            item_base_emb = None
            self.fat_input_list.append(user_base_emb) # ub seq
            if self.mode:
                item_base_emb = ego.DenseTower(name="item_{}_{}".format(phase["name"], 'shared_bottom'),
                                output_dims=[256, self.fat_input_dim],
                                kernel_initializers=[self.param_initializer] * 2,
                                bias_initializers=[self.param_initializer] * 2,
                                activations=[tf.nn.leaky_relu] * 2,
                                norms=[False, True]
                                )(nn_inputs[i][self.mode][1])
                if i == 0:
                    item_base_emb = ego.replace_gradient(item_base_emb, self.assign_slot_emb, item_base_emb) # cache做法
            else:
                item_base_emb = self.assign_slot_emb
            self.fat_input_list.append(item_base_emb) # item

            online_fea_emb = ego.DenseTower(name="online_fea_tower",
                                  output_dims=[self.fat_input_dim],
                                  kernel_initializers=[self.param_initializer],
                                  bias_initializers=[self.param_initializer],
                                  activations=[tf.nn.leaky_relu],
                                  norms=[True])(self.online_emb)


            self.fat_input_list.append(online_fea_emb) # recall


            ## fat 


            ITEM_SPLIT = False
            DEP_GROUP_NAMES = []
            MM_TOKEN = True
            FAT_DICT = {
                "d_model": self.fat_input_dim,
                "num_token": 8,
                "num_head": 8,
                "num_layers": 3, # 4
                "ffn_type": "share_all", ## per_token or share_all
                "ffn_act": "relu", # silu
                "st_act": "silu", # lrelu
                "init_op": "xavier_normal",
                "pooling_type": ["mean", "max"],
                "mix_ln": True,
                "ffn_ln": False,
                "ln_eps": 1e-6
            }
            fat_layer = FAT(d_model=FAT_DICT["d_model"], 
                    num_token=FAT_DICT["num_token"], 
                    num_head=FAT_DICT["num_head"],
                    ffn_type=FAT_DICT["ffn_type"], 
                    ffn_act=FAT_DICT["ffn_act"], 
                    init_op=FAT_DICT["init_op"], 
                    num_layers=FAT_DICT["num_layers"],
                    mix_ln=FAT_DICT.get("mix_ln", False),
                    ffn_ln=FAT_DICT.get("ffn_ln", False),
                    ln_eps=FAT_DICT.get("ln_eps", 1e-6),
                    )
            fat_inp = tf.stack(self.fat_input_list, axis=1)
            print("[fat_inp]", fat_inp)
            fat_seq_output = fat_layer(fat_inp)

            fat_pool = [aggregator_function(fat_seq_output, seq_len=None, reduce_type=pool_type, use_mask=False) for pool_type in FAT_DICT["pooling_type"]]

            print("[fat_seq_output]", fat_seq_output)
            fat_pool = tf.concat(fat_pool, axis=1, name="fat_pool_concat")
            print("[fat_pool]", fat_pool)

            feature_input = tf.concat([fat_pool, item_base_emb], axis=1)

            # target: click,roi2_ctr,atc,order,roi2_cvr,roi2_single
            for idx, target in enumerate(self.target_names):
                target_name = "{}_tower".format(phase["name"], target)
                pred = ego.DenseTower(
                    name=target_name,
                    output_dims=[128, 64, 1],
                    kernel_initializers=[self.param_initializer] * 3,
                    bias_initializers=[self.param_initializer] * 3,
                    activations=[tf.nn.leaky_relu, tf.nn.leaky_relu, tf.nn.sigmoid],
                    norms=[False, False, False],
                )(feature_input)

                node = "{}_{}".format(phase["name"], target)
                output = tf.identity(pred, node)
                label_idx = idx * 2
                label, weight = ego.get_label_weight(target_name="{}_{}_label_weight".format(phase["name"], target), label_idx=label_idx)
                loss = cross_entropy_loss(label, output, target)

                phase["nodes"].append(node)
                phase["outputs"].append(output)
                phase["labels"].append(label)
                phase["weights"].append(weight)
                phase["losses"].append(loss)



    def get_debug_nodes(self):
        print("[debug_nodes] =", self.debug_nodes)
        return self.debug_nodes

    def get_scalar_tensor(self):
        return self.scalar_tensor

    def build_graph(self):
        self.build_inputs()
        self.build_network()
        self.build_targets()
        self.build_loss()
        return self.phases
