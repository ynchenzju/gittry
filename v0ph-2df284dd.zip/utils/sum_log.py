#!/usr/bin/env python
# -*- coding: utf-8 -*-
import tensorflow as tf


def summary_vector(tenosr, name):
    with tf.variable_scope(f"{name}_vector_summary"):
        res = []
        emb = tenosr
        ## embed stat
        neg_value_ratio = tf.reduce_mean(tf.where(emb < 0.0, tf.ones_like(emb), tf.zeros_like(emb)), name=f"{name}_neg_value_ratio")
        zero_ratio = tf.reduce_mean(tf.where(tf.abs(emb) <= 0.0001, tf.ones_like(emb), tf.zeros_like(emb)), name=f"{name}_zero_ratio")
        res.extend([neg_value_ratio, zero_ratio])
        del neg_value_ratio, zero_ratio
        # norm stat
        norm = tf.norm(emb, axis=1)
        del emb
        norm_avg = tf.reduce_mean(norm, name=f"{name}_norm")
        norm_zero_ratio = tf.reduce_mean(tf.where(norm <= 0.0001, tf.ones_like(norm), tf.zeros_like(norm)), name=f"{name}_norm_zero_ratio")
        res.extend([norm_avg, norm_zero_ratio])
        del norm, norm_zero_ratio
        return res


def summary_scalar(tensor, vals, val_names, name, use_std=True, use_cv=True):
    with tf.variable_scope(f"{name}_scalar_summary"):
        emb = tensor
        avg = tf.reduce_mean(emb, name=f"{name}_avg")
        res = [avg]
        t_std = tf.math.reduce_std(emb, name=f"{name}_std")
        t_cv = tf.math.divide(t_std, avg, name=f"{name}_cv")
        if use_cv and use_std:
            res.extend([t_std, t_cv])
        elif use_std:
            res.append(t_std)
        elif use_cv:
            res.append(t_cv)

        for v, v_name in zip(vals, val_names):
            stat = tf.reduce_mean(tf.where(emb <= v, tf.ones_like(emb), tf.zeros_like(emb)), name=f"{name}_{v_name}_ratio")
            res.append(stat)
        return res
