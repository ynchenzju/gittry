function split(s, sep)
    local fields = {}

    local sep = sep or " "
    local pattern = string.format("([^%s]+)", sep)
    string.gsub(s, pattern, function(c) fields[#fields + 1] = c end)

    return fields
end

function uid_fn(sample_id)
    local uid = split(sample_id, ";")[2]
    return uid
end

function filter_fn(sample_id)
    local uid = uid_fn(sample_id)
    if string.find(sample_id, ':ads') or string.find(sample_id, ':video')
    then
        return false
    end
    return true
end
