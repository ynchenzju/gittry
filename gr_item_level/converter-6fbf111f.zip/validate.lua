local function parseString(input)
    local map = {}
    for pair in string.gmatch(input, "[^:]+") do
        local key, value = pair:match("([^,]*),?(.*)")
        if key and value then
            map[key] = value
        end
    end

    return map
end

function extract_origin_fea_fn(debug_info)
    debug_info = debug_info:sub(16)
    local debug_info_map = parseString(debug_info)
    if debug_info_map['pb_msg'] ~= nil
    then
        return debug_info_map['pb_msg']
    else
        return ""
    end
end