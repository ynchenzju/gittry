#!/usr/bin/env python
# -*- coding: utf-8 -*-

from models.hinet_v5 import HiNetModel
import os
import tensorflow as tf
import ego
from tools.feature import FeatureManager
from utils.get_emb import get_item_embs
from utils.get_emb import get_item_attention_embs
from utils.get_emb import get_item_long_seq_att_embs
from utils.sum_log import summary_vector
from utils.sum_log import summary_scalar

print("ego training mode: {}".format(ego.is_training_mode()))
# train: total nn layer size: 5436492, total sparse input dim: 166452, total dense input dim: 131
# serve: total nn layer size: 5274982, total sparse input dim: 166452, total dense input dim: 131
MC_PATH = "configs/mcconf_v5.yaml"
fm = None
if os.path.exists(MC_PATH):
    fm = FeatureManager(MC_PATH, "configs/convert.yaml")

assert fm is not None

# 2. encoder增加user特征、context特征、avg_clk、avg_order、click_seq对avg_ord/avg_cart/avg_clk/click_long_seq的attention score。并放在tensorboard的监控里。
# 3. decoder最后一层增加item对各部分attention score监控
# 4. 对decoder两层的attention score，分别计算并监控entropy = -tf.reduce_sum(score * tf.math.log(score + eps), axis=1) ，用来观测score1到score2的熵增熵减情况。
# 5. 看一下不同item序列特征差异，如果只是差在一些不重要的特征上，可以去掉冗余特征然后用同一套qkv [TODO]
# 6. 加layernorm保证训练稳定
# 6.1 移除base_v5.py中所有ego.Normalization(BN)和clip_by_value
# 6.2 移除hinet_v5.py中DenseTower的BN (make_input_dim, user_base, item_tower, prediction tower)
# 6.3 在不同量级特征concat/stack前加RMSNorm (base concat, ns_feas, seq, item, multi-layer output, pred_inp, decoder input)
# 6.4 Encoder/Decoder输出加final RMSNorm (pre-norm标准)

shared_dense_slots = [
    101,102,103,104,602
]
iterable_dense_slots = [
    301, 302, 303, 304, 305, 306,
    311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330,
    501, 502, 503, 504, 505, 506, 507, 551
]
shared_onehot_slots = [
    100
]
iterable_onehot_slots = [
    201,202,203,204,401,402,403,404
]

SHARED_DENSE_DIM = 53
ITERABLE_DENSE_DIM = 39
SHARED_ONEHOT_DIM = 13
ITERABLE_ONEHOT_DIM = 26
BUNDLE_DIM = 7

SCEN_EXPERT_NUM = 4
TASK_EXPERT_NUM = 2
BUNDLE_INDEX_MAPPING = {"cart": 0, "osp": 1, "buya": 2, "mpp": 3, "odp": 4}

BUNDLE_INDICATOR = [1000]

model = HiNetModel(fm,
                   shared_dense_dim=SHARED_DENSE_DIM, iterable_dense_dim=ITERABLE_DENSE_DIM,
                   shared_onehot_dim=SHARED_ONEHOT_DIM, iterable_onehot_dim=ITERABLE_ONEHOT_DIM,
                   bundle_dim=BUNDLE_DIM,
                   scen_expert_num=SCEN_EXPERT_NUM, task_expert_num=TASK_EXPERT_NUM,
                   bundle_index_mapping=BUNDLE_INDEX_MAPPING,
                   bundle_indicator=BUNDLE_INDICATOR)
p0 = model.build_graph()[0]
debug_nodes = model.get_debug_nodes()
scalar_tensor = model.get_scalar_tensor()
# sample_att_weights = model.get_sample_att_weights()
# print('sample_att_weights', sample_att_weights)
print(['cache_flag'] + p0['nodes'] + debug_nodes)

if ego.is_training_mode():

    eval_round = ego.OfflineRound(name="eval",
                                  targets=['cache_flag'] + p0["nodes"] + debug_nodes, 
                                  final_loss = None, 
                                  dump_scalar_tensors_to_tensorboard = scalar_tensor
                                  # ,dump_tensors_to_hdfs=sample_att_weights
                                  )
    
    r1 = ego.OfflineRound(name="p0", 
                          targets=['cache_flag'] + p0["nodes"] + debug_nodes, 
                          final_loss=p0["final_loss"], 
                          dump_scalar_tensors_to_tensorboard = scalar_tensor, 
                          # dump_tensors_to_hdfs=sample_att_weights,
                          train_sparse=True)
    ego.compile(rounds=[eval_round, r1])
else:
    r = ego.OnlineRound(name="online", targets=(['cache_flag'] + p0['nodes']))
    ego.compile(rounds=[r])
