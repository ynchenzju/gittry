import ego
import tensorflow as tf
from models.base_v5 import BaseModel
from tools.loss import cross_entropy_loss
from utils.get_emb import get_item_embs
from utils.get_emb import get_item_attention_embs
from utils.get_emb import get_item_long_seq_att_embs
from utils.sum_log import summary_vector
from utils.sum_log import summary_scalar
from utils.onetrans_res import Transformer
from tools.ops import RMSNorm



@tf.custom_gradient
def ignore_grad(x):
    def grad(upstream):
        return upstream * 0.0

    return x, grad

class HiNetModel(BaseModel):
    def __init__(self, fm, **kwargs):
        super().__init__(fm, **kwargs)
        self.num_blocks = 2
        self.debug_nodes = []
        self.scalar_tensor = []
        self.mode = ego.is_training_mode()
        ego.config_feature_admission_evict(slots=[8900,8901,12900,12901,12910,12911,12920,12921,12906,12907,8533,12347,12350,12352,12354], create_clk_prob=0, create_nonclk_prob=0, delete_after_unseen_days=24*366)
        self.fat_input_list = []

        self.assign_slot_id = [8001]
        self.llm_len = 33
        self.group_fea = []
        self.tb = True
        self.tokens = {}
        self.num_layers = 2
        self.d_model = 128
        self.num_heads = 4
        self.max_seq_len = 50
        self.action_types = ["user_order_long_seq", "user_order_seq", "user_cart_seq", "user_click_long_seq", "user_click_seq"]
        self.focus_seq_names = ["user_click_seq"]
        self.sequence_masks = {}
        self.sample_att_weights = []

        self._ENC_NS_PART_NAMES = ["ctx", "uid", "user_base", "user_prefer", "user_click_bucket", "user_cart_bucket", "user_order_bucket", "avg_ord_long", "avg_ord", "avg_cart", "avg_clk_long", "avg_clk"]
        self._DEC_NS_PART_NAMES = ["ctx", "uid", "user_base", "user_prefer", "user_click_bucket", "user_cart_bucket", "user_order_bucket", "avg_ord_long", "avg_ord", "avg_cart", "avg_clk_long", "avg_clk"]

        _ns_static_keys = ["ctx", "uid", "user_base", "user_prefer", "user_click_bucket", "user_cart_bucket", "user_order_bucket"]
        self.ns_static_norms = {k: RMSNorm() for k in _ns_static_keys}
        self.ns_avg_fea_norms = {action: RMSNorm() for action in self.action_types}
        self.ns_item_emb_norm = RMSNorm()
        self.sep_norm = RMSNorm()
        self.seq_token_norm = RMSNorm()
        self.item_input_norm = RMSNorm()
        self.ns_out_norm_list = [RMSNorm() for _ in range(2)]   # [x_ns_initial, x_ns_dec_in]
        self.item_out_norm_list = [RMSNorm() for _ in range(3)] # [x_item, layer0_out, layer1_out]
        self.s_out_norm_list = [RMSNorm() for _ in range(2)]    # [x_s_initial, x_s_dec_in]
        self.out_s_norm = RMSNorm()
        self.out_ns_norm = RMSNorm()
        self.out_item_norm = RMSNorm()
        self.shallow_norm = RMSNorm()
        self.bottom_norm = RMSNorm()
        self.simtier_norm = RMSNorm()

        self.item_tower_norm = RMSNorm()
        self.shared_dense_norm = RMSNorm()
        self.user_base_concat_norm = RMSNorm()
        self.iter_dense_norm = RMSNorm()

    def build_inputs(self):
        super().build_inputs()

    def _get_cache_emb(self, _emb, cache_name):
        item_cache_sum = tf.reduce_sum(tf.abs(_emb), axis = -1, keepdims=True)
        mode = float(self.mode)
        one_flag = tf.cast(tf.ones_like(item_cache_sum), dtype = tf.float32) - mode * 0.001
        zero_flag = tf.cast(tf.zeros_like(item_cache_sum), dtype = tf.float32)
        item_cache_flag = tf.where(item_cache_sum > 0.00001, one_flag, zero_flag)
        label, weight = ego.get_label_weight(cache_name, label_idx=0)
        ego.Target(name=cache_name, pred=item_cache_flag, label=label, weight=weight, loss=None)
        self.debug_nodes.append(cache_name)

    def get_tb_log(self, group_input_map):
        from utils.sum_log import summary_vector
        from utils.sum_log import summary_scalar

        ego.config_dump_tensor(with_sample_id=False)

        _scalar_tensor = []
        with tf.compat.v1.variable_scope(f"Group_EMBED"):
            for name in sorted(group_input_map.keys()):
                if not name.endswith("_seq"):
                    print(f"[item!!! {name}]", group_input_map[name])
                    res= summary_vector(group_input_map[name][0], name=name)
                else:
                    _, seq_len = group_input_map[name]
                    res = summary_scalar(seq_len, vals=[0, 10],  val_names=["eq0", "lt10"] , name=f"{name}_length", use_std=False, use_cv=False)
                _scalar_tensor.extend(res)

        print("*" * 10, f"len(_scalar_tensor) = {len(_scalar_tensor)}", "*" * 40)

        return _scalar_tensor

    def get_seq_tb_log(self, group_input_map, seq_names_, att_wgts, seq_index=[0, 1, 2]):
        res_all = []
        for _idx, seq_name in enumerate(seq_names_):
                print(f"[{seq_name} USE_ATTENTION]", group_input_map[seq_name])
                seq_tensors, _ = group_input_map[seq_name]
                _din_weights = att_wgts[_idx]
                with tf.compat.v1.variable_scope(f"DIN_{seq_name}_attention_weights"):
                    for idx in seq_index:
                        tensor = _din_weights[:, idx]
                        res = summary_scalar(tensor, vals=[], val_names=[], name=f"seq{idx}_att_w", use_std=False, use_cv=False)
                        res_all.extend(res)

                with tf.compat.v1.variable_scope(f"DIN_{seq_name}_seq_embed"):
                    for idx in seq_index:
                        tensor_emb = seq_tensors[:, idx, :]
                        res = summary_vector(tensor=tensor_emb, name=f"seq{idx}_emb")
                        res_all.extend(res)
                del _din_weights
        return res_all

    # def dump_sim(self, query_name, seq_names, att_weights):
    #     for seq, t in zip(seq_names, att_weights):
    #         self.sample_att_weights.append(tf.identity(t[0], name=f"{query_name}__to__{seq}_att_weight"))

    def prepare_simtier(self, group_input_map, q, seq_names):
        q_emb, q_emb_list, q_dims = group_input_map[q]
        score, att_weights = get_item_attention_embs(group_input_map, item_query_emb = q_emb, seq_keys = seq_names,tiers=[5,20], op_name="get_item_attention_" + q)
        # self.dump_sim(q, seq_names, att_weights)

        for seq, att_wgt in zip(seq_names, att_weights):
            print(f"[seq] {seq}, {att_wgt}")
            for seq_idx in [0, 1]:
                tensor_emb = att_wgt[:, seq_idx: seq_idx + 1]
                c_name = f"{seq}{seq_idx}_cache_flag"
                self._get_cos(tensor_emb, c_name)

        # if self.mode:
        #     self._get_cache_emb(q_emb, q + '_cache_flag')
        #     seq_tb = self.get_seq_tb_log(group_input_map, seq_names, att_weights)
        #     self.scalar_tensor += seq_tb
        return score

    def prepare_long_simtier(self, group_input_map, q, seq_names):
        q_emb, q_emb_list, q_dims = group_input_map[q]

        print("[!!! USE_LONG_SEQ]")
        score, att_weights = get_item_long_seq_att_embs(group_input_map, item_query_emb=q_emb, seq_keys=seq_names, tiers=[20, 80], use_sim=False, use_simtier=True, op_name="get_item_long_seq_att_embs_" + q)
        # self.dump_sim(q, seq_names, att_weights)
        print("[!!! USE_LONG_SEQ]", score, att_weights)

        for seq, att_wgt in zip(seq_names, att_weights):
            print(f"[seq] {seq}, {att_wgt}")
            for seq_idx in [0, 499]:
                tensor_emb = att_wgt[:, seq_idx: seq_idx + 1]
                c_name = f"{seq}{seq_idx}_cache_flag"
                self._get_cos(tensor_emb, c_name)

        # if self.mode:
        #     seq_tb = self.get_seq_tb_log(group_input_map, seq_names, att_weights, seq_index=[0, 1, 2, 300, 498, 499])
        #     self.scalar_tensor += seq_tb
        return score

    def _get_cos(self, _emb, cache_name):
        label, weight = ego.get_label_weight(cache_name, label_idx=0)
        ego.Target(name=cache_name, pred=_emb, label=label, weight=weight, loss=None)
        self.debug_nodes.append(cache_name)

    # --- Transformer attention monitoring (tb scalars) ---
    def _add_scalars(self, scope, name_to_tensor, use_std=True, use_cv=False):
        with tf.compat.v1.variable_scope(scope):
            for name, tensor in name_to_tensor.items():
                res = summary_scalar(tensor, vals=[], val_names=[], name=name, use_std=use_std, use_cv=use_cv)
                self.scalar_tensor.extend(res)

    def _attn_entropy(self, att_weights, eps=1e-8):
        h = -tf.reduce_sum(att_weights * tf.math.log(att_weights + eps), axis=-1)
        return tf.squeeze(h, axis=1)

    def _add_enc_last_att_monitor(self, enc_att_weights_list, ns_length):
        # enc_last: (B, q_seq, k_seq). Organize by query as scope so each scope's attention sum = 1.
        enc_last = enc_att_weights_list[self.num_layers - 1]
        enc_ns_names = self._ENC_NS_PART_NAMES
        seq_starts = [ns_length]
        for seg_len in self.action_seq_lengths[:-1]:
            seq_starts.append(seq_starts[-1] + seg_len)

        # NS queries: scope encoder_att/ns_{q_name}, scalars to_ns_* + to_s_*
        for i in range(ns_length):
            q_name = enc_ns_names[i] if i < len(enc_ns_names) else f"ns_{i}"
            scope = f"encoder_att_ns_{q_name}"
            name_to_tensor = {}
            for j in range(ns_length):
                k_name = enc_ns_names[j] if j < len(enc_ns_names) else f"ns_{j}"
                name_to_tensor[f"to_ns_{k_name}"] = enc_last[:, i, j]
            for a_idx, action in enumerate(self.action_types):
                k_start, k_end = seq_starts[a_idx], seq_starts[a_idx] + self.action_seq_lengths[a_idx]
                name_to_tensor[f"to_s_{action}"] = tf.reduce_sum(enc_last[:, i, k_start:k_end], axis=1)
            self._add_scalars(scope, name_to_tensor, use_std=False, use_cv=False)

        # S query segments: scope encoder_att/s_{action}, scalars to_ns_* + to_s_* (mean over query dim)
        for a_idx, action in enumerate(self.action_types):
            q_start = seq_starts[a_idx]
            q_end = q_start + self.action_seq_lengths[a_idx]
            scope = f"encoder_att_s_{action}"
            name_to_tensor = {}
            for j in range(ns_length):
                k_name = enc_ns_names[j] if j < len(enc_ns_names) else f"ns_{j}"
                name_to_tensor[f"to_ns_{k_name}"] = tf.reduce_mean(enc_last[:, q_start:q_end, j], axis=1)
            for b_idx, action_k in enumerate(self.action_types):
                k_start = seq_starts[b_idx]
                k_end = k_start + self.action_seq_lengths[b_idx]
                name_to_tensor[f"to_s_{action_k}"] = tf.reduce_mean(
                    tf.reduce_sum(enc_last[:, q_start:q_end, k_start:k_end], axis=2), axis=1
                )
            self._add_scalars(scope, name_to_tensor, use_std=False, use_cv=False)

    def _add_enc_important_att_monitor(self, enc_att_weights_list, ns_length):
        # enc_att_important: query (ctx, user, avg_clk, avg_ord, click_seq) -> key (avg_ord, avg_cart, avg_clk, click_long_seq)
        enc_last = enc_att_weights_list[self.num_layers - 1]
        seq_starts = [ns_length]
        for seg_len in self.action_seq_lengths[:-1]:
            seq_starts.append(seq_starts[-1] + seg_len)
        q_click_seq = (seq_starts[4], seq_starts[4] + self.action_seq_lengths[4])
        k_click_long = (seq_starts[3], seq_starts[3] + self.action_seq_lengths[3])

        query_list = [("ctx", 0), ("uid", 1), ("user", 2), ("avg_clk", 7), ("avg_ord", 4), ("click_seq", q_click_seq)]
        key_list = [("avg_ord", 4), ("avg_cart", 5), ("avg_clk", 7), ("click_long_seq", k_click_long)]

        def _slice(x):
            return (x, x + 1) if isinstance(x, int) else x

        name_to_tensor = {}
        for q_name, q_spec in query_list:
            for k_name, k_spec in key_list:
                qs, qe = _slice(q_spec)
                ks, ke = _slice(k_spec)
                block = enc_last[:, qs:qe, ks:ke]  # (B, q_len, k_len)
                t = tf.reduce_sum(tf.reduce_mean(block, axis=1), axis=1)  # (B,)
                name_to_tensor[f"{q_name}_to_{k_name}"] = t
        self._add_scalars("enc_att_important", name_to_tensor, use_std=False, use_cv=False)

    def _add_dec_last_att_monitor(self, dec_att_weights_list, ns_length):
        # dec_last: (B, num_heads, 1, 1+ns_length+s_length)
        dec_last = dec_att_weights_list[self.num_layers - 1]
        num_heads = self.num_heads
        ns_names = self._DEC_NS_PART_NAMES

        segments = [("item_to_self", 0, 1)]
        for i in range(ns_length):
            name = ns_names[i] if i < len(ns_names) else f"ns_{i}"
            segments.append((f"item_to_ns_{name}", 1 + i, 2 + i))
        seq_segments = {}
        seq_start = 1 + ns_length
        for action, seg_len in zip(self.action_types, self.action_seq_lengths):
            segments.append((f"item_to_s_{action}", seq_start, seq_start + seg_len))
            seq_segments[action] = (seq_start, seq_start + seg_len, seg_len)
            seq_start += seg_len

        for h in range(num_heads):
            item_att_h = dec_last[:, h, 0, :]  # (B, k_seq)
            name_to_tensor = {
                name: tf.reduce_sum(item_att_h[:, start:end], axis=1)
                for name, start, end in segments
            }
            self._add_scalars(f"decoder_att_head{h}", name_to_tensor, use_std=False, use_cv=False)

            for action in self.focus_seq_names:
                if action not in seq_segments:
                    continue
                s_start, s_end, s_len = seq_segments[action]
                seq_att = item_att_h[:, s_start + 1 : s_end]  # exclude sep token
                seq_positions = s_len - 1
                group_size = 5
                n_groups = seq_positions // group_size
                focus_tensors = {}
                for g in range(n_groups):
                    gs, ge = g * group_size, (g + 1) * group_size
                    focus_tensors[f"pos{gs}_to_{ge}"] = tf.reduce_mean(seq_att[:, gs:ge], axis=1)
                remainder = seq_positions % group_size
                if remainder > 0:
                    gs = n_groups * group_size
                    focus_tensors[f"pos{gs}_to_{seq_positions}"] = tf.reduce_mean(seq_att[:, gs:], axis=1)
                self._add_scalars(f"decoder_att_head{h}_focus_{action}", focus_tensors, use_std=False, use_cv=False)

        item_att_mean = tf.reduce_mean(dec_last[:, :, 0, :], axis=1)  # (B, k_seq)
        name_to_tensor = {
            name: tf.reduce_sum(item_att_mean[:, start:end], axis=1)
            for name, start, end in segments
        }
        self._add_scalars("decoder_att", name_to_tensor, use_std=False, use_cv=False)

    def _add_dec_entropy_monitor(self, dec_att_weights_list, eps=1e-8):
        name_to_tensor = {}
        dec_att_means = []
        for layer_idx, dec_att in enumerate(dec_att_weights_list):
            # dec_att: (B, num_heads, 1, k_seq) -> average over heads for entropy
            dec_att_mean = tf.reduce_mean(dec_att, axis=1)  # (B, 1, k_seq)
            dec_att_means.append(dec_att_mean)
            name_to_tensor[f"dec_layer{layer_idx}_entropy"] = self._attn_entropy(dec_att_mean, eps)
        e1 = self._attn_entropy(dec_att_means[0], eps)
        e2 = self._attn_entropy(dec_att_means[1], eps)
        name_to_tensor["dec_entropy_change"] = e2 - e1
        self._add_scalars("dec_att_entropy", name_to_tensor, use_std=False, use_cv=False)

    def make_input_dim(self, emb, name, dim):
        return ego.DenseTower(name=f"{name}_dim_input_nn",
                                output_dims=[dim],
                                kernel_initializers=[self.param_initializer],
                                bias_initializers=[self.param_initializer],
                                activations=[tf.nn.leaky_relu],
                                norms=[False]
                                )(emb)

    def avg_long_seq(self, fea, length, seq_len, cut_head, group_num, group_size):
        B = tf.shape(fea)[0]
        length = tf.cast(tf.squeeze(length, axis=1), tf.int32)
        fea_cut = fea[:, cut_head:, :]
        length_cut = tf.maximum(length - cut_head, 0)
        length_group = tf.cast(tf.math.ceil(tf.cast(length_cut, tf.float32) / group_size), tf.int32)
        mask = tf.sequence_mask(length_cut, maxlen=seq_len - cut_head, dtype=fea.dtype)
        mask = mask[:, :, None]
        fea_group = tf.reshape(fea_cut, [B, group_num, -1, fea_cut.shape[2]])
        mask_group = tf.reshape(mask, [B, group_num, -1, 1])
        sum_fea = tf.reduce_sum(fea_group * mask_group, axis=2)
        cnt = tf.reduce_sum(mask_group, axis=2)
        cnt = tf.maximum(cnt, 1.0)
        fea_avg = sum_fea / cnt
        length_avg = tf.expand_dims(length_group, axis=1)
        fea, length = fea_avg, length_avg

        return fea, length, group_num

    def build_network(self):
        if self.mode:
            ego.config_dump_tensor(with_sample_id=False)
        for i, phase in enumerate(self.phases):
            self.ns_feas = []
            self.ns_fea_dim  = 128
            # simtier (from cart_rr_l2_ot_long model_v1): use simtier_group_input_map, project scores, prepend to ns_feas
    
            img_score = self.prepare_simtier(self.simtier_group_input_map, self.q_img, self.img_seq_names)
            title_score = self.prepare_simtier(self.simtier_group_input_map, self.q_title, self.title_seq_names)
            img_long_score = self.prepare_long_simtier(self.simtier_group_input_map, self.q_img, self.img_long_seq_names)
            sid_score = self.prepare_simtier(self.simtier_group_input_map, self.q_sid, self.sid_seq_names)
            sid_long_score = self.prepare_long_simtier(self.simtier_group_input_map, self.q_sid, self.sid_long_seq_names)


            # tb = self.get_tb_log(self.group_input_map)
            # self.scalar_tensor += tb
            self.simtier_feas_list = [img_score, title_score, img_long_score, sid_score, sid_long_score]



            ctx_fat_input = self.make_input_dim(self.ctx_emb, "context", self.ns_fea_dim)
            self.ns_feas.append(self.ns_static_norms["ctx"](ctx_fat_input))

            uid_input = self.make_input_dim(self.uid_emb, "uid", self.ns_fea_dim)
            self.ns_feas.append(self.ns_static_norms["uid"](uid_input))

            # online_fea_emb = self.make_input_dim(self.online_emb, "online_fea", self.ns_fea_dim)
            # self.ns_feas.append(online_fea_emb)

            user_fea = tf.concat([self.shared_onehot_input, self.shared_dense_norm(self.shared_dense_input), self.user_base_concat_norm(self.user_base_emb)], axis=-1)
            user_base_emb = ego.DenseTower(name="user_{}_{}".format(phase["name"], 'shared_bottom'),
                                output_dims=[256, self.ns_fea_dim],
                                kernel_initializers=[self.param_initializer] * 2,
                                bias_initializers=[self.param_initializer] * 2,
                                activations=[tf.nn.leaky_relu] * 2,
                                norms=[False, False],
                                )(user_fea)
            self.ns_feas.append(self.ns_static_norms["user_base"](user_base_emb))

            user_prefer_emb = self.make_input_dim(self.user_prefer_emb, "user_prefer", self.ns_fea_dim)
            self.ns_feas.append(self.ns_static_norms["user_prefer"](user_prefer_emb))

            user_click_bucket_emb = self.make_input_dim(self.user_click_bucket_emb, "user_click_bucket", self.ns_fea_dim)
            self.ns_feas.append(self.ns_static_norms["user_click_bucket"](user_click_bucket_emb))

            user_cart_bucket_emb = self.make_input_dim(self.user_cart_bucket_emb, "user_cart_bucket", self.ns_fea_dim)
            self.ns_feas.append(self.ns_static_norms["user_cart_bucket"](user_cart_bucket_emb))

            user_order_bucket_emb = self.make_input_dim(self.user_order_bucket_emb, "user_order_bucket", self.ns_fea_dim)
            self.ns_feas.append(self.ns_static_norms["user_order_bucket"](user_order_bucket_emb))

            # ------------------------------------- ITEM CACHE ---------------------------------
            item_vec = tf.concat([self.iterable_onehot_input, self.iter_dense_norm(self.iterable_dense_input), self.item_emb, self.img_emb, self.title_emb, self.sid_emb], axis=-1)
            if self.mode:
                item_tower_output = ego.DenseTower(
                    name='item_tower',
                    output_dims=[128, self.ns_fea_dim],
                    kernel_initializers=[self.param_initializer] * 2,
                    bias_initializers=[self.param_initializer] * 2,
                    activations=[tf.nn.leaky_relu, None],
                    norms=[False, False],
                    use_bias=True
                )(item_vec)
                self._get_cache_emb(item_tower_output, 'item_tower_cache_flag')
                self._get_cache_emb(self.assign_slot_emb, 'assign_slot_emb_cache_flag')
                if i == 0:
                    item_tower_output = ego.replace_gradient(item_tower_output, self.assign_slot_emb, item_tower_output)
            else:
                item_tower_output = self.assign_slot_emb
            item_emb = tf.concat([self.item_tower_norm(item_tower_output), self.online_emb, self.sid_emb], axis=-1)
            item_emb = self.make_input_dim(item_emb, "item_emb", self.ns_fea_dim)
            abs_val = tf.sqrt(tf.reduce_sum(abs(item_emb ** 2), axis=-1, keepdims=True))
            print("phrase {} abs val: dim {}".format(phase, abs_val.get_shape().as_list()))
            # ------------------------------------- ITEM CACHE ---------------------------------

            # ------------------------------------- Transformer ---------------------------------
            gr_seq_feas, masks_out = [], []
            dec_attn_masks = []
            self.action_len_dict = {}
            self.action_seq_lengths = []  # per-action seq segment length (sep+fea), same order as action_types
            s_length = 0
            for action in self.action_types:
                fea, length = self.group_input_map[action]
                fea = self.make_input_dim(fea, action, self.d_model)

                avg_fea = tf.reduce_mean(fea, axis=1)
                self.ns_feas.append(self.ns_avg_fea_norms[action](avg_fea))

                print(action)
                with tf.compat.v1.variable_scope("action_sep_embs", reuse=tf.compat.v1.AUTO_REUSE):
                    sep_emb = tf.compat.v1.get_variable(
                        name='sep_embs_' + action,
                        shape=(1, 1, self.d_model),
                        initializer=self.param_initializer,
                        trainable=True,
                    )

                B_fea = tf.shape(fea)[0]
                sep_emb_tiled = tf.tile(sep_emb, [B_fea, 1, 1])
                max_seq_len = 50

                if action in ("user_click_long_seq", "user_order_long_seq"):
                    fea, length, max_seq_len = self.avg_long_seq(fea, length, seq_len=500, cut_head=50, group_num=9, group_size=50)

                length = tf.squeeze(length, axis=1)

                mask = tf.sequence_mask(
                    lengths=length,
                    maxlen=max_seq_len,
                    dtype=tf.float32
                )

                part = tf.concat([self.sep_norm(sep_emb_tiled), self.seq_token_norm(fea)], axis=1)
                gr_seq_feas.append(part)
                seg_len = max_seq_len + 1
                self.action_seq_lengths.append(seg_len)
                s_length += seg_len
                print('debug info | seq mask of action {}: {}'.format(action, mask.get_shape()))
                sep_mask = tf.ones_like(mask[:, :1])

                masks_out += [tf.zeros_like(sep_mask), mask]
                dec_attn_masks.append(tf.concat([tf.ones_like(mask[:, :1]), mask], axis=1))

            print('gr_seq_feas', gr_seq_feas)
            s_fea = tf.concat(gr_seq_feas, axis=1)
            print('debug info | s_length: ', s_length)
            x_item = tf.expand_dims(self.item_input_norm(item_emb), axis=1)

            ns_length = len(self.ns_feas)
            ns_fea = tf.stack(self.ns_feas, axis=1)
            print('debug info | ns_fea of shape: ', ns_fea.get_shape())

            seq_attn_mask = tf.concat(dec_attn_masks, axis=1)
            item_ns_ones = tf.ones([tf.shape(seq_attn_mask)[0], 1 + ns_length], dtype=tf.float32)
            dec_attn_mask = tf.concat([item_ns_ones, seq_attn_mask], axis=1)
            enc_attn_mask = tf.concat([tf.ones([tf.shape(seq_attn_mask)[0], ns_length], dtype=tf.float32), seq_attn_mask], axis=1)

            s_out_list, ns_out_list, item_out_list, enc_att_weights_list, dec_att_weights_list = Transformer(num_layers = self.num_layers, d_model = self.d_model, num_heads = self.num_heads, ns_length = ns_length,
                                        s_length = s_length)([s_fea, ns_fea, x_item, [None for _ in range(self.num_layers)], dec_attn_mask, enc_attn_mask],
                                                                                                                        ego.is_training_mode())

            # for i in range(self.num_layers):
            #     self.sample_att_weights.append(tf.identity(enc_att_weights_list[i], name=f"transformer_encoder_layer_{i}_ns_and_seq_self_att_weight"))
            # for i in range(self.num_layers):
            #     self.sample_att_weights.append(tf.identity(dec_att_weights_list[i], name=f"transformer_decoder_layer_{i}_item_to_ns_and_seq_att_weight"))

            idx_last = self.num_layers - 1
            self.sample_att_weights.append(tf.identity(enc_att_weights_list[idx_last], name=f"transformer_encoder_layer_{idx_last}_ns_and_seq_self_att_weight"))
            self.sample_att_weights.append(tf.identity(dec_att_weights_list[idx_last], name=f"transformer_decoder_layer_{idx_last}_item_to_ns_and_seq_att_weight"))

            if self.mode:
                self._add_enc_last_att_monitor(enc_att_weights_list, ns_length)
                # self._add_enc_important_att_monitor(enc_att_weights_list, ns_length)
                self._add_dec_last_att_monitor(dec_att_weights_list, ns_length)
                self._add_dec_entropy_monitor(dec_att_weights_list)

            ns_out = tf.concat([self.ns_out_norm_list[idx](x) for idx, x in enumerate(ns_out_list)], axis=-1)
            print('debug info | ns_out: ', ns_out.get_shape())
            ns_out = self.make_input_dim(ns_out, "ns_out", self.d_model)
            item_out = tf.concat([self.item_out_norm_list[idx](x) for idx, x in enumerate(item_out_list)], axis=-1)
            print('debug info | item_out: ', item_out.get_shape())
            item_out = self.make_input_dim(item_out, "item_out", self.d_model)
            seq_masks_out = tf.expand_dims(tf.concat(masks_out, axis=1), axis=-1)
            epsilon = 1e-4
            denominator = tf.reduce_sum(seq_masks_out, axis=1, keepdims=True)
            denominator = tf.maximum(denominator + epsilon, 1.0)
            s_out_masked_mean_list = []
            for idx, s_out in enumerate(s_out_list):
                s_out_masked_mean = tf.reduce_sum(s_out * seq_masks_out, axis=1, keepdims=True) / denominator
                s_out_masked_mean_list.append(self.s_out_norm_list[idx](s_out_masked_mean))
            s_out_masked_mean = tf.concat(s_out_masked_mean_list, axis=-1)
            s_out_masked_mean = self.make_input_dim(s_out_masked_mean, "s_out_masked_mean", self.d_model)

            out = tf.concat([self.out_s_norm(s_out_masked_mean), self.out_ns_norm(ns_out), self.out_item_norm(item_out)], axis=1)

            num_tks = 1 + ns_length + 1
            print('debug info | transformer out: ', out.get_shape(), 'num_tks: ', num_tks)
            share_bottom = tf.reshape(out, [-1, self.d_model * num_tks])
            print('debug info | share_bottom: ', share_bottom.get_shape())
            # ------------------------------------- Transformer ---------------------------------

            shallow_feas = []
            for fea in self.ns_feas:
                shallow_feas.append(fea)

            shallow_feas.append(self.ns_item_emb_norm(item_emb))

            shallow_fea = tf.concat(shallow_feas, axis=-1)
            bottom_fea = tf.concat([share_bottom], axis=-1)
            simtier_fea = tf.concat(self.simtier_feas_list, axis=-1)

            shallow_fea = self.make_input_dim(shallow_fea, "shallow_fea", 256)
            bottom_fea = self.make_input_dim(bottom_fea, "bottom_fea", 256)
            simtier_fea = self.make_input_dim(simtier_fea, "simtier_fea", 128)

            pred_inp = tf.concat([self.shallow_norm(shallow_fea), self.bottom_norm(bottom_fea), self.simtier_norm(simtier_fea)], axis=-1)


            for idx, target in enumerate(self.target_names):
                target_name = "{}_{}_tower".format(phase["name"], target)
                pred = ego.DenseTower(
                                name=target_name,
                                output_dims=[256, 128, 64, 1],
                                kernel_initializers=[self.param_initializer] * 4,
                                bias_initializers=[self.param_initializer] * 4,
                                activations=[tf.nn.leaky_relu, tf.nn.leaky_relu, tf.nn.leaky_relu, tf.nn.sigmoid],
                                norms=[False, False, False, False])(pred_inp)

                node = "{}_{}".format(phase["name"], target)
                output = tf.identity(pred, node)
                label_idx = idx * 2
                label, weight = ego.get_label_weight(target_name="{}_{}_label_weight".format(phase["name"], target), label_idx=label_idx)
                loss = cross_entropy_loss(label, output, target)

                phase["nodes"].append(node)
                phase["outputs"].append(output)
                phase["labels"].append(label)
                phase["weights"].append(weight)
                phase["losses"].append(loss)

    def get_debug_nodes(self):
        print("[debug_nodes] =", self.debug_nodes)
        return self.debug_nodes

    def get_scalar_tensor(self):
        return self.scalar_tensor

    def get_sample_att_weights(self):
        return self.sample_att_weights

    def build_graph(self):
        self.build_inputs()
        self.build_network()
        self.build_targets()
        self.build_loss()
        return self.phases
