#!/usr/bin/env python
# -*- coding: utf-8 -*-

import tensorflow as tf
import ego
import numpy as np


__tf_version = tf.__version__
if __tf_version >= '2.0':
    tf2 = tf
    tf = tf.compat.v1


local_param_initializer = tf.truncated_normal_initializer(stddev=0.001, dtype=tf.float32)
attn_param_initializer = tf.initializers.glorot_uniform()
attn_bias_initializer = tf.zeros_initializer()


def get_shape(inputs):
    dynamic_shape = tf.shape(inputs)
    static_shape = inputs.get_shape().as_list()
    shape = []
    for i, dim in enumerate(static_shape):
        shape.append(dim if dim is not None else dynamic_shape[i])
    return shape


def get_init_op(init_name, param_dicts=None):
    if param_dicts is None:
        param_dicts = {}

    if init_name == "truncated_normal":
        stddev = param_dicts.get("stddev", 0.001)
        return tf.truncated_normal_initializer(stddev=stddev, dtype=tf.float32)
    elif init_name == "random_uniform":
        min_val = param_dicts.get("min_val", -0.05)
        max_val = param_dicts.get("max_val", -0.05)
        return tf.random_uniform_initializer(min_val=min_val, max_val=max_val, dtype=tf.float32)
    elif init_name == "random_normal":
        mean = param_dicts.get("mean", 0.0)
        stddev = param_dicts.get("stddev", 0.05)
        seed = param_dicts.get("seed", 123)
        return tf.random_normal_initializer(mean=mean, stddev=stddev, seed=seed)
    elif init_name == "ones":
        return tf.ones_initializer(dtype=tf.float32)
    elif init_name == "zeros":
        return tf.zeros_initializer(dtype=tf.float32)
    elif init_name == "constant":
        value = param_dicts.get("value", 0.1)
        return tf.constant_initializer(value=value, dtype=tf.float32, verify_shape=True)
    elif init_name == "xavier_normal" or init_name == "glorot_normal":
        return tf.initializers.glorot_normal()
    elif init_name == "xavier_uniform" or init_name == "glorot_uniform":
        return tf.initializers.glorot_uniform()
    else:
        raise ValueError(f"[wrong init_op={init_op}] param_dicts = {param_dicts}")


def get_act_op(act_name, param_dicts=None):
    if param_dicts is None:
        param_dicts = {}
    
    if act_name == "relu":
        return tf.nn.relu
    elif act_name == "relu6":
        return tf.nn.relu6
    elif act_name == "elu":
        return tf.nn.elu
    elif act_name == "selu":
        return tf.nn.selu
    elif act_name == "gelu":
        return tf.nn.gelu #TODO: gelu
    elif act_name == "lrelu":
        return tf.nn.leaky_relu
    elif act_name == "silu":
        return tf.nn.silu
    elif act_name == "tanh":
        return tf.nn.tanh
    elif act_name == "sigmoid":
        return tf.nn.sigmoid
    else:
        raise ValueError(f"[wrong act_name={act_name}] param_dicts = {param_dicts}")



@tf.custom_gradient
def ignore_grad(x):
    def grad(upstream):
        return upstream * 0.0

    return x, grad

def get_ego_layer(layername, dim):
    return ego.DenseTower(
        name=layername,
        output_dims=[dim],
        kernel_initializers=[local_param_initializer] * 1,
        bias_initializers=[local_param_initializer] * 1,
        activations=[None],
        norms=[False],
        use_bias=True,
    )

def get_attn_layer(layername, dim):
    return ego.DenseTower(
        name=layername,
        output_dims=[dim],
        kernel_initializers=[attn_param_initializer],
        bias_initializers=[attn_bias_initializer],
        activations=[None],
        norms=[False],
        use_bias=True,
    )


def positional_encoding(max_position, d_model):
    position = np.arange(max_position)[:, np.newaxis]
    div_term = np.exp(np.arange(0, d_model, 2) * -(np.log(10000.0) / d_model))

    sin_encoding = np.sin(position * div_term)
    cos_encoding = np.cos(position * div_term)

    pos_encoding = np.zeros((max_position, d_model))
    pos_encoding[:, 0::2] = sin_encoding
    pos_encoding[:, 1::2] = cos_encoding

    return tf.cast(pos_encoding, dtype=tf.float32)

class NaiveAttention(tf.keras.layers.Layer):
    def __init__(self, d_model, num_heads, layer_idx, rate=0.1):
        super(NaiveAttention, self).__init__()
        self.num_heads = num_heads
        self.d_model = d_model
        self.depth = d_model // self.num_heads
        ffn_hidden_dim = int(d_model * 4 / 3)
        ffn_hidden_dim = ffn_hidden_dim + (ffn_hidden_dim % 2)
        self.wq = get_attn_layer("Q" + str(layer_idx), d_model)
        self.wk = get_attn_layer("K" + str(layer_idx), d_model)
        self.wv = get_attn_layer("V" + str(layer_idx), d_model)
        self.dense = get_attn_layer("O" + str(layer_idx), d_model)
        self.layernorm1 = RMSNorm()
        self.layernorm2 = RMSNorm()
        self.layernorm3 = RMSNorm()
        self.layernorm4 = RMSNorm()
        self.dropout1 = tf.keras.layers.Dropout(rate)
        self.dropout2 = tf.keras.layers.Dropout(rate)
        self.ffn = SwiGLU(d_model, ffn_hidden_dim, layer_idx=f"naive_{layer_idx}")

    def split_heads(self, x, batch_size, len):
        x = tf.reshape(x, (batch_size, len, self.num_heads, self.depth))
        return tf.transpose(x, perm=[0, 2, 1, 3])

    def call(self, v, k, q, mask, causality, k_len):
        v_ = self.layernorm1(v)
        k_ = self.layernorm2(k)
        q_ = self.layernorm3(q)

        batch_size = get_shape(q_)[0]
        q_ = self.wq(q_)
        k_ = self.wk(k_)
        v_ = self.wv(v_)
        print('debug info | q, k', q.get_shape(), k.get_shape())

        q = self.split_heads(q_, batch_size, 1)
        k = self.split_heads(k_, batch_size, k_len)
        v = self.split_heads(v_, batch_size, k_len)
        print('debug info | q, k', q.get_shape(), k.get_shape())

        attention_output, attention_weights = scaled_dot_product_attention(q, k, v, mask, causality)
        scaled_attention = tf.transpose(attention_output, perm=[0, 2, 1, 3])
        print('debug info | scaled attention', scaled_attention.get_shape())
        concat_attention = tf.reshape(scaled_attention, (batch_size, 1, self.d_model))
        output = self.dense(concat_attention)

        output = self.dropout1(output, training=ego.is_training_mode()) + q_
        output_ = self.layernorm4(output)
        ffn_output = self.ffn(output_)
        ffn_output_f = self.dropout2(ffn_output, training=ego.is_training_mode()) + output

        return ffn_output_f, attention_weights

def scaled_dot_product_attention(q, k, v, mask, causality):
    # (B, num_heads, q_seq, k_seq)
    matmul_qk = tf.matmul(q, k, transpose_b=True)
    dk = tf.shape(k)[-1]
    scaled_attention_logits = matmul_qk / tf.math.sqrt(tf.cast(dk, tf.float32))
    if mask is not None:
        # (B, k_seq)
        paddings = 1.0 - mask
        scaled_attention_logits += (paddings[:, tf.newaxis, tf.newaxis, :] * -1e4)

    if causality:
        id_matrix = tf.ones_like(scaled_attention_logits[0, 0, :, :])
        lower_tril = tf.linalg.LinearOperatorLowerTriangular(id_matrix).to_dense()
        mask = tf.linalg.set_diag(lower_tril, tf.zeros([tf.shape(lower_tril)[0]], dtype=lower_tril.dtype))
        scaled_attention_logits += (mask[tf.newaxis, tf.newaxis, ...] * -1e4)

    attention_weights = tf.nn.softmax(scaled_attention_logits, axis=-1)
    # (B, num_heads, q_seq, k_seq) (B, num_heads, k_seq, dim)
    output = tf.matmul(attention_weights, v) # (B, num_heads, q_seq, dim)
    return output, attention_weights


class RotaryPositionEmbedding(tf.keras.layers.Layer):
    def __init__(self, dim=64, max_seq_len=50, theta=10000.0, **kwargs):
        super().__init__(**kwargs)
        if dim % 2 != 0:
            raise ValueError(f"RoPE要求dim为偶数，但收到dim={dim}")
        self.dim = dim
        self.max_seq_len = max_seq_len
        self.theta = float(theta)

    def build(self, input_shape):
        half_dim = self.dim // 2

        indices = tf.range(0, half_dim, dtype=tf.float32)
        inv_freq = 1.0 / (self.theta ** (2.0 * indices / self.dim))

        positions = tf.range(self.max_seq_len, dtype=tf.float32)

        # equal to tf.matmul(positions[:, tf.newaxis], theta_i[:, tf.newaxis], transpose_b=True)
        angles = tf.einsum('i,j->ij', positions, inv_freq)

        # (max_seq_len, dim / 2)
        self.cos_cached = tf.constant(tf.cos(angles))
        self.sin_cached = tf.constant(tf.sin(angles))
        super().build(input_shape)

    def call(self, x):

        # x shape: [B, H, T, D]
        x_even = x[..., ::2]
        x_odd = x[..., 1::2]

        cos = self.cos_cached[tf.newaxis, tf.newaxis, :, :]
        sin = self.sin_cached[tf.newaxis, tf.newaxis, :, :]

        x_rotated_even = x_even * cos - x_odd * sin
        x_rotated_odd = x_even * sin + x_odd * cos
        # [B, H, T, D/2, 2]
        x_rotated = tf.stack([x_rotated_even, x_rotated_odd], axis=-1)
        x_rotated = tf.reshape(x_rotated, tf.concat([tf.shape(x)[:-1], [self.dim]], axis=0))
        return x_rotated


class LLaMARoPE(tf.keras.layers.Layer):
    def __init__(self, dim=64, max_seq_len=50, base=10000, scaling_factor=1.0, **kwargs):
        super().__init__(**kwargs)
        if dim % 2 != 0:
            raise ValueError("dim must be even")
        self.dim = dim
        self.max_position_embeddings = max_seq_len
        self.base = base
        self.scaling_factor = scaling_factor

    def build(self, input_shape):
        half_dim = self.dim // 2
        # 预计算 inv_freq
        inv_freq = 1.0 / (self.base ** (tf.range(0, self.dim, 2, dtype=tf.float32) / self.dim))
        t = tf.range(self.max_position_embeddings, dtype=tf.float32) / self.scaling_factor
        # [max_seq_len, half_dim]
        freqs = tf.einsum('i,j->ij', t, inv_freq)
        emb = tf.concat([freqs, freqs], axis=-1)       # [max_seq_len, dim]
        # 预计算 cos/sin 缓存
        self.cos_cached = tf.cos(emb)
        self.sin_cached = tf.sin(emb)
        super().build(input_shape)

    def call(self, x):
        """
        x: [batch, num_heads, seq_len, head_size] or [batch, seq_len, dim]
        """
        x1 = x[..., : self.dim // 2]
        x2 = x[..., self.dim // 2:]
        x_rotated = tf.concat([-x2, x1], axis=-1)
        cos = self.cos_cached[tf.newaxis, tf.newaxis, :, :]
        sin = self.sin_cached[tf.newaxis, tf.newaxis, :, :]
        return x * cos + x_rotated * sin


class RMSNorm(tf.keras.layers.Layer):
    def __init__(self, epsilon=1e-6, **kwargs):
        super(RMSNorm, self).__init__(**kwargs)
        self.epsilon = epsilon

    def build(self, input_shape):
        dim = input_shape[-1]
        self.gamma = self.add_weight(
            name='RMSNorm_gamma',
            shape=(dim,),
            initializer=tf.ones_initializer(),
            trainable=True
        )
        super().build(input_shape)

    def call(self, x):
        rms = tf.sqrt(tf.reduce_mean(tf.square(x), axis=-1, keepdims=True) + self.epsilon)
        return self.gamma * (x / rms)


class EncoderCrossAttention(tf.keras.layers.Layer):
    def __init__(self, d_model, num_heads, ns_length, layer_idx, s_length):
        super(EncoderCrossAttention, self).__init__()
        self.num_heads = num_heads
        self.d_model = d_model
        self.ns_length = ns_length
        self.depth = d_model // self.num_heads
        self.wq_s = get_attn_layer("Q_S" + str(layer_idx), d_model)
        self.wk_s = get_attn_layer("K_S" + str(layer_idx), d_model)
        self.wv_s = get_attn_layer("V_S" + str(layer_idx), d_model)

        self.kernel_initializer = tf.keras.initializers.get("glorot_uniform")
        self.kernel_regularizer = tf.keras.regularizers.get(None)
        self.kernel_constraint = tf.keras.constraints.get(None)
        self.q_ns_kernel = self.add_weight(
            name="query_kernel",
            shape=[self.ns_length, self.d_model, self.d_model],
            initializer=self.kernel_initializer,
            regularizer=self.kernel_regularizer,
            constraint=self.kernel_constraint,
        )
        self.k_ns_kernel = self.add_weight(
            name="key_kernel",
            shape=[self.ns_length, self.d_model, self.d_model],
            initializer=self.kernel_initializer,
            regularizer=self.kernel_regularizer,
            constraint=self.kernel_constraint,
        )
        self.v_ns_kernel = self.add_weight(
            name="value_kernel",
            shape=[self.ns_length, self.d_model, self.d_model],
            initializer=self.kernel_initializer,
            regularizer=self.kernel_regularizer,
            constraint=self.kernel_constraint,
        )

        self.dense = get_attn_layer("O" + str(layer_idx), d_model)

    def split_heads(self, x, batch_size, len):
        x = tf.reshape(x, (batch_size, len, self.num_heads, self.depth))
        return tf.transpose(x, perm=[0, 2, 1, 3])

    def call(self, s_input, ns_input, enc_attn_mask=None):
        batch_size = get_shape(ns_input)[0]
        s_len, ns_len = get_shape(s_input)[1], get_shape(ns_input)[1]

        q_ns = tf.einsum('bij,ijk->bik', ns_input, self.q_ns_kernel)
        k_ns = tf.einsum('bij,ijk->bik', ns_input, self.k_ns_kernel)
        v_ns = tf.einsum('bij,ijk->bik', ns_input, self.v_ns_kernel)

        q_s = self.wq_s(s_input)
        k_s = self.wk_s(s_input)
        v_s = self.wv_s(s_input)

        q_ns_h = self.split_heads(q_ns, batch_size, ns_len)
        k_ns_h = self.split_heads(k_ns, batch_size, ns_len)
        v_ns_h = self.split_heads(v_ns, batch_size, ns_len)

        q_s_h = self.split_heads(q_s, batch_size, s_len)
        k_s_h = self.split_heads(k_s, batch_size, s_len)
        v_s_h = self.split_heads(v_s, batch_size, s_len)

        q = tf.concat([q_ns_h, q_s_h], axis=2)
        k = tf.concat([k_ns_h, k_s_h], axis=2)
        v = tf.concat([v_ns_h, v_s_h], axis=2)

        attention_output, attention_weights = scaled_dot_product_attention(q, k, v, mask=enc_attn_mask, causality=False)
        att_mean = tf.reduce_mean(attention_weights, axis=1)
        scaled_attention = tf.transpose(attention_output, perm=[0, 2, 1, 3])
        concat_attention = tf.reshape(scaled_attention, (batch_size, -1, self.d_model))
        output_cur = self.dense(concat_attention)

        part_ns, part_s = tf.split(output_cur, [ns_len, s_len], 1)
        return part_ns, part_s, att_mean



class DecoderCrossAttention(tf.keras.layers.Layer):
    def __init__(self, d_model, num_heads, ns_length, layer_idx, s_length):
        super(DecoderCrossAttention, self).__init__()
        self.num_heads = num_heads
        self.d_model = d_model
        self.ns_length = ns_length
        self.depth = d_model // self.num_heads

        self.wq_item = get_attn_layer("Q_ITEM" + str(layer_idx), d_model)
        self.wk_item = get_attn_layer("K_ITEM" + str(layer_idx), d_model)
        self.wv_item = get_attn_layer("V_ITEM" + str(layer_idx), d_model)

        self.wk_s = get_attn_layer("K_S" + str(layer_idx), d_model)
        self.wv_s = get_attn_layer("V_S" + str(layer_idx), d_model)

        self.kernel_initializer = tf.keras.initializers.get("glorot_uniform")
        self.kernel_regularizer = tf.keras.regularizers.get(None)
        self.kernel_constraint = tf.keras.constraints.get(None)

        self.k_ns_kernel = self.add_weight(
            name="key_kernel",
            shape=[self.ns_length, self.d_model, self.d_model],
            initializer=self.kernel_initializer,
            regularizer=self.kernel_regularizer,
            constraint=self.kernel_constraint,
        )
        self.v_ns_kernel = self.add_weight(
            name="value_kernel",
            shape=[self.ns_length, self.d_model, self.d_model],
            initializer=self.kernel_initializer,
            regularizer=self.kernel_regularizer,
            constraint=self.kernel_constraint,
        )

        self.dense = get_attn_layer("O" + str(layer_idx), d_model)

    def split_heads(self, x, batch_size, len):
        x = tf.reshape(x, (batch_size, len, self.num_heads, self.depth))
        return tf.transpose(x, perm=[0, 2, 1, 3])


    def call(self, s_input, ns_input, item_input, cache, training, dec_attn_mask=None):
        batch_size = get_shape(s_input)[0]
        bs_q = get_shape(item_input)[0]
        s_len, ns_len = get_shape(s_input)[1], get_shape(ns_input)[1]

        if training or cache is None:
            k_ns = tf.einsum('bij,ijk->bik', ns_input, self.k_ns_kernel)
            v_ns = tf.einsum('bij,ijk->bik', ns_input, self.v_ns_kernel)

            k_s = self.wk_s(s_input)
            v_s = self.wv_s(s_input)

            q_item = self.wq_item(item_input)
            k_item = self.wk_item(item_input)
            v_item = self.wv_item(item_input)

            k_ns_h = self.split_heads(k_ns, batch_size, ns_len)
            v_ns_h = self.split_heads(v_ns, batch_size, ns_len)
            k_s_h = self.split_heads(k_s, batch_size, s_len)
            v_s_h = self.split_heads(v_s, batch_size, s_len)

            k = tf.concat([k_ns_h, k_s_h], axis=2)
            v = tf.concat([v_ns_h, v_s_h], axis=2)

            if not training:
                cache = {'k': k, 'v': v}
            k_cur, v_cur = k, v
        else:
            k_cur, v_cur = cache['k'], cache['v']

        q_final = self.split_heads(q_item, bs_q, 1)
        k_final = tf.concat([self.split_heads(k_item, bs_q, 1), k_cur], axis=2)
        v_final = tf.concat([self.split_heads(v_item, bs_q, 1), v_cur], axis=2)

        attention_output_tar, attention_weights = scaled_dot_product_attention(q_final, k_final, v_final, dec_attn_mask, False)
        scaled_attention_tar = tf.transpose(attention_output_tar, perm=[0, 2, 1, 3])
        concat_attention_ns = tf.reshape(scaled_attention_tar, (bs_q, 1, self.d_model))
        output_tar = self.dense(concat_attention_ns)

        return output_tar, attention_weights



class SwiGLU(tf.keras.layers.Layer):
    """
    SwiGLU FFN: gate_proj(x) * silu(up_proj(x)) -> down_proj.

    ffn_type="share_all"  : single set of weights shared across all tokens.
    ffn_type="per_token"  : independent weights per token position (num_token sets).
    """
    def __init__(self, d_model, hidden_dim, layer_idx, ffn_type="share_all", num_token=1,
                 init_op="glorot_uniform", **kwargs):
        super().__init__(**kwargs)
        assert ffn_type in ("share_all", "per_token")
        self.ffn_type = ffn_type
        self.num_token = num_token
        print(f"[SwiGLU {ffn_type}] d_model={d_model}, hidden={hidden_dim}, layer={layer_idx}")

        def _make(prefix):
            gate = ego.DenseTower(
                name=f"{prefix}_gate", output_dims=[hidden_dim],
                kernel_initializers=[get_init_op(init_op)],
                bias_initializers=[get_init_op("zeros")],
                activations=[None], norms=[False], use_bias=[True],
            )
            up = ego.DenseTower(
                name=f"{prefix}_up", output_dims=[hidden_dim],
                kernel_initializers=[get_init_op(init_op)],
                bias_initializers=[get_init_op("zeros")],
                activations=[None], norms=[False], use_bias=[True],
            )
            down = ego.DenseTower(
                name=f"{prefix}_down", output_dims=[d_model],
                kernel_initializers=[get_init_op(init_op)],
                bias_initializers=[get_init_op("zeros")],
                activations=[None], norms=[False], use_bias=[True],
            )
            return gate, up, down

        if ffn_type == "share_all":
            self.gate_proj, self.up_proj, self.down_proj = _make(f"swiglu_{layer_idx}")
        else:
            projs = [_make(f"swiglu_{layer_idx}_{t}") for t in range(num_token)]
            self.gate_projs = [p[0] for p in projs]
            self.up_projs   = [p[1] for p in projs]
            self.down_projs = [p[2] for p in projs]

    def call(self, x):
        if self.ffn_type == "share_all":
            return self.down_proj(self.gate_proj(x) * tf.nn.silu(self.up_proj(x)))
        else:
            chunks = tf.split(x, self.num_token, axis=1)
            outs = [d(g(c) * tf.nn.silu(u(c)))
                    for c, g, u, d in zip(chunks, self.gate_projs, self.up_projs, self.down_projs)]
            return tf.concat(outs, axis=1)




class Encoder(tf.keras.layers.Layer):
    def __init__(self, d_model, num_heads, ns_length, num_layers, s_length, use_res=True, mix_ln=True, rate=0.1):
        super(Encoder, self).__init__()
        self.d_model = d_model
        ffn_hidden_dim = int(d_model * 4 / 3)
        ffn_hidden_dim = ffn_hidden_dim + (ffn_hidden_dim % 2)
        self.mha_list = [EncoderCrossAttention(d_model, num_heads, ns_length, layer_idx, s_length) for layer_idx in range(num_layers)]
        self.s_ffn_list = [SwiGLU(d_model, ffn_hidden_dim, layer_idx=layer_idx, ffn_type="share_all") for layer_idx in range(num_layers)]
        self.ns_ffn_list = [SwiGLU(d_model, ffn_hidden_dim, layer_idx=layer_idx, ffn_type="per_token", num_token=ns_length) for layer_idx in range(num_layers)]
        self.s_ln1_list = [RMSNorm() for _ in range(num_layers)]
        self.ns_ln1_list = [RMSNorm() for _ in range(num_layers)]
        self.s_ln2_list = [RMSNorm() for _ in range(num_layers)]
        self.ns_ln2_list = [RMSNorm() for _ in range(num_layers)]
        self.s_final_norm = RMSNorm()
        self.ns_final_norm = RMSNorm()
        self.attn_dropout_list = [tf.keras.layers.Dropout(rate) for _ in range(num_layers)]
        self.ffn_dropout_list  = [tf.keras.layers.Dropout(rate) for _ in range(num_layers)]


        self.kernel_initializer = tf.keras.initializers.get("glorot_uniform")
        self.kernel_regularizer = tf.keras.regularizers.get(None)
        self.kernel_constraint = tf.keras.constraints.get(None)

    def call(self, x_s, x_ns, enc_attn_mask=None):
        enc_att_weights_list = []
        for i, (mhtm_layer, s_ffn, ns_ffn, s_ln1, ns_ln1, s_ln2, ns_ln2, attn_drop, ffn_drop) in enumerate(
                zip(self.mha_list, self.s_ffn_list, self.ns_ffn_list,
                    self.s_ln1_list, self.ns_ln1_list, self.s_ln2_list, self.ns_ln2_list,
                    self.attn_dropout_list, self.ffn_dropout_list)):
            mth_x_ns, mth_x_s, att_weights = mhtm_layer(s_ln1(x_s), ns_ln1(x_ns), enc_attn_mask)
            enc_att_weights_list.append(att_weights)
            x_s = x_s + attn_drop(mth_x_s, training=ego.is_training_mode())
            x_ns = x_ns + attn_drop(mth_x_ns, training=ego.is_training_mode())

            x_s = x_s + ffn_drop(s_ffn(s_ln2(x_s)), training=ego.is_training_mode())
            x_ns = x_ns + ffn_drop(ns_ffn(ns_ln2(x_ns)), training=ego.is_training_mode())

            print(f"[FAT{i}]", x_s, x_ns)
        return self.s_final_norm(x_s), self.ns_final_norm(x_ns), enc_att_weights_list

class Decoder(tf.keras.layers.Layer):
    def __init__(self, d_model, num_heads, ns_length, num_layers, s_length, use_res=True, mix_ln=True, rate=0.1):
        super(Decoder, self).__init__()
        self.d_model = d_model
        ffn_hidden_dim = int(d_model * 4 / 3)
        self.mha_list = [DecoderCrossAttention(d_model, num_heads, ns_length, layer_idx, s_length) for layer_idx in range(num_layers)]
        # self.s_ffn_list = [SwiGLU(d_model, ffn_hidden_dim, layer_idx=layer_idx, ffn_type="per_token", num_token=...) for layer_idx in range(num_layers)]
        self.ffn_list = [SwiGLU(d_model, ffn_hidden_dim, layer_idx=layer_idx, ffn_type="share_all") for layer_idx in range(num_layers)]
        self.s_ln1_list = [RMSNorm() for _ in range(num_layers)]
        self.ns_ln1_list = [RMSNorm() for _ in range(num_layers)]
        self.item_ln1_list = [RMSNorm() for _ in range(num_layers)]
        self.item_ln2_list = [RMSNorm() for _ in range(num_layers)]
        self.ns_length = ns_length
        self.use_res = use_res
        self.mix_ln = mix_ln
        self.attn_dropout_list = [tf.keras.layers.Dropout(rate) for _ in range(num_layers)]
        self.ffn_dropout_list  = [tf.keras.layers.Dropout(rate) for _ in range(num_layers)]

        self.kernel_initializer = tf.keras.initializers.get("glorot_uniform")
        self.kernel_regularizer = tf.keras.regularizers.get(None)
        self.kernel_constraint = tf.keras.constraints.get(None)

    def call(self, x_s, x_ns, x_item, cache, training, dec_attn_mask=None):
        x_item_dec_out_list = []
        dec_att_weights_list = []

        for i, (mhtm_layer, ffn, s_ln1, ns_ln1, item_ln1, item_ln2, attn_drop, ffn_drop) in enumerate(
                zip(self.mha_list, self.ffn_list,
                    self.s_ln1_list, self.ns_ln1_list, self.item_ln1_list, self.item_ln2_list,
                    self.attn_dropout_list, self.ffn_dropout_list)):
            mth_x_item, att_weights = mhtm_layer(s_ln1(x_s), ns_ln1(x_ns), item_ln1(x_item), cache[i], training, dec_attn_mask)
            dec_att_weights_list.append(att_weights)
            x_item = x_item + attn_drop(mth_x_item, training=ego.is_training_mode())
            x_item = x_item + ffn_drop(ffn(item_ln2(x_item)), training=ego.is_training_mode())
            x_item_dec_out_list.append(x_item)

        return x_item_dec_out_list, dec_att_weights_list


MAX_NS_LENGTH = 64  # max ns tokens for position_emb_ns (variable ns_length)


class Transformer(tf.keras.layers.Layer):
    def __init__(self, num_layers, d_model, num_heads, ns_length, s_length):
        super(Transformer, self).__init__()
        self.d_model = d_model
        self.num_layers = num_layers
        self.ns_length = ns_length
        self.enc = Encoder(d_model, num_heads, ns_length, num_layers, s_length)
        self.dec = Decoder(d_model, num_heads, ns_length, num_layers, s_length)

        self.proj_layer_s = []
        self.sep_embs = []
        self.proj_layer_q = get_ego_layer("proj_layer_q", d_model)
        self.kernel_initializer = tf.keras.initializers.get("glorot_uniform")
        self.kernel_regularizer = tf.keras.regularizers.get(None)
        self.kernel_constraint = tf.keras.constraints.get(None)
        self.dec_in_norm_s_init = RMSNorm()
        self.dec_in_norm_ns_init = RMSNorm()
        self.position_emb_s = self.add_weight(
            name='position_emb_s', shape=(s_length, d_model),
            initializer=local_param_initializer, trainable=True)
        self.position_emb_ns = self.add_weight(
            name='position_emb_ns', shape=(ns_length, d_model),
            initializer=local_param_initializer, trainable=True)

    def make_input_dim(self, emb, name, dim):
        return ego.DenseTower(
            name=name,
            output_dims=[dim],
            kernel_initializers=[self.kernel_initializer],
            bias_initializers=[self.kernel_initializer],
            activations=[tf.nn.leaky_relu],
        )(emb)

    def call(self, inputs, training = True):
        x_s, x_ns, x_item, caches = inputs[:4]
        dec_attn_mask = inputs[4] if len(inputs) > 4 else None
        enc_attn_mask = inputs[5] if len(inputs) > 5 else None
        x_s_initial = x_s
        x_ns_initial = x_ns

        x_s = x_s + tf.expand_dims(self.position_emb_s, axis=0)
        x_ns = x_ns + tf.expand_dims(self.position_emb_ns, axis=0)

        x_s_enc_out, x_ns_enc_out, enc_att_weights_list = self.enc(x_s_initial, x_ns_initial, enc_attn_mask)

        x_ns_dec_in = tf.concat([self.dec_in_norm_ns_init(x_ns_initial), x_ns_enc_out], axis=-1)
        x_s_dec_in = tf.concat([self.dec_in_norm_s_init(x_s_initial), x_s_enc_out], axis=-1)
        x_s_dec_in = self.make_input_dim(x_s_dec_in, "x_s_dec_in", self.d_model)
        x_ns_dec_in = self.make_input_dim(x_ns_dec_in, "x_ns_dec_in", self.d_model)

        x_item_dec_out_list, dec_att_weights_list = self.dec(x_s_dec_in, x_ns_dec_in, x_item, caches, training, dec_attn_mask)

        x_s_out_list = [x_s_initial, x_s_dec_in]
        x_ns_out_list = [x_ns_initial, x_ns_dec_in]
        x_item_out_list = [x_item] + x_item_dec_out_list

        return x_s_out_list, x_ns_out_list, x_item_out_list, enc_att_weights_list, dec_att_weights_list


