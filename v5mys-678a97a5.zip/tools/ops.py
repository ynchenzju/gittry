import tensorflow as tf
import ego
import tensorflow.python.keras.layers
from ego import DenseTower


class RMSNorm(tf.keras.layers.Layer):
    def __init__(self, epsilon=1e-6, **kwargs):
        super(RMSNorm, self).__init__(**kwargs)
        self.epsilon = epsilon

    def build(self, input_shape):
        dim = input_shape[-1]
        self.gamma = self.add_weight(
            name='RMSNorm_gamma',
            shape=(dim,),
            initializer=tf.ones_initializer(),
            trainable=True
        )
        super().build(input_shape)

    def call(self, x):
        rms = tf.sqrt(tf.reduce_mean(tf.square(x), axis=-1, keepdims=True) + self.epsilon)
        return self.gamma * (x / rms)

def mask_block(
        name,
        emb_input,
        hidden_input,
        hidden_dim,
        output_dim,
        param_initializer,
        activation_fn=None,
        ratio=0.5,
        region='other'
):
    if hidden_input is None:
        hidden_input = emb_input  # B * ( Length * Field ) BN

    mask_gate = DenseTower(name='Mask_Net_Gate_Proj_{}_1_{}'.format(name, region),
                           output_dims=[int(hidden_dim*ratio), hidden_dim],
                           kernel_initializers=[param_initializer]*2,
                           bias_initializers=[param_initializer]*2,
                           activations=[activation_fn, None],
                           norms=[False, False])(hidden_input)
    v_masked = hidden_input * mask_gate

    v_masked_ = DenseTower(name='Mask_Net_gate_Proj_{}_2_{}'.format(name, region),
                           output_dims=[output_dim],
                           activations=[None],
                           norms=[False])(v_masked)

    return tf.nn.leaky_relu(tf.keras.layers.LayerNormalization(axis=1)(v_masked_))

