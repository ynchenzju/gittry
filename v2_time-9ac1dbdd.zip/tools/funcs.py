import tensorflow as tf
import ego
from ego import DenseTower, Normalization, BatchNormalization
from collections import defaultdict
from tensorflow.keras.layers import Dense
from tensorflow.python.keras.layers import Dense, Lambda, Layer
from .parallel_ffn import ParallelDenseTower


def convert_pooling(p):
    if p == 'sum' or p == ego.Pooling.SUM:
        return ego.Pooling.SUM
    elif p == 'avg' or p == ego.Pooling.AVG:
        return ego.Pooling.AVG
    elif p == 'max' or p == ego.Pooling.MAX:
        return ego.Pooling.MAX
    elif p == 'min' or p == ego.Pooling.MIN:
        return ego.Pooling.MIN
    elif p == 'tile' or p == ego.Pooling.TILE:
        return ego.Pooling.TILE
    elif p == 'tile_nf' or p == ego.Pooling.TILE_NF:
        return ego.Pooling.TILE_NF
    else:
        print(p)
        print("pooling method not implemented")
        exit()

def cal_cosine_similarity(name, x, y):
    """
    :param
        x: B * H
        y: B * H
    :return:
    """
    assert x.get_shape().as_list()[1] == y.get_shape().as_list()[1]
    norm_x = tf.nn.l2_normalize(x, axis=-1, name="{}_x".format(name))
    norm_y = tf.nn.l2_normalize(y, axis=-1, name="{}_x".format(name))
    output = tf.reduce_sum(tf.multiply(norm_x, norm_y), axis=-1, keepdims=True, name=name)
    return output


def bin_bucket_layer(name, x, bin_range, nbins):
    """
    :input
        feature: B * H
        bin_range: P
        nbins: integer
    :return:
        output: B * H
    """
    output = tf.histogram_fixed_width_bins(values=x, value_range=bin_range, nbins=nbins, name=name)
    return output

def replace_gradient(x):

    @tf.custom_gradient
    def stop_gradient(x):

        def grad(upstream):
            return upstream * 0.0

        return x, grad

    return stop_gradient(x)


def compute_kd_loss(teacher_logits, student_logits, temperature=1.0, reduction="mean", name=None):
    """Knowledge distillation loss for binary (1-d) and multi-class logits."""
    with tf.name_scope(name or "kd_loss"):
        temperature = tf.cast(temperature, tf.float32)
        teacher_logits = tf.cast(tf.stop_gradient(teacher_logits), tf.float32)
        student_logits = tf.cast(student_logits, tf.float32)

        def reduce_loss(loss):
            if reduction == "sum":
                return tf.reduce_sum(loss)
            if reduction == "none":
                return loss
            return tf.reduce_mean(loss)

        def binary_loss():
            teacher_prob = tf.stop_gradient(tf.nn.sigmoid(teacher_logits / temperature))
            loss = tf.nn.sigmoid_cross_entropy_with_logits(
                labels=teacher_prob,
                logits=student_logits / temperature
            )
            return reduce_loss(loss * tf.square(temperature))

        def multiclass_loss():
            teacher_prob = tf.stop_gradient(tf.nn.softmax(teacher_logits / temperature, axis=-1))
            student_log_prob = tf.nn.log_softmax(student_logits / temperature, axis=-1)
            loss = -tf.reduce_sum(teacher_prob * student_log_prob, axis=-1, keepdims=True)
            return reduce_loss(loss * tf.square(temperature))

        logits_dim = teacher_logits.shape.as_list()[-1]
        if logits_dim == 1:
            kd_loss = binary_loss()
        elif logits_dim is not None:
            kd_loss = multiclass_loss()
        else:
            kd_loss = tf.cond(
                tf.equal(tf.shape(teacher_logits)[-1], 1),
                lambda: binary_loss(),
                lambda: multiclass_loss(),
            )

        return tf.identity(kd_loss, name=name or "kd_loss")


def ppnet_unit(dim, phase, target, nn_input,  ppnet_inputs, param_initializer):
    share_bottom = DenseTower(name='p{}_{}_bottom_{}'.format(phase, target, dim),
                                   output_dims=[dim],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[tf.nn.relu],
                                   norms=[False])(nn_input)
    ppnet = DenseTower(name='p{}_{}_ppnet_{}'.format(phase, target, dim),
                            output_dims=[dim//2, dim],
                            kernel_initializers=param_initializer,
                            bias_initializers=param_initializer,
                            activations=[tf.nn.relu, None],
                            norms=[False, False])(ppnet_inputs)
    return 2 * tf.nn.sigmoid(tf.clip_by_value(ppnet, -1000, 1000)) * share_bottom


def multihead_target_attention_new(
    queries,
    keys,
    values,
    num_units=None,
    num_output_units=None,
    activation_fn=None,
    num_heads=8,
    name="multihead_target_attention",
    key_masks=None
):
    if num_units is None:
        num_units = queries.get_shape().as_list()[-1]
    query_len = queries.get_shape().as_list()[1]
    query_dim = queries.get_shape().as_list()[-1]
    key_len = keys.get_shape().as_list()[1]
    key_dim = keys.get_shape().as_list()[-1]
    value_dim = values.get_shape().as_list()[-1]

    queries_2d = tf.reshape(queries, [-1, query_dim])
    keys_2d = tf.reshape(keys, [-1, key_dim])
    values_2d = tf.reshape(values, [-1, value_dim])

    Q = DenseTower(
        name="{}_ln_proj_q".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(queries_2d)
    Q = tf.reshape(Q, [-1, query_len, num_units])
    K = DenseTower(
        name="{}_ln_proj_k".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(keys_2d)
    K = tf.reshape(K, [-1, key_len, num_units])
    V = DenseTower(
        name="{}_ln_proj_v".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(values_2d)
    V = tf.reshape(V, [-1, key_len, num_units])

    key_masks_ = tf.tile(
        tf.reshape(key_masks, [-1, 1, 1, key_len]), [1, num_heads, query_len, 1]
    )

    Q_ = tf.stack(tf.split(Q, num_heads, axis=2), axis=1)
    K_ = tf.stack(tf.split(K, num_heads, axis=2), axis=1)
    V_ = tf.stack(tf.split(V, num_heads, axis=2), axis=1)

    Q_ = tf.reshape(Q_, [-1, query_len, int(num_units / num_heads)])
    K_ = tf.reshape(K_, [-1, key_len, int(num_units / num_heads)])

    Q_ = tf.keras.layers.LayerNormalization(axis=-1)(Q_)
    K_ = tf.keras.layers.LayerNormalization(axis=-1)(K_)

    Q_ = tf.reshape(Q_, [-1, num_heads, query_len, int(num_units / num_heads)])
    K_ = tf.reshape(K_, [-1, num_heads, key_len, int(num_units / num_heads)])

    feature_map = tf.matmul(Q_, K_, transpose_b=True)
    feature_map = feature_map * ((num_units//num_heads) ** (-0.5))

    paddings = tf.fill(
        tf.shape(feature_map), tf.constant(-(2 ** 20) + 1, dtype=tf.float32)
    )
    feature_map = tf.where(key_masks_ > 0, feature_map, paddings)
    feature_map = tf.nn.softmax(feature_map)

    outputs = tf.matmul(feature_map, V_)
    outputs = tf.concat(tf.unstack(outputs, axis=1), axis=-1)
    return outputs, feature_map

def multihead_target_attention(
    queries,
    keys,
    values,
    num_units=None,
    num_output_units=None,
    activation_fn=None,
    num_heads=8,
    name="multihead_target_attention",
    key_masks=None
):
    if num_units is None:
        num_units = queries.get_shape().as_list()[-1]
    query_len = queries.get_shape().as_list()[1]
    query_dim = queries.get_shape().as_list()[-1]
    key_len = keys.get_shape().as_list()[1]
    key_dim = keys.get_shape().as_list()[-1]
    value_dim = values.get_shape().as_list()[-1]

    queries_2d = tf.reshape(queries, [-1, query_dim])
    keys_2d = tf.reshape(keys, [-1, key_dim])
    values_2d = tf.reshape(values, [-1, value_dim])

    Q = DenseTower(
        name="{}_ln_proj_q".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(queries_2d)
    Q = tf.reshape(Q, [-1, query_len, num_units])
    K = DenseTower(
        name="{}_ln_proj_k".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(keys_2d)
    K = tf.reshape(K, [-1, key_len, num_units])
    V = DenseTower(
        name="{}_ln_proj_v".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(values_2d)
    V = tf.reshape(V, [-1, key_len, num_units])

    key_masks_ = tf.tile(
        tf.reshape(key_masks, [-1, 1, 1, key_len]), [1, num_heads, query_len, 1]
    )

    Q_ = tf.stack(tf.split(Q, num_heads, axis=2), axis=1)
    K_ = tf.stack(tf.split(K, num_heads, axis=2), axis=1)
    V_ = tf.stack(tf.split(V, num_heads, axis=2), axis=1)

    Q_ = tf.reshape(Q_, [-1, query_len, int(num_units / num_heads)])
    K_ = tf.reshape(K_, [-1, key_len, int(num_units / num_heads)])

    Q_ = tf.keras.layers.LayerNormalization(axis=1)(Q_)
    K_ = tf.keras.layers.LayerNormalization(axis=1)(K_)

    Q_ = tf.reshape(Q_, [-1, num_heads, query_len, int(num_units / num_heads)])
    K_ = tf.reshape(K_, [-1, num_heads, key_len, int(num_units / num_heads)])

    feature_map = tf.matmul(Q_, K_, transpose_b=True)
    feature_map = feature_map * (num_units ** (-0.5))

    paddings = tf.fill(
        tf.shape(feature_map), tf.constant(-(2 ** 20) + 1, dtype=tf.float32)
    )
    feature_map = tf.where(key_masks_ > 0, feature_map, paddings)
    feature_map = tf.nn.softmax(feature_map)

    outputs = tf.matmul(feature_map, V_)
    outputs = tf.concat(tf.unstack(outputs, axis=1), axis=-1)
    return outputs, feature_map

def target_attention_new(sequence_name, query, key, mask, hidden_dim=64, shared_input=False, activation_fn=None):
    ta_output, ta_feature_map = multihead_target_attention_new(
        queries=query,
        keys=key,
        values=key,
        num_units=hidden_dim,
        activation_fn=None,
        key_masks=mask,
        name="{}_ta".format(sequence_name),
    )
    ta_output = tf.squeeze(ta_output, 1)
    ta_feature_map = tf.squeeze(ta_feature_map,2)
    return ta_output, ta_feature_map

def target_attention(sequence_name, query, key, mask, hidden_dim=64, shared_input=False):
    ta_output, ta_feature_map = multihead_target_attention(
        queries=query,
        keys=key,
        values=key,
        num_units=hidden_dim,
        activation_fn=None,
        key_masks=mask,
        name="{}_ta".format(sequence_name),
    )
    ta_output = tf.squeeze(ta_output, 1)
    return ta_output

def seq_pooling(sequence_name, inputs, mask, hidden_dim=64):
    seq_ln = DenseTower(
        name="seq_pooling_{}".format(sequence_name),
        output_dims=[hidden_dim],
        activations=[None],
    )(inputs)
    res = tf.reduce_mean(seq_ln * tf.expand_dims(mask, axis=-1), axis=1)
    return res

def get_custom_feature(slot_list, non_shared_batch_size, shared_batch_size):
    # TODO
    # only for sum features
    customized_feature_list = []
    for slot in slot_list:
        shared_feature_idx = start_idx_for_sum_shared_slot_dict.get(slot, -1)
        iterable_feature_idx = start_idx_for_sum_iterable_slot_dict.get(slot, -1)

        if shared_feature_idx != -1:
            shared_feature = sum_shared_slot_embs[:, shared_feature_idx:shared_feature_idx+slot_dim_dict[slot]]
            customized_feature_list.append(shared_feature)
        elif iterable_feature_idx != -1:
            iterable_feature = sum_iterable_slot_embs[:, iterable_feature_idx:iterable_feature_idx+slot_dim_dict[slot]]
            customized_feature_list.append(iterable_feature)
        else:
            raise ("slot not in shared or iterable feature dict: {slot}".format(slot))
    return customized_feature_list  #  bxn list


def get_hp_result(feature_l, feature_r, dim, name, cosine_flag=False):
    param_initializer = tf.keras.initializers.TruncatedNormal(stddev=0.001)
    feature_l = tf.clip_by_value(Normalization('p{}_norm_l'.format(name))(feature_l), -5, 5)
    feature_l_aligned = DenseTower(name='p{}_algin_dim_l'.format(name),
                           output_dims=[dim],
                           kernel_initializers=param_initializer,
                           bias_initializers=param_initializer,
                           activations=[None],
                           norms=[False])(feature_l)
    feature_r = tf.clip_by_value(Normalization('p{}_norm_r'.format(name))(feature_r), -5, 5)
    feature_r_aligned = DenseTower(name='p{}_algin_dim_r'.format(name),
                           output_dims=[dim],
                           kernel_initializers=param_initializer,
                           bias_initializers=param_initializer,
                           activations=[None],
                           norms=[False])(feature_r)
    if cosine_flag:
        cosine_score = cal_cosine_similarity(name='{}_cosine'.format(name), x=feature_l_aligned, y=feature_r_aligned)
        return feature_l_aligned * feature_r_aligned, cosine_score
    else:
        return feature_l_aligned * feature_r_aligned



def simple_concat(inputs):
    return tf.concat(inputs, axis=1, name="gate_net/input_concat")
 
 
def simple_stat(inputs):
    input_lst = []
    for _input in inputs:
        input_lst.append(tf.reduce_sum(_input, axis=-1, keepdims=True))
        input_lst.append(tf.reduce_mean(_input, axis=-1, keepdims=True))
        input_lst.append(tf.reduce_max(_input, axis=-1, keepdims=True))
        input_lst.append(tf.reduce_min(_input, axis=-1, keepdims=True))
    return tf.concat(input_lst, axis=1, name="gate_net/input_concat")
 
 
def concat_with_stat(inputs):
    input_lst = []
    for _input in inputs:
        input_lst.append(_input)
        input_lst.append(tf.reduce_sum(_input, axis=-1, keepdims=True))
        input_lst.append(tf.reduce_mean(_input, axis=-1, keepdims=True))
        input_lst.append(tf.reduce_max(_input, axis=-1, keepdims=True))
        input_lst.append(tf.reduce_min(_input, axis=-1, keepdims=True))
    return tf.concat(input_lst, axis=1, name="gate_net/input_concat")
 
 
def simple_lhuc_network(inputs, scen_slot_emb, layer1_dim, layer2_dim, name):
    param_initializer = tf.keras.initializers.TruncatedNormal(stddev=0.001)
    # param_initializer = tf.zeros_initializer()
    with tf.name_scope("{}_lhuc".format(name)):
        # output1 = Dense('slot_gatenet_layer{}'.format(1), layer1_dim, kernel_initializer=param_initializer,
        #                   bias_initializer=param_initializer)(inputs)
        output1 = Dense(name='slot_gatenet_layer{}'.format(1), units=layer1_dim, kernel_initializer=param_initializer,
                        bias_initializer=param_initializer)(inputs)
        output1 = tf.nn.relu(output1)
        if scen_slot_emb is not None:
            output1 = tf.concat([output1, replace_gradient(scen_slot_emb)], axis = 1)
        output2 = 2 * Dense(name='slot_gatenet_layer{}'.format(2), units=layer2_dim,
                            kernel_initializer=param_initializer,
                            bias_initializer=param_initializer, activation='sigmoid')(output1)
        # output2 = 2 * L.Sigmoid(name="slot_gatenet_layer{}/{}".format(2, 'sigmoid'))(output2)
        # output2 = 2 * tf.nn.sigmoid(output2, name="slot_gatenet_layer{}/{}".format(2, 'sigmoid'))
        return output2
 
 
def slot_gate(slot_emb_lst, slot_id_lst, name="slot_gate", input_process_func=simple_concat, layer1_dim=None,
              extra_inputs=None, scen_slot_emb=None):
    """
    slot_emb_lst: list
        [slot1_emb, slot2_emb, ... slotN_emb]
    return: list
        [slot1_w, slot2_w, ... slotN_w]
    """
    assert len(slot_emb_lst) == len(slot_id_lst), "length of inputs Must be equal to slot_id_lst"
    if isinstance(slot_emb_lst, (list, tuple)):
        gatenet_inputs = input_process_func(slot_emb_lst)
    else:
        raise TypeError("inputs must be iterable")

    if extra_inputs:
        gatenet_inputs = tf.concat([replace_gradient(gatenet_inputs)] + replace_gradient(extra_inputs), 1,
                                   name="{}/extra_input_concat".format(name))
    else:
        gatenet_inputs = tf.stop_gradient(gatenet_inputs)
 
    if layer1_dim is None:
        layer1_dim = 2 * len(slot_emb_lst)
 
    slot_nums = len(slot_emb_lst)
    weights_output = simple_lhuc_network(gatenet_inputs, scen_slot_emb, layer1_dim, slot_nums, name)
    slot_weight_lst = tf.split(weights_output, slot_nums, 1)
 
    weighted_slot_emb_lst = []
    weight_lst = []
    for slot_weight, slot_emb, slot_id in zip(slot_weight_lst, slot_emb_lst, slot_id_lst):
        # slot_weight_ = tf.identity(slot_weight, name="{}_weight".format(slot.name).replace(":", '_'))
        weight_lst.append(tf.reduce_mean(slot_weight, name="{}_weight".format(slot_id)))
        weighted_slot_emb_lst.append(slot_weight * slot_emb)
    return weighted_slot_emb_lst, weight_lst



def PPNet(nn_input, phase, ppnet_gate_slot_emb, expert_name,
          project = False, hidden_layer_dims = [512, 256, 128, 128, 64],
          hidden_layer_activations = ['relu', 'relu', 'relu', 'relu', 'relu']):
    assert len(hidden_layer_dims) == len(hidden_layer_activations), "hidden_layer_dims must be equal to hidden_layer_activations"
    param_initializer = tf.keras.initializers.TruncatedNormal(stddev=0.001)
    layer_output_lst = [nn_input]
    for i, (hidden_layer_dim, hidden_layer_activation) in enumerate(zip(hidden_layer_dims, hidden_layer_activations)):
        hidden_output = Dense(name=f'phase{phase}_{expert_name}_layer{i}', units=hidden_layer_dim, activation=hidden_layer_activation,
                              kernel_initializer=param_initializer, bias_initializer=param_initializer)(layer_output_lst[-1])
        layer_output_lst.append(hidden_output)
    
    layer_weight_output = 2 * DenseTower(
            name=f'phase{phase}_{expert_name}_gate',
            output_dims=[128, len(hidden_layer_dims)],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.relu, tf.nn.sigmoid],
            norms=[False, False]
        )(replace_gradient(ppnet_gate_slot_emb))
    ppnet_out_lst = []
    for layer_weight, layer_output in zip(tf.split(layer_weight_output, len(hidden_layer_dims), 1), layer_output_lst[1:]):
        ppnet_out_lst.append(layer_weight * layer_output)

    ppnet_out = tf.concat(ppnet_out_lst, axis=1)
    if project:
        return DenseTower(
            name=f'phase{phase}_{expert_name}_project',
            output_dims=[512, 256],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.relu, tf.nn.relu],
            norms=[False, False]
        )(ppnet_out)
    else:
        return ppnet_out

def PLE(inputs,
        phase,
        task_names,
        specific_expert_num=1,
        share_expert_num=1,
        layer_num=2,
        expert_hidden_dim=256,
        gate_hidden_dim=128,
        similar_input=None,
        tensor_dump=None,
        scenario_label=None
        ):
    """
    PLE layers, borrow from yuexin.huang
    """

    def CGC(inputs, level, is_last=False):
        param_initializer = tf.keras.initializers.TruncatedNormal(stddev=0.001)
        specific_expert_outputs = []
        for i, task in enumerate(task_names):
            for j in range(specific_expert_num):
                expert_output = DenseTower(
                    name="phase_{}_level_{}_{}_expert_layer_{}".format(phase, level, task, j),
                    output_dims=[1024, 256, expert_hidden_dim],
                    kernel_initializers=param_initializer,
                    bias_initializers=param_initializer,
                    activations=[tf.nn.relu, tf.nn.relu, tf.nn.relu],
                    norms=[False, False, False]
                )(inputs[i])
                specific_expert_outputs.append(expert_output)
        share_expert_outputs = []
        assert level == 0
        assert share_expert_num == 1
        assert expert_hidden_dim == 128
        for i in range(share_expert_num + 3):
            share_name = "p{}_share_bottom".format(phase) if i == 0 else "p{}_share_bottom{}".format(phase,i)
            expert_output = DenseTower(
                name=share_name,
                output_dims=[1024, 256, expert_hidden_dim],
                kernel_initializers=param_initializer,
                bias_initializers=param_initializer,
                activations=[tf.nn.relu, tf.nn.relu, tf.nn.relu],
                norms=[False, False, False]
            )(inputs[-1 * (i + 1)])
            dump_name = "common"
            if i  == 1:
                expert_output = tf.where(scenario_label != 0, replace_gradient(expert_output), expert_output)
                dump_name = "pdp"
            if i == 2:
                expert_output = tf.where(scenario_label != 1, replace_gradient(expert_output), expert_output)
                dump_name = "dd"
            if i == 3:
                expert_output = tf.where(scenario_label != 2, replace_gradient(expert_output), expert_output)
                dump_name = "cart"
            if tensor_dump:
                tensor_dump.append(tf.reshape(tf.reduce_mean(expert_output, axis = 0), (-1, ), name="{}_{}".format(share_name, dump_name)))
            if similar_input is not None:
                expert_output = expert_output + tf.math.multiply(expert_output, similar_input)
            share_expert_outputs.append(expert_output)


        cgc_outputs = []
        for i, task in enumerate(task_names):
            cur_experts_num = specific_expert_num + share_expert_num + 3
            # cur_experts_num * B * dim
            cur_experts = specific_expert_outputs[
                          i * specific_expert_num:(i + 1) * specific_expert_num] + share_expert_outputs
            cur_experts = tf.stack(cur_experts, axis=1) # B * e * dim
            gate_output = DenseTower(
                name="phase_{}_level_{}_{}_gate_layer".format(phase, level, task),
                output_dims=[gate_hidden_dim, cur_experts_num],
                kernel_initializers=param_initializer,
                bias_initializers=param_initializer,
                activations=[tf.nn.relu, tf.nn.softmax],
                norms=[False, False]
            )(inputs[i])
            gate_weights = tf.expand_dims(gate_output, axis=-1) # B * e * 1
            if tensor_dump:
                tensor_dump.append(tf.reshape(tf.reduce_mean(gate_output, axis = 0), (-1, ), name ="phase_{}_{}_{}_cgc_weight".format(phase, level, task)))
            print('sp gate weights:', gate_weights.shape)
            print('expert output shape:', cur_experts.shape)
            weighted_expert_output = tf.reduce_sum(tf.math.multiply(cur_experts, gate_weights), axis=-2)
            cgc_outputs.append(weighted_expert_output)

        if not is_last:
            cur_experts_num = len(task_names) * specific_expert_num + share_expert_num + 3
            # cur_experts_num * B * dim
            cur_experts = specific_expert_outputs + share_expert_outputs
            cur_experts = tf.stack(cur_experts, axis=1)
            gate_output = DenseTower(
                name="phase_{}_level_{}_share_gate_layer".format(phase, level),
                output_dims=[gate_hidden_dim, cur_experts_num],
                kernel_initializers=param_initializer,
                bias_initializers=param_initializer,
                activations=[tf.nn.relu, tf.nn.softmax],
                norms=[False, False]
            )(inputs[-1])
            gate_weights = tf.expand_dims(gate_output, axis=-1)
            print('share gate weights:', gate_weights.shape)
            print('expert output shape:', cur_experts.shape)
            weighted_expert_output = tf.reduce_sum(tf.math.multiply(cur_experts, gate_weights), axis=-2)
            cgc_outputs.append(weighted_expert_output)

        return cgc_outputs

    if isinstance(inputs, list):
        assert len(inputs) == len(task_names) + 1
        cgc_inputs = inputs
    else:
        cgc_inputs = [inputs] * (len(task_names) + share_expert_num + 3)
    for i in range(layer_num):
        if i == layer_num - 1:
            ple_output = CGC(cgc_inputs, i, is_last=True)
        else:
            ple_output = CGC(cgc_inputs, i, is_last=False)
            cgc_inputs = ple_output
    return ple_output


def mask_block(
            name,
            emb_input,
            hidden_input,
            hidden_dim,
            output_dim,
            param_initializer,
            activation_fn=None,
            ratio=0.25
    ):
        if hidden_input is None:
            hidden_input = emb_input  # B * ( Length * Field ) BN

        mask_gate = DenseTower(name='Mask_Net_Gate_Proj_{}_1'.format(name),
                               output_dims=[int(hidden_dim * ratio), hidden_dim],
                               kernel_initializers=[param_initializer] * 2,
                               bias_initializers=[param_initializer] * 2,
                               activations=[activation_fn, None],
                               norms=[False, False])(hidden_input)
        v_masked = hidden_input * mask_gate

        v_masked_ = DenseTower(name='Mask_Net_gate_Proj_{}_2'.format(name),
                               output_dims=[output_dim],
                               activations=[None],
                               norms=[False])(v_masked)

        return tf.nn.relu(tf.keras.layers.LayerNormalization(axis=1)(v_masked_))

def SENet(inputs, name, hidden_dim=1024, res_net=False):
    """
    SENet layers
    """
    param_initializer = tf.keras.initializers.TruncatedNormal(stddev=0.001)
    nn_input_dim = inputs.get_shape().as_list()[-1]
    senet_gate = DenseTower(name=name,
                            output_dims=[hidden_dim, nn_input_dim],
                            kernel_initializers=param_initializer,
                            bias_initializers=param_initializer,
                            activations=[tf.nn.relu, None],
                            norms=[False, False])(inputs)
    senet_gate = tf.nn.sigmoid(tf.clip_by_value(senet_gate, -1000, 1000))
    if res_net:
        return inputs * senet_gate + inputs, senet_gate
    else:
        return inputs * senet_gate, senet_gate


def SENet_v2(inputs, name, hidden_dim=1024, output_dim=256):
    """
    SENet v2
    """
    param_initializer = tf.keras.initializers.TruncatedNormal(stddev=0.001)
    nn_input_dim = inputs.get_shape().as_list()[-1]
    senet_gate = DenseTower(name='Senet_Gate_{}_1'.format(name),
                            output_dims=[hidden_dim, nn_input_dim],
                            kernel_initializers=param_initializer,
                            bias_initializers=param_initializer,
                            activations=[tf.nn.relu, None],
                            norms=[False, False])(inputs)
    senet_gate = tf.clip_by_value(senet_gate, -1000, 1000)
    out1 = inputs * senet_gate

    out2 = DenseTower(name='Senet_Gate_{}_2'.format(name),
                           output_dims=[output_dim],
                           activations=[None],
                           norms=[False])(out1)
    out2 = tf.clip_by_value(out2, -1000, 1000)
    return tf.nn.relu(out2), senet_gate

def multi_scene_SENet_v2(inputs, name, scene_num, scene_vec, rank, hidden_dim=1024, output_dim=256):
    """
    SENet v2
    """
    param_initializer = tf.keras.initializers.TruncatedNormal(stddev=0.001)
    nn_input_dim = inputs.get_shape().as_list()[-1]
    senet_gate = DenseTower(name='Senet_Gate_{}_1'.format(name),
                            output_dims=[hidden_dim, nn_input_dim],
                            kernel_initializers=param_initializer,
                            bias_initializers=param_initializer,
                            activations=[tf.nn.relu, None],
                            norms=[False, False])(inputs)
    senet_gate = tf.clip_by_value(senet_gate, -1000, 1000)
    out1 = inputs * senet_gate

    out2 = DenseTower(name='Senet_Gate_{}_2'.format(name),
                           output_dims=[output_dim],
                           activations=[None],
                           norms=[False])(out1)
    out2 += multi_scene_lora_layer_v2(name, param_initializer, scene_num, scene_vec, output_dim, rank, out1)
    out2 = tf.clip_by_value(out2, -1000, 1000)
    return tf.nn.relu(out2), senet_gate

def SENet_v3(inputs, name, hidden_dim=1024, output_dim=256):
    """
    SENet v3: add sigmoid to senet_gate
    """
    param_initializer = tf.keras.initializers.TruncatedNormal(stddev=0.001)
    nn_input_dim = inputs.get_shape().as_list()[-1]
    senet_gate = DenseTower(name='Senet_Gate_{}_1'.format(name),
                            output_dims=[hidden_dim, nn_input_dim],
                            kernel_initializers=param_initializer,
                            bias_initializers=param_initializer,
                            activations=[tf.nn.relu, None],
                            norms=[False, False])(inputs)
    senet_gate = 2 * tf.nn.sigmoid(senet_gate)

    out1 = inputs * senet_gate

    out2 = DenseTower(name='Senet_Gate_{}_2'.format(name),
                           output_dims=[output_dim],
                           activations=[None],
                           norms=[False])(out1)
    out2 = tf.clip_by_value(out2, -1000, 1000)
    return tf.nn.relu(out2), senet_gate

def SENet_v4(inputs, name, hidden_dim=1024, output_dim=256):
    """
    SENet v3: add sigmoid to senet_gate
    """
    param_initializer = tf.keras.initializers.TruncatedNormal(stddev=0.001)
    nn_input_dim = inputs.get_shape().as_list()[-1]
    senet_gate = DenseTower(name='Senet_Gate_{}_1'.format(name),
                            output_dims=[hidden_dim, nn_input_dim],
                            kernel_initializers=param_initializer,
                            bias_initializers=param_initializer,
                            activations=[tf.nn.relu, None],
                            norms=[False, False])(inputs)
    senet_gate = 2 * tf.nn.sigmoid(tf.clip_by_value(senet_gate, -1000, 1000))

    out1 = inputs * senet_gate

    out2 = DenseTower(name='Senet_Gate_{}_2'.format(name),
                           output_dims=[output_dim],
                           activations=[None],
                           norms=[False])(out1)
    out2 = tf.clip_by_value(out2, -1000, 1000)
    return tf.nn.relu(out2), senet_gate

def SENet_v5(inputs, name, hidden_dim=1024, output_dim=256):
    """
    SENet v3: add sigmoid to senet_gate
    """
    param_initializer = tf.keras.initializers.TruncatedNormal(stddev=0.001)
    nn_input_dim = inputs.get_shape().as_list()[-1]
    senet_gate = DenseTower(name='Senet_Gate_{}_1'.format(name),
                            output_dims=[hidden_dim, nn_input_dim],
                            kernel_initializers=param_initializer,
                            bias_initializers=param_initializer,
                            activations=[tf.nn.relu, swish],
                            norms=[False, False])(inputs)

    out1 = inputs * senet_gate

    out2 = DenseTower(name='Senet_Gate_{}_2'.format(name),
                           output_dims=[output_dim],
                           activations=[None],
                           norms=[False])(out1)
    out2 = tf.clip_by_value(out2, -1000, 1000)
    return tf.nn.relu(out2), senet_gate

def gateNU(inputs, gate_inputs, gate_type='', name=''):
    dim = inputs.get_shape().as_list()[-1]
    param_initializer = tf.truncated_normal_initializer(stddev=0.001, dtype=tf.float32)
    gate_score = DenseTower(name='{}_Gate_{}'.format(gate_type, name),
                           output_dims=[dim],
                           kernel_initializers=param_initializer,
                           bias_initializers=param_initializer,
                           activations=[None],
                           norms=[False])(gate_inputs)
    gate_weight = 2 * tf.nn.sigmoid(tf.clip_by_value(gate_score, -1000, 1000))

    out = inputs * gate_weight

    return out


def ctx_gate(inputs, gate_inputs, name):
    dim = inputs.get_shape().as_list()[-1]
    param_initializer = tf.keras.initializers.TruncatedNormal(stddev=0.001)
    ctx_score = DenseTower(name='Ctx_Gate_{}'.format(name),
                           output_dims=[dim],
                           kernel_initializers=param_initializer,
                           bias_initializers=param_initializer,
                           activations=[None],
                           norms=[False])(gate_inputs)
    ctx_weight = 2 * tf.nn.sigmoid(tf.clip_by_value(ctx_score, -1000, 1000))

    out = inputs * ctx_weight

    return out

def duin_gate(ta_emb, tr_emb, gate_inputs, type='concat', name=''):
    dim = ta_emb.get_shape().as_list()[-1]
    param_initializer = tf.keras.initializers.TruncatedNormal(stddev=0.001)
    score = DenseTower(name='DUIN_Gate_{}'.format(name),
                           output_dims=[dim],
                           kernel_initializers=param_initializer,
                           bias_initializers=param_initializer,
                           activations=[None],
                           norms=[False])(gate_inputs)
    weight = tf.nn.sigmoid(tf.clip_by_value(score, -1000, 1000))

    if type == 'concat':
        out = tf.concat([ta_emb * (1.0 - weight), tr_emb * weight], axis=-1)
    elif type == 'add':
        out = ta_emb * (1.0 - weight) + tr_emb * weight
    else:
        out = tf.concat([ta_emb * (1.0 - weight), tr_emb * weight], axis=-1)
    return out

def swish(x):
    return x * tf.nn.sigmoid(x)

def dense_gate_block(
        name,
        emb_input,
        hidden_dim,
        param_initializer
):
    dense_layer = DenseTower(name='Dense_Layer_{}'.format(name),
                             output_dims=[hidden_dim],
                             kernel_initializers=[param_initializer],
                             bias_initializers=[param_initializer],
                             activations=[swish],
                             norms=[False])
    dense_gate_layer = DenseTower(name='Dense_Gate_Layer_{}'.format(name),
                                  output_dims=[hidden_dim, hidden_dim],
                                  kernel_initializers=[param_initializer] * 2,
                                  bias_initializers=[param_initializer] * 2,
                                  activations=[swish, tf.nn.sigmoid],
                                  norms=[False, False])

    x = dense_layer(emb_input)
    x_gate = dense_gate_layer(x)
    out = x * x_gate
    return out


def dense_gate_tower(
        name,
        emb_input,
        hidden_dims,
        param_initializer
):
    x = emb_input
    for idx in range(len(hidden_dims)):
        hidden_dim = hidden_dims[idx]
        x = dense_gate_block("{}_{}".format(name, idx), x, hidden_dim, param_initializer)
    return x

def multi_scene_lora_layer(name, param_initializer, scene_num, scenario_label, out_dim, rank, lora_input, alpha=8.0):
        lora_input = tf.stop_gradient(lora_input)
        lora_inputs = tf.tile(tf.expand_dims(lora_input, axis = 1), [1, scene_num, 1]) # (B, scene_num, in_dim)
        print("lora inputs shape:{}".format(lora_inputs.shape))
        lora_outputs = ParallelDenseTower(name='p{}_multi_scene_lora_block'.format(name),
                                hidden_units=[rank, out_dim],
                                activations=[None, None],
                                kernel_initializers=[param_initializer,tf.keras.initializers.Zeros()],
                                use_bias=False
                                )(lora_inputs)
        print("lora outputs shape:{}".format(lora_outputs.shape))
        scene_vec = tf.one_hot(scenario_label, depth=scene_num, dtype=tf.float32)
        print("scene vec shape:{}".format(scene_vec.shape))
        lora_outputs = lora_outputs * tf.expand_dims(scene_vec, axis = 2)
        lora_output = tf.reduce_sum(lora_outputs, axis = 1)
        
        return lora_output * (alpha / rank)

def multi_scene_dense_gate_block(
        name,
        emb_input,
        scene_num,
        scenario_label,
        rank,
        hidden_dim,
        param_initializer
):
    dense_layer = DenseTower(name='Dense_Layer_{}'.format(name),
                             output_dims=[hidden_dim],
                             kernel_initializers=[param_initializer],
                             bias_initializers=[param_initializer],
                             activations=[None],
                             norms=[False])
    dense_gate_layer = DenseTower(name='Dense_Gate_Layer_{}'.format(name),
                                  output_dims=[hidden_dim, hidden_dim],
                                  kernel_initializers=[param_initializer] * 2,
                                  bias_initializers=[param_initializer] * 2,
                                  activations=[swish, tf.nn.sigmoid],
                                  norms=[False, False])

    x = dense_layer(emb_input)
    ### ln + lora
    x = swish(tf.keras.layers.LayerNormalization(axis=-1)(x) + multi_scene_lora_layer(name,param_initializer,scene_num,scenario_label,hidden_dim,rank,emb_input))
    x_gate = dense_gate_layer(x)
    out = x * x_gate
    return out

def multi_scene_dense_gate_tower(
        name,
        emb_input,
        scene_num,
        scene_vec,
        ranks,
        hidden_dims,
        param_initializer
):
    x = emb_input
    for idx in range(len(hidden_dims)):
        hidden_dim = hidden_dims[idx]
        rank = ranks[idx]
        x = multi_scene_dense_gate_block("{}_{}".format(name, idx), x, scene_num, scene_vec, rank, hidden_dim, param_initializer)
    return x


def multi_scene_dense_gate_block_v3( #apply lora more completely
        name,
        emb_input,
        scene_num,
        scenario_label,
        rank,
        hidden_dim,
        param_initializer
):
    dense_layer = DenseTower(name='Dense_Layer_{}'.format(name),
                             output_dims=[hidden_dim],
                             kernel_initializers=[param_initializer],
                             bias_initializers=[param_initializer],
                             activations=[None],
                             norms=[False])
    dense_gate_layer_1 = DenseTower(name='Dense_Gate_Layer_{}_1'.format(name),
                                  output_dims=[hidden_dim],
                                  kernel_initializers=[param_initializer],
                                  bias_initializers=[param_initializer],
                                  activations=[None],
                                  norms=[False])
    dense_gate_layer_2 = DenseTower(name='Dense_Gate_Layer_{}_2'.format(name),
                                  output_dims=[hidden_dim],
                                  kernel_initializers=[param_initializer],
                                  bias_initializers=[param_initializer],
                                  activations=[None],
                                  norms=[False])

    x = dense_layer(emb_input)
    ### ln + lora
    x = swish(x + multi_scene_lora_layer(name,param_initializer,scene_num,scenario_label,hidden_dim,rank,emb_input))
    x_gate_1 = dense_gate_layer_1(x)
    x_gate_1 = swish(x_gate_1 + multi_scene_lora_layer(name,param_initializer,scene_num,scenario_label,hidden_dim,rank,x))
    
    x_gate_2 = dense_gate_layer_2(x_gate_1)
    x_gate_2 = tf.nn.sigmoid(x_gate_2 + multi_scene_lora_layer(name,param_initializer,scene_num,scenario_label,hidden_dim,rank,x_gate_1))

    out = x * x_gate_2
    return out

def multi_scene_dense_gate_tower_v3(
        name,
        emb_input,
        scene_num,
        scenario_label,
        ranks,
        hidden_dims,
        param_initializer
):
    x = emb_input
    for idx in range(len(hidden_dims)):
        hidden_dim = hidden_dims[idx]
        rank = ranks[idx]
        x = multi_scene_dense_gate_block_v3("{}_{}".format(name, idx), x, scene_num, scenario_label, rank, hidden_dim, param_initializer)
    return x

def sim_tier(query, key, mask, is_mask=False, round=[16]):
    '''
    query: [B, D]
    key: [B, L, D]
    mask: [B, L]
    '''
    k_norm = tf.nn.l2_normalize(key, axis=-1) # [B, L, D]
    q_norm = tf.nn.l2_normalize(tf.expand_dims(query, axis=1), axis=-1) # [B, 1, D]

    score = tf.reduce_sum(q_norm * k_norm, axis=2)  # [B, L]
    _, S = score.get_shape().as_list()
    tier_lst = []
    for N in round:
        idx = tf.reshape(tf.cast(tf.math.ceil((score + 1) / 2 * N), dtype=tf.int32), [-1, S])
        weight = tf.equal(tf.reshape(tf.range(0, N, 1), [1, N, 1]),
                          tf.expand_dims(idx, 1))  # [B, N, L]
        if is_mask:
            weight = tf.cast(weight, dtype=tf.float32) * tf.expand_dims(mask, axis=1)
        tier = tf.reduce_sum(tf.cast(weight, dtype=tf.float32), axis=2)  # [B, N]
        tier_lst.append(tier)

    tier_tensor = tf.concat(tier_lst, axis=-1)
    return tier_tensor, score

def sim_tier2_opt(query, key, mask, round=[16]):
    '''
    query: [B, D]
    key: [B, L, D]
    mask: [B, L]
    '''
    k_norm = tf.nn.l2_normalize(key, axis=-1) # [B, L, D]
    q_norm = tf.nn.l2_normalize(tf.expand_dims(query, axis=1), axis=-1) # [B, 1, D]

    score = tf.reduce_sum(q_norm * k_norm, axis=2)  # [B, L]
    B = tf.shape(score)[0]
    L = tf.shape(score)[1]
    tier_lst = []
    mask_tier_lst = []

    weight = tf.ones_like(score, tf.float32) # (B,L)
    masked_weight = weight * mask

    ### flat
    weight_flat = tf.reshape(weight,[-1])
    masked_weight_flat = tf.reshape(masked_weight,[-1])

    ### represent the score belongs to which batch
    batch_ids = tf.reshape(tf.tile(tf.expand_dims(tf.range(B, dtype=tf.int32), 1), [1, L]), [-1])  # [B*L]

    for N in round:
        Nf = tf.cast(N, tf.float32)
        idx = tf.clip_by_value(tf.cast(tf.floor((score + 1.0) * 0.5 * Nf), tf.int32), 0, N-1) # [B, L]
        idx_flat = tf.reshape(idx, [-1]) # [B*L]

        seg_ids = batch_ids * N + idx_flat # B * N bins

        tier_flat = tf.math.unsorted_segment_sum(weight_flat, seg_ids, B * N) #(B*N)
        mask_tier_flat = tf.math.unsorted_segment_sum(masked_weight_flat, seg_ids, B * N) #(B*N)

        tier_lst.append(tf.reshape(tier_flat,[B,N]))
        mask_tier_lst.append(tf.reshape(mask_tier_flat,[B,N]))

    tier_tensor = tf.concat(tier_lst, axis=-1)
    masked_tier_tensor = tf.concat(mask_tier_lst, axis=-1)
    return tier_tensor, masked_tier_tensor, score

def sim_tier2(query, key, mask, round=[16]):
    '''
    query: [B, D]
    key: [B, L, D]
    mask: [B, L]
    '''
    k_norm = tf.nn.l2_normalize(key, axis=-1) # [B, L, D]
    q_norm = tf.nn.l2_normalize(tf.expand_dims(query, axis=1), axis=-1) # [B, 1, D]

    score = tf.reduce_sum(q_norm * k_norm, axis=2)  # [B, L]
    _, S = score.get_shape().as_list()
    tier_lst = []
    mask_tier_lst = []
    for N in round:
        idx = tf.reshape(tf.cast(tf.math.ceil((score + 1) / 2 * N), dtype=tf.int32), [-1, S])
        weight = tf.equal(tf.reshape(tf.range(0, N, 1), [1, N, 1]),
                          tf.expand_dims(idx, 1))  # [B, N, L]

        masked_weight = tf.cast(weight, dtype=tf.float32) * tf.expand_dims(mask, axis=1)
        masked_tier = tf.reduce_sum(tf.cast(masked_weight, dtype=tf.float32), axis=2)  # [B, N]
        mask_tier_lst.append(masked_tier)

        tier = tf.reduce_sum(tf.cast(weight, dtype=tf.float32), axis=2)  # [B, N]
        tier_lst.append(tier)

    tier_tensor = tf.concat(tier_lst, axis=-1)
    masked_tier_tensor = tf.concat(mask_tier_lst, axis=-1)
    return tier_tensor, masked_tier_tensor, score

def sim_tier3(score, round=[16], stop_gradient=False):
    _, S = score.get_shape().as_list()
    tier_lst = []
    for N in round:
        idx = tf.reshape(tf.cast(tf.math.ceil((score + 1) / 2 * N), dtype=tf.int32), [-1, S])
        weight = tf.equal(tf.reshape(tf.range(0, N, 1), [1, N, 1]),
                          tf.expand_dims(idx, 1))  # [B, N, L]

        tier = tf.reduce_sum(tf.cast(weight, dtype=tf.float32), axis=2)  # [B, N]
        tier_lst.append(tier)

    tier_tensor = tf.concat(tier_lst, axis=-1)
    if stop_gradient:
        tier_tensor = tf.stop_gradient(tier_tensor)
    return tier_tensor

def multi_head_sim_tier(score, head_num, bins=[16], stop_gradient=True):
    ### score: (B,H,L)
    tier_lst = []
    for N in bins:
        idx = tf.cast(tf.math.ceil(score * N), dtype=tf.int32) #(B,H,L)
        onehot = tf.one_hot(idx, depth = N, axis = -1, dtype=tf.float32) #(B,H,L,N)
        print("onehot shape:{}".format(onehot.shape))
        tier = tf.reduce_sum(onehot, axis=2)  # [B, H, N]
        print("tier shape:{}".format(tier.shape))
        tier_lst.append(tier)

    tier_tensor = tf.concat(tier_lst, axis=-1)
    tier_tensor = tf.reshape(tier_tensor,[-1, head_num * sum(bins)])
    print("tier_tensor shape:{}".format(tier_tensor.shape))
    if stop_gradient:
        tier_tensor = tf.stop_gradient(tier_tensor)
    return tier_tensor

def cal_cos_score(x, y):
    '''
    x: [B, D]
    y: [B, D]
    '''
    x_norm = tf.nn.l2_normalize(x, axis=-1)
    y_norm = tf.nn.l2_normalize(y, axis=-1)

    score = tf.reduce_sum(x_norm * y_norm, axis=-1, keepdims=True) # [B, 1]

    return score

@tf.custom_gradient
def ignore_grad(x):
    def grad(upstream):
        return upstream * 0.0
    return x, grad

def stop_grad_but_keep_path(x):
    return tf.stop_gradient(x) + (x * 0.0)

# ppnet_like_unit
def mal_gate_unit(input_vec, dim, gate_input, gate_dim, phase, param_initializer):
    input_vec = DenseTower(name='p{}_input_trans_{}'.format(phase, dim),
                                   output_dims=[dim],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[tf.nn.relu],
                                   norms=[False])(input_vec)
    gate_output = DenseTower(name='p{}_mal_gate_{}'.format(phase, gate_dim),
                            output_dims=[gate_dim//2, dim],
                            kernel_initializers=param_initializer,
                            bias_initializers=param_initializer,
                            activations=[tf.nn.relu, None],
                            norms=[False, False])(gate_input)
    return 2 * tf.nn.sigmoid(tf.clip_by_value(gate_output, -1000, 1000)) * input_vec

# hstu fusion: fuse the attention and gate
def mal_hstu_layer(input_vecs, dim, head_num, phase, param_initializer, mask = None):
    print("hstu input shape: {}".format(input_vecs.shape))

    # step1 silu(linear(X))
    # (B, seq, d) --> (B, seq, 4 * d)
    expand_input = DenseTower(name='p{}_hstu_trans_{}'.format(phase, dim),
                                   output_dims=[4 * dim],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[swish],
                                   norms=[False])(input_vecs)
    
    U, Q, K, V = tf.split(expand_input, 4, axis = -1) # (B,head_num,seq,d / head_num)
    U = tf.stack(tf.split(U, head_num, axis = -1), axis = 1)
    Q = tf.stack(tf.split(Q, head_num, axis = -1), axis = 1)
    K = tf.stack(tf.split(K, head_num, axis = -1), axis = 1)
    V = tf.stack(tf.split(V, head_num, axis = -1), axis = 1)

    # self-attention & no softmax & no norm to keep raw intensity
    
    attention_score = tf.matmul(Q, K, transpose_b = True)
    attention_score *= (dim // head_num) ** (-0.5)

    # no softmax & pointwise SiLU
    attention_score = swish(tf.clip_by_value(attention_score,-1000,1000))
    attention_output = tf.matmul(attention_score, V)

    #gate
    attention_output = tf.keras.layers.LayerNormalization(name = 'p{}_hstu'.format(phase),axis=-1)(attention_output) * U  # (B, head_num, seq, d / head_num)
    attention_output = tf.concat(tf.unstack(attention_output, axis = 1), -1) # (B,seq,d)

    #output trans
    final_output = DenseTower(name='p{}_hstu_output_trans_{}'.format(phase, dim),
                                   output_dims=[dim],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[None],
                                   norms=[False])(attention_output)
    return final_output

def mal_hstu_tower(input_vecs, dim, head_num, layer_num, phase, param_initializer, mask = None):
    for _ in range(layer_num):
        # pre-norm & residual connection.
        input_vecs += (mal_hstu_layer(tf.keras.layers.LayerNormalization(name = 'p{}_hstu'.format(phase),axis=-1)(input_vecs), dim, head_num, phase, param_initializer, mask))
    return input_vecs

def gelu_tanh(x, name=None):
    with tf.name_scope(name or "gelu_tanh"):
        c = tf.constant(0.044715, dtype=x.dtype)
        k = tf.constant(0.7978845608028654, dtype=x.dtype)  # sqrt(2/pi)
        return 0.5 * x * (1.0 + tf.tanh(k * (x + c * tf.pow(x, 3))))

def mixer_block(input_vecs, head_num, hidden_dim, k, phase, param_initializer):

    ### token mixing seq = head_num = T
    input_tokens = tf.stack(tf.split(input_vecs, head_num, axis = -1), axis = 1) # (B,head_num,seq,hidden_dim//head_num)
    print("input_tokens shape:{}".format(input_tokens.shape))
    input_tokens = tf.reshape(input_tokens, [-1,head_num,hidden_dim])
    print("input_tokens shape:{}".format(input_tokens.shape))

    ### post-norm and add-residual
    input_tokens = tf.keras.layers.LayerNormalization(axis=-1)(input_tokens + input_vecs) #(B,H,D)

    ### per token ffn
    tokens = ParallelDenseTower(name='p{}_mixer_block/pffn'.format(phase),
                                hidden_units=[int(k * hidden_dim), hidden_dim],
                                activations=[gelu_tanh, None],
                                kernel_initializers=[param_initializer,param_initializer]
                                )(input_tokens)

    output_tokens = tf.keras.layers.LayerNormalization(axis=-1)(tokens + input_tokens)
    return output_tokens

def mixer_tower(input_vecs, head_num, hidden_dim, output_dim, k, layer_num, phase, param_initializer, pooling=True):
    for _ in range(layer_num):
        input_vecs = mixer_block(input_vecs,head_num,hidden_dim,k,phase,param_initializer)
    
    if pooling:
        ### mean pooling
        output_vec = tf.reduce_mean(input_vecs, axis = 1)
        output_vec = DenseTower(name='p{}_mixer_block/output_proj'.format(phase),
                                    output_dims=[output_dim],
                                    kernel_initializers=param_initializer,
                                    bias_initializers=param_initializer,
                                    activations=[gelu_tanh],
                                    norms=[False])(output_vec)
    else:
        output_vec = DenseTower(name='p{}_mixer_block/output_proj'.format(phase),
                                    output_dims=[output_dim],
                                    kernel_initializers=param_initializer,
                                    bias_initializers=param_initializer,
                                    activations=[gelu_tanh],
                                    norms=[False])(input_vecs)
    return output_vec

def mal_mhta(queries, keys, qk_dim, v_dim, output_dim, head_num, phase, param_initializer, mask = None, tau = 0.5):
    Q = DenseTower(name='p{}_mal_mhta_q_trans'.format(phase),
                                   output_dims=[qk_dim],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[None],
                                   norms=[False])(queries)
    KV = DenseTower(name='p{}_mal_mhta_kv_trans'.format(phase),
                                   output_dims=[qk_dim + v_dim],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[None],
                                   norms=[False])(keys)
    K, V = tf.split(KV, [qk_dim, v_dim], axis = -1)
    Q = tf.stack(tf.split(Q, head_num, axis = -1), axis = 1) #(B, H, 1, D//H)
    K = tf.stack(tf.split(K, head_num, axis = -1), axis = 1) #(B, H, L, D//H)
    V = tf.stack(tf.split(V, head_num, axis = -1), axis = 1)

    Q = tf.nn.l2_normalize(Q, axis = -1)
    K = tf.nn.l2_normalize(K, axis = -1)

    attn_scores = tf.matmul(Q, K, transpose_b=True) / tau
    attn_scores = attn_scores - tf.reduce_max(attn_scores, axis = -1 ,keepdims=True)
    attn_scores = tf.nn.softmax(attn_scores, axis = -1)
    attn_output = tf.matmul(attn_scores, V) #(B, H, 1, D//H)
    final_output = tf.squeeze(tf.concat(tf.unstack(attn_output, axis = 1), axis = -1), axis = 1)
    
    return final_output, tf.squeeze(attn_scores,2)

def mhta(queries, keys, qk_dim, v_dim, head_num, phase, param_initializer, activation = None, bound_activation=True, mask = None):
    ### pre-norm
    Q = tf.keras.layers.LayerNormalization(axis=-1)(queries)
    KV = tf.keras.layers.LayerNormalization(axis=-1)(keys)

    Q = DenseTower(name='p{}_mal_mhta_q_trans'.format(phase),
                                   output_dims=[qk_dim],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[activation],
                                   norms=[False])(Q)
    KV = DenseTower(name='p{}_mal_mhta_kv_trans'.format(phase),
                                   output_dims=[qk_dim + v_dim],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[activation],
                                   norms=[False])(KV)
    K, V = tf.split(KV, [qk_dim, v_dim], axis = -1)
    Q = tf.stack(tf.split(Q, head_num, axis = -1), axis = 1) #(B, H, 1, D//H)
    K = tf.stack(tf.split(K, head_num, axis = -1), axis = 1) #(B, H, L, D//H)
    V = tf.stack(tf.split(V, head_num, axis = -1), axis = 1)

    attn_scores = tf.matmul(Q, K, transpose_b=True) * (qk_dim // head_num)**(-0.5)
    attn_scores = tf.nn.softmax(attn_scores, axis = -1) if bound_activation else swish(attn_scores)
    attn_scores = tf.clip_by_value(attn_scores, -10.0, 10.0)

    attn_output = tf.matmul(attn_scores, V) #(B, H, 1, D//H)
    final_output = tf.squeeze(tf.concat(tf.unstack(attn_output, axis = 1), axis = -1), axis = 1)

    return final_output, tf.squeeze(attn_scores,2)

def gated_mhta(queries, keys, qk_dim, v_dim, head_num, phase, param_initializer, activation = None, mask = None):
    ### pre-norm
    Q_ = tf.keras.layers.LayerNormalization(axis=-1)(queries) #(B,1,D)
    KV_ = tf.keras.layers.LayerNormalization(axis=-1)(keys)
    L = keys.shape[1]

    Q = DenseTower(name='p{}_gated_mhta_q_trans'.format(phase),
                                   output_dims=[qk_dim],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[activation],
                                   norms=[False])(Q_)
    # per field trans
    KV = ParallelDenseTower(name='p{}_gated_mhta_kv_trans'.format(phase),
                                hidden_units=[qk_dim + v_dim],
                                activations=[None],
                                kernel_initializers=[param_initializer]
                                )(KV_)
    K, V = tf.split(KV, [qk_dim, v_dim], axis = -1)
    Q = tf.stack(tf.split(Q, head_num, axis = -1), axis = 1) #(B, H, 1, D//H)
    K = tf.stack(tf.split(K, head_num, axis = -1), axis = 1) #(B, H, L, D//H)
    V = tf.stack(tf.split(V, head_num, axis = -1), axis = 1)

    ### token gate:query-dependent, sparse, non linear
    token_wise_gate =  DenseTower(name='p{}_gated_mhta_token_gate_tower'.format(phase),
                                   output_dims=[L],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[tf.nn.sigmoid],
                                   norms=[False])(Q_) #(B,1,L)
    token_wise_gate = tf.reshape(token_wise_gate, [-1,1,L,1])
    V = V * token_wise_gate

    attn_scores = tf.matmul(Q, K, transpose_b=True) * (qk_dim // head_num)**(-0.5) #(B,H,1,L)
    attn_scores = tf.nn.softmax(attn_scores, axis = -1)

    attn_output = tf.matmul(attn_scores, V) #(B, H, 1, D//H)

    ### gate:query-dependent, sparse, non linear
    head_wise_gate =  DenseTower(name='p{}_gated_mhta_gate_tower'.format(phase),
                                   output_dims=[head_num],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[tf.nn.sigmoid],
                                   norms=[False])(Q_) #(B,1,head_num)
    head_wise_gate = tf.reshape(head_wise_gate,[-1,head_num,1,1])
    attn_output = attn_output * head_wise_gate

    final_output = tf.squeeze(tf.concat(tf.unstack(attn_output, axis = 1), axis = -1), axis = 1)
    
    return final_output, tf.squeeze(attn_scores,2), tf.squeeze(token_wise_gate),tf.squeeze(head_wise_gate)


def gated_mhta_lite(queries, keys, qk_dim, v_dim, head_num, phase, param_initializer, activation = None, mask = None):
    ### pre-norm
    Q_ = tf.keras.layers.LayerNormalization(axis=-1)(queries) #(B,1,D)
    KV_ = tf.keras.layers.LayerNormalization(axis=-1)(keys)
    L = keys.shape[1]

    Q = DenseTower(name='p{}_gated_mhta_q_trans'.format(phase),
                                   output_dims=[qk_dim],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[activation],
                                   norms=[False])(Q_)
    # per field trans
    KV = ParallelDenseTower(name='p{}_gated_mhta_kv_trans'.format(phase),
                                hidden_units=[qk_dim + v_dim],
                                activations=[None],
                                kernel_initializers=[param_initializer]
                                )(KV_)
    K, V = tf.split(KV, [qk_dim, v_dim], axis = -1)
    Q = tf.stack(tf.split(Q, head_num, axis = -1), axis = 1) #(B, H, 1, D//H)
    K = tf.stack(tf.split(K, head_num, axis = -1), axis = 1) #(B, H, L, D//H)
    V = tf.stack(tf.split(V, head_num, axis = -1), axis = 1)

    attn_scores = tf.matmul(Q, K, transpose_b=True) * (qk_dim // head_num)**(-0.5) #(B,H,1,L)
    attn_scores = tf.nn.softmax(attn_scores, axis = -1)

    attn_output = tf.matmul(attn_scores, V) #(B, H, 1, D//H)

    ### gate:query-dependent, sparse, non linear
    head_wise_gate =  DenseTower(name='p{}_gated_mhta_gate_tower'.format(phase),
                                   output_dims=[head_num],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[tf.nn.sigmoid],
                                   norms=[False])(Q_) #(B,1,head_num)
    head_wise_gate = tf.reshape(head_wise_gate,[-1,head_num,1,1])
    attn_output = attn_output * head_wise_gate

    final_output = tf.squeeze(tf.concat(tf.unstack(attn_output, axis = 1), axis = -1), axis = 1)
    
    return final_output, tf.squeeze(attn_scores,2), tf.squeeze(head_wise_gate)

def SwishGLUFFN(dim, ratio, input_emb, phase, param_initializer, out_dtype=None):
    if out_dtype is None:
        out_dtype = input_emb.dtype

    x = tf.cast(input_emb, out_dtype)

    trans_layer = DenseTower(name='p{}_swishgluffn_trans_layer'.format(phase),
                                   output_dims=[dim * ratio],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[None],
                                   norms=[False])
    gate_layer = DenseTower(name='p{}_swishgluffn_gate_layer'.format(phase),
                                   output_dims=[dim * ratio],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[swish],
                                   norms=[False])
    out_layer = DenseTower(name='p{}_swishgluffn_out_layer'.format(phase),
                                   output_dims=[dim],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[None],
                                   norms=[False])

    trans = tf.cast(trans_layer(x), out_dtype)
    gate = tf.cast(gate_layer(x), out_dtype)
    y = trans * gate
    y = tf.cast(out_layer(y), out_dtype)
    return y


def lite_encoder(hidden_dim, input, gate_input, idx, param_initializer, seq_name):
    trans_layer = DenseTower(name='p{}{}_lite_encoder_trans_layer'.format(idx, seq_name),
                                   output_dims=[hidden_dim],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[None],
                                   norms=[False])
    gate_layer = DenseTower(name='p{}{}_lite_encoder_gate_layer'.format(idx, seq_name),
                                   output_dims=[hidden_dim],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[swish],
                                   norms=[False])
    return trans_layer(input) * gate_layer((gate_input if gate_input is not None else input))

def rope_position_encoder(x, base=10000.0, positions=None):
    ###
    # x: (B,H,L,D)
    # positions: default [0,1,2 … L-1]
    ###
    hidden_dim, L = tf.shape(x)[-1], tf.shape(x)[-2]
    half = hidden_dim//2
    if positions is None:
        pos = tf.cast(tf.range(L), tf.float32)  # (L,)
    else:
        pos = tf.cast(tf.reshape(positions, [-1]), tf.float32)  # (L,)
    w = tf.pow(base, -2.0 * tf.cast(tf.range(half), dtype=tf.float32) / tf.cast(hidden_dim, tf.float32)) #(d/2)
    ang = tf.expand_dims(pos, axis = 1) * tf.expand_dims(w, axis = 0) #(L, d/2)
    cos_ang, sin_ang = tf.cast(tf.cos(ang)[None, None, :, :], dtype=tf.float32), tf.cast(tf.sin(ang)[None, None, :, :], dtype=tf.float32) #(1,1,L,d/2)
    a, b = x[..., 0::2], x[..., 1::2] # a+bi
    out = tf.stack([a*cos_ang - b*sin_ang, a*sin_ang + b*cos_ang], axis = -1) #(B,H,L,d/2,2)
    return tf.reshape(out, tf.shape(x))

def token_shift_mix(x, mask):
    """
    x:   (B, L, D)
    mask:(B, L)  (sequence_mask, 0/1)
    """
    D = x.get_shape().as_list()[-1]
    if D is None:
        raise ValueError("token_shift_mix requires static last-dim D")

    # shift-right with zero at t=0
    x0 = tf.zeros_like(x[:, :1, :])          # (B,1,D)
    x_prev = tf.concat([x0, x[:, :-1, :]], 1) # (B,L,D)

    with tf.variable_scope(None, default_name="token_shift_mix"):
        mix_raw = tf.get_variable(
            "mix_raw",
            shape=[D],
            dtype=tf.float32,
            initializer=tf.truncated_normal_initializer(stddev=0.001, dtype=tf.float32),
        )

    mix = tf.reshape(tf.cast(tf.nn.sigmoid(mix_raw), x.dtype), [1, 1, D])

    # lerp: x_prev + mix * (x - x_prev)
    y = x_prev + mix * (x - x_prev)

    mask3 = tf.cast(mask, x.dtype)[:, :, None]
    return y * mask3


def stacked_target_cross_attention(query, keys, hidden_dim, head_num, layer_num, phase, param_initializer, mask=None):
    Q = query
    L = tf.shape(keys)[1]
    outputs = []
    for i in range(layer_num):
        ### query fusion
        Q_ = DenseTower(name='p{}{}_stca_query_fuse_layer'.format(phase,i),
                                   output_dims=[hidden_dim],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[None],
                                   norms=[False])(tf.concat(outputs + [Q], axis = -1))
        ### input encoder: LN + SwishGLUFFN
        Q_ = tf.keras.layers.LayerNormalization(axis=-1)(SwishGLUFFN(hidden_dim, 0.5, Q_, i, param_initializer))
        KV_ = tf.keras.layers.LayerNormalization(axis=-1)(SwishGLUFFN(hidden_dim, 0.5, keys, i, param_initializer))

        ### target attention
        assert hidden_dim % head_num == 0, "hidden dim must be divided by head num"
        Q_ = DenseTower(name='p{}{}_stca_query_trans_layer'.format(phase,i),
                                   output_dims=[hidden_dim],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[None],
                                   norms=[False])(Q_)
        KV_ = DenseTower(name='p{}{}_stca_kv_trans_layer'.format(phase,i),
                                   output_dims=[hidden_dim * 2],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[None],
                                   norms=[False])(KV_)
        K_, V_ = tf.split(KV_, 2, axis = -1)
        Q_ = tf.stack(tf.split(Q_, head_num, axis = -1), axis = 1)
        K_ = tf.stack(tf.split(K_, head_num, axis = -1), axis = 1)
        V_ = tf.stack(tf.split(V_, head_num, axis = -1), axis = 1)

        attn_scores = tf.matmul(Q_, K_, transpose_b=True) * ((hidden_dim // head_num) ** (-0.5))
        
        if mask is not None:
            cur_mask = tf.tile(tf.reshape(mask,[-1,1,1,L]), [1,head_num,1,1])
            paddings = tf.fill(tf.shape(attn_scores), tf.constant(-(2 ** 20) + 1, dtype=tf.float32))
            attn_scores = tf.where(cur_mask > 0, attn_scores, paddings)

        attn_scores = tf.nn.softmax(attn_scores, axis = -1)

        output = tf.matmul(attn_scores, V_) #(B,H,1,head_dim)
        output = tf.concat(tf.unstack(output, axis = 1), axis = -1) #(B,1,hidden_dim)

        output = DenseTower(name='p{}{}_stca_output_trans_layer'.format(phase,i),
                                   output_dims=[hidden_dim],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[None],
                                   norms=[False])(output)
        outputs.append(output)

    ### fuse all layers outputs
    final_output = DenseTower(name='p{}{}_stca_final_output_trans_layer'.format(phase,i),
                                   output_dims=[hidden_dim],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[None],
                                   norms=[False])(tf.concat(outputs + [Q], axis = -1))
    final_output = SwishGLUFFN(hidden_dim, 0.5, final_output, i, param_initializer)
    return tf.squeeze(final_output, axis = 1)

def stacked_mm_target_cross_attention_v2(
    query_lst, keys, mm_sim_scores, hidden_dim, head_num, layer_num, phase,
    param_initializer, seq_name, mask=None, return_lst=False, apply_rope=False, rope_reverse=False,
    apply_token_shift=False
):
    L = tf.shape(keys)[1]
    outputs = []
    for i in range(layer_num):
        # query fuse
        Q_ = DenseTower(name='p{}{}_stca_query_fuse_layer'.format(phase, i),
                        output_dims=[hidden_dim],
                        kernel_initializers=param_initializer,
                        bias_initializers=param_initializer,
                        activations=[None],
                        norms=[False])(tf.concat(outputs + [query_lst[i]], axis=-1))

        Q_ = tf.keras.layers.LayerNormalization(axis=-1)(SwishGLUFFN(hidden_dim, 0.5, Q_, i, param_initializer))
        KV_ = tf.keras.layers.LayerNormalization(axis=-1)(lite_encoder(hidden_dim, keys, (outputs[i-1] if i > 0 else None), i, param_initializer, seq_name))

        ### simple token shift
        if apply_token_shift:
            KV_ = token_shift_mix(KV_, mask)

        # proj
        Q_ = DenseTower(name='p{}{}_stca_query_trans_layer'.format(phase, i),
                        output_dims=[hidden_dim],
                        kernel_initializers=param_initializer,
                        bias_initializers=param_initializer,
                        activations=[None],
                        norms=[False])(Q_)

        KV_ = DenseTower(name='p{}{}_stca_kv_trans_layer'.format(phase, i),
                         output_dims=[hidden_dim * 2],
                         kernel_initializers=param_initializer,
                         bias_initializers=param_initializer,
                         activations=[None],
                         norms=[False])(KV_)

        K_, V_ = tf.split(KV_, 2, axis=-1)

        Q_ = tf.transpose(tf.reshape(Q_, [-1, 1, head_num, hidden_dim // head_num]), [0, 2, 1, 3])
        K_ = tf.transpose(tf.reshape(K_, [-1, L, head_num, hidden_dim // head_num]), [0, 2, 1, 3])
        V_ = tf.transpose(tf.reshape(V_, [-1, L, head_num, hidden_dim // head_num]), [0, 2, 1, 3])

        if apply_rope:
            key_pos = tf.range(L, 0, -1) if rope_reverse else tf.range(1, L + 1)
            K_ = rope_position_encoder(K_, positions=key_pos)

        attn_scores = tf.matmul(Q_, K_, transpose_b=True) * ((hidden_dim // head_num) ** (-0.5)) #(B,H,1,L)
    
        ### multi-modal cosine similarity: no split head
        expand_sim_scores = tf.expand_dims(tf.expand_dims(mm_sim_scores[i], axis = 1), axis = 2) # (B, L) -> (B, 1, 1, L) 

        with tf.variable_scope("sa_ta_fusion_{}".format(seq_name), reuse=tf.AUTO_REUSE):
            alpha = tf.get_variable(
                "alpha", shape=[], dtype=tf.float32,
                initializer=tf.constant_initializer(1.0)
            )
            beta = tf.get_variable(
                "beta", shape=[], dtype=tf.float32,
                initializer=tf.constant_initializer(0.0)
            )
            gamma = tf.get_variable(
                "gamma", shape=[], dtype=tf.float32,
                initializer=tf.constant_initializer(0.0)
            )

        ### fuse id scores and mm scores    
        final_scores = alpha * attn_scores + beta * expand_sim_scores + gamma * (expand_sim_scores * attn_scores)
        if mask is not None:
            cur_mask = tf.reshape(mask, [-1, 1, 1, L])
            final_scores += (1.0 - cur_mask) * (-(2 ** 20) + 1)

        final_scores = tf.nn.softmax(final_scores, axis = -1)

        output = tf.matmul(final_scores, V_) #(B,H,1,head_dim)
        output = tf.reshape(tf.transpose(output, [0, 2, 1, 3]), [-1, 1, hidden_dim])
        output = DenseTower(name='p{}{}_stca_output_trans_layer'.format(phase, i),
                            output_dims=[hidden_dim],
                            kernel_initializers=param_initializer,
                            bias_initializers=param_initializer,
                            activations=[None],
                            norms=[False])(output)
        outputs.append(output)

    final_output = DenseTower(name='p{}{}_stca_final_output_trans_layer'.format(phase, i),
                              output_dims=[hidden_dim],
                              kernel_initializers=param_initializer,
                              bias_initializers=param_initializer,
                              activations=[None],
                              norms=[False])(tf.concat(outputs + query_lst, axis=-1))
    final_output = SwishGLUFFN(hidden_dim, 0.5, final_output, i, param_initializer)
    outputs.append(final_output)
    return [tf.squeeze(output, axis = 1) for output in outputs] if return_lst else (tf.squeeze(final_output, axis=1))

    
def semantic_aware_target_attention(id_query, id_keys, mm_sim_scores, hidden_dim, head_num, phase, param_initializer, seq_name, mask=None):
    L = tf.shape(id_keys)[1]
    ### target attention
    assert hidden_dim % head_num == 0, "hidden dim must be divided by head num"
    Q_ = DenseTower(name='p{}{}_sata_query_trans_layer'.format(phase, seq_name),
                                   output_dims=[hidden_dim],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[None],
                                   norms=[False])(id_query)
    KV_ = DenseTower(name='p{}{}_sata_kv_trans_layer'.format(phase,seq_name),
                                   output_dims=[hidden_dim * 2],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[None],
                                   norms=[False])(id_keys)
    K_, V_ = tf.split(KV_, 2, axis = -1)
    Q_ = tf.stack(tf.split(Q_, head_num, axis = -1), axis = 1)
    K_ = tf.stack(tf.split(K_, head_num, axis = -1), axis = 1)
    V_ = tf.stack(tf.split(V_, head_num, axis = -1), axis = 1)

    attn_scores = tf.matmul(Q_, K_, transpose_b=True) * ((hidden_dim // head_num) ** (-0.5)) #(B,H,1,L)
    
    ### multi-modal cosine similarity: no split head
    expand_sim_scores = tf.expand_dims(tf.expand_dims(mm_sim_scores, axis = 1), axis = 2) # (B, L) -> (B, 1, 1, L) 

    with tf.variable_scope("sa_ta_fusion_{}".format(seq_name), reuse=tf.AUTO_REUSE):
        alpha = tf.get_variable(
            "alpha", shape=[], dtype=tf.float32,
            initializer=tf.constant_initializer(1.0)
        )
        beta = tf.get_variable(
            "beta", shape=[], dtype=tf.float32,
            initializer=tf.constant_initializer(0.0)
        )
        gamma = tf.get_variable(
            "gamma", shape=[], dtype=tf.float32,
            initializer=tf.constant_initializer(0.0)
        )

    ### fuse id scores and mm scores    
    final_scores = alpha * attn_scores + beta * expand_sim_scores + gamma * (expand_sim_scores * attn_scores)
    if mask is not None:
        cur_mask = tf.tile(tf.reshape(mask,[-1,1,1,L]), [1,head_num,1,1])
        paddings = tf.fill(tf.shape(final_scores), tf.constant(-(2 ** 20) + 1, dtype=tf.float32))
        final_scores = tf.where(cur_mask > 0, final_scores, paddings)

    final_scores = tf.nn.softmax(final_scores, axis = -1)

    output = tf.matmul(final_scores, V_) #(B,H,1,head_dim)
    output = tf.squeeze(tf.concat(tf.unstack(output, axis = 1), axis = -1), axis = 1) #(B,hidden_dim)

    output = DenseTower(name='p{}{}_sa_ta_output_trans_layer'.format(phase,seq_name),
                                   output_dims=[hidden_dim],
                                   kernel_initializers=param_initializer,
                                   bias_initializers=param_initializer,
                                   activations=[None],
                                   norms=[False])(output)
    return output

def hyformer(
    query_tokens, ns_tokens, keys, mm_sim_scores, hidden_dim, head_num, layer_num, seq_num, phase,
    param_initializer, seq_name_lst, mask_lst=None, return_lst=False, apply_rope=False, rope_reverse=False,
    apply_token_shift=False
):
    ###
    # add non more non sequence fs and context fs into query
    # tokenize query
    # cross interact multiple seqs through query cross interaction(rankmixer_style)
    # query_tokens: (B,seq_num,query_len,D)
    # keys: (B,seq_num,L,D)
    # mm_sim_scores: (B,seq_num,query_len,L) masked
    ###
    L = tf.shape(keys)[2] #defaultly, all seqs have same length
    query_len = query_tokens.shape.as_list()[2]
    outputs = [] #list((B,seq_num,query_len,D))
    for i in range(layer_num):
        # query boosting: multiple seq query and ns token cross
        # print("ns token shape:{}, query token shape:{}".format(ns_tokens.shape, query_tokens.shape))
        all_tokens = tf.concat([ns_tokens, tf.reshape(query_tokens, [-1, seq_num * query_len, hidden_dim])], axis = 1) #(B,8,D) 4+4
        # print("all tokens shape:{}".format(all_tokens.shape))
        all_tokens = mixer_tower(all_tokens, head_num, 64, 64, 2, 1, phase, param_initializer, False)
        ns_tokens, query_tokens_delta = tf.split(all_tokens, 2, axis = 1)
        #residual
        query_tokens += tf.reshape(query_tokens_delta, [-1, seq_num, query_len, hidden_dim])
        # print("ns token shape:{}, query token shape:{}".format(ns_tokens.shape, query_tokens.shape))
        # query fuse, share parameter
        Q_ = DenseTower(name='p{}{}_stca_query_fuse_layer'.format(phase, i),
                        output_dims=[hidden_dim],
                        kernel_initializers=param_initializer,
                        bias_initializers=param_initializer,
                        activations=[None],
                        norms=[False])(tf.concat(outputs + [query_tokens], axis=-1))

        Q_ = tf.keras.layers.LayerNormalization(axis=-1)(SwishGLUFFN(hidden_dim, 0.5, Q_, i, param_initializer)) #(B,seq_num,query_len,D)

        seq_outputs = []
        for j in range(seq_num):
            Q_seq = Q_[:,j,:,:] #(B,query_len,D)
            KV_seq = keys[:,j,:,:] #(B,L,D)
            mm_sim_score_seq = mm_sim_scores[:,j,:,:] #(B,query_len,L)
            mask_seq, seq_name = mask_lst[j], seq_name_lst[j]
            # proj
            Q_seq = DenseTower(name='p{}{}{}_hyformer_query_trans_layer'.format(phase,i,j),
                            output_dims=[hidden_dim],
                            kernel_initializers=param_initializer,
                            bias_initializers=param_initializer,
                            activations=[None],
                            norms=[False])(Q_seq)
            
            KV_seq = tf.keras.layers.LayerNormalization(axis=-1)(lite_encoder(hidden_dim, KV_seq, (tf.reshape(outputs[i-1][:, j, :, :], [-1,1,query_len * hidden_dim]) if i > 0 else None), i, param_initializer, seq_name))

            ### simple token shift
            if apply_token_shift:
                KV_seq = token_shift_mix(KV_seq, mask_seq)

            KV_seq = DenseTower(name='p{}{}{}_hyformer_kv_trans_layer'.format(phase,i,j),
                            output_dims=[hidden_dim * 2],
                            kernel_initializers=param_initializer,
                            bias_initializers=param_initializer,
                            activations=[None],
                            norms=[False])(KV_seq)

            K_seq, V_seq = tf.split(KV_seq, 2, axis=-1)

            Q_seq = tf.transpose(tf.reshape(Q_seq, [-1, query_len, head_num, hidden_dim // head_num]), [0, 2, 1, 3])
            K_seq = tf.transpose(tf.reshape(K_seq, [-1, L, head_num, hidden_dim // head_num]), [0, 2, 1, 3])
            V_seq = tf.transpose(tf.reshape(V_seq, [-1, L, head_num, hidden_dim // head_num]), [0, 2, 1, 3])

            if apply_rope:
                key_pos = tf.range(L, 0, -1) if rope_reverse else tf.range(1, L + 1)
                K_seq = rope_position_encoder(K_seq, positions=key_pos)

            attn_scores = tf.matmul(Q_seq, K_seq, transpose_b=True) * ((hidden_dim // head_num) ** (-0.5)) #(B,H,query_len,L)
        
            ### multi-modal cosine similarity: no split head
            expand_sim_scores = tf.expand_dims(mm_sim_score_seq, axis = 1) # (B, query_len, L) -> (B, 1, query_len, L) 

            with tf.variable_scope("sa_ta_fusion_{}".format(seq_name), reuse=tf.AUTO_REUSE):
                alpha = tf.get_variable(
                    "alpha", shape=[], dtype=tf.float32,
                    initializer=tf.constant_initializer(1.0)
                )
                beta = tf.get_variable(
                    "beta", shape=[], dtype=tf.float32,
                    initializer=tf.constant_initializer(0.0)
                )
                gamma = tf.get_variable(
                    "gamma", shape=[], dtype=tf.float32,
                    initializer=tf.constant_initializer(0.0)
                )

            ### fuse id scores and mm scores    
            final_scores = alpha * attn_scores + beta * expand_sim_scores + gamma * (expand_sim_scores * attn_scores)
            if mask_seq is not None:
                cur_mask = tf.reshape(mask_seq, [-1, 1, 1, L])
                final_scores += (1.0 - cur_mask) * (-(2 ** 20) + 1)

            final_scores = tf.nn.softmax(final_scores, axis = -1)

            output = tf.matmul(final_scores, V_seq) #(B,H,query_len,head_dim)
            output = tf.reshape(tf.transpose(output, [0, 2, 1, 3]), [-1, query_len, hidden_dim])
            output = DenseTower(name='p{}{}{}_hyformer_output_trans_layer'.format(phase,i,j),
                                output_dims=[hidden_dim],
                                kernel_initializers=param_initializer,
                                bias_initializers=param_initializer,
                                activations=[None],
                                norms=[False])(output)

            seq_outputs.append(output)

        outputs.append(tf.stack(seq_outputs, axis = 1)) #(B,seq_num,query_len,hidden_dim)

    final_output = DenseTower(name='p{}_hyformer_final_output_trans_layer'.format(phase),
                              output_dims=[hidden_dim],
                              kernel_initializers=param_initializer,
                              bias_initializers=param_initializer,
                              activations=[None],
                              norms=[False])(tf.concat(outputs + [query_tokens], axis=-1))
    final_output = SwishGLUFFN(hidden_dim, 0.5, final_output, phase, param_initializer) #(B,seq_num,query_len,hidden_dim)
    outputs.append(final_output)
    return outputs if return_lst else final_output