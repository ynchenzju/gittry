import tensorflow as tf

class ParallelDense(tf.keras.layers.Layer):
    """
    一个并行的全连接层，可选是否使用 bias。
    inputs: (B, T, D)
    kernel: (T, D, H)
    bias:   (T, H)
    output: (B, T, H)
    """
    def __init__(self,
                 hidden_dim,
                 activation='relu',
                 kernel_initializer='glorot_uniform',
                 bias_initializer='zeros',
                 use_bias=True,
                 **kwargs):
        super().__init__(**kwargs)
        self.hidden_dim = hidden_dim
        self.activation = tf.keras.activations.get(activation)
        self.kernel_initializer = tf.keras.initializers.get(kernel_initializer)
        self.bias_initializer = tf.keras.initializers.get(bias_initializer)
        self.use_bias = use_bias

    def build(self, input_shape):
        num_tokens = input_shape[1]
        input_dim = input_shape[-1]

        self.kernel = self.add_weight(
            shape=(num_tokens, input_dim, self.hidden_dim),
            initializer=self.kernel_initializer,
            trainable=True,
            name='kernel'
        )

        if self.use_bias:
            self.bias = self.add_weight(
                shape=(num_tokens, self.hidden_dim),
                initializer=self.bias_initializer,
                trainable=True,
                name='bias'
            )
        else:
            self.bias = None

        super().build(input_shape)

    def call(self, inputs):
        # inputs: (B, T, D)
        output = tf.einsum('btd,tdh->bth', inputs, self.kernel)
        if self.use_bias and self.bias is not None:
            output = output + self.bias
        if self.activation is not None:
            output = self.activation(output)
        return output

    def get_config(self):
        config = super().get_config()
        config.update({
            'hidden_dim': self.hidden_dim,
            'activation': tf.keras.activations.serialize(self.activation),
            'kernel_initializer': tf.keras.initializers.serialize(self.kernel_initializer),
            'bias_initializer': tf.keras.initializers.serialize(self.bias_initializer),
            'use_bias': self.use_bias,
        })
        return config


class ParallelDenseTower(tf.keras.layers.Layer):
    """
    由多个 ParallelDense 堆叠的塔。
    支持每一层单独控制 use_bias，也支持一个全局的 use_bias。
    """
    def __init__(self,
                 hidden_units,              # list, e.g. [256, 128]
                 activations=None,
                 kernel_initializers='glorot_uniform',
                 bias_initializers='zeros',
                 use_bias=True,             # bool 或 list[bool]
                 **kwargs):
        super().__init__(**kwargs)

        self.hidden_units = hidden_units

        # activations 统一成 list
        if not isinstance(activations, list):
            self.activations = [activations] * len(hidden_units)
        else:
            self.activations = activations

        # kernel_initializers 统一成 list
        if not isinstance(kernel_initializers, list):
            self.kernel_initializers = [kernel_initializers] * len(hidden_units)
        else:
            self.kernel_initializers = kernel_initializers

        # bias_initializers 统一成 list
        if not isinstance(bias_initializers, list):
            self.bias_initializers = [bias_initializers] * len(hidden_units)
        else:
            self.bias_initializers = bias_initializers

        # use_bias 统一成 list
        if not isinstance(use_bias, list):
            self.use_biases = [use_bias] * len(hidden_units)
        else:
            self.use_biases = use_bias

        # 创建子层
        self.parallel_layers = []
        for i, units in enumerate(self.hidden_units):
            activation = self.activations[i] if i < len(self.activations) else None
            k_init = self.kernel_initializers[i] if i < len(self.kernel_initializers) else 'glorot_uniform'
            b_init = self.bias_initializers[i] if i < len(self.bias_initializers) else 'zeros'
            use_b  = self.use_biases[i] if i < len(self.use_biases) else True

            layer = ParallelDense(
                hidden_dim=units,
                activation=activation,
                kernel_initializer=k_init,
                bias_initializer=b_init,
                use_bias=use_b,
                name=f'parallel_dense_{i}'
            )
            self.parallel_layers.append(layer)

    def call(self, inputs):
        x = inputs
        for layer in self.parallel_layers:
            x = layer(x)
        return x

    def get_config(self):
        config = super().get_config()
        config.update({
            'hidden_units': self.hidden_units,
            'activations': [tf.keras.activations.serialize(a) for a in self.activations],
            'kernel_initializers': [tf.keras.initializers.serialize(k) for k in self.kernel_initializers],
            'bias_initializers': [tf.keras.initializers.serialize(b) for b in self.bias_initializers],
            'use_bias': self.use_biases,
        })
        return config
