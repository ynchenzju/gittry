#!/usr/bin/env python
# -*- coding: utf-8 -*-

import tensorflow as tf
import ego
from ego import DenseTower, Normalization, BatchNormalization
from collections import defaultdict
import yaml
from tools.funcs import *
from tensorflow.keras.layers import Dense

class MAL_NET_SEARCH:
    def __init__(
            self,
            raw_targets,
            main_targets, 
            auxiliary_targets,
            sub_scene_targets,
            search_targets, 
            param_initializer,
            phase,
            fuse_config = "attention_fuse",
            use_catlabel = True,
            stop_search_tower_gradient = False,
            search_split = False
        ):
        self.main_targets = main_targets
        self.auxiliary_targets = auxiliary_targets
        self.sub_scene_targets = sub_scene_targets
        self.search_targets = search_targets
        self.raw_targets = raw_targets
        self.scene_idx_map = {'dd':0, 'pdp':1, 'pp':2}
        self.param_initializer = param_initializer
        self.target_idx_map = defaultdict(int)
        self.phase = phase
        self.fuse_config = fuse_config
        self.use_catlabel = use_catlabel
        self.stop_search_tower_gradient = stop_search_tower_gradient
        self.search_split = search_split
        self.nn_outputs, self.labels, self.weights, self.losses, self.targets = defaultdict(list), defaultdict(list), defaultdict(list), defaultdict(list), defaultdict(list)
        self.cat_labels = defaultdict(list) # the candidate labels to construct cat label for every main label
        self.sub_scene_vecs = defaultdict(list) # the candidate sub scene vecs to augument main vec for every main tasks
        self.cat_losses, self.cat_weights = [], []
        self.eval_nodes = []
        self.dump_tensors, self.dump_scalars = [], []
        self.build_target_idx_map()
        self.rezero_alpha = {}
        self.rezero_search_alpha = {}

    def build_target_idx_map(self):
        for idx, target in enumerate(self.raw_targets):
            self.target_idx_map[target] = idx
            #print("target:{}, idx:{}".format(target, idx))
        ### for search targets
        for idx, target in enumerate(self.search_targets):
            self.target_idx_map[target] = idx + (len(self.raw_targets) * (len(self.scene_idx_map) + 1)) ### label: rec_label + dd_eval_rec_label + pdp_eval_rec_label + pp_rec_eval_label + search_label

    def get_rec_mask(self):
        ### only for cat tower(share and scene)
        def _wsum(ws):
            return tf.add_n([tf.reshape(tf.cast(w, tf.float32), [-1, 1]) for w in ws])
        
        s = len(self.auxiliary_targets)
        return tf.cast(_wsum(self.weights[self.phase][:s]) > 0, tf.float32)  # (B,1)

    def compute_share_cat_label(self): # if search auxiliary task label make sense, new search share cat label can be added here
        cat_label_weight = 1.0
        cat_label = 0

        labels = [tf.cast(label, dtype=tf.int32) for label in self.labels[self.phase]]
        pos_sizes = [2,3,2,4] # atc or not/ direct order 1d,2-7d,none / shop cr or not/ terminal status: cancel/return/complete/none
        atc_indicator = labels[0] #atc: 0/1
        direct_order_indicator = labels[1] * 1 + labels[2] * 2 #direct order: 0:none, 1:1d, 2:2-7d
        direct_order_indicator = tf.clip_by_value(direct_order_indicator,0,2)
        shop_cr_indicator = labels[3] #shop cr: 0/1
        terminal_status = labels[4] * 1 + labels[5] * 2 + labels[6] * 3  #terminal status: 0:none, 1:cancel, 2:return, 3:complete
        terminal_status = tf.clip_by_value(terminal_status,0,3)
        indicator_weights = [10.0,20.0,20.0,20.0]
        indicators = [atc_indicator, direct_order_indicator, shop_cr_indicator, terminal_status]
        for pos_size, indicator, weight in zip(pos_sizes, indicators, indicator_weights):
            cat_label = cat_label * pos_size + indicator
            cat_label_weight += tf.math.log(10.0 * weight) * tf.cast((indicator > 0), tf.float32) # 5,10,15,20
        
        print("share cat label:{}, share cat weight:{}".format(cat_label, cat_label_weight))
        return cat_label, cat_label_weight

    def compute_scene_cat_label(self, main_target_name):
        cat_label = None
        cat_label_weight = 1.0
        cat_labels = tf.concat(self.cat_labels[main_target_name], axis = -1)
        cat_labels = tf.concat([cat_labels, tf.ones_like(cat_labels[:,:1])], axis = -1)
        cat_label = tf.argmax(cat_labels, axis = -1)
        is_neg = tf.cast(tf.equal(cat_label, 3), tf.float32)
        cat_label_weight = is_neg * 1.0 + (1.0 - is_neg) * 20.0
        return cat_label, cat_label_weight
    
    def share_cat_tower(self, task_input, lhuc_input, gate_input):
        phase, idx, target, param_initializer = self.phase, self.target_idx_map["cat_label"], "cat_label", self.param_initializer

        t_input = dense_gate_tower(name='Task_Share_Bottom_{}{}_{}'.format(phase, idx, target),
                                   emb_input=task_input,
                                   hidden_dims=[128],
                                   param_initializer=param_initializer)
        
        # 1011 update: 增加scene gate
        t_input = gateNU(inputs=t_input, gate_inputs=gate_input,
                         gate_type='Scene', name='{}_{}'.format(phase, target))
        
        lhuc_weight_input = DenseTower(
            name="{}{}_lhuc_{}_input".format(phase, idx, target),
            output_dims=[512, t_input.shape[1]],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        lhuc_weight = DenseTower(
            name="{}{}_lhuc_{}".format(phase, idx, target),
            output_dims=[256, 64],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        t_mid = t_input * lhuc_weight_input * 2
        t_out = DenseTower(name='p{}_{}_tower_l1'.format(phase, target),
                           output_dims=[64],
                           kernel_initializers=param_initializer,
                           bias_initializers=param_initializer,
                           activations=[tf.nn.relu],
                           norms=[False])(t_mid)

        tlogits = DenseTower(name='p{}_{}_tower_l2'.format(phase, target),
                             output_dims=[48],
                             kernel_initializers=param_initializer,
                             bias_initializers=param_initializer,
                             activations=[None],
                             norms=[False])(t_out * lhuc_weight * 2)
        
        tlogits = tf.clip_by_value(tlogits, -1000, 1000)

        
        toutput = tf.identity(tf.nn.softmax(tlogits, axis = -1, name = "p{}_{}_logits".format(phase, target)),
                                  "p{}_{}".format(phase, target))
        tlabel, tweight = self.compute_share_cat_label()
        # 'reduction = none' means no avg over batch here; for per sample reweight
        loss_fn = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True, reduction='none',name='p{}_{}_loss'.format(phase, target))
        tloss = tf.reshape(loss_fn(tlabel, tlogits),[-1,1])

        self.cat_losses.append(tloss)
        self.cat_weights.append(tweight * self.get_rec_mask())

        # self.dump_scalars.append(tf.reduce_mean(tf.cast(tlabel,tf.float32), name='cat_label'))
        # self.dump_scalars.append(tf.reduce_mean(tloss,name='cat_label_loss'))
        # self.dump_scalars.append(tf.reduce_mean(tweight,name='cat_label_weight'))

        return t_out
    
    def scene_cat_tower(self, main_target_name, task_input, lhuc_input, gate_input):
        phase, target, param_initializer = self.phase, "{}_cat_label".format(main_target_name), self.param_initializer
        t_input = dense_gate_tower(name='Task_Share_Bottom_{}_{}'.format(phase, target),
                                   emb_input=task_input,
                                   hidden_dims=[128],
                                   param_initializer=param_initializer)
        # 1011 update: 增加scene gate
        t_input = gateNU(inputs=t_input, gate_inputs=gate_input,
                         gate_type='Scene', name='{}_{}'.format(phase, target))
        
        lhuc_weight_input = DenseTower(
            name="{}_lhuc_{}_input".format(phase, target),
            output_dims=[512, t_input.shape[1]],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        lhuc_weight = DenseTower(
            name="{}_lhuc_{}".format(phase, target),
            output_dims=[256, 64],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        t_out = DenseTower(name='p{}_{}_tower_l1'.format(phase, target),
                           output_dims=[64],
                           kernel_initializers=param_initializer,
                           bias_initializers=param_initializer,
                           activations=[tf.nn.relu],
                           norms=[False])(t_input * lhuc_weight_input * 2)
        
        final_output_dim = len(self.cat_labels[main_target_name]) + 1 

        tlogits = DenseTower(name='p{}_{}_tower_l2'.format(phase, target),
                             output_dims=[final_output_dim],
                             kernel_initializers=param_initializer,
                             bias_initializers=param_initializer,
                             activations=[None],
                             norms=[False])(t_out * lhuc_weight * 2)
        
        tlogits = tf.clip_by_value(tlogits, -1000, 1000)

        
        toutput = tf.identity(tf.nn.softmax(tlogits, axis = -1, name = "p{}_{}_logits".format(phase, target)),
                                  "p{}_{}".format(phase, target))
        tlabel, tweight = self.compute_scene_cat_label(main_target_name)

        # 'reduction = none' means no avg over batch here; for per sample reweight
        loss_fn = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True, reduction='none',name='p{}_{}_loss'.format(phase, target))
        tloss = tf.reshape(loss_fn(tlabel, tlogits),[-1,1])
        tweight = tf.reshape(tweight,[-1,1])

        self.cat_losses.append(tloss)
        self.cat_weights.append(tweight * self.get_rec_mask())

        # self.dump_scalars.append(tf.reduce_mean(tf.cast(tlabel,tf.float32), name='cat_label'))
        # self.dump_scalars.append(tf.reduce_mean(tloss,name='cat_label_loss'))
        # self.dump_scalars.append(tf.reduce_mean(tweight,name='cat_label_weight'))
        # for i in range(4):
        #     scene_i_prob_mean = tf.reduce_mean(toutput[:,i], name='{}_scene_{}_convert_prob'.format(main_target_name,i+1))
        #     self.dump_scalars.append(scene_i_prob_mean)

        return t_out, toutput
        
        
    def task_tower(self, target_name, task_input, lhuc_input, gate_input, extra_input=None):
        phase, target, param_initializer = self.phase, target_name, self.param_initializer
        raw_target = None
        if target in self.target_idx_map:
            idx = self.target_idx_map[target]
        else:### sub scene target
            raw_target, sub_scene = target.rsplit('_',1)
            print("raw target:{}, scene:{}".format(raw_target, sub_scene))
            raw_idx = self.target_idx_map[raw_target]
            idx = raw_idx + (self.scene_idx_map[sub_scene] + 1) * len(self.raw_targets)

        if target in self.search_targets and self.stop_search_tower_gradient:
            task_input, lhuc_input, gate_input = tf.stop_gradient(task_input), tf.stop_gradient(lhuc_input), tf.stop_gradient(gate_input)
        
        t_input = dense_gate_tower(name='Task_Share_Bottom_{}{}_{}'.format(phase, idx, target),
                                   emb_input=task_input,
                                   hidden_dims=[128],
                                   param_initializer=param_initializer)
        # 1011 update: 增加scene gate
        t_input = gateNU(inputs=t_input, gate_inputs=gate_input,
                         gate_type='Scene', name='{}{}_{}'.format(phase, idx, target))
        
        lhuc_weight_input = DenseTower(
            name="{}{}_lhuc_{}_input".format(phase, idx, target),
            output_dims=[512, t_input.shape[1]],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        lhuc_weight = DenseTower(
            name="{}{}_lhuc_{}".format(phase, idx, target),
            output_dims=[256, 64],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        t_out = DenseTower(name='p{}_{}_tower_l1'.format(phase, target),
                           output_dims=[64],
                           kernel_initializers=param_initializer,
                           bias_initializers=param_initializer,
                           activations=[tf.nn.relu],
                           norms=[False])(t_input * lhuc_weight_input * 2)
        
        if target in self.main_targets and extra_input is not None:
            # stop gradient at the input, so the fusion net params can be updated normally
            print("extra_input shape:{}".format(extra_input.shape))
            extra_input = tf.stop_gradient(extra_input)
            auxiliary_vec_num = extra_input.shape[1]

            if self.fuse_config == "ta_cat":
                ### main vec augument
                query = t_out
                if target in self.sub_scene_vecs:
                    cat_vec, cat_prob = tf.stop_gradient(self.sub_scene_vecs[target][-2]), tf.stop_gradient(self.sub_scene_vecs[target][-1])
                    aug_vecs = tf.stack([tf.stop_gradient(v) for v in self.sub_scene_vecs[target][0:3]] + [t_out], axis = 1) #(B,4,64)
                    aug_vecs = DenseTower(name='p{}_{}_cat_aug_trans'.format(phase, target),
                             output_dims=[64],
                             kernel_initializers=param_initializer,
                             bias_initializers=param_initializer,
                             activations=[None],
                             norms=[False])(aug_vecs)
                    aug_main_vec = tf.reduce_sum((tf.expand_dims(cat_prob, axis = 2) * aug_vecs), axis = 1) #(B,64)

                    ### use the cat vec to augument main vec FILM
                    film_cat_layer = DenseTower(name='p{}_{}_cat_film_trans'.format(phase, target),
                             output_dims=[128],
                             kernel_initializers=tf.keras.initializers.Zeros(),
                             bias_initializers=tf.keras.initializers.Zeros(),
                             activations=[None],
                             norms=[False])
                    alpha, beta = tf.split(film_cat_layer(cat_vec),2,axis = -1)
                    aug_main_vec = (1.0 + alpha) * aug_main_vec + beta
                    query = aug_main_vec

                ### extra_input: rec_auxiliary + share_cat + search_auxiliary
                if self.search_split:
                    rec_auxiliary_vecs, search_auxiliary_vecs = tf.split(extra_input, [len(self.auxiliary_targets) + 1, len(self.search_targets)], axis = 1)
                    
                    rec_auxiliary_vec, attn_scores, _, head_weights = gated_mhta(tf.expand_dims(query,1),rec_auxiliary_vecs,128,64,8,phase,param_initializer,None)
                    search_auxiliary_vec, attn_scores, _, head_weights = gated_mhta(tf.expand_dims(query,1),search_auxiliary_vecs,128,64,8,phase,param_initializer,None)
                    
                    if target not in self.rezero_alpha:
                        self.rezero_alpha[target] = tf.Variable(1.0, trainable=True, name=f"rezero_alpha_{target}")
                    if target not in self.rezero_search_alpha:
                        self.rezero_search_alpha[target] = tf.Variable(0.1, trainable=True, name=f"rezero_search_alpha_{target}")
                    
                    t_out = t_out + self.rezero_alpha[target] * rec_auxiliary_vec + self.rezero_search_alpha[target] * search_auxiliary_vec
                
                else:
                    auxiliary_vec, attn_scores, head_weights = gated_mhta_lite(tf.expand_dims(query,1),extra_input,128,64,8,phase,param_initializer,None)
                    if target not in self.rezero_alpha:
                        self.rezero_alpha[target] = tf.Variable(1.0, trainable=True, name=f"rezero_alpha_{target}")
                    t_out = t_out + self.rezero_alpha[target] * auxiliary_vec

        tlogits = DenseTower(name='p{}_{}_tower_l2'.format(phase, target),
                             output_dims=[1],
                             kernel_initializers=param_initializer,
                             bias_initializers=param_initializer,
                             activations=[None],
                             norms=[False])(t_out * lhuc_weight * 2)
        
        tlogits = tf.clip_by_value(tlogits, -1000, 1000)

        
        toutput = tf.identity(tf.nn.sigmoid(tlogits, name="p{}_{}_logits".format(phase, target)),
                              "p{}_{}".format(phase, target))
        tlabel, tweight = ego.get_label_weight(target_name="p{}_{}_label".format(phase, target), label_idx=idx * 2)            
        tloss = tf.nn.sigmoid_cross_entropy_with_logits(labels=tlabel, logits=tlogits,
                                                        name='p{}_{}_loss'.format(phase, target))
        print("tloss shape:{}, tweight shape:{}".format(tloss.shape,tweight.shape))

        tname = "p{}_{}".format(phase, target)
        self.nn_outputs[phase].append(toutput)
        self.labels[phase].append(tlabel)
        self.weights[phase].append(tweight)
        self.losses[phase].append(tloss)
        self.targets[phase].append(tname)

        if raw_target is not None:
            self.cat_labels[raw_target].append(tlabel * tf.cast(tweight > 0,tf.float32))
            self.sub_scene_vecs[raw_target].append(t_out)

        ego.Target(tname, toutput, tlabel, tweight, tloss, metric_type=None) 
        print("Target name:{}".format(tname))

        if phase == 0 and (idx < len(self.raw_targets) or ("search" in target_name)): ### add eval search targets
            ### label: rec_label + dd_eval_rec_label + pdp_eval_rec_label + pp_rec_eval_label + search_label
            if "search" in target_name:
                tname = "search_p{}_{}".format(phase, target)
                eval_item_output = tf.identity(toutput, tname)
                ego.Target(tname, eval_item_output, tlabel, tweight, metric_type=ego.MetricType.GAUC)
                print("Target name:{}".format(tname))
                self.eval_nodes.append(tname)
            else:
                eval_bundles = ["dd", "pdp", "pp"]
                label_idx_gap = len(self.raw_targets) * 2  
                for i, bundle in enumerate(eval_bundles, 1):
                    tname = "{}_p{}_{}".format(bundle, phase, target)
                    tlabel, tweight = ego.get_label_weight(
                        target_name="p{}_{}_{}_label_weight".format(phase, target, bundle),
                        label_idx=idx * 2 + i * label_idx_gap)
                    eval_item_output = tf.identity(toutput, tname)
                    ego.Target(tname, eval_item_output, tlabel, tweight, metric_type=ego.MetricType.GAUC)
                    print("Target name:{}".format(tname))
                    self.eval_nodes.append(tname)
        
        return t_out

    def forward(self, *inputs): # currently input: share_bottom + bias_feature, lhuc_input
        task_input = inputs[0]
        lhuc_input = inputs[1]
        gate_input = inputs[2]
        def AKA():
            aka_vecs = [] # 64 x 8 = 512 share vecs + 6 = 14

            ### auxiliary task
            for target_name in self.auxiliary_targets:
                aka_vecs.append(self.task_tower(target_name, task_input, lhuc_input, gate_input))

            ### share cat tower
            aka_vecs.append(self.share_cat_tower(task_input, lhuc_input, gate_input))

            ### auxiliary search task
            for target_name in self.search_targets:
                aka_vecs.append(self.task_tower(target_name, task_input, lhuc_input, gate_input))
            
            ### auxiliary scene task
            for target_name in self.sub_scene_targets:
                self.task_tower(target_name, task_input, lhuc_input, gate_input)
            
            ### target specific scene task
            for target_name in self.main_targets:
                if target_name in self.cat_labels:
                    cat_vec, cat_prob = self.scene_cat_tower(target_name, task_input, lhuc_input, gate_input)
                    self.sub_scene_vecs[target_name].append(cat_vec)
                    self.sub_scene_vecs[target_name].append(cat_prob)
        
            aka_vecs = tf.stack(aka_vecs,axis = 1)
            print("AKA vecs shape: {}".format(aka_vecs.shape))
            return aka_vecs

        def PTP(aka_vecs):
            for target_name in self.main_targets:
                self.task_tower(target_name, task_input, lhuc_input, gate_input, aka_vecs)

        aka_vecs = AKA()
        PTP(aka_vecs)
        
        return self.nn_outputs, self.labels, self.weights, self.losses, self.targets, self.eval_nodes, self.cat_losses, self.cat_weights

    def get_dump_tensors(self):
        return self.dump_tensors
    
    def get_dump_scalars(self):
        return self.dump_scalars