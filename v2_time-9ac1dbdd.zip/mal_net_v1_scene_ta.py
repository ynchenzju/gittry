#!/usr/bin/env python
# -*- coding: utf-8 -*-

import tensorflow as tf
import ego
from ego import DenseTower, Normalization, BatchNormalization
from collections import defaultdict
import yaml
from tools.funcs import *
from tensorflow.keras.layers import Dense

class MAL_NET_V1:
    def __init__(
            self,
            all_targets, # all_targets = auxiliary_targets + sub_scene_targets + main_targets, no use
            raw_targets,
            main_targets, 
            auxiliary_targets,
            sub_scene_targets, 
            param_initializer,
            phase,
            fuse_config = "attention_fuse",
            use_catlabel = True,
            stop_sub_tower_gradient = False
        ):
        self.all_targets = all_targets
        self.main_targets = main_targets
        self.auxiliary_targets = auxiliary_targets
        self.sub_scene_targets = sub_scene_targets
        self.raw_targets = raw_targets
        self.scene_idx_map = {'dd':0, 'pdp':1, 'pp':2}
        self.param_initializer = param_initializer
        self.target_idx_map = defaultdict(int)
        self.phase = phase
        self.fuse_config = fuse_config
        self.use_catlabel = use_catlabel
        self.stop_sub_tower_gradient = stop_sub_tower_gradient
        self.nn_outputs, self.labels, self.weights, self.losses, self.targets = defaultdict(list), defaultdict(list), defaultdict(list), defaultdict(list), defaultdict(list)
        self.sub_scene_vecs = defaultdict(list) # the candidate sub scene vecs to augument main vec for every main tasks
        self.aux_losses, self.aux_weights = [], []
        self.eval_nodes = []
        self.dump_tensors, self.dump_scalars = [], []
        self.build_target_idx_map()
        self.rezero_alpha = {}
        self._scenario_label = None

    def _dump_attention_scores(self, attn_scores, name_prefix, token_names=None):
        if not ego.is_training_mode():
            return
        if attn_scores is None:
            return

        attn = attn_scores
        if len(attn.shape) == 3:
            # (B, H, L) -> (B, L)
            attn = tf.reduce_mean(attn, axis=1)
        if len(attn.shape) != 2:
            return

        eps = tf.constant(1e-8, dtype=attn.dtype)
        p = tf.clip_by_value(attn, eps, 1.0)
        entropy = -tf.reduce_sum(p * tf.math.log(p), axis=-1)  # (B,)
        max_prob = tf.reduce_max(attn, axis=-1)  # (B,)

        self.dump_scalars.append(tf.reduce_mean(max_prob, name="{}_max_prob_mean".format(name_prefix)))
        self.dump_scalars.append(tf.reduce_mean(entropy, name="{}_entropy_mean".format(name_prefix)))
        self.dump_tensors.append(tf.reshape(max_prob, (-1,), name="{}_max_prob".format(name_prefix)))
        self.dump_tensors.append(tf.reshape(entropy, (-1,), name="{}_entropy".format(name_prefix)))

        if token_names is None:
            self.dump_tensors.append(tf.reshape(attn, (-1,), name="{}_flat".format(name_prefix)))
            return

        attn_len = attn.shape[1]
        if attn_len is None:
            self.dump_tensors.append(tf.reshape(attn, (-1,), name="{}_flat".format(name_prefix)))
            return
        if len(token_names) != int(attn_len):
            self.dump_tensors.append(tf.reshape(attn, (-1,), name="{}_flat".format(name_prefix)))
            return

        for i, token_name in enumerate(token_names):
            self.dump_scalars.append(tf.reduce_mean(attn[:, i], name="{}_{}_mean".format(name_prefix, token_name)))
            self.dump_tensors.append(tf.reshape(attn[:, i], (-1,), name="{}_{}".format(name_prefix, token_name)))

    def _get_scenario_label(self):
        if self._scenario_label is not None:
            return self._scenario_label

        # converter appends scenario label after: labels + (labels * 3 for eval bundles)
        eval_bundle_num = len(self.scene_idx_map)  # dd/pdp/pp
        scenario_label_idx = len(self.raw_targets) * (1 + eval_bundle_num) * 2
        scenario_label, _ = ego.get_label_weight(
            target_name="p{}_scenario_label".format(self.phase), label_idx=scenario_label_idx
        )
        scenario_label = tf.cast(tf.reshape(scenario_label, (-1,)), tf.int32)
        self._scenario_label = scenario_label
        return scenario_label

    def _dump_attention_scores_by_head(self, attn_scores, name_prefix, token_names=None):
        if not ego.is_training_mode():
            return
        if attn_scores is None:
            return
        if len(attn_scores.shape) != 3:
            return

        head_num = attn_scores.shape[1]
        token_num = attn_scores.shape[2]
        if head_num is None or token_num is None:
            return

        head_num = int(head_num)
        token_num = int(token_num)
        if token_names is None or len(token_names) != token_num:
            token_names = ["tok{}".format(i) for i in range(token_num)]

        eps = tf.constant(1e-8, dtype=attn_scores.dtype)
        for h in range(head_num):
            head_attn = attn_scores[:, h, :]  # (B, L)
            p = tf.clip_by_value(head_attn, eps, 1.0)
            entropy = -tf.reduce_sum(p * tf.math.log(p), axis=-1)  # (B,)
            max_prob = tf.reduce_max(head_attn, axis=-1)  # (B,)

            self.dump_scalars.append(
                tf.reduce_mean(max_prob, name="{}_head{}_max_prob_mean".format(name_prefix, h))
            )
            self.dump_scalars.append(
                tf.reduce_mean(entropy, name="{}_head{}_entropy_mean".format(name_prefix, h))
            )

            for i, token_name in enumerate(token_names):
                self.dump_scalars.append(
                    tf.reduce_mean(head_attn[:, i], name="{}_head{}_{}_mean".format(name_prefix, h, token_name))
                )
                self.dump_tensors.append(
                    tf.reshape(head_attn[:, i], (-1,), name="{}_head{}_{}".format(name_prefix, h, token_name))
                )

    def _dump_scene_transition(self, scene_attn_scores, name_prefix, token_names):
        if not ego.is_training_mode():
            return
        if scene_attn_scores is None:
            return
        if len(scene_attn_scores.shape) != 3:
            return
        if token_names is None or len(token_names) != 3:
            return

        # (B, H, 3) -> (B, 3)
        attn = tf.reduce_mean(scene_attn_scores, axis=1)
        scene_label = self._get_scenario_label()  # (B,)

        total_cnt = tf.cast(tf.shape(scene_label)[0], attn.dtype)
        eps = tf.constant(1e-8, dtype=attn.dtype)

        # converter mapping: pdp -> 0, dd -> 1, pp -> 2
        scene_defs = [("dd", 1), ("pdp", 0), ("pp", 2)]
        for current_scene, current_label in scene_defs:
            mask = tf.cast(tf.equal(scene_label, current_label), attn.dtype)  # (B,)
            mask_ = tf.reshape(mask, (-1, 1))  # (B, 1)
            cnt = tf.reduce_sum(mask)  # scalar
            denom = tf.maximum(cnt, eps)
            ratio = cnt / tf.maximum(total_cnt, eps)
            mean_vec = tf.reduce_sum(attn * mask_, axis=0) / denom  # (3,)

            self.dump_scalars.append(tf.identity(ratio, name="{}_{}_ratio".format(name_prefix, current_scene)))
            for i, token_name in enumerate(token_names):
                self.dump_scalars.append(
                    tf.identity(
                        mean_vec[i], name="{}_{}_to_{}_mean".format(name_prefix, current_scene, token_name)
                    )
                )

            # per-head transition (scalar only)
            head_num = scene_attn_scores.shape[1]
            if head_num is not None:
                head_num = int(head_num)
                attn_h = scene_attn_scores * tf.reshape(mask, (-1, 1, 1))  # (B, H, 3)
                mean_h = tf.reduce_sum(attn_h, axis=0) / denom  # (H, 3)
                for h in range(head_num):
                    for i, token_name in enumerate(token_names):
                        self.dump_scalars.append(
                            tf.identity(
                                mean_h[h, i],
                                name="{}_head{}_{}_to_{}_mean".format(
                                    name_prefix, h, current_scene, token_name
                                ),
                            )
                        )

    def build_target_idx_map(self):
        for idx, target in enumerate(self.raw_targets):
            self.target_idx_map[target] = idx
            #print("target:{}, idx:{}".format(target, idx))

    def compute_share_cat_label(self): # if search auxiliary task label make sense, new search share cat label can be added here
        cat_label_weight = 1.0
        cat_label = 0

        labels = [tf.cast(label, dtype=tf.int32) for label in self.labels[self.phase]]
        pos_sizes = [2,3,2,4] # atc or not/ direct order 1d,2-7d,none / shop cr or not/ terminal status: cancel/return/complete/none
        atc_indicator = labels[0] #atc: 0/1
        direct_order_indicator = labels[1] * 1 + labels[2] * 2 #direct order: 0:none, 1:1d, 2:2-7d
        direct_order_indicator = tf.clip_by_value(direct_order_indicator,0,2)
        shop_cr_indicator = labels[3] #shop cr: 0/1
        terminal_status = labels[4] * 1 + labels[5] * 2 + labels[6] * 3  #terminal status: 0:none, 1:cancel, 2:return, 3:complete
        terminal_status = tf.clip_by_value(terminal_status,0,3)
        indicator_weights = [10.0,20.0,20.0,20.0]
        indicators = [atc_indicator, direct_order_indicator, shop_cr_indicator, terminal_status]
        for pos_size, indicator, weight in zip(pos_sizes, indicators, indicator_weights):
            cat_label = cat_label * pos_size + indicator
            cat_label_weight += tf.math.log(10.0 * weight) * tf.cast((indicator > 0), tf.float32) # 5,10,15,20
        
        print("share cat label:{}, share cat weight:{}".format(cat_label, cat_label_weight))
        return cat_label, cat_label_weight
    
    def share_cat_tower(self, task_input, lhuc_input, gate_input):
        phase, idx, target, param_initializer = self.phase, self.target_idx_map["cat_label"], "cat_label", self.param_initializer
        t_input = dense_gate_tower(name='Task_Share_Bottom_{}{}_{}'.format(phase, idx, target),
                                   emb_input=task_input,
                                   hidden_dims=[128],
                                   param_initializer=param_initializer)
        
        # 1011 update: 增加scene gate
        t_input = gateNU(inputs=t_input, gate_inputs=gate_input,
                         gate_type='Scene', name='{}_{}'.format(phase, target))
        
        lhuc_weight_input = DenseTower(
            name="{}{}_lhuc_{}_input".format(phase, idx, target),
            output_dims=[512, t_input.shape[1]],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        lhuc_weight = DenseTower(
            name="{}{}_lhuc_{}".format(phase, idx, target),
            output_dims=[256, 64],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        t_mid = t_input * lhuc_weight_input * 2
        t_out = DenseTower(name='p{}_{}_tower_l1'.format(phase, target),
                           output_dims=[64],
                           kernel_initializers=param_initializer,
                           bias_initializers=param_initializer,
                           activations=[tf.nn.relu],
                           norms=[False])(t_mid)

        tlogits = DenseTower(name='p{}_{}_tower_l2'.format(phase, target),
                             output_dims=[48],
                             kernel_initializers=param_initializer,
                             bias_initializers=param_initializer,
                             activations=[None],
                             norms=[False])(t_out * lhuc_weight * 2)
        
        tlogits = tf.clip_by_value(tlogits, -1000, 1000)

        
        toutput = tf.identity(tf.nn.softmax(tlogits, axis = -1, name = "p{}_{}_logits".format(phase, target)),
                                  "p{}_{}".format(phase, target))
        tlabel, tweight = self.compute_share_cat_label()
        # 'reduction = none' means no avg over batch here; for per sample reweight
        loss_fn = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True, reduction='none',name='p{}_{}_loss'.format(phase, target))
        tloss = tf.reshape(loss_fn(tlabel, tlogits),[-1,1])

        self.aux_losses.append(tloss)
        self.aux_weights.append(tweight)

        # self.dump_scalars.append(tf.reduce_mean(tf.cast(tlabel,tf.float32), name='cat_label'))
        # self.dump_scalars.append(tf.reduce_mean(tloss,name='cat_label_loss'))
        # self.dump_scalars.append(tf.reduce_mean(tweight,name='cat_label_weight'))

        return t_out
        
    def task_tower(self, target_name, task_input, lhuc_input, gate_input, extra_input=None):
        phase, target, param_initializer = self.phase, target_name, self.param_initializer
        raw_target = None
        if target in self.target_idx_map:
            idx = self.target_idx_map[target]
        else:### sub scene target
            raw_target, sub_scene = target.rsplit('_',1)
            print("raw target:{}, scene:{}".format(raw_target, sub_scene))
            raw_idx = self.target_idx_map[raw_target]
            idx = raw_idx + (self.scene_idx_map[sub_scene] + 1) * len(self.raw_targets)

        if raw_target is not None and self.stop_sub_tower_gradient:
            task_input, lhuc_input = tf.stop_gradient(task_input), tf.stop_gradient(lhuc_input)
        
        t_input = dense_gate_tower(name='Task_Share_Bottom_{}{}_{}'.format(phase, idx, target),
                                   emb_input=task_input,
                                   hidden_dims=[128],
                                   param_initializer=param_initializer)
        # 1011 update: 增加scene gate
        t_input = gateNU(inputs=t_input, gate_inputs=gate_input,
                         gate_type='Scene', name='{}{}_{}'.format(phase, idx, target))
        
        lhuc_weight_input = DenseTower(
            name="{}{}_lhuc_{}_input".format(phase, idx, target),
            output_dims=[512, t_input.shape[1]],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        lhuc_weight = DenseTower(
            name="{}{}_lhuc_{}".format(phase, idx, target),
            output_dims=[256, 64],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        t_out = DenseTower(name='p{}_{}_tower_l1'.format(phase, target),
                           output_dims=[64],
                           kernel_initializers=param_initializer,
                           bias_initializers=param_initializer,
                           activations=[tf.nn.relu],
                           norms=[False])(t_input * lhuc_weight_input * 2)
        
        if target in self.main_targets and extra_input is not None:
            # stop gradient at the input, so the fusion net params can be updated normally
            print("extra_input shape:{}".format(extra_input.shape))
            extra_input = tf.stop_gradient(extra_input)
            auxiliary_vec_num = extra_input.shape[1]

            if self.fuse_config == "ta_cat":
                ### main vec augument
                query = t_out
                if target in self.sub_scene_vecs:
                    aug_vecs = tf.stack([tf.stop_gradient(v) for v in self.sub_scene_vecs[target][0:3]], axis = 1) #(B,3,64)
                    if ego.is_training_mode():
                        self.dump_scalars.append(
                            tf.reduce_mean(
                                tf.norm(query, axis=-1), name="p{}_{}_scene_ta_query_norm_mean".format(phase, target)
                            )
                        )
                        self.dump_scalars.append(
                            tf.reduce_mean(
                                tf.math.reduce_variance(query, axis=-1),
                                name="p{}_{}_scene_ta_query_var_mean".format(phase, target),
                            )
                        )
                        for i, scene_name in enumerate(["dd", "pdp", "pp"]):
                            self.dump_scalars.append(
                                tf.reduce_mean(
                                    tf.norm(aug_vecs[:, i, :], axis=-1),
                                    name="p{}_{}_scene_ta_key_{}_norm_mean".format(phase, target, scene_name),
                                )
                            )
                            self.dump_scalars.append(
                                tf.reduce_mean(
                                    tf.math.reduce_variance(aug_vecs[:, i, :], axis=-1),
                                    name="p{}_{}_scene_ta_key_{}_var_mean".format(phase, target, scene_name),
                                )
                            )
                    query, scene_attn_scores, _, _ = gated_mhta(tf.expand_dims(query,1), aug_vecs, 128, 64, 8, phase, param_initializer, None)
                    self._dump_attention_scores(
                        scene_attn_scores,
                        name_prefix="p{}_{}_scene_ta".format(phase, target),
                        token_names=["dd", "pdp", "pp"],
                    )
                    self._dump_attention_scores_by_head(
                        scene_attn_scores,
                        name_prefix="p{}_{}_scene_ta".format(phase, target),
                        token_names=["dd", "pdp", "pp"],
                    )
                    self._dump_scene_transition(
                        scene_attn_scores,
                        name_prefix="p{}_{}_scene_ta_trans".format(phase, target),
                        token_names=["dd", "pdp", "pp"],
                    )

                auxiliary_vec, attn_scores, token_gate_weights, head_weights = gated_mhta(tf.expand_dims(query,1),extra_input,128,64,8,phase,param_initializer,None)

                if target not in self.rezero_alpha:
                    self.rezero_alpha[target] = tf.Variable(1.0, trainable=True, name=f"rezero_alpha_{target}")
                if ego.is_training_mode():
                    self.dump_scalars.append(
                        tf.identity(self.rezero_alpha[target], name="p{}_{}_rezero_alpha".format(phase, target))
                    )
                    self.dump_scalars.append(
                        tf.reduce_mean(
                            tf.norm(auxiliary_vec, axis=-1), name="p{}_{}_aux_vec_norm_mean".format(phase, target)
                        )
                    )
                t_out = t_out + self.rezero_alpha[target] * auxiliary_vec

        tlogits = DenseTower(name='p{}_{}_tower_l2'.format(phase, target),
                             output_dims=[1],
                             kernel_initializers=param_initializer,
                             bias_initializers=param_initializer,
                             activations=[None],
                             norms=[False])(t_out * lhuc_weight * 2)
        
        tlogits = tf.clip_by_value(tlogits, -1000, 1000)

        
        toutput = tf.identity(tf.nn.sigmoid(tlogits, name="p{}_{}_logits".format(phase, target)),
                              "p{}_{}".format(phase, target))
        tlabel, tweight = ego.get_label_weight(target_name="p{}_{}_label".format(phase, target), label_idx=idx * 2)            
        tloss = tf.nn.sigmoid_cross_entropy_with_logits(labels=tlabel, logits=tlogits,
                                                        name='p{}_{}_loss'.format(phase, target))
        print("tloss shape:{}, tweight shape:{}".format(tloss.shape,tweight.shape))

        tname = "p{}_{}".format(phase, target)
        self.nn_outputs[phase].append(toutput)
        self.labels[phase].append(tlabel)
        self.weights[phase].append(tweight)
        self.losses[phase].append(tloss)
        self.targets[phase].append(tname)

        if raw_target is not None:
            self.sub_scene_vecs[raw_target].append(t_out)

        ego.Target(tname, toutput, tlabel, tweight, tloss, metric_type=None) 
        print("Target name:{}".format(tname))

        if phase == 0 and idx < len(self.raw_targets): ### ensure use main tower output to eval
            eval_bundles = ["dd", "pdp", "pp"]
            label_idx_gap = len(self.raw_targets) * 2  
            for i, bundle in enumerate(eval_bundles, 1):
                tname = "{}_p{}_{}".format(bundle, phase, target)
                tlabel, tweight = ego.get_label_weight(
                    target_name="p{}_{}_{}_label_weight".format(phase, target, bundle),
                    label_idx=idx * 2 + i * label_idx_gap)
                eval_item_output = tf.identity(toutput, tname)
                ego.Target(tname, eval_item_output, tlabel, tweight, metric_type=ego.MetricType.GAUC)
                print("Target name:{}".format(tname))
                self.eval_nodes.append(tname)
        
        return t_out

    def forward(self, *inputs): # currently input: share_bottom + bias_feature, lhuc_input
        task_input = inputs[0]
        lhuc_input = inputs[1]
        gate_input = inputs[2]
        def AKA():
            aka_vecs = [] # 64 x 8 = 512 share vecs

            ### auxiliary task
            for target_name in self.auxiliary_targets:
                aka_vecs.append(self.task_tower(target_name, task_input, lhuc_input, gate_input))

            ### share cat tower
            aka_vecs.append(self.share_cat_tower(task_input, lhuc_input, gate_input))
            
            ### auxiliary scene task
            for target_name in self.sub_scene_targets:
                self.task_tower(target_name, task_input, lhuc_input, gate_input)
        
            aka_vecs = tf.stack(aka_vecs,axis = 1)
            print("AKA vecs shape: {}".format(aka_vecs.shape))
            return aka_vecs

        def PTP(aka_vecs):
            for target_name in self.main_targets:
                self.task_tower(target_name, task_input, lhuc_input, gate_input, aka_vecs)

        aka_vecs = AKA()
        PTP(aka_vecs)
        
        return self.nn_outputs, self.labels, self.weights, self.losses, self.targets, self.eval_nodes, self.aux_losses, self.aux_weights

    def get_dump_tensors(self):
        return self.dump_tensors
    
    def get_dump_scalars(self):
        return self.dump_scalars
