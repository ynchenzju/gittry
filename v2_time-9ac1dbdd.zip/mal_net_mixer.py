#!/usr/bin/env python
# -*- coding: utf-8 -*-

import tensorflow as tf
import ego
from ego import DenseTower, Normalization, BatchNormalization
from collections import defaultdict
import yaml
from tools.funcs import *
from tensorflow.keras.layers import Dense

class MAL_NET_MIXER:
    def __init__(
            self,
            all_targets, 
            main_targets, 
            auxiliary_targets, 
            param_initializer,
            phase,
            fuse_config = "attention_fuse",
            use_catlabel = True
        ):
        self.all_targets = all_targets
        self.main_targets = main_targets
        self.auxiliary_targets = auxiliary_targets
        self.param_initializer = param_initializer
        self.target_idx_map = defaultdict(int)
        self.phase = phase
        self.fuse_config = fuse_config
        self.use_catlabel = use_catlabel
        self.nn_outputs, self.labels, self.weights, self.losses, self.targets = defaultdict(list), defaultdict(list), defaultdict(list), defaultdict(list), defaultdict(list)
        self.aux_weights, self.aux_losses = [], []
        self.eval_nodes = []
        self.dump_tensors = []
        self.dump_scalars = []
        self.build_target_idx_map()
        self.rezero_alpha = {}

    def build_target_idx_map(self):
        for idx, target in enumerate(self.all_targets):
            self.target_idx_map[target] = idx
        self.target_idx_map["cat_label"] = len(self.all_targets)


    def compute_cat_label(self):
        cat_label = 0
        cat_label_weight = 1
        for label in self.labels[self.phase]:
            bit = tf.cast(label,dtype = tf.int32)
            cat_label = tf.bitwise.bitwise_or(cat_label,bit)
        return cat_label, cat_label_weight
    
    def cat_tower(self, task_input, mixer_input, lhuc_input):
        phase, idx, target, param_initializer = self.phase, self.target_idx_map["cat_label"], "cat_label", self.param_initializer

        t_input = dense_gate_tower(name='Task_Share_Bottom_{}{}_{}'.format(phase, idx, target),
                                   emb_input=task_input,
                                   hidden_dims=[128],
                                   param_initializer=param_initializer)
        
        ### add mixer part
        t_mixer_input = dense_gate_tower(name='Mixer_Task_Share_Bottom_{}{}_{}'.format(phase, idx, target),
                                   emb_input=mixer_input,
                                   hidden_dims=[128],
                                   param_initializer=param_initializer)
        
        lhuc_weight_input = DenseTower(
            name="{}{}_lhuc_{}_input".format(phase, idx, target),
            output_dims=[512, t_input.shape[1]],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        ### for mixer lhuc
        mixer_lhuc_weight_input = DenseTower(
            name="mixer_{}{}_lhuc_{}_input".format(phase, idx, target),
            output_dims=[512, t_mixer_input.shape[1]],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(tf.stop_gradient(lhuc_input))

        lhuc_weight = DenseTower(
            name="{}{}_lhuc_{}".format(phase, idx, target),
            output_dims=[256, 64],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        ### for mixer lhuc
        mixer_lhuc_weight = DenseTower(
            name="{}{}_lhuc_{}".format(phase, idx, target),
            output_dims=[256, 64],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(tf.stop_gradient(lhuc_input))

        t_mid = t_input * lhuc_weight_input * 2
        t_mixer_mid = t_mixer_input * mixer_lhuc_weight_input * 2

        t_out = DenseTower(name='p{}_{}_tower_l1'.format(phase, target),
                           output_dims=[64],
                           kernel_initializers=param_initializer,
                           bias_initializers=param_initializer,
                           activations=[tf.nn.relu],
                           norms=[False])(t_mid)
        ### for mixer
        t_mixer_out = DenseTower(name='mixer_p{}_{}_tower_l1'.format(phase, target),
                           output_dims=[64],
                           kernel_initializers=param_initializer,
                           bias_initializers=param_initializer,
                           activations=[tf.nn.relu],
                           norms=[False])(t_mixer_mid)
        
        ### fuse mixer and origin with scalar for explainable and replacement
        fuse_alpha = DenseTower(
                                name="{}_mixer_fuse{}_{}".format(phase, idx, target),
                                output_dims=[512, 1],
                                kernel_initializers=param_initializer,
                                bias_initializers=param_initializer,
                                activations=[tf.nn.selu, tf.nn.sigmoid],
                                norms=[False, False]
                                )(tf.stop_gradient(tf.concat([lhuc_input, t_out, t_mixer_out], axis = -1)))
        self.dump_scalars.append(tf.identity(fuse_alpha, name='mixer_{}_fuse_alpha'.format(target)))
        
        t_out = t_out * fuse_alpha + (1 - fuse_alpha) * t_mixer_out
        lhuc_weight = lhuc_weight * fuse_alpha + (1 - fuse_alpha) * mixer_lhuc_weight
        
        final_output_dim = (1 << len(self.auxiliary_targets)) 

        tlogits = DenseTower(name='p{}_{}_tower_l2'.format(phase, target),
                             output_dims=[final_output_dim],
                             kernel_initializers=param_initializer,
                             bias_initializers=param_initializer,
                             activations=[None],
                             norms=[False])(t_out * lhuc_weight * 2)
        
        tlogits = tf.clip_by_value(tlogits, -1000, 1000)

        ### aux logits for train mixer tower
        mixer_tlogits = DenseTower(name='p_mixer_{}_{}_tower_l2'.format(phase, target),
                             output_dims=[final_output_dim],
                             kernel_initializers=param_initializer,
                             bias_initializers=param_initializer,
                             activations=[None],
                             norms=[False])(t_mixer_out * mixer_lhuc_weight * 2)
        
        mixer_tlogits = tf.clip_by_value(mixer_tlogits, -1000, 1000)

        
        toutput = tf.identity(tf.nn.softmax(tlogits, axis = -1, name = "p{}_{}_logits".format(phase, target)),
                                  "p{}_{}".format(phase, target))
        tlabel, tweight = self.compute_cat_label()
        loss_fn = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True, name='p{}_{}_loss'.format(phase, target))
        tloss = loss_fn(tf.squeeze(tlabel, axis = 1), tlogits)
        aux_tloss = loss_fn(tf.squeeze(tlabel, axis = 1), mixer_tlogits)
        
        self.aux_weights.append(tweight)
        self.aux_losses.append(tloss)
        self.dump_scalars.append(tf.identity(tloss, name='{}_loss'.format(target)))

        self.aux_weights.append(tweight)
        self.aux_losses.append(aux_tloss)
        self.dump_scalars.append(tf.identity(aux_tloss, name='mixer_{}_aux_loss'.format(target)))

        return t_out
        
    def task_tower(self, target_name, task_input, mixer_input, lhuc_input, extra_input=None):
        phase, idx, target, param_initializer = self.phase, self.target_idx_map[target_name], target_name, self.param_initializer
        
        t_input = dense_gate_tower(name='Task_Share_Bottom_{}{}_{}'.format(phase, idx, target),
                                   emb_input=task_input,
                                   hidden_dims=[128],
                                   param_initializer=param_initializer)
        
        ### add mixer part
        t_mixer_input = dense_gate_tower(name='Mixer_Task_Share_Bottom_{}{}_{}'.format(phase, idx, target),
                                   emb_input=mixer_input,
                                   hidden_dims=[128],
                                   param_initializer=param_initializer)
        
        lhuc_weight_input = DenseTower(
            name="{}{}_lhuc_{}_input".format(phase, idx, target),
            output_dims=[512, t_input.shape[1]],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        ### for mixer lhuc
        mixer_lhuc_weight_input = DenseTower(
            name="mixer_{}{}_lhuc_{}_input".format(phase, idx, target),
            output_dims=[512, t_mixer_input.shape[1]],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(tf.stop_gradient(lhuc_input))

        lhuc_weight = DenseTower(
            name="{}{}_lhuc_{}".format(phase, idx, target),
            output_dims=[256, 64],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        ### for mixer lhuc
        mixer_lhuc_weight = DenseTower(
            name="{}{}_lhuc_{}".format(phase, idx, target),
            output_dims=[256, 64],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(tf.stop_gradient(lhuc_input))

        t_mid = t_input * lhuc_weight_input * 2
        t_mixer_mid = t_mixer_input * mixer_lhuc_weight_input * 2

        t_out = DenseTower(name='p{}_{}_tower_l1'.format(phase, target),
                           output_dims=[64],
                           kernel_initializers=param_initializer,
                           bias_initializers=param_initializer,
                           activations=[tf.nn.relu],
                           norms=[False])(t_mid)
        
        ### for mixer
        t_mixer_out = DenseTower(name='mixer_p{}_{}_tower_l1'.format(phase, target),
                           output_dims=[64],
                           kernel_initializers=param_initializer,
                           bias_initializers=param_initializer,
                           activations=[tf.nn.relu],
                           norms=[False])(t_mixer_mid)
        
        ### fuse mixer and origin with scalar for explainable and replacement
        fuse_alpha = DenseTower(
                                name="{}_mixer_fuse{}_{}".format(phase, idx, target),
                                output_dims=[512, 1],
                                kernel_initializers=param_initializer,
                                bias_initializers=param_initializer,
                                activations=[tf.nn.selu, tf.nn.sigmoid],
                                norms=[False, False]
                                )(tf.stop_gradient(tf.concat([lhuc_input, t_out, t_mixer_out], axis = -1)))
        self.dump_scalars.append(tf.identity(fuse_alpha, name='mixer_{}_fuse_alpha'.format(target)))
        
        t_out = t_out * fuse_alpha + (1 - fuse_alpha) * t_mixer_out
        lhuc_weight = lhuc_weight * fuse_alpha + (1 - fuse_alpha) * mixer_lhuc_weight

        if target in self.main_targets and extra_input is not None:
            # stop gradient at the input, so the fusion net params can be updated normally
            print("extra_input shape:{}".format(extra_input.shape))
            extra_input = ignore_grad(extra_input)
            auxiliary_vec_num = extra_input.shape[1]
            if self.fuse_config == "attention_fuse":
                ### fuse: target attention
                length_mask = tf.sequence_mask(tf.fill([tf.shape(extra_input)[0]], auxiliary_vec_num), maxlen=auxiliary_vec_num, dtype=tf.float32)
                auxiliary_vec, attn_scores = target_attention_new("mal_fuse_vec", tf.expand_dims(t_out,1),extra_input,length_mask,hidden_dim=64)
                t_out += auxiliary_vec

        ### final logits
        tlogits = DenseTower(name='p{}_{}_tower_l2'.format(phase, target),
                             output_dims=[1],
                             kernel_initializers=param_initializer,
                             bias_initializers=param_initializer,
                             activations=[None],
                             norms=[False])(t_out * lhuc_weight * 2)
        
        tlogits = tf.clip_by_value(tlogits, -1000, 1000)

        ### aux logits for train mixer tower
        mixer_tlogits = DenseTower(name='p_mixer_{}_{}_tower_l2'.format(phase, target),
                             output_dims=[1],
                             kernel_initializers=param_initializer,
                             bias_initializers=param_initializer,
                             activations=[None],
                             norms=[False])(t_mixer_out * mixer_lhuc_weight * 2)
        
        mixer_tlogits = tf.clip_by_value(mixer_tlogits, -1000, 1000)

        
        toutput = tf.identity(tf.nn.sigmoid(tlogits, name="p{}_{}_logits".format(phase, target)),
                              "p{}_{}".format(phase, target))
        tlabel, tweight = ego.get_label_weight(target_name="p{}_{}_label".format(phase, target), label_idx=idx * 2)            
        tloss = tf.nn.sigmoid_cross_entropy_with_logits(labels=tlabel, logits=tlogits,
                                                        name='p{}_{}_loss'.format(phase, target))
        
        aux_tloss = tf.nn.sigmoid_cross_entropy_with_logits(labels=tlabel, logits=mixer_tlogits,
                                                        name='p_mixer_aux_{}_{}_loss'.format(phase, target))

        tname = "p{}_{}".format(phase, target)
        self.nn_outputs[phase].append(toutput)
        self.labels[phase].append(tlabel)
        self.weights[phase].append(tweight)
        self.losses[phase].append(tloss)
        self.targets[phase].append(tname)

        self.aux_weights.append(tweight)
        self.aux_losses.append(aux_tloss)
        self.dump_scalars.append(tf.identity(aux_tloss, name='mixer_{}_aux_loss'.format(target)))

        ego.Target(tname, toutput, tlabel, tweight, tloss, metric_type=None) 
        print("Target name:{}".format(tname))

        if phase == 0:
            eval_bundles = ["dd", "pdp", "cart_cart", "cart_osp", "cart_buya", "cart_mpp", "cart_odp"]
            label_idx_gap = len(self.all_targets) * 2  
            for i, bundle in enumerate(eval_bundles, 1):
                tname = "{}_p{}_{}".format(bundle, phase, target)
                tlabel, tweight = ego.get_label_weight(
                    target_name="p{}_{}_{}_label_weight".format(phase, target, bundle),
                    label_idx=idx * 2 + i * label_idx_gap)
                eval_item_output = tf.identity(toutput, tname)
                ego.Target(tname, eval_item_output, tlabel, tweight, metric_type=ego.MetricType.GAUC)
                print("Target name:{}".format(tname))
                self.eval_nodes.append(tname)
        
        return t_out

    def forward(self, *inputs): # currently input: share_bottom + bias_feature, rankmixer_input + bias_fs, lhuc_input
        task_input = inputs[0]
        mixer_input = inputs[1]
        lhuc_input = inputs[2]
        def AKA():
            aka_vecs = [] # 64 x 16 = 1024
            for target_name in self.auxiliary_targets:
                aka_vec = self.task_tower(target_name, task_input, mixer_input, lhuc_input)
                aka_vecs.append(aka_vec)
            
            if self.use_catlabel:
                cat_vec = self.cat_tower(task_input, mixer_input, lhuc_input)
                aka_vecs.append(cat_vec)
            
            aka_vecs = tf.stack(aka_vecs,axis = 1)
            print("AKA vecs shape: {}".format(aka_vecs.shape))
            return aka_vecs

        def PTP(aka_vecs):
            for target_name in self.main_targets:
                aka_vec = self.task_tower(target_name, task_input, mixer_input, lhuc_input, aka_vecs)

        aka_vecs = AKA()
        PTP(aka_vecs)
        
        return self.nn_outputs, self.labels, self.weights, self.losses, self.targets, self.eval_nodes, self.aux_losses, self.aux_weights
    
    def get_dump_tensors(self):
        return self.dump_tensors

    def get_dump_scalars(self):
        return self.dump_scalars