#!/usr/bin/env python
# -*- coding: utf-8 -*-

import tensorflow as tf
import ego
from ego import DenseTower, Normalization, BatchNormalization
from collections import defaultdict
import yaml
from tools.funcs import *
from tensorflow.keras.layers import Dense

class MAL_NET:
    def __init__(
            self,
            all_targets, 
            main_targets, 
            auxiliary_targets, 
            param_initializer,
            phase,
            fuse_config = "attention_fuse",
            use_catlabel = True
        ):
        self.all_targets = all_targets
        self.main_targets = main_targets
        self.auxiliary_targets = auxiliary_targets
        self.param_initializer = param_initializer
        self.target_idx_map = defaultdict(int)
        self.phase = phase
        self.fuse_config = fuse_config
        self.use_catlabel = use_catlabel
        self.nn_outputs, self.labels, self.weights, self.losses, self.targets = defaultdict(list), defaultdict(list), defaultdict(list), defaultdict(list), defaultdict(list)
        self.eval_nodes = []
        self.dump_tensors = []
        self.dump_scalars = []
        self.build_target_idx_map()
        self.rezero_alpha = {}

    def build_target_idx_map(self):
        for idx, target in enumerate(self.all_targets):
            self.target_idx_map[target] = idx
        self.target_idx_map["cat_label"] = len(self.all_targets)


    def compute_cat_label(self):
        cat_label = 0
        cat_label_weight = 1
        for label in self.labels[self.phase]:
            bit = tf.cast(label,dtype = tf.int32)
            cat_label = tf.bitwise.bitwise_or(cat_label,bit)
        return cat_label, cat_label_weight
    
    def cat_tower(self, task_input, lhuc_input):
        phase, idx, target, param_initializer = self.phase, self.target_idx_map["cat_label"], "cat_label", self.param_initializer

        t_input = dense_gate_tower(name='Task_Share_Bottom_{}{}_{}'.format(phase, idx, target),
                                   emb_input=task_input,
                                   hidden_dims=[128],
                                   param_initializer=param_initializer)
        lhuc_weight_input = DenseTower(
            name="{}{}_lhuc_{}_input".format(phase, idx, target),
            output_dims=[512, t_input.shape[1]],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        lhuc_weight = DenseTower(
            name="{}{}_lhuc_{}".format(phase, idx, target),
            output_dims=[256, 64],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        t_mid = t_input * lhuc_weight_input * 2
        t_out = DenseTower(name='p{}_{}_tower_l1'.format(phase, target),
                           output_dims=[64],
                           kernel_initializers=param_initializer,
                           bias_initializers=param_initializer,
                           activations=[tf.nn.relu],
                           norms=[False])(t_mid)
        
        final_output_dim = (1 << len(self.auxiliary_targets)) 

        tlogits = DenseTower(name='p{}_{}_tower_l2'.format(phase, target),
                             output_dims=[final_output_dim],
                             kernel_initializers=param_initializer,
                             bias_initializers=param_initializer,
                             activations=[None],
                             norms=[False])(t_out * lhuc_weight * 2)
        
        tlogits = tf.clip_by_value(tlogits, -1000, 1000)

        
        toutput = tf.identity(tf.nn.softmax(tlogits, axis = -1, name = "p{}_{}_logits".format(phase, target)),
                                  "p{}_{}".format(phase, target))
        tlabel, tweight = self.compute_cat_label()
        loss_fn = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True, name='p{}_{}_loss'.format(phase, target))
        tloss = loss_fn(tf.squeeze(tlabel, axis = 1), tlogits)

        return t_out, tloss, tweight
        
        
    def task_tower(self, target_name, task_input, lhuc_input, extra_input=None, extra_ids=None):
        phase, idx, target, param_initializer = self.phase, self.target_idx_map[target_name], target_name, self.param_initializer
        
        t_input = dense_gate_tower(name='Task_Share_Bottom_{}{}_{}'.format(phase, idx, target),
                                   emb_input=task_input,
                                   hidden_dims=[128],
                                   param_initializer=param_initializer)
        lhuc_weight_input = DenseTower(
            name="{}{}_lhuc_{}_input".format(phase, idx, target),
            output_dims=[512, t_input.shape[1]],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        lhuc_weight = DenseTower(
            name="{}{}_lhuc_{}".format(phase, idx, target),
            output_dims=[256, 64],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        t_mid = t_input * lhuc_weight_input * 2
        t_out = DenseTower(name='p{}_{}_tower_l1'.format(phase, target),
                           output_dims=[64],
                           kernel_initializers=param_initializer,
                           bias_initializers=param_initializer,
                           activations=[tf.nn.relu],
                           norms=[False])(t_mid)
        
        if target in self.main_targets and extra_input is not None:
            # stop gradient at the input, so the fusion net params can be updated normally
            print("extra_input shape:{}".format(extra_input.shape))
            extra_input = ignore_grad(extra_input)
            auxiliary_vec_num = extra_input.shape[1]
            if self.fuse_config == "attention_fuse":
                ### fuse: target attention
                length_mask = tf.sequence_mask(tf.fill([tf.shape(extra_input)[0]], auxiliary_vec_num), maxlen=auxiliary_vec_num, dtype=tf.float32)
                auxiliary_vec, attn_scores = target_attention_new("mal_fuse_vec", tf.expand_dims(t_out,1),extra_input,length_mask,hidden_dim=64)
                print("attn scores shape:{}".format(attn_scores.shape))
                attn_mean_scores = tf.reduce_mean(attn_scores, axis = 0) #(8,8)
                self.dump_tensors.append(tf.reshape(attn_mean_scores,(-1,),name='{}_attn_scores_flat'.format(target)))
                self.dump_tensors.append(tf.reduce_mean(attn_scores, axis = [0,1], name='{}_attn_scores_head_mean'.format(target)))
                t_out += auxiliary_vec
            
            elif self.fuse_config == "ta_simtier":
                ### fuse: target attention
                length_mask = tf.sequence_mask(tf.fill([tf.shape(extra_input)[0]], auxiliary_vec_num), maxlen=auxiliary_vec_num, dtype=tf.float32)
                auxiliary_vec, attn_scores = target_attention_new("mal_fuse_vec", tf.expand_dims(t_out,1),extra_input,length_mask,hidden_dim=64)
                tier_tensor = multi_head_sim_tier(attn_scores, 8, bins = [8], stop_gradient=True)
                #scalar gate
                alpha = DenseTower(name='p{}_{}_simtier_trans'.format(phase, target),
                             output_dims=[1],
                             kernel_initializers=param_initializer,
                             bias_initializers=param_initializer,
                             activations=[tf.nn.sigmoid],
                             norms=[False])(tier_tensor)
                
                if target not in self.rezero_alpha:
                    self.rezero_alpha[target] = tf.Variable(1.0, trainable=True, name=f"rezero_alpha_{target}")
                t_out = t_out + alpha * self.rezero_alpha[target] * auxiliary_vec

                self.dump_scalars.append(tf.reduce_mean(alpha, axis = -1, name='{}_simtier_alpha'.format(target)))
                self.dump_scalars.append(tf.reduce_mean(self.rezero_alpha[target], name='{}_fuse_alpha'.format(target)))

            elif self.fuse_config == "mal_ta":
                auxiliary_vec, attn_scores = mal_mhta(tf.expand_dims(t_out,1),extra_input, 128, 64, 64, 8, phase, param_initializer)
                auxiliary_vec = tf.keras.layers.LayerNormalization(axis=-1)(auxiliary_vec)
                
                ### tensorboard log
                print("attn scores shape:{}".format(attn_scores.shape))
                attn_mean_scores = tf.reduce_mean(attn_scores, axis = 0) #(8,8)
                attn_mean_cross_head_scores = tf.reduce_mean(attn_scores, axis = [0,1]) #(8)
                for i, aux_target_name in enumerate(self.auxiliary_targets + (["cat_label"] if self.use_catlabel else [])):
                    self.dump_scalars.append(tf.identity(attn_mean_cross_head_scores[i],name='{}/{}_cross_head_mean'.format(target, aux_target_name)))
                    for head in range(attn_scores.shape[1]):
                        self.dump_scalars.append(tf.identity(attn_mean_scores[head,i],name='{}/{}_head_{}_scores'.format(target, aux_target_name, head)))
                self.dump_scalars.append(tf.reduce_mean(tf.reduce_max(attn_scores, axis=2), name="{}/attn_max".format(target)))
                self.dump_scalars.append(-tf.reduce_mean(attn_scores * tf.math.log(tf.clip_by_value(attn_scores, 1e-9, 1.0)), name="{}/attn_entropy".format(target)))
                self.dump_tensors.append(tf.reshape(attn_mean_scores,(-1,),name='{}_attn_scores_flat'.format(target)))
                self.dump_tensors.append(tf.reduce_mean(attn_scores, axis = [0,1], name='{}_attn_scores_head_mean'.format(target)))
                ###

                if target not in self.rezero_alpha:
                    self.rezero_alpha[target] = tf.Variable(1.0, trainable=True, name=f"rezero_alpha_{target}")
                t_out = t_out + self.rezero_alpha[target] * auxiliary_vec

            elif self.fuse_config == "mhta_new":
                auxiliary_vec, attn_scores = mhta(tf.expand_dims(t_out,1),extra_input, 128, 64, 8, phase, param_initializer, swish, False)
                t_out = DenseTower(name='p{}_{}_ta_output_trans'.format(phase, target),
                             output_dims=[64],
                             kernel_initializers=param_initializer,
                             bias_initializers=param_initializer,
                             activations=[gelu_tanh],
                             norms=[False])(tf.concat([t_out, auxiliary_vec], axis = -1))

    
        tlogits = DenseTower(name='p{}_{}_tower_l2'.format(phase, target),
                             output_dims=[1],
                             kernel_initializers=param_initializer,
                             bias_initializers=param_initializer,
                             activations=[None],
                             norms=[False])(t_out * lhuc_weight * 2)
        
        tlogits = tf.clip_by_value(tlogits, -1000, 1000)

        
        toutput = tf.identity(tf.nn.sigmoid(tlogits, name="p{}_{}_logits".format(phase, target)),
                              "p{}_{}".format(phase, target))
        tlabel, tweight = ego.get_label_weight(target_name="p{}_{}_label".format(phase, target), label_idx=idx * 2)            
        tloss = tf.nn.sigmoid_cross_entropy_with_logits(labels=tlabel, logits=tlogits,
                                                        name='p{}_{}_loss'.format(phase, target))
        tname = "p{}_{}".format(phase, target)
        self.nn_outputs[phase].append(toutput)
        self.labels[phase].append(tlabel)
        self.weights[phase].append(tweight)
        self.losses[phase].append(tloss)
        self.targets[phase].append(tname)

        ego.Target(tname, toutput, tlabel, tweight, tloss, metric_type=None) 
        print("Target name:{}".format(tname))

        if phase == 0:
            eval_bundles = ["dd", "pdp", "cart_cart", "cart_osp", "cart_buya", "cart_mpp", "cart_odp"]
            label_idx_gap = len(self.all_targets) * 2  
            for i, bundle in enumerate(eval_bundles, 1):
                tname = "{}_p{}_{}".format(bundle, phase, target)
                tlabel, tweight = ego.get_label_weight(
                    target_name="p{}_{}_{}_label_weight".format(phase, target, bundle),
                    label_idx=idx * 2 + i * label_idx_gap)
                eval_item_output = tf.identity(toutput, tname)
                ego.Target(tname, eval_item_output, tlabel, tweight, metric_type=ego.MetricType.GAUC)
                print("Target name:{}".format(tname))
                self.eval_nodes.append(tname)
        
        return t_out

    def forward(self, *inputs): # currently input: share_bottom + bias_feature, lhuc_input
        task_input = inputs[0]
        lhuc_input = inputs[1]
        def AKA():
            aka_vecs = [] # 64 x 8 = 512
            aka_ids = []
            for target_name in self.auxiliary_targets:
                aka_vec = self.task_tower(target_name, task_input, lhuc_input)
                aka_vecs.append(aka_vec)
                aka_ids.append(self.target_idx_map[target_name])
                self.dump_tensors.append(tf.reduce_mean(aka_vec, axis = 0, name='{}_aka_vec'.format(target_name)))
            ### keep cat tower although do not use just for simple, reconstruct in next large new version
            cat_vec, cat_loss, cat_weight = self.cat_tower(task_input, lhuc_input)
            ### do not use cat tower tensor as auxiliary vecs
            if self.use_catlabel:
                aka_vecs.append(cat_vec)
                aka_ids.append(self.target_idx_map["cat_label"])
            aka_vecs = tf.stack(aka_vecs,axis = 1)
            aka_ids = tf.constant(aka_ids, dtype=tf.int32)
            print("AKA vecs shape: {}".format(aka_vecs.shape))
            print("AKA ids shape:{}".format(aka_ids.shape))
            return aka_vecs, aka_ids, cat_loss, cat_weight

        def PTP(aka_vecs, aka_ids):
            for target_name in self.main_targets:
                self.task_tower(target_name, task_input, lhuc_input, aka_vecs, aka_ids)

        aka_vecs, aka_ids, cat_loss, cat_weight = AKA()
        PTP(aka_vecs, aka_ids)
        
        return self.nn_outputs, self.labels, self.weights, self.losses, self.targets, self.eval_nodes, cat_loss, cat_weight
    
    def get_dump_tensors(self):
        return self.dump_tensors

    def get_dump_scalars(self):
        return self.dump_scalars