#!/usr/bin/env python
# -*- coding: utf-8 -*-

import tensorflow as tf
import ego
from ego import DenseTower, Normalization, BatchNormalization
from collections import defaultdict
import yaml
from tools.funcs import *
from tensorflow.keras.layers import Dense

class MAL_NET:
    def __init__(
            self,
            all_targets, 
            main_targets, 
            auxiliary_targets, 
            param_initializer,
            phase,
            fuse_config = "attention_fuse"
        ):
        self.all_targets = all_targets
        self.main_targets = main_targets
        self.auxiliary_targets = auxiliary_targets
        self.param_initializer = param_initializer
        self.target_idx_map = defaultdict(int)
        self.phase = phase
        self.fuse_config = fuse_config
        self.nn_outputs, self.labels, self.weights, self.losses, self.targets = defaultdict(list), defaultdict(list), defaultdict(list), defaultdict(list), defaultdict(list)
        self.eval_nodes = []
        self.build_target_idx_map()

    def build_target_idx_map(self):
        for idx, target in enumerate(self.all_targets):
            self.target_idx_map[target] = idx
        self.target_idx_map["cat_label"] = len(self.all_targets)


    def compute_cat_label(self):
        cat_label = 0
        cat_label_weight = 1
        for label in self.labels[self.phase]:
            bit = tf.cast(label,dtype = tf.int32)
            cat_label = tf.bitwise.bitwise_or(cat_label,bit)
        return cat_label, cat_label_weight
    
    def cat_tower(self, task_input, lhuc_input):
        phase, idx, target, param_initializer = self.phase, self.target_idx_map["cat_label"], "cat_label", self.param_initializer
        t_input = dense_gate_tower(name='Task_Share_Bottom_{}{}_{}'.format(phase, idx, target),
                                   emb_input=task_input,
                                   hidden_dims=[128],
                                   param_initializer=param_initializer)
        lhuc_weight_input = DenseTower(
            name="{}{}_lhuc_{}_input".format(phase, idx, target),
            output_dims=[512, t_input.shape[1]],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        lhuc_weight = DenseTower(
            name="{}{}_lhuc_{}".format(phase, idx, target),
            output_dims=[256, 64],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        t_out = DenseTower(name='p{}_{}_tower_l1'.format(phase, target),
                           output_dims=[64],
                           kernel_initializers=param_initializer,
                           bias_initializers=param_initializer,
                           activations=[tf.nn.relu],
                           norms=[False])(t_input * lhuc_weight_input * 2)
        
        final_output_dim = (1 << len(self.auxiliary_targets)) 

        tlogits = DenseTower(name='p{}_{}_tower_l2'.format(phase, target),
                             output_dims=[final_output_dim],
                             kernel_initializers=param_initializer,
                             bias_initializers=param_initializer,
                             activations=[None],
                             norms=[False])(t_out * lhuc_weight * 2)
        
        tlogits = tf.clip_by_value(tlogits, -1000, 1000)

        
        toutput = tf.identity(tf.nn.softmax(tlogits, axis = -1, name = "p{}_{}_logits".format(phase, target)),
                                  "p{}_{}".format(phase, target))
        tlabel, tweight = self.compute_cat_label()
        loss_fn = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True, name='p{}_{}_loss'.format(phase, target))
        tloss = loss_fn(tf.squeeze(tlabel, axis = 1), tlogits)

        return t_out, tloss, tweight
        
        
    def task_tower(self, target_name, task_input, lhuc_input, extra_input=None):
        phase, idx, target, param_initializer = self.phase, self.target_idx_map[target_name], target_name, self.param_initializer
        t_input = dense_gate_tower(name='Task_Share_Bottom_{}{}_{}'.format(phase, idx, target),
                                   emb_input=task_input,
                                   hidden_dims=[128],
                                   param_initializer=param_initializer)
        lhuc_weight_input = DenseTower(
            name="{}{}_lhuc_{}_input".format(phase, idx, target),
            output_dims=[512, t_input.shape[1]],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        lhuc_weight = DenseTower(
            name="{}{}_lhuc_{}".format(phase, idx, target),
            output_dims=[256, 64],
            kernel_initializers=param_initializer,
            bias_initializers=param_initializer,
            activations=[tf.nn.selu, tf.nn.sigmoid],
            norms=[False, False]
        )(lhuc_input)

        t_out = DenseTower(name='p{}_{}_tower_l1'.format(phase, target),
                           output_dims=[64],
                           kernel_initializers=param_initializer,
                           bias_initializers=param_initializer,
                           activations=[tf.nn.relu],
                           norms=[False])(t_input * lhuc_weight_input * 2)
        
        if target in self.main_targets and extra_input is not None:
            # stop gradient at the input, so the fusion net params can be updated normally
            extra_input = ignore_grad(extra_input)
            if self.fuse_config == "attention_fuse":
                ### fuse: target attention
                length_mask = tf.sequence_mask(tf.fill([tf.shape(extra_input)[0]], 8), maxlen=8, dtype=tf.float32)
                auxiliary_vec, attn_scores = target_attention_new("mal_fuse_vec", tf.expand_dims(t_out,1),extra_input,length_mask,hidden_dim=64)
                t_out += auxiliary_vec
    
        tlogits = DenseTower(name='p{}_{}_tower_l2'.format(phase, target),
                             output_dims=[1],
                             kernel_initializers=param_initializer,
                             bias_initializers=param_initializer,
                             activations=[None],
                             norms=[False])(t_out * lhuc_weight * 2)
        
        tlogits = tf.clip_by_value(tlogits, -1000, 1000)

        
        toutput = tf.identity(tf.nn.sigmoid(tlogits, name="p{}_{}_logits".format(phase, target)),
                              "p{}_{}".format(phase, target))
        tlabel, tweight = ego.get_label_weight(target_name="p{}_{}_label".format(phase, target), label_idx=idx * 2)            
        tloss = tf.nn.sigmoid_cross_entropy_with_logits(labels=tlabel, logits=tlogits,
                                                        name='p{}_{}_loss'.format(phase, target))
        tname = "p{}_{}".format(phase, target)
        self.nn_outputs[phase].append(toutput)
        self.labels[phase].append(tlabel)
        self.weights[phase].append(tweight)
        self.losses[phase].append(tloss)
        self.targets[phase].append(tname)

        ego.Target(tname, toutput, tlabel, tweight, tloss, metric_type=None) 
        print("Target name:{}".format(tname))

        if phase == 0:
            eval_bundles = ["dd", "pdp", "cart_cart", "cart_osp", "cart_buya", "cart_mpp", "cart_odp"]
            label_idx_gap = (len(self.all_targets) + 6) * 2  
            for i, bundle in enumerate(eval_bundles, 1):
                tname = "{}_p{}_{}".format(bundle, phase, target)
                tlabel, tweight = ego.get_label_weight(
                    target_name="p{}_{}_{}_label_weight".format(phase, target, bundle),
                    label_idx=idx * 2 + i * label_idx_gap)
                eval_item_output = tf.identity(toutput, tname)
                ego.Target(tname, eval_item_output, tlabel, tweight, metric_type=ego.MetricType.GAUC)
                print("Target name:{}".format(tname))
                self.eval_nodes.append(tname)
        
        return t_out

    def forward(self, *inputs): # currently input: share_bottom + bias_feature, lhuc_input
        task_input = inputs[0]
        lhuc_input = inputs[1]
        def AKA():
            aka_vecs = [] # 64 x 8 = 512
            for target_name in self.auxiliary_targets:
                aka_vecs.append(self.task_tower(target_name, task_input, lhuc_input))
            cat_vec, cat_loss, cat_weight = self.cat_tower(task_input, lhuc_input)
            aka_vecs.append(cat_vec)
            aka_vecs = tf.stack(aka_vecs,axis = 1)
            print("AKA vecs shape: {}".format(aka_vecs.shape))
            return aka_vecs, cat_loss, cat_weight

        def PTP(aka_vecs):
            for target_name in self.main_targets:
                self.task_tower(target_name, task_input, lhuc_input, aka_vecs)

        aka_vecs, cat_loss, cat_weight = AKA()
        PTP(aka_vecs)
        
        return self.nn_outputs, self.labels, self.weights, self.losses, self.targets, self.eval_nodes, cat_loss, cat_weight

