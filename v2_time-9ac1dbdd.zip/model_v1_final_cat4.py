#!/usr/bin/env python
# -*- coding: utf-8 -*-

import ego
from ego import DenseTower, Normalization, BatchNormalization
import yaml
from tools.funcs import *
from mal_net_v1_final import MAL_NET_V1
from tensorflow.keras.layers import Dense

# update: add last feature + dgl + multi-round Senet(1024 -> 256)
# 0526 update: 删除ple，改用share-bot，增加madnn
# 0624 update: rebase model_mm0.py，增加多模态sim-tier和相关特征, 停多模态梯度
# 0811 update: 增加paid order和roi2样本修复，逻辑跟pdp id的推全对齐
# 0812 update: 增加context Sim-Tier、多序列sim-tier、多模态cross attention、更换多模态emb源为searchV4、增加<ctx, target>相关性建模
# 0825 update: 增加rec-based simtier
# 0924 update: 增加SN（https://dl.acm.org/doi/pdf/10.1145/3705328.3748093）, 增加ctx_gate的input
# 1011 update: 删除SN，增加scene gate
# 1020 update: rebase mal v0
# 1031 update: 跟gate25代码保持一致，改变热启方式，gate28从mal热启；gate25从gate24热启

# version: config_gate25

#################### Train Config ####################
ego.config_mf(learning_rate=1.0, initial_g2sum=3, initial_range=0.1,
              weight_bounds=[-10, 10])
# ego.config_lr(use_lr=False)
ego.config_default_nn_optimizer(learning_rate=1e-3)
ego.config_feature_admission_evict(slots=None,
                                   create_clk_prob=1.0,
                                   create_nonclk_prob=1.0,
                                   clk_coeff=1.0,
                                   nonclk_coeff=0.02,
                                   delete_threshold=0.01)
# ego.config_feature_admission_evict(slots=None,
#                                    create_clk_prob=1,
#                                    create_nonclk_prob=1,
#                                    vec_create_threshold=5,
#                                    cvm_decay_rate=0.995,
#                                    delete_threshold=0.1,
#                                    delete_after_unseen_days=30,
#                                    clk_coeff=10,
#                                    nonclk_coeff=1)
#####################################################


#################### Dense Config ####################
if ego.is_training_mode():
    shared_dense_input = ego.get_dense_feature(name='shared_dense', dim=22, feature_type=ego.FeatureType.COMMON)
    iterable_dense_input = ego.get_dense_feature(name='iterable_dense', dim=73, feature_type=ego.FeatureType.ITEM)
    shared_dense_input = tf.clip_by_value(Normalization('shared_dense_input_norm')(shared_dense_input), -5, 5)
    iterable_dense_input = tf.clip_by_value(Normalization('iterable_dense_input_norm')(iterable_dense_input), -5, 5)

    shared_onehot_input = ego.get_dense_feature(name='shared_onehot', dim=124, feature_type=ego.FeatureType.COMMON)
    iterable_onehot_input = ego.get_dense_feature(name='iterable_onehot', dim=186, feature_type=ego.FeatureType.ITEM)
else:
    import json

    with open('/workspace/data/cali_param.json') as f:
        config = json.load(f)
        scenario = config['scenario']
        dim_config = config[scenario]
    shared_dense_input = ego.get_dense_feature(name='shared_dense', dim=dim_config['shared_dense_dim'] + 22,
                                               feature_type=ego.FeatureType.COMMON)
    _, shared_dense_input = tf.split(shared_dense_input, [dim_config['shared_dense_dim'], 22], axis=1)

    iterable_dense_input = ego.get_dense_feature(name='iterable_dense', dim=dim_config['iterable_dense_dim'] + 73,
                                                 feature_type=ego.FeatureType.ITEM)
    _, iterable_dense_input = tf.split(iterable_dense_input, [dim_config['iterable_dense_dim'], 73], axis=1)

    shared_dense_input = tf.clip_by_value(Normalization('shared_dense_input_norm')(shared_dense_input), -5, 5)
    iterable_dense_input = tf.clip_by_value(Normalization('iterable_dense_input_norm')(iterable_dense_input), -5, 5)

    shared_onehot_input = ego.get_dense_feature(name='shared_onehot', dim=dim_config['shared_onehot_dim'] + 124,
                                                feature_type=ego.FeatureType.COMMON)
    _, shared_onehot_input = tf.split(shared_onehot_input, [dim_config['shared_onehot_dim'], 124], axis=1)
    iterable_onehot_input = ego.get_dense_feature(name='iterable_onehot', dim=dim_config['iterable_onehot_dim'] + 186,
                                                  feature_type=ego.FeatureType.ITEM)
    _, iterable_onehot_input = tf.split(iterable_onehot_input, [dim_config['iterable_onehot_dim'], 186], axis=1)

#####################################################

#################### Sparse Config ####################
print("ego training mode: {}".format(ego.is_training_mode()))
import os

print(os.getcwd())
with open("configs/slot-conf_gate22.yaml", "r", encoding="utf-8") as fh:
    # eg { sum_shared_slot: [{'slot_id': 12246, 'name': xx, 'aggregator': 'sum', 'dim': 16}, {}], sum_iterable_slot: [{}, {}], tile_shared_slot: [{}, {}], tile_iterable_slot: [{}, {}]}
    slot_conf = yaml.safe_load(fh)

# mad_slot_pools, mad_slot_ids, mad_slot_dims = [], [], []
u_mad_slot_pools, u_mad_slot_ids, u_mad_slot_dims = [], [], []
i_mad_slot_pools, i_mad_slot_ids, i_mad_slot_dims = [], [], []
for slot in slot_conf['user_madnn']:
    u_mad_slot_pools.append(convert_pooling(slot['aggregator']))
    u_mad_slot_ids.append(slot['slot_id'])
    u_mad_slot_dims.append(slot['dim'])

for slot in slot_conf['item_madnn']:
    i_mad_slot_pools.append(convert_pooling(slot['aggregator']))
    i_mad_slot_ids.append(slot['slot_id'])
    i_mad_slot_dims.append(slot['dim'])

last_slot_pools, last_slot_ids, last_slot_dims = [], [], []
for slot in slot_conf['ub_latest_click_l3l2_sim_pool']:
    last_slot_pools.append(convert_pooling(slot['aggregator']))
    last_slot_ids.append(slot['slot_id'])
    last_slot_dims.append(slot['dim'])

mm_query_slot_pools, mm_query_slot_ids, mm_query_slot_dims = [], [], []
for slot in slot_conf['mm_target_item']:
    mm_query_slot_pools.append(convert_pooling(slot['aggregator']))
    mm_query_slot_ids.append(slot['slot_id'])
    mm_query_slot_dims.append(slot['dim'])

# 0813新增
mm_pdp_item_slot_pools, mm_pdp_item_slot_ids, mm_pdp_item_slot_dims = [], [], []
for slot in slot_conf['mm_pdp_item']:
    mm_pdp_item_slot_pools.append(convert_pooling(slot['aggregator']))
    mm_pdp_item_slot_ids.append(slot['slot_id'])
    mm_pdp_item_slot_dims.append(slot['dim'])

sum_shared_slot_pools, sum_shared_slot_ids, sum_shared_slot_dims = [], [], []
for slot in slot_conf['sum_shared_slot']:
    sum_shared_slot_pools.append(convert_pooling(slot['aggregator']))
    sum_shared_slot_ids.append(slot['slot_id'])
    sum_shared_slot_dims.append(slot['dim'])

sum_iterable_slot_pools, sum_iterable_slot_ids, sum_iterable_slot_dims = [], [], []
for slot in slot_conf['sum_iterable_slot']:
    sum_iterable_slot_pools.append(convert_pooling(slot['aggregator']))
    sum_iterable_slot_ids.append(slot['slot_id'])
    sum_iterable_slot_dims.append(slot['dim'])

# 0814新增recall特征
recall_slot_pools, recall_slot_ids, recall_slot_dims = [], [], []
for slot in slot_conf['recall_queues']:
    recall_slot_pools.append(convert_pooling(slot['aggregator']))
    recall_slot_ids.append(slot['slot_id'])
    recall_slot_dims.append(slot['dim'])

dummy_item_slot_pools, dummy_item_slot_ids, dummy_item_slot_dims = [], [], []
for slot in slot_conf['dummy_item_id']:
    dummy_item_slot_pools.append(convert_pooling(slot['aggregator']))
    dummy_item_slot_ids.append(slot['slot_id'])
    dummy_item_slot_dims.append(slot['dim'])

dummy_pdp_item_slot_pools, dummy_pdp_item_slot_ids, dummy_pdp_item_slot_dims = [], [], []
for slot in slot_conf['dummy_pdp_item_id']:
    dummy_pdp_item_slot_pools.append(convert_pooling(slot['aggregator']))
    dummy_pdp_item_slot_ids.append(slot['slot_id'])
    dummy_pdp_item_slot_dims.append(slot['dim'])

# extra shared sparse id
extra_shared_slot_pools, extra_shared_slot_ids, extra_shared_slot_dims = [], [], []
for slot in slot_conf['extra_shared_sparse_id']:
    extra_shared_slot_pools.append(convert_pooling(slot['aggregator']))
    extra_shared_slot_ids.append(slot['slot_id'])
    extra_shared_slot_dims.append(slot['dim'])


tile_shared_slot_pools, tile_shared_slot_ids, tile_shared_slot_dims, tile_shared_slot_lens = [], [], [], []
for name in ['tile_shared_slot', 'mm_ub_click_item_seq', 'mm_ub_order_item_seq', 'mm_ub_click_short_item_seq',
             'mm_ub_order_short_item_seq', 'mm_ub_view_item_seq', 'ub_extra_shared_item_seq']:
    for slot in slot_conf[name]:
        tile_shared_slot_pools.append(convert_pooling(slot['aggregator']))
        tile_shared_slot_ids.append(slot['slot_id'])
        tile_shared_slot_dims.append(slot['dim'])
        tile_shared_slot_lens.append(slot['hist_len'])


tile_iterable_slot_pools, tile_iterable_slot_ids, tile_iterable_slot_dims, tile_iterable_slot_lens = [], [], [], []
for name in ['tile_iterable_slot', 'mm_ub_click_sim_item_seq', 'mm_ub_order_sim_item_seq']:
    for slot in slot_conf[name]:
        tile_iterable_slot_pools.append(convert_pooling(slot['aggregator']))
        tile_iterable_slot_ids.append(slot['slot_id'])
        tile_iterable_slot_dims.append(slot['dim'])
        tile_iterable_slot_lens.append(slot['hist_len'])

## extract sum slot
sum_shared_slot_embs = ego.get_slots(name="sum_shared_slots_input",
                                     slots=sum_shared_slot_ids, dims=sum_shared_slot_dims,
                                     poolings=sum_shared_slot_pools, feature_type=ego.FeatureType.COMMON)
sum_iterable_slot_embs = ego.get_slots(name="sum_iterable_slots_input",
                                       slots=sum_iterable_slot_ids, dims=sum_iterable_slot_dims,
                                       poolings=sum_iterable_slot_pools, feature_type=ego.FeatureType.ITEM)

# get mad slot
u_mad_slot_embs = ego.get_slots(name='u_mad_slots_input', slots=u_mad_slot_ids, dims=u_mad_slot_dims,
                                poolings=u_mad_slot_pools, feature_type=ego.FeatureType.COMMON)

i_mad_slot_embs = ego.get_slots(name="i_mad_slots_input", slots=i_mad_slot_ids, dims=i_mad_slot_dims,
                                poolings=i_mad_slot_pools, feature_type=ego.FeatureType.ITEM)

# get last slot
last_slot_embs = ego.get_slots(name='last_slots_input', slots=last_slot_ids, dims=last_slot_dims,
                               poolings=last_slot_pools, feature_type=ego.FeatureType.COMMON)

# get mm query slot
mm_query_embs = ego.get_slots(name="mm_query_input",
                              slots=mm_query_slot_ids, dims=mm_query_slot_dims,
                              poolings=mm_query_slot_pools, feature_type=ego.FeatureType.ITEM)
# get mm pdp item slot
mm_pdp_item_embs = ego.get_slots(name="mm_pdp_item_input",
                              slots=mm_pdp_item_slot_ids, dims=mm_pdp_item_slot_dims,
                              poolings=mm_pdp_item_slot_pools, feature_type=ego.FeatureType.COMMON)

# get recall slot
recall_slot_embs = ego.get_slots(name="recall_input",
                              slots=recall_slot_ids, dims=recall_slot_dims,
                              poolings=recall_slot_pools, feature_type=ego.FeatureType.ITEM)

# get dummy item/pdp item slot
item_slot_embs = ego.get_slots(name="dummy_item_input",
                              slots=dummy_item_slot_ids, dims=dummy_item_slot_dims,
                              poolings=dummy_item_slot_pools, feature_type=ego.FeatureType.ITEM)
pdp_item_slot_embs = ego.get_slots(name="dummy_pdp_item_input",
                              slots=dummy_pdp_item_slot_ids, dims=dummy_pdp_item_slot_dims,
                              poolings=dummy_pdp_item_slot_pools, feature_type=ego.FeatureType.COMMON)

# get extra shared sparse slot
extra_shared_slot_embs = ego.get_slots(name="extra_shared_slots_input",
                              slots=extra_shared_slot_ids, dims=extra_shared_slot_dims,
                              poolings=extra_shared_slot_pools, feature_type=ego.FeatureType.COMMON)

tlst_sum_iterable_slot_embs = list(tf.split(sum_iterable_slot_embs, sum_iterable_slot_dims, axis=1))
tlst_sum_shared_slot_embs = list(tf.split(sum_shared_slot_embs, sum_shared_slot_dims, axis=1))
tlst_u_mad_slot_embs = list(tf.split(u_mad_slot_embs, u_mad_slot_dims, axis=1))
tlst_i_mad_slot_embs = list(tf.split(i_mad_slot_embs, i_mad_slot_dims, axis=1))
tlst_last_slot_embs = list(tf.split(last_slot_embs, last_slot_dims, axis=1))
tlst_mm_query_slot_embs = list(tf.split(mm_query_embs, mm_query_slot_dims, axis=1))
tlst_mm_pdp_item_slot_embs = list(tf.split(mm_pdp_item_embs, mm_pdp_item_slot_dims, axis=1))
tlst_recall_slot_embs = list(tf.split(recall_slot_embs, recall_slot_dims, axis=1))
tlst_item_slot_embs = list(tf.split(item_slot_embs, dummy_item_slot_dims, axis=1))
tlst_pdp_item_slot_embs = list(tf.split(pdp_item_slot_embs, dummy_pdp_item_slot_dims, axis=1))
tlst_extra_shared_slot_embs = list(tf.split(extra_shared_slot_embs, extra_shared_slot_dims, axis=1))
sum_slot_embs = tlst_sum_shared_slot_embs + tlst_sum_iterable_slot_embs
ext_slot_embs = tlst_last_slot_embs + tlst_u_mad_slot_embs + tlst_i_mad_slot_embs + tlst_mm_query_slot_embs + tlst_mm_pdp_item_slot_embs + tlst_recall_slot_embs + tlst_item_slot_embs + tlst_pdp_item_slot_embs + tlst_extra_shared_slot_embs
non_shared_batch_size = tf.shape(tlst_sum_iterable_slot_embs[0])[0]
shared_batch_size = tf.shape(tlst_sum_shared_slot_embs[0])[0]

sum_slot_ids = list(map(str, sum_shared_slot_ids + sum_iterable_slot_ids))
ext_slot_ids = list(map(str, last_slot_ids + u_mad_slot_ids + i_mad_slot_ids + mm_query_slot_ids + mm_pdp_item_slot_ids + recall_slot_ids + dummy_item_slot_ids + dummy_pdp_item_slot_ids + extra_shared_slot_ids))
tensor_dict = {}
for slot_id, slot_emb in zip(sum_slot_ids + ext_slot_ids, sum_slot_embs + ext_slot_embs):
    tensor_dict[slot_id] = slot_emb

## extract tile slot
tile_tensor_dict = {}
session_len = {}

for slot_id, slot_len, slot_dim, slot_pool in \
        zip(tile_shared_slot_ids, tile_shared_slot_lens, tile_shared_slot_dims, tile_shared_slot_pools):
    item = ego.get_slots(name=str(slot_id), slots=[slot_id],
                         dims=[(slot_len, slot_dim)],
                         poolings=[slot_pool],
                         feature_type=ego.FeatureType.COMMON)
    tile_tensor_dict[str(slot_id)] = item[0]
    session_len[str(slot_id)] = item[1]

for slot_id, slot_len, slot_dim, slot_pool in \
        zip(tile_iterable_slot_ids, tile_iterable_slot_lens, tile_iterable_slot_dims, tile_iterable_slot_pools):
    item = ego.get_slots(name=str(slot_id), slots=[slot_id],
                         dims=[(slot_len, slot_dim)],
                         poolings=[slot_pool],
                         feature_type=ego.FeatureType.ITEM)
    tile_tensor_dict[str(slot_id)] = item[0]
    session_len[str(slot_id)] = item[1]
lhuc_slot_ids, lhuc_slot_dims = [], []
for slot in slot_conf['lhuc_slot']:
    lhuc_slot_ids.append(str(slot['slot_id']))
    lhuc_slot_dims.append(slot['dim'])
############################################################

#################### DIN ###################################
attention_sparse_input, attention_sparse_input_name = [], []
mm_sparse_input = []
mm_sparse_input2 = [] # 存储本次新增的simtier信息
mm_ctx_input = [] # 存储由pdp item产生的多模态信息
lhuc_input_tensors = []
# itemid, cat1, cat2, cat3, l0, shopid, item_click7_buck, item_click30_buck, item_order30_buck, context_hour, context_weekday
target_keys = [30102, 30107, 30108, 30109, 30104, 30103, 30115, 30117, 30118, 30081, 30080]
target_emb = tf.concat([tensor_dict[str(slot)] for slot in target_keys], axis=-1)
target_query = tf.expand_dims(target_emb, 1)
# user_id, user_gender, user_mpiage, user_mpigender, mpi_income_level, user_income_level
user_keys = [30000, 30586, 30360, 31283, 30693]
user_emb = tf.concat([tensor_dict[str(slot)] for slot in user_keys], axis=-1)
user_query = tf.expand_dims(user_emb, 1)

for hist_keys, seq_name in [
    [[30036, 30037, 30038, 30040, 30041, 30039, 30043, 30048, 30050, 30051, 30053, 30054, 30055], "ub_click_long_seq"],
    [[31226, 31227, 31269, 31270], "ub_long_click_timeslice"],
    [[30159, 30161, 30160], "ub_sim_l2_click_seq"],
    [[31038, 31043, 31040, 34211, 34209], "ub_order_long_seq"]
]:
    key_emb = tf.concat([tile_tensor_dict[str(slot)] for slot in hist_keys], axis=-1)
    sequence_lengths = tf.concat([session_len[str(slot)] for slot in hist_keys], axis=-1)
    lengths = tf.reduce_max(sequence_lengths, axis=-1)
    max_lengths = key_emb.get_shape().as_list()[1]
    length_mask = tf.sequence_mask(lengths, maxlen=max_lengths, dtype=tf.float32)

    if seq_name in ["ub_click_long_seq"]:  # part_11, part_12
        tres = seq_pooling(seq_name, key_emb, length_mask, hidden_dim=128)
        attention_sparse_input.append(tres)
        attention_sparse_input_name.append(seq_name + "_pool")
        # part_11: latest intention
        part_11 = target_attention(seq_name + "_p11", tf.expand_dims(tf.concat([tres, user_emb], axis=1), 1), key_emb,
                                   length_mask, hidden_dim=128, shared_input=True)
        attention_sparse_input.append(part_11)
        attention_sparse_input_name.append(seq_name + "_p11")
        # part_12
        part_12 = target_attention(seq_name + "_p12", tf.concat([user_query, target_query], axis=2), key_emb,
                                   length_mask, hidden_dim=128, shared_input=True)
        attention_sparse_input.append(part_12)
        attention_sparse_input_name.append(seq_name + "_p12")
    elif seq_name in ["ub_long_click_timeslice"]:  # part_2*
        attention_sparse_input.append(
            target_attention(seq_name, tf.expand_dims(part_11, 1), key_emb, length_mask, hidden_dim=128,
                             shared_input=True))
        attention_sparse_input_name.append(seq_name)
        tres = seq_pooling(seq_name, key_emb, length_mask, hidden_dim=128)
        attention_sparse_input.append(tres)
        attention_sparse_input_name.append(seq_name + "_pool")
    elif seq_name in ["ub_sim_l2_click_seq", "ub_long_sim_l2_2k_click_target", "ub_order_long_seq"]:
        attention_sparse_input.append(target_attention(seq_name, target_query, key_emb, length_mask, hidden_dim=64))
        attention_sparse_input_name.append(seq_name)
        attention_sparse_input.append(seq_pooling(seq_name, key_emb, length_mask, hidden_dim=64))
        attention_sparse_input_name.append(seq_name + "_pool")

mm_query_sparse_input = [tensor_dict[str(slot_id)] for slot_id in mm_query_slot_ids]
mm_ctx_sparse_input = [tensor_dict[str(slot_id)] for slot_id in mm_pdp_item_slot_ids]
mm_query_emb = tf.stop_gradient(tf.concat(mm_query_sparse_input, axis=-1))  # [B, D]
mm_ctx_emb = tf.stop_gradient(tf.concat(mm_ctx_sparse_input, axis=-1)) # [B, D]
mm_score_dict = {}
mm_ctx_score_dict = {}
for hist_keys, seq_name, is_key_pooling, is_ctx_tier, is_target_score, is_ctx_score, rounds, tensor_lst in [
    [[12345], 'mm_ub_click_item_seq',       True, True, False, False,  [16, 32, 64],   mm_sparse_input],
    [[12347], 'mm_ub_order_item_seq',       True, True, False, False,  [16, 32, 64],   mm_sparse_input],
    [[12349], 'mm_ub_click_short_item_seq', False, True, True, True,  [8, 16],        mm_sparse_input2],
    [[12350], 'mm_ub_order_short_item_seq', False, True, False, True,  [8, 16],        mm_sparse_input2],
    [[12351], 'mm_ub_view_item_seq',        True, True, True, True,   [8, 16],        mm_sparse_input2],
    [[12352], 'mm_ub_click_sim_item_seq',   False, True, False, False, [8, 16],        mm_sparse_input2],
    [[12353], 'mm_ub_order_sim_item_seq',   False, True, False, False, [8, 16],        mm_sparse_input2],
]:
    key_emb = tf.concat([tile_tensor_dict[str(slot)] for slot in hist_keys], axis=-1)  # [B, L, D]
    sequence_lengths = tf.concat([session_len[str(slot)] for slot in hist_keys], axis=-1)
    lengths = tf.reduce_max(sequence_lengths, axis=-1)
    max_lengths = key_emb.get_shape().as_list()[1]
    length_mask = tf.sequence_mask(lengths, maxlen=max_lengths, dtype=tf.float32)  # [B, L]

    key_emb = tf.stop_gradient(key_emb)

    if is_key_pooling:
        pool_tensor = tf.reduce_mean(key_emb * tf.expand_dims(length_mask, axis=-1), axis=1)
        tensor_lst.append(pool_tensor)

    tier_nomask, tier_mask, score = sim_tier2(mm_query_emb, key_emb, length_mask, round=rounds)

    tensor_lst.append(tier_mask)
    tensor_lst.append(tier_nomask)

    if is_target_score:
        mm_score_dict[seq_name] = score # 用于多模态cross attention

    # ctx SimTier
    if is_ctx_tier:
        ctx_tier_nomask, ctx_tier_mask, ctx_score = sim_tier2(mm_ctx_emb, key_emb, length_mask, round=rounds)
        mm_ctx_input.append(ctx_tier_mask)
        mm_ctx_input.append(ctx_tier_nomask)
        if is_ctx_score:
            mm_ctx_input.append(ctx_score) # for feature or gate input
            mm_ctx_score_dict[seq_name] = ctx_score # 用于多模态cross attention

# 0825 add rec-based simtier
item_query_emb = tf.stop_gradient(tensor_dict["30102"])
ctx_query_emb = tf.stop_gradient(tensor_dict["39201"])
rec_simtier_sparse_input = []
ctx_rec_simtier_sparse_input = []
for hist_keys, seq_name, is_ctx_tier in [
    [[39102], 'ults_origin_click_itemid',   True],
    [[39103], 'ults_origin_order_itemid',   True],
    [[30036], 'ub_click_item_long_term',    True],
    [[31038], 'user_long_term_session_impression_unclick_itemid_recent50', True],
]:
    key_emb = tf.concat([tile_tensor_dict[str(slot)] for slot in hist_keys], axis=-1)  # [B, L, D]
    sequence_lengths = tf.concat([session_len[str(slot)] for slot in hist_keys], axis=-1)
    lengths = tf.reduce_max(sequence_lengths, axis=-1)
    max_lengths = key_emb.get_shape().as_list()[1]
    length_mask = tf.sequence_mask(lengths, maxlen=max_lengths, dtype=tf.float32)  # [B, L]

    key_emb = tf.stop_gradient(key_emb)

    tier_mask, _ = sim_tier(item_query_emb, key_emb, length_mask, is_mask=True, round=[16, 32])
    tier_nomask, _ = sim_tier(item_query_emb, key_emb, length_mask, is_mask=False, round=[16, 32])
    rec_simtier_sparse_input.append(tier_mask)
    rec_simtier_sparse_input.append(tier_nomask)

    if is_ctx_tier:
        ctx_tier_nomask, ctx_tier_mask, _ = sim_tier2(ctx_query_emb, key_emb, length_mask, round=[16, 32])
        ctx_rec_simtier_sparse_input.append(ctx_tier_mask)
        ctx_rec_simtier_sparse_input.append(ctx_tier_nomask)


# 多模态cross attention
cross_attention_input = []
ctx_cross_attention_input = []
for seq_name, slot_ids in [
    ['mm_ub_click_short_item_seq', [30036, 30037, 30038, 30040, 30041, 30039, 30043, 30048, 30050, 30053, 30054, 30055]],
    ['mm_ub_view_item_seq', [31038, 31043, 31040, 34211, 34209]]
]:
    score = mm_score_dict[seq_name] # [B, L]
    ctx_score = mm_ctx_score_dict[seq_name] # [B, L]

    v = tf.concat([tile_tensor_dict[str(slot)] for slot in slot_ids], axis=-1) # [B, L, D]
    sequence_lengths = tf.concat([session_len[str(slot)] for slot in slot_ids], axis=-1)
    lengths = tf.reduce_max(sequence_lengths, axis=-1)
    max_lengths = v.get_shape().as_list()[1]
    mask = tf.sequence_mask(lengths, maxlen=max_lengths, dtype=tf.bool)  # [B, L]

    # add mask
    paddings = tf.ones_like(score) * (-2 ** 32 + 1)
    masked_score = tf.where(mask, score, paddings)
    masked_ctx_score = tf.where(mask, ctx_score, paddings)

    w = tf.nn.softmax(masked_score)

    w_ctx = tf.nn.softmax(masked_ctx_score)

    pooling_tensor = tf.reduce_sum(v*tf.expand_dims(w, axis=-1), axis=1)

    ctx_pooling_tensor = tf.reduce_sum(v * tf.expand_dims(w_ctx, axis=-1), axis=1)

    cross_attention_input.append(tf.stop_gradient(pooling_tensor))
    ctx_cross_attention_input.append(tf.stop_gradient(ctx_pooling_tensor))


# ctx建模
sim_ctx_input = []
ctx_target_score = cal_cos_score(tensor_dict['39100'], tensor_dict['39101'])
mm_ctx_target_score = cal_cos_score(mm_query_emb, mm_ctx_emb)
sim_ctx_input.append(ctx_target_score)
sim_ctx_input.append(mm_ctx_target_score)
sim_ctx_input.append(tensor_dict['39100'])
sim_ctx_input.append(tensor_dict['39101'])
sim_ctx_input.append(tf.stop_gradient(user_emb))
sim_ctx_input.append(mm_query_emb)
sim_ctx_input.append(mm_ctx_emb)
# 0925新增
sim_ctx_input2 = []
ctx_target_score2 = cal_cos_score(tensor_dict['30102'], tensor_dict['39201'])
sim_ctx_input2.append(tf.stop_gradient(ctx_target_score2))
sim_ctx_input2.append(tf.stop_gradient(tensor_dict['30102']))
sim_ctx_input2.append(tf.stop_gradient(tensor_dict['39201']))

# 8000 8001 8002 8003 item_id
# 8010 8011 8012 8013 pdp_item_id
# IMG_TITLE_SLOT = [8000, 8001, 8010, 8011]
# I2V_SLOT = [8002, 8012]
# GRAPH_SLOT = [8003, 8013]
sum_sparse_input = [tensor_dict[slot_id] for slot_id in sum_slot_ids]
u_mad_sparse_input = [tensor_dict[str(slot_id)] for slot_id in u_mad_slot_ids]
i_mad_sparse_input = [tensor_dict[str(slot_id)] for slot_id in i_mad_slot_ids]
last_sparse_input = [tensor_dict[str(slot_id)] for slot_id in last_slot_ids]
recall_sparse_input = [tensor_dict[str(slot_id)] for slot_id in recall_slot_ids]
print('sum_sparse_input:', tf.concat(sum_sparse_input, axis=-1).shape)
print('attention_sparse_input:', tf.concat(attention_sparse_input, axis=-1).shape)
print('last_sparse_input:', tf.concat(last_sparse_input, axis=-1).shape)  # (?, 104)
print('mm_query_sparse_input:', mm_query_emb.shape)  # (?, 129)
print('u_mad_sparse_input:', tf.concat(u_mad_sparse_input, axis=-1).shape)  # (?, 256)
print('i_mad_sparse_input:', tf.concat(i_mad_sparse_input, axis=-1).shape)  # (?, 256)
print('recall_sparse_input:', tf.concat(recall_sparse_input, axis=-1).shape)  # (?, 16)
sparse_input = tf.clip_by_value(Normalization('sparse_input_norm')(tf.concat(sum_sparse_input + attention_sparse_input, axis=1)), -5, 5)
extra_input_norm = tf.clip_by_value(Normalization('extra_input_norm')(tf.concat(last_sparse_input + u_mad_sparse_input + i_mad_sparse_input, axis=1)), -5, 5)
recall_input_norm = tf.clip_by_value(Normalization('recall_input_norm')(tf.concat(recall_sparse_input, axis=1)), -5, 5)
extra_mm_input_norm = tf.clip_by_value(Normalization('extra_mad_input_norm')(tf.concat(mm_sparse_input, axis=1)), -5, 5)
extra_mm_input2_norm = tf.clip_by_value(Normalization('extra_mm_input2_norm')(tf.concat(mm_sparse_input2, axis=1)), -5, 5)
sim_ctx_input_norm = tf.clip_by_value(Normalization('sim_ctx_input_norm')(tf.concat(sim_ctx_input, axis=1)), -5, 5)
sim_ctx_input2_norm = tf.clip_by_value(Normalization('sim_ctx_input2_norm')(tf.concat(sim_ctx_input2, axis=1)), -5, 5)
mm_ctx_input_norm = tf.clip_by_value(Normalization('mm_ctx_input_norm')(tf.concat(mm_ctx_input, axis=1)), -5, 5)
cross_attention_input_norm = tf.clip_by_value(Normalization('cross_attention_input_norm')(tf.concat(cross_attention_input, axis=1)), -5, 5)
ctx_cross_attention_input_norm = tf.clip_by_value(Normalization('ctx_cross_attention_input_norm')(tf.concat(ctx_cross_attention_input, axis=1)), -5, 5)
rec_simtier_input_norm = tf.clip_by_value(Normalization('rec_simtier_input_norm')(tf.concat(rec_simtier_sparse_input, axis=1)), -5, 5)
ctx_rec_simtier_input_norm = tf.clip_by_value(Normalization('ctx_rec_simtier_input_norm')(tf.concat(ctx_rec_simtier_sparse_input, axis=1)), -5, 5)
print('extra_sparse_input:', extra_input_norm.shape)  # (?, 616)
print('extra_mm_sparse_input:', extra_mm_input_norm.shape)  # (?, 706)
print('extra_mm_sparse_input2:', extra_mm_input2_norm.shape)  # (?, 369)
print('sim_ctx_input_norm:', sim_ctx_input_norm.shape)  # (?, 452)
print('sim_ctx_input2_norm:', sim_ctx_input2_norm.shape)  # (?, 129)
print('mm_ctx_input_norm:', mm_ctx_input_norm.shape)  # (?, 838)
print('cross_attention_input_norm:', cross_attention_input_norm.shape)  # (?, 276)
print('ctx_cross_attention_input_norm:', ctx_cross_attention_input_norm.shape)  # (?, 276)
print('rec_simtier_input_norm:', rec_simtier_input_norm.shape) # (?, 384)
print('ctx_rec_simtier_input_norm:', ctx_rec_simtier_input_norm.shape) # (?, 384)

tower1_input = tf.concat([shared_onehot_input, iterable_onehot_input, shared_dense_input, iterable_dense_input, sparse_input], axis=1)
# For 2round training
tower2_input = sparse_input

# 1011 update: 增加 ctx rec-based sim-tier
ctx_gate_input = tf.concat([sim_ctx_input_norm, mm_ctx_input_norm, sim_ctx_input2_norm, ctx_rec_simtier_input_norm], axis=-1) #

nn_inputs = [tower1_input]
for slot_id in lhuc_slot_ids:
    if slot_id in tensor_dict:
        lhuc_input_tensors.append(tensor_dict[slot_id])
lhuc_input = tf.concat(lhuc_input_tensors, axis=1, name='lhuc_input')

mad_input = {'uma_pos': tensor_dict['39000'], 'uma_neg': tensor_dict['39001']
    , 'ima_pos': tensor_dict['39002'], 'ima_neg': tensor_dict['39003']
             }
mad_target = {}

hist_tensor = []
scalar_tensor = []
# Train
param_initializer = tf.truncated_normal_initializer(stddev=0.001, dtype=tf.float32)
main_targets = "first_oa_order,first_oa_order_7d,ads_direct_order,ads_broad_order,paid_order_1d,paid_order_7d".split(',')
auxiliary_targets = "ads_atc,ads_org_direct_order_0_1d_cnt,ads_org_direct_order_2_7d_cnt,shop_cr_order_cnt,cancel_order_7d,return_order_7d,complete_order_7d".split(',')
sub_scene_targets = "first_oa_order_dd,first_oa_order_pdp,first_oa_order_pp,first_oa_order_7d_dd,first_oa_order_7d_pdp,first_oa_order_7d_pp,\
paid_order_1d_dd,paid_order_1d_pdp,paid_order_1d_pp,paid_order_7d_dd,paid_order_7d_pdp,paid_order_7d_pp".split(',')
all_targets = auxiliary_targets + sub_scene_targets + main_targets
raw_targets = "first_oa_order,first_oa_order_7d,ads_atc,ads_direct_order,ads_broad_order,ads_org_direct_order_0_1d_cnt,ads_org_direct_order_2_7d_cnt,shop_cr_order_cnt,paid_order_1d,paid_order_7d,cancel_order_7d,return_order_7d,complete_order_7d".split(',')
nn_outputs = defaultdict(list)
losses, labels, weights, targets = defaultdict(list), defaultdict(list), defaultdict(list), defaultdict(list)
eval_nodes = []
ma_target = [[], []]
blocks = 3
base_input_dim = 6501
for phase, _nn_input in enumerate(nn_inputs):
    hist_tensor.append(
        tf.reshape(tf.reduce_mean(lhuc_input, axis=0), (-1,), name="{}_lhuc_input_w_no_normal".format(phase)))
    lhuc_input = tf.clip_by_value(Normalization('p{}_input/lhuc_input'.format(phase))(lhuc_input), -5, 5)
    hist_tensor.append(tf.reshape(tf.reduce_mean(lhuc_input, axis=0), (-1,), name="{}_lhuc_input_w".format(phase)))

    _nn_input = tf.clip_by_value(Normalization('p{}_input/input_norm'.format(phase))(_nn_input), -5, 5)
    _nn_input = tf.concat([_nn_input, extra_input_norm, extra_mm_input_norm, extra_mm_input2_norm, recall_input_norm, cross_attention_input_norm, ctx_cross_attention_input_norm], axis=-1) # 6501 + 616 + 706 + 369 + 16 + 276 + 276
    print('Origin Input Shape:', _nn_input.shape)  # (?, 8760)
    _nn_input = tf.concat([_nn_input, rec_simtier_input_norm], axis=-1)
    print('SeNet Input Shape:', _nn_input.shape)  # (?, 9144)

    bias_feature_input = tf.concat([tensor_dict[slot_id] for slot_id in ['35488', '31678']], axis=1,
                                   name='bias_feature_input')
    # ctx gate
    _nn_input = ctx_gate(_nn_input, tf.concat([ctx_gate_input, bias_feature_input], axis=-1), 'p{}'.format(phase))

    senet_lst = []
    for i in range(blocks):
        nn_input, _ = SENet_v2(_nn_input, 'p{}{}'.format(phase, i), hidden_dim=512, output_dim=1024)
        senet_lst.append(nn_input)

    senet_tensor = tf.concat(senet_lst, axis=-1)
    print('SeNet Output Shape:', senet_tensor.shape)

    # 256 * 3 -> 64 -> 6501
    share_bottom = dense_gate_tower(name='Share_Bottom_{}'.format(phase),
                                    emb_input=senet_tensor,
                                    hidden_dims=[1024, 512, 128],
                                    param_initializer=param_initializer)

    # add mad target
    mad_target['uma_target'] = tf.stop_gradient(share_bottom)
    mad_target['ima_target'] = tf.stop_gradient(share_bottom)
    # mad_target['uma_ads_target'] = tf.stop_gradient((ple_output_lst[3]+ple_output_lst[4])/2)

    print('Main Net Input Shape:', share_bottom.shape)

    gate_input = tf.concat([bias_feature_input, extra_mm_input_norm, extra_mm_input2_norm,
                            rec_simtier_input_norm, ctx_rec_simtier_input_norm, ctx_gate_input], axis=-1)

    mal_net = MAL_NET_V1(all_targets, raw_targets, main_targets, auxiliary_targets, sub_scene_targets, param_initializer, phase, "cat_4")
    nn_outputs, labels, weights, losses, targets, eval_nodes, cat_losses, cat_weights = mal_net.forward(tf.concat([share_bottom, bias_feature_input], axis=1), lhuc_input, gate_input)
    scalar_tensor += mal_net.get_dump_scalars()


def multi_loss_func(losses, loss_weights, target_names, extra_params):
    final_loss = None
    for loss, loss_weight, target_name in list(zip(losses, loss_weights, target_names)):
        loss = tf.multiply(loss, -loss_weight, name=target_name + "_loss")
        loss = tf.math.reduce_sum(loss, name=target_name + "_batchloss")
        if final_loss is not None:
            final_loss = loss + final_loss
        else:
            final_loss = loss

    return final_loss


def mean_square_loss(emb, target, alpha=1.0):
    mse = alpha * tf.reduce_mean(tf.square(target - emb))
    return mse


def madnn_loss(pos=None, neg=None, target=None, label_idx=None, name=None):
    label_lst = []
    weight_lst = []
    for idx in label_idx:
        l, w = ego.get_label_weight(target_name="{}_{}_label".format(name, idx), label_idx=idx * 2)
        label_lst.append(l)
        weight_lst.append(w)
    label_sum = sum(label_lst)
    weight_sum = sum(weight_lst)
    label = tf.broadcast_to(label_sum, tf.shape(pos))
    weight = tf.broadcast_to(weight_sum, tf.shape(pos))
    ma_emb = tf.where(label > 0, pos, neg)
    ma_emb = tf.where(weight > 0, ma_emb, target)
    loss = mean_square_loss(ma_emb, target, 0.1)
    return loss


p0_loss = multi_loss_func(losses[0], weights[0], targets[0], None)
# extra loss
umad_org_loss = madnn_loss(pos=mad_input['uma_pos'], neg=mad_input['uma_neg'], target=mad_target['uma_target'],
                           label_idx=[0, 1], name='uma')
umad_ads_loss = madnn_loss(pos=mad_input['ima_pos'], neg=mad_input['ima_neg'], target=mad_target['ima_target'],
                           label_idx=[0, 1], name='ima')
p0_loss += umad_org_loss
p0_loss += umad_ads_loss

#cat loss
total_cat_loss = 0.0
for cat_loss, cat_weight in zip(cat_losses, cat_weights):
    total_cat_loss += tf.multiply(cat_loss, -cat_weight, name="cat_label" + "_loss")
total_cat_loss = tf.math.reduce_sum(total_cat_loss, name="cat_label" + "_batchloss")
print("cat loss = {}".format(total_cat_loss))

p0_loss += total_cat_loss

# p1_loss = multi_loss_func(losses[1], weights[1], targets[1], None)
# multitask trick
# tlabel, tweight = ego.get_label_weight(target_name="tlabel", label_idx=0)
# ego.Target("predict_node", tf.identity(nn_outputs[0][0]**0.6*(nn_outputs[0][2]+0.05), 'predict_node'), tlabel, tweight, None, metric_type=ego.MetricType.GAUC)

ego.config_dump_tensor(with_sample_id=False)
if ego.is_training_mode():
    round0 = ego.OfflineRound(name="eval", targets=targets[0] + eval_nodes, final_loss=None)
    round1 = ego.OfflineRound(name="p0_train", targets=targets[0], final_loss=p0_loss, train_sparse=True,
                              dump_histo_tensors_to_tensorboard=hist_tensor,
                              dump_scalar_tensors_to_tensorboard=scalar_tensor)
    # round2 = ego.OfflineRound(name="p1_train", targets=targets[1], final_loss=p1_loss, train_sparse=True)
    ego.compile(rounds=[round0, round1])
else:
    import json

    with open('/workspace/data/cali_param.json') as f:
        config = json.load(f)
        region = config['region']
        cali_configs = config[region]
        print("region={region}")
        dst_name_lst = []
        nn_outputs[0] = nn_outputs[0][:len(auxiliary_targets)] + nn_outputs[0][len(auxiliary_targets + sub_scene_targets):]
        for cali_config in cali_configs:
            src_name = cali_config["src_name"]
            src_idx = cali_config["src_idx"]
            dst_name = cali_config["dst_name"]
            formula_ratio = cali_config["formula_ratio"]
            const_ratio = cali_config["const_ratio"]
            print(f'dst_name={dst_name} formula ratio={formula_ratio}, const_ratio={const_ratio}')
            if cali_config["simple_cali"]:
                ego.Target(dst_name, tf.identity(const_ratio * nn_outputs[0][src_idx],
                                                 dst_name), None, None, None)
            else:
                ego.Target(dst_name, tf.identity(const_ratio * nn_outputs[0][src_idx] / (
                            nn_outputs[0][src_idx] + (1 - nn_outputs[0][src_idx]) / formula_ratio),
                                                 dst_name), None, None, None)
            dst_name_lst.append(dst_name)

    round0 = ego.OnlineRound(name="online_predict", targets=dst_name_lst)
    ego.compile(rounds=[round0])
