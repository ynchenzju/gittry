#!/usr/bin/env python
# -*- coding: utf-8 -*-
import tensorflow as tf
import ego
import json
import sys


sample_cnt = 40

def get_shape(inputs):
    dynamic_shape = tf.shape(inputs)
    static_shape = inputs.get_shape().as_list()
    shape = []
    for i, dim in enumerate(static_shape):
        shape.append(dim if dim is not None else dynamic_shape[i])
    return shape


def rank_metrics(score_tensor):
    max_score_idx = tf.cast(tf.argmax(score_tensor, 1), tf.int32)
    length = get_shape(score_tensor)[0]
    zero_idx = tf.zeros([length], dtype=tf.int32)
    # p = tf.reduce_mean(tf.cast(tf.equal(max_score_idx, zero_idx), tf.float32), name = 'p_at_0')
    p = tf.reduce_sum(tf.cast(tf.equal(max_score_idx, zero_idx), tf.float32), name = 'p_at_0')

    ranks = tf.argsort(score_tensor, axis = 1, direction='DESCENDING')
    shape = get_shape(ranks)
    zero_idx = tf.zeros(shape, dtype=tf.int32)

    true_rank = tf.cast(tf.where(tf.equal(ranks, zero_idx))[:, 1:], tf.float32)
    # mrr = tf.reduce_mean(1.0 / (true_rank + 1.0), name='mrr')
    mrr = tf.reduce_sum(1.0 / (true_rank + 1.0), name='mrr')
    return p, mrr

def training_monitor(dot_2d, label):
    order_idx = tf.where(tf.cast(label, tf.int32))[:, 0]
    order_dot2d = tf.gather(dot_2d, order_idx)
    pos_score =  tf.expand_dims(order_dot2d[:, 0], 1) # dot_2d[:, :1]
    neg_score = order_dot2d[:, 1:]
    cos_similarity_true = tf.reduce_sum(tf.reduce_sum(pos_score, axis=1), axis=0, name = "cos_pos")
    cos_similarity_false = tf.reduce_sum(tf.reduce_sum(neg_score, axis=1) / float(sample_cnt), axis=0, name = "cos_neg")

    order_num = tf.cast(tf.reduce_sum(tf.ones_like(order_idx)), tf.float32, 'order_num')
    p, mrr = rank_metrics(order_dot2d)
    label_mean = tf.reduce_mean(label, name='label_mean')
    return [cos_similarity_true, cos_similarity_false, order_num, p, mrr, label_mean]

ego.config_dump_tensor(with_sample_id=False)

USER_SLOT_IDS = [1001, 5051, 1004, 1005 # user profile
    , 2101, 2102, 2103
    , 2301, 2302, 2303
    , 2401, 2402, 2403
    , 2111, 2112, 2113
    , 2311, 2312, 2313
    , 2411, 2412, 2413
    , 2321, 2322, 2323
    , 2421, 2422, 2423 # short term behavior
]
ITEM_SLOT_IDS = [3001, 2001, 2004, 2006, 2009, 2010, 2011]
USER_SLOT_NUM = len(USER_SLOT_IDS)
ITEM_SLOT_NUM = len(ITEM_SLOT_IDS)

SLOT_IDS = USER_SLOT_IDS + ITEM_SLOT_IDS

SLOT_DIM = 17
SLOT_DIMS = [SLOT_DIM] * len(SLOT_IDS)
POOLING_METHODS = [ego.Pooling.SUM] * len(SLOT_IDS)
param_initializer = tf.truncated_normal_initializer(stddev=0.001, dtype=tf.float32)


user_input = ego.get_slots(
                        name='user_sparse_input',
                        slots=USER_SLOT_IDS,
                        dims=[SLOT_DIM] * USER_SLOT_NUM,
                        poolings=[ego.Pooling.SUM] * USER_SLOT_NUM,
                        feature_type=ego.FeatureType.UNDEFINED
                    )

user_ret = ego.DenseTower(
                        name='UserTower1',
                        output_dims=[255, 127, 63, 32],
                        kernel_initializers=[param_initializer] * 4,
                        bias_initializers=[param_initializer] * 4,
                        activations=[tf.nn.leaky_relu, tf.nn.leaky_relu, tf.nn.leaky_relu, tf.nn.leaky_relu],
                        norms=[True, False, False, False],
                        use_bias=True
                    ) (user_input)
user_emb = tf.nn.l2_normalize(user_ret, axis=1, epsilon=1e-6, name='user_emb')

item_tower_dnn = ego.DenseTower(
                        name='ItemTower1',
                        output_dims=[255, 127, 63, 32],
                        kernel_initializers=[param_initializer] * 4,
                        bias_initializers=[param_initializer] * 4,
                        activations=[tf.nn.leaky_relu, tf.nn.leaky_relu, tf.nn.leaky_relu, None],
                        norms=[True, False, False, False],
                        use_bias=True
                        )

if ego.is_training_mode():
    ego.config_nsc(use_nsc=True, sample_ratio=sample_cnt, share_batch=False)
    item_embs = ego.get_slots(
                    name='item_sparse_input',
                    slots=ITEM_SLOT_IDS,
                    dims=[SLOT_DIM] * ITEM_SLOT_NUM,
                    poolings=[ego.Pooling.SUM] * ITEM_SLOT_NUM,
                    feature_type=ego.FeatureType.ITEM,
                    use_nsc=True,
                    )
    item_input = tf.concat(item_embs, axis = 0)

    item_emb = tf.nn.l2_normalize(item_tower_dnn(item_input), axis=1, epsilon=1e-6, name='item_vec')

    dot_ctr = tf.reduce_sum(tf.multiply(tf.tile(user_emb, [1 + sample_cnt, 1]), item_emb), axis=1, keepdims=True, name='ip')

    dot_result = tf.transpose(tf.reshape(tf.transpose(dot_ctr), [1 + sample_cnt, -1]))

    order_target = tf.nn.softmax(dot_result * 20, axis=-1, name='logits')
    pos_order_target = tf.slice(order_target, [0, 0], [-1, 1], name="pos_order_target")

    label, weight = ego.get_label_weight(target_name="label0", label_idx=0)
    loss_cvr = tf.multiply(label, -tf.math.log(pos_order_target + 1e-8), name='c_loss')

    monitor_var = training_monitor(dot_result, label)

    tmp_loss = tf.stop_gradient(tf.reduce_sum(tf.stack(monitor_var)))
    final_loss = tf.add(tf.reduce_sum(loss_cvr * -weight), 0 * tmp_loss, name = 'final_loss')
    ego.Target("order_target", pos_order_target, label, weight, final_loss, ego.MetricType.RMSE)

    round1 = ego.OfflineRound(name="train_round1",
                targets=['order_target'],
                final_loss=final_loss,
                train_sparse=True,
                dump_tensors_to_hdfs=monitor_var)
    ego.compile(rounds=[round1])
else:
    item_input = ego.get_slots(
                            name='item_input_v2',
                            slots=ITEM_SLOT_IDS,
                            dims=[SLOT_DIM] * ITEM_SLOT_NUM,
                            poolings=[ego.Pooling.SUM] * ITEM_SLOT_NUM,
                            feature_type=ego.FeatureType.ITEM,
                            use_nsc=False
                            )
    item_vec_normed = tf.nn.l2_normalize(item_tower_dnn(item_input), axis=1, epsilon=1e-6, name='item_vec_normed')

    try:
        with open('online_compile_config.json') as f:
            cfg = json.load(f)
        cfg_targets = cfg.get('targets', ['user_emb_output', 'item_emb_output'])
    except:
        cfg_targets = ['user_emb_output', 'item_emb_output']

    targets = []
    if 'user_emb_output' in cfg_targets:
        ego.import_extra_slots(ITEM_SLOT_IDS, [SLOT_DIM] * ITEM_SLOT_NUM)
        ego.Target("user_emb_output", user_emb, None, None, None, None)
        targets.append('user_emb_output')

    if 'item_emb_output' in cfg_targets:
        ego.import_extra_slots(ITEM_SLOT_IDS, [SLOT_DIM] * ITEM_SLOT_NUM)
        ego.Target("item_emb_output", item_vec_normed, None, None, None, None)
        targets.append('item_emb_output')
    #logging.info('online_targets={targets}'.format(targets=targets))
    ego.compile(rounds=[
        ego.OnlineRound(name='online', targets=targets),
    ])

