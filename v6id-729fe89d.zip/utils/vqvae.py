#!/usr/bin/env python
# -*- coding: utf-8 -*-

import tensorflow as tf

class MVAVG():
    def __init__(self, shape, name):
        self.hidden = tf.Variable(tf.zeros(shape), trainable=False, name="hid_" + name)
        self.counter = tf.Variable(0, trainable=False, dtype=tf.int64, name="cnt_" + name)

    def update_mv_avg(self, value, decay):
        self.counter.assign_add(1)
        counter = tf.cast(self.counter, value.dtype)
        self.hidden.assign_sub((self.hidden - value) * (1 - decay))
        return self.hidden / (1. - tf.pow(decay, counter))


class VQ(tf.keras.layers.Layer):
    def __init__(self, codebook_num, embedding_dim, commitment_cost, decay = 0.99):
        super(VQ, self).__init__()
        self.commitment_cost = commitment_cost
        self.decay = float(decay)
        self.codebook_num = codebook_num

        self.codebook = self.add_weight(name='codebook', shape=(codebook_num, embedding_dim),
                initializer=tf.truncated_normal_initializer(stddev=tf.sqrt(2.0 / codebook_num)), trainable=True)

        self.ema_means = MVAVG((codebook_num, embedding_dim), 'ema_means')
        self.ema_count = MVAVG((codebook_num, 1), 'ema_count')
        self.epsilon = 1e-5

    def call(self, inputs, use_ema = False):
        # inputs: (B, embedding_dim)
        # 计算输入和 codebook 之间的欧几里得距离
        # tf.norm((B, codebook_num, embedding_dim)) --> (B, codebook_num)
        distances = tf.norm(inputs[:, tf.newaxis, :] - self.codebook[tf.newaxis, :, :], axis=-1)

        # 找到最近的 codebook 向量的索引
        index = tf.argmin(distances, axis=-1) # (B,)
        quantized = tf.nn.embedding_lookup(self.codebook, index) # (B, embedding_dim)
        # 计算量化损失和聚合损失
        # (B, 1)
        commitment_loss = tf.reduce_sum((tf.stop_gradient(quantized) - inputs) ** 2, axis = -1, keepdims=True)
        vq_loss = self.commitment_cost * commitment_loss

        one_hot_vec = tf.transpose(tf.one_hot(index, depth=self.codebook_num)) # (codebook_num, B)
        one_hot_vec_sum = tf.reduce_sum(one_hot_vec, axis=1, keepdims=True) # (codebook_num, 1)
        max_num_idx = tf.argmax(one_hot_vec_sum, axis=0)
        max_cluster_num = tf.cast(tf.reduce_sum(tf.gather(one_hot_vec_sum, max_num_idx)), dtype=tf.float32)
        batch_size = tf.cast(tf.reduce_sum(one_hot_vec_sum), dtype=tf.float32)
        max_cluster_ratio = max_cluster_num / batch_size

        if use_ema:
            updated_ema_count = self.ema_count.update_mv_avg(one_hot_vec_sum, self.decay)
            # Laplace smoothing of the ema count
            updated_ema_count = (updated_ema_count + self.epsilon) / (batch_size + self.codebook_num * self.epsilon) * batch_size
            # (codebook_num, embedding_dim_sum) = (codebook_num, B) matmul (B, embedding_dim)
            batch_emb_sum = tf.matmul(one_hot_vec, inputs)
            updated_ema_means = self.ema_means.update_mv_avg(batch_emb_sum, self.decay)
            with tf.control_dependencies([commitment_loss]):
                self.codebook.assign(updated_ema_means / updated_ema_count)
        else:
            quantization_loss = tf.reduce_sum((quantized - tf.stop_gradient(inputs)) ** 2, axis = -1, keepdims=True)
            vq_loss += quantization_loss

        # 重构量化向量
        quantized = inputs + tf.stop_gradient(quantized - inputs)

        return quantized, vq_loss, max_cluster_ratio

    def get_codebook(self):
        return self.codebook
