#!/usr/bin/env python
# -*- coding: utf-8 -*-

import tensorflow as tf
import ego
import yaml
import numpy as np
import random
import json
__tf_version = tf.__version__
if __tf_version >= '2.0':
    tf2 = tf
    tf = tf.compat.v1


local_param_initializer = tf.truncated_normal_initializer(stddev=0.001, dtype=tf.float32)

def get_shape(inputs):
    dynamic_shape = tf.shape(inputs)
    static_shape = inputs.get_shape().as_list()
    shape = []
    for i, dim in enumerate(static_shape):
        shape.append(dim if dim is not None else dynamic_shape[i])
    return shape


def read_train_cfg():
    cfg = {}
    if ego.is_training_mode():
        try:
            with open("ego-learner.yaml") as fh:
                yaml_data = yaml.safe_load(fh)
            if 'my_train_config' in yaml_data:
                for key in yaml_data['my_train_config']:
                    cfg[key] = yaml_data['my_train_config'][key]
        except Exception as e:
            print("here are some error", e)
    else:
        with open('online_compile_config.json') as f:
            cfg = json.load(f)
    print(cfg)
    return cfg


def config_kv(key, default_v, cfg):
    return default_v if key not in cfg else cfg[key]


def random_mask_feature(ub_click_seq_list, dropout_rate = 0.5, mask_len = 0):
    dropout_layer = tf.keras.layers.Dropout(dropout_rate)
    feature_length = len(ub_click_seq_list)
    index = [i for i in range(feature_length)]
    random.shuffle(index)
    mask_len = int(feature_length / 2) if mask_len == 0 else mask_len
    index_set1 = index[:mask_len]
    random.shuffle(index)
    # max_len = min(2 * mask_len, feature_length)
    # index_set2 = index[mask_len: max_len]
    index_set2 = index[:mask_len]
    aug_list1 = []
    aug_list2 = []
    for idx, part_seq_info in enumerate(ub_click_seq_list):
        # (B, 50, dim)
        part_seq_emb, _ = part_seq_info[1]
        if idx in index_set1:
            aug_list1.append(dropout_layer(part_seq_emb, training=ego.is_training_mode()))
        else:
            aug_list1.append(part_seq_emb)

        if idx in index_set2:
            aug_list2.append(dropout_layer(part_seq_emb, training=ego.is_training_mode()))
        else:
            aug_list2.append(part_seq_emb)

    # (B, 50, dim_sum)
    aug_seq_emb1 = tf.concat(aug_list1, axis=-1)
    aug_seq_emb2 = tf.concat(aug_list2, axis=-1)
    return aug_seq_emb1, aug_seq_emb2


def random_mask_feature_item(random_uniform_neg_item, dim_list, dropout_rate = 0.5, mask_len = 2):
    # random_uniform_neg_item (B, sample_cnt, dim)
    dropout_layer = tf.keras.layers.Dropout(dropout_rate)
    feature_neg_item_list = tf.split(random_uniform_neg_item, dim_list, axis = -1)
    feature_length = len(feature_neg_item_list)
    index = [i for i in range(feature_length)]
    random.shuffle(index)
    mask_len = int(feature_length / 2) if mask_len == 0 else mask_len
    index_set1 = index[:mask_len]
    random.shuffle(index)
    # max_len = min(2 * mask_len, feature_length)
    # index_set2 = index[mask_len: max_len]
    index_set2 = index[:mask_len]
    aug_list1 = []
    aug_list2 = []
    for idx, part_seq_info in enumerate(feature_neg_item_list):
        # (B, 50, dim)
        part_seq_emb = part_seq_info
        if idx in index_set1:
            aug_list1.append(dropout_layer(part_seq_emb, training=ego.is_training_mode()))
        else:
            aug_list1.append(part_seq_emb)

        if idx in index_set2:
            aug_list2.append(dropout_layer(part_seq_emb, training=ego.is_training_mode()))
        else:
            aug_list2.append(part_seq_emb)

    # (B, sample_cnt, dim_sum)
    aug_item_emb1 = tf.concat(aug_list1, axis=-1)
    aug_item_emb2 = tf.concat(aug_list2, axis=-1)
    return aug_item_emb1, aug_item_emb2


def safe_reduce_mean(tensor, axis=None, keepdims=False, name=None):
    return tf.cond(
        tf.math.greater(tf.size(tensor, out_type=tf.int32), tf.constant(0, tf.int32)),
        lambda: tf.reduce_mean(tensor, axis=axis, keepdims=keepdims, name=name),
        lambda: tf.constant(0.0, dtype=tensor.dtype),
    )


def in_batch_sampling_loss(x, y, weight):
    dot_product = tf.linalg.matmul(x, y, transpose_b=True)
    loss = tf.nn.sparse_softmax_cross_entropy_with_logits(
        labels=tf.range(tf.shape(dot_product)[0], dtype=tf.int32),
        logits=dot_product,
    )
    loss = tf.expand_dims(loss, axis=1) * weight
    loss = tf.reduce_sum(loss)
    return loss, dot_product


def training_monitor(dot_2d, label):
    order_idx = tf.where(tf.cast(label, tf.int32))[:, 0]
    order_dot2d = tf.gather(dot_2d, order_idx)
    pos_score =  tf.expand_dims(order_dot2d[:, 0], 1) # dot_2d[:, :1]
    neg_score = order_dot2d[:, 1:]
    cos_similarity_true = tf.reduce_sum(tf.reduce_sum(pos_score, axis=1), axis=0, name = "cos_pos")
    cos_similarity_false = tf.reduce_sum(tf.reduce_sum(neg_score, axis=1) / float(sample_cnt), axis=0, name = "cos_neg")

    order_num = tf.cast(tf.reduce_sum(tf.ones_like(order_idx)), tf.float32, 'order_num')
    p, mrr = rank_metrics(order_dot2d)
    label_mean = tf.reduce_mean(label, name='label_mean')
    return [cos_similarity_true, cos_similarity_false, order_num, p, mrr, label_mean]


def rank_metrics(dot_product, mask=None):
    max_idx = tf.argmax(dot_product, axis=1, output_type=tf.int32)
    label = tf.range(tf.shape(dot_product)[0], dtype=tf.int32)
    if mask is not None:
        max_idx = tf.boolean_mask(max_idx, mask)
        label = tf.boolean_mask(label, mask)
    p = safe_reduce_mean(tf.cast(tf.equal(max_idx, label), tf.float32))

    ranks = tf.argsort(dot_product, direction="DESCENDING")
    pos_ranks = tf.linalg.tensor_diag_part(ranks)
    if mask is not None:
        pos_ranks = tf.boolean_mask(pos_ranks, mask)
    mrr = safe_reduce_mean(1.0 / (1.0 + tf.cast(pos_ranks, tf.float32)))

    return p, mrr


def similarity_metrics(dot_product, mask=None):
    pos_scores = tf.linalg.tensor_diag_part(dot_product)
    neg_scores = dot_product - tf.linalg.diag(pos_scores)
    if mask is not None:
        pos_scores = tf.boolean_mask(pos_scores, mask)
        neg_scores = tf.boolean_mask(neg_scores, mask)
    pos_similarity = safe_reduce_mean(pos_scores)
    neg_similarity = tf.math.divide_no_nan(
        tf.reduce_sum(neg_scores),
        tf.math.count_nonzero(neg_scores, dtype=neg_scores.dtype),
    )
    return pos_similarity, neg_similarity


@tf.custom_gradient
def ignore_grad(x):
    def grad(upstream):
        return upstream * 0.0

    return x, grad


def local_neg_sample(match_size, local_samples, cnt, start_idx = 0):
    batch_size = get_shape(local_samples)[0]
    batch_neg_idx = tf.random.uniform([match_size, cnt], minval=start_idx, maxval=batch_size, dtype=tf.int32)
    return tf.gather(local_samples, batch_neg_idx) # (B, sample_cnt, 16)


def get_batch_neg_sample(item_emb, sample_cnt, batch_size):
    #output shape: (B, sample_cnt, dim)
    batch_neg_idx = tf.random.uniform([batch_size, sample_cnt], minval=0, maxval=batch_size, dtype=tf.int32)
    row_indices = tf.range(batch_size)
    row_indices = tf.expand_dims(row_indices, axis=1)
    row_same_indices = tf.cast(tf.equal(batch_neg_idx, row_indices), tf.int32)
    last_row = tf.multiply(row_same_indices[batch_size - 1], -(batch_size - 1))
    row_same_indices = tf.tensor_scatter_nd_update(row_same_indices, [[batch_size - 1]], [last_row])
    batch_neg_idx += row_same_indices
    return tf.gather(item_emb, batch_neg_idx)


def get_ego_layer(layername, dim):
    return ego.DenseTower(
        name=layername,
        output_dims=[dim],
        kernel_initializers=[local_param_initializer] * 1,
        bias_initializers=[local_param_initializer] * 1,
        activations=[None],
        norms=[False],
        use_bias=True,
    )


def positional_encoding(max_position, d_model):
    position = np.arange(max_position)[:, np.newaxis]
    div_term = np.exp(np.arange(0, d_model, 2) * -(np.log(10000.0) / d_model))

    sin_encoding = np.sin(position * div_term)
    cos_encoding = np.cos(position * div_term)

    pos_encoding = np.zeros((max_position, d_model))
    pos_encoding[:, 0::2] = sin_encoding
    pos_encoding[:, 1::2] = cos_encoding

    return tf.cast(pos_encoding, dtype=tf.float32)


def scaled_dot_product_attention(q, k, v, mask, causality):
    # (B, num_heads, q_seq, k_seq)
    matmul_qk = tf.matmul(q, k, transpose_b=True)
    dk = tf.shape(k)[-1]
    scaled_attention_logits = matmul_qk / tf.math.sqrt(tf.cast(dk, tf.float32))
    if mask is not None:
        # (B, k_seq)
        paddings = 1.0 - mask
        scaled_attention_logits += (paddings[:, tf.newaxis, tf.newaxis, :] * -1e5)

    if causality:
        id_matrix = tf.ones_like(scaled_attention_logits[0, 0, :, :])
        lower_tril = tf.linalg.LinearOperatorLowerTriangular(id_matrix).to_dense()
        mask = tf.linalg.set_diag(lower_tril, tf.zeros([tf.shape(lower_tril)[0]], dtype=lower_tril.dtype))
        scaled_attention_logits += (mask[tf.newaxis, tf.newaxis, ...] * -1e5)

    attention_weights = tf.nn.softmax(scaled_attention_logits, axis=-1)
    # (B, num_heads, q_seq, k_seq) (B, num_heads, k_seq, dim)
    output = tf.matmul(attention_weights, v) # (B, num_heads, q_seq, dim)
    return output, attention_weights


class MultiHeadAttention(tf.keras.layers.Layer):
    def __init__(self, d_model, num_heads, layer_idx):
        super(MultiHeadAttention, self).__init__()
        self.num_heads = num_heads
        self.d_model = d_model
        self.depth = d_model // self.num_heads
        self.wq = get_ego_layer("Q" + str(layer_idx), d_model)
        self.wk = get_ego_layer("K" + str(layer_idx), d_model)
        self.wv = get_ego_layer("V" + str(layer_idx), d_model)
        self.dense = get_ego_layer("O" + str(layer_idx), d_model)

    def split_heads(self, x, batch_size):
        x = tf.reshape(x, (batch_size, -1, self.num_heads, self.depth))
        return tf.transpose(x, perm=[0, 2, 1, 3])

    def call(self, v, k, q, mask, causality):
        batch_size = get_shape(q)[0]
        q = self.wq(q)
        k = self.wk(k)
        v = self.wv(v)

        q = self.split_heads(q, batch_size)
        k = self.split_heads(k, batch_size)
        v = self.split_heads(v, batch_size)

        attention_output, attention_weights = scaled_dot_product_attention(q, k, v, mask, causality)
        scaled_attention = tf.transpose(attention_output, perm=[0, 2, 1, 3])
        concat_attention = tf.reshape(scaled_attention, (batch_size, -1, self.d_model))
        output = self.dense(concat_attention)

        return output, attention_weights


class EncoderLayer(tf.keras.layers.Layer):
    def __init__(self, d_model, num_heads, layer_idx, rate=0.1):
        super(EncoderLayer, self).__init__()

        self.mha = MultiHeadAttention(d_model, num_heads, layer_idx)
        self.ffn = ego.DenseTower(
            name="ffn" + str(layer_idx),
            output_dims=[d_model * 4, d_model],
            kernel_initializers=[local_param_initializer] * 2,
            bias_initializers=[local_param_initializer] * 2,
            activations=[tf.nn.leaky_relu, None],
            norms=[False, False],
            use_bias=True
        )

        self.layernorm1 = tf.keras.layers.LayerNormalization(epsilon=1e-6)
        self.layernorm2 = tf.keras.layers.LayerNormalization(epsilon=1e-6)

        self.dropout1 = tf.keras.layers.Dropout(rate)
        self.dropout2 = tf.keras.layers.Dropout(rate)

    def call(self, x, training, mask, causality):
        attn_output, _ = self.mha(x, x, x, mask, causality)
        attn_output = self.dropout1(attn_output, training=training)
        out1 = self.layernorm1(x + attn_output)
        ffn_output = self.ffn(out1)
        ffn_output = self.dropout2(ffn_output, training=training)
        out2 = self.layernorm2(out1 + ffn_output)
        return out2


class Transformer(tf.keras.layers.Layer):
    def __init__(self, num_layers, d_model, num_heads, maximum_position_encoding = 50, rate=0.1):
        super(Transformer, self).__init__()

        self.d_model = d_model
        self.num_layers = num_layers
        self.maximum_position_encoding = maximum_position_encoding
        self.enc_layers = [EncoderLayer(d_model, num_heads, layer_idx, rate) for layer_idx in range(num_layers)]
        self.proj_layer = get_ego_layer("proj_layer", d_model)
        self.position_emb = self.add_weight(name='position', shape=(maximum_position_encoding, d_model),
                                            initializer=local_param_initializer, trainable=True)

    def call(self, x, training, mask, use_pos = True, causality = False):
        # pos_length = get_shape(x)[-1]
        x = self.proj_layer(x)
        if use_pos:
            x += self.position_emb

        for i in range(self.num_layers):
            x = self.enc_layers[i](x, training, mask, causality)

        return x


def multihead_target_attention_v2_auto_fold(
        queries,
        keys,
        values,
        num_units=None,
        activation_fn=None,
        num_heads=8,
        name="multihead_target_attention",
        key_masks=None,
):
    if num_units is None:
        num_units = queries.get_shape().as_list()[-1]
    query_len = queries.get_shape().as_list()[1]
    query_dim = queries.get_shape().as_list()[-1]
    key_len = keys.get_shape().as_list()[1]
    key_dim = keys.get_shape().as_list()[-1]
    value_dim = values.get_shape().as_list()[-1]

    queries_2d = tf.reshape(queries, [-1, query_dim])
    keys_2d = tf.reshape(keys, [-1, key_dim])
    values_2d = tf.reshape(values, [-1, value_dim])

    Q = ego.DenseTower(
        name="{}_ln_proj_q".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(queries_2d)
    Q = tf.reshape(Q, [-1, query_len, num_units])
    K = ego.DenseTower(
        name="{}_ln_proj_k".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(keys_2d)
    K = tf.reshape(K, [-1, key_len, num_units])
    V = ego.DenseTower(
        name="{}_ln_proj_v".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(values_2d)
    V = tf.reshape(V, [-1, key_len, num_units])

    key_masks_ = tf.tile(
        tf.reshape(key_masks, [-1, 1, 1, key_len]), [1, num_heads, query_len, 1]
    )

    Q_ = tf.stack(tf.split(Q, num_heads, axis=2), axis=1)
    K_ = tf.stack(tf.split(K, num_heads, axis=2), axis=1)
    V_ = tf.stack(tf.split(V, num_heads, axis=2), axis=1)

    Q_ = tf.keras.layers.LayerNormalization(axis=-1)(Q_)
    K_ = tf.keras.layers.LayerNormalization(axis=-1)(K_)

    feature_map = tf.matmul(Q_, K_, transpose_b=True)
    feature_map = feature_map * (num_units ** (-0.5))

    paddings = tf.fill(
        tf.shape(feature_map), tf.constant(-(2 ** 20) + 1, dtype=tf.float32)
    )
    feature_map = tf.where(key_masks_ > 0, feature_map, paddings)
    feature_map = tf.nn.softmax(feature_map)

    outputs = tf.matmul(feature_map, V_)
    outputs = tf.concat(tf.unstack(outputs, axis=1), axis=-1)
    return outputs, feature_map

def din_target_attention(
        queries,
        keys,
        values,
        num_units=None,
        activation_fn=None,
        name="din_target_attention",
        key_masks=None,
        weight_nn=None,
        infer=False,
        topk=0,
):
    if num_units is None:
        num_units = queries.get_shape().as_list()[-1]
    query_len = queries.get_shape().as_list()[1]
    query_dim = queries.get_shape().as_list()[-1]
    key_len = keys.get_shape().as_list()[1]
    key_dim = keys.get_shape().as_list()[-1]
    value_dim = values.get_shape().as_list()[-1]

    queries_2d = tf.reshape(queries, [-1, query_dim])
    keys_2d = tf.reshape(keys, [-1, key_dim])
    values_2d = tf.reshape(values, [-1, value_dim])

    Q = ego.DenseTower(
        name="{}_ln_proj_q".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(queries_2d)
    Q = tf.reshape(Q, [-1, query_len, num_units])
    K = ego.DenseTower(
        name="{}_ln_proj_k".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(keys_2d)
    K = tf.reshape(K, [-1, key_len, num_units])
    V = ego.DenseTower(
        name="{}_ln_proj_v".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(values_2d)
    V = tf.reshape(V, [-1, key_len, num_units])

    # (B, query_len, 1, num_units) (B, 1, key_len, num_units)
    Q_K_fea = Q[:, :, tf.newaxis, :] * K[:, tf.newaxis, :, :] + Q[:, :, tf.newaxis, :] + K[:, tf.newaxis, :, :]
    # (B, query_len, key_len)
    Q_K_weight = tf.squeeze(weight_nn(Q_K_fea), axis = -1)
    feature_map = Q_K_weight * key_masks[:, tf.newaxis, :]
    outputs = tf.matmul(feature_map, V) # (B, query_len, num_units)
    if infer == True:
        # (B, query_len)
        feature_map_sum = tf.reduce_sum(feature_map, axis = -1)
        # (B, topk)
        _, top_indices = tf.math.top_k(feature_map_sum, k = topk)

        # (B, 1, 1)
        row_indices = tf.range(tf.shape(outputs)[0])[:, tf.newaxis, tf.newaxis]
        # (B, topk, 1)
        row_indices = tf.tile(row_indices, [1, topk, 1])

        # (B, topk, 2)
        gather_indices = tf.concat([row_indices, top_indices[..., tf.newaxis]], axis=-1)

        # (B, topk, num_units)
        gather_outputs = tf.gather_nd(outputs, gather_indices)
        return gather_outputs, top_indices

    # # (B, query_len, key_len)
    # Q_K_weight = tf.matmul(Q, K, transpose_b=True)
    # feature_map = tf.math.sigmoid(Q_K_weight) * key_masks[:, tf.newaxis, :]

    return outputs, feature_map


## https://github.com/reczoo/FuxiCTR/blob/main/model_zoo/multitask/PLE/src/PLE.py
def cgc_layer(inputs,
              num_shared_experts,
              num_specific_experts,
              num_tasks,
              target_names,
              expert_hidden_units,
              gate_hidden_units,
              hidden_activations,
              gate_hidden_activations,
              gate_output_activations,
              # net_dropout,
              use_norm,
              require_gate,
              final_flag):
    """
    x: list, len(x)==num_tasks+1 if flag_flag == False else num_tasks
    """
    x = inputs
    if __tf_version >= '2.0':
        param_initializer = tf.initializers.glorot_normal()
    else:
        param_initializer = tf.contrib.layers.xavier_initializer(uniform=False)
    bias_initializer = tf.zeros_initializer()
    specific_expert_outputs = []
    shared_expert_outputs = []
    # specific experts
    for i in range(num_tasks):
        target_n = target_names[i]
        task_expert_outputs = []
        with tf.variable_scope(f"specific_{target_n}"):
            for j in range(num_specific_experts):
                _out = ego.DenseTower(
                    name=f"specific_{target_n}_{i}_{j}",
                    output_dims=expert_hidden_units,
                    kernel_initializers=[param_initializer] * len(expert_hidden_units),
                    bias_initializers=[bias_initializer] * len(expert_hidden_units),
                    activations=[hidden_activations for _ in range(len(expert_hidden_units))],
                    norms=[use_norm for _ in range(len(expert_hidden_units))],
                    use_bias=True,
                )(x[i])
                task_expert_outputs.append(_out)
                # task_expert_outputs.append(self.specific_experts[i][j](x[i]))
            specific_expert_outputs.append(task_expert_outputs)
    # shared experts
    with tf.variable_scope(f"shared"):
        for i in range(num_shared_experts):
            _out = ego.DenseTower(
                name=f"shared_expert_{i}",
                output_dims=expert_hidden_units,
                kernel_initializers=[param_initializer] * len(expert_hidden_units),
                bias_initializers=[bias_initializer] * len(expert_hidden_units),
                activations=[hidden_activations for _ in range(len(expert_hidden_units))],
                norms=[use_norm for _ in range(len(expert_hidden_units))],
                use_bias=True,
            )(x[-1])
            shared_expert_outputs.append(_out)
        # shared_expert_outputs.append(self.shared_experts[i](x[-1]))
    # gate
    cgc_outputs = []
    gates = []
    for i in range(num_tasks if final_flag else num_tasks + 1):
        target_n = target_names[i] if i < num_tasks else "total"
        with tf.variable_scope(f"gate_{target_n}"):
            gate_hidden_sz = len(gate_hidden_units) + 1
            gate_output_dim = len(specific_expert_outputs[i] + shared_expert_outputs if i < num_tasks else shared_expert_outputs)
            print(i, target_n, gate_hidden_sz, gate_output_dim)
            if i < num_tasks:
                # for specific experts
                # gate_input: (?, num_specific_experts+num_shared_experts, dim)
                gate_input = tf.stack(shared_expert_outputs + specific_expert_outputs[i], axis=1)
                # gate = gate_activation(gate[i](x[i])) # (?, num_specific_experts+num_shared_experts)
            else:
                # for shared experts
                gate_input = tf.stack(shared_expert_outputs, axis=1) # (?, num_shared_experts, dim)
                # gate = gate_activation(gate[i](x[-1])) # (?, num_shared_experts)
            gate = ego.DenseTower(
                name=f"gate_{target_n}",
                output_dims=gate_hidden_units + [gate_output_dim],
                kernel_initializers=[param_initializer] * gate_hidden_sz,
                bias_initializers=[bias_initializer] * gate_hidden_sz,
                activations=[gate_hidden_activations for _ in range(gate_hidden_sz - 1)] + [gate_output_activations],
                norms=[use_norm for _ in range(gate_hidden_sz)],
                use_bias=True,
            )(x[i])

            # gates.append((f"{target_n}", tf.reduce_mean(gate, axis=0)))
            gates.append((f"{target_n}", gate))
            cgc_output = tf.reduce_sum(tf.expand_dims(gate, -1) * gate_input, axis=1) # (?, dim)
            cgc_outputs.append(cgc_output)
    if require_gate:
        return cgc_outputs, gates
    else:
        return cgc_outputs


def ple_layer(inputs,
              inputs_list,
              num_level,
              num_shared_experts,
              num_specific_experts,
              num_tasks,
              target_names,
              expert_hidden_units,
              gate_hidden_units,
              hidden_activations,
              gate_hidden_activations,
              gate_output_activations,
              use_norm):
    ple_gates = []
    if inputs_list is None:
        cgc_outputs = [inputs for _ in range(num_tasks + 1)]
    else:
        cgc_inputs = inputs_list
        assert len(cgc_inputs) == num_tasks + 1
    for i in range(num_level):
        final_flag = True if i == num_level - 1 else False
        cgc_outputs, cgc_gates = cgc_layer(inputs=cgc_inputs,
                                           num_shared_experts=num_shared_experts,
                                           num_specific_experts=num_specific_experts, num_tasks=num_tasks, target_names=target_names,
                                           expert_hidden_units=expert_hidden_units, gate_hidden_units=gate_hidden_units,
                                           hidden_activations=hidden_activations, gate_hidden_activations=gate_hidden_activations, gate_output_activations=gate_output_activations,
                                           use_norm=use_norm, require_gate=True, final_flag=final_flag)
        cgc_inputs = cgc_outputs
        ple_gates.append(cgc_gates)

    return cgc_outputs, ple_gates

def gatenet_layer(inputs,
                  gate_inputs,
                  gate_hidden_units,
                  gate_hidden_activations,
                  use_norm,
                  require_gate,
                  norm_type="ego",
                  name="",
                  ):

    if gate_inputs is None:
        x = inputs
    else:
        x = gate_inputs

    print(f"gatenet {x}")
    gate_output_dim = int(get_shape(inputs)[-1])
    print(f"gate_output_dim = {gate_output_dim}")
    gate_hidden_sz = len(gate_hidden_units) + 1
    if __tf_version >= '2.0':
        param_initializer = tf.initializers.glorot_normal()
    else:
        param_initializer = tf.contrib.layers.xavier_initializer(uniform=False)
    bias_initializer = tf.zeros_initializer()
    with tf.variable_scope(f"{name}_gatenet_layer"):
        if use_norm and norm_type == "ego":
            gates = ego.DenseTower(
                name=f"{name}_gatenet_mlp",
                output_dims=gate_hidden_units + [gate_output_dim],
                kernel_initializers=[param_initializer] * gate_hidden_sz,
                bias_initializers=[bias_initializer] * gate_hidden_sz,
                activations=[gate_hidden_activations for _ in range(gate_hidden_sz - 1)] + [tf.nn.sigmoid],
                norms=[use_norm for _ in range(gate_hidden_sz)],
                use_bias=True,
            )(x)
        else:
            gates = ego.DenseTower(
                name=f"{name}_gatenet_mlp",
                output_dims=gate_hidden_units + [gate_output_dim],
                kernel_initializers=[param_initializer] * gate_hidden_sz,
                bias_initializers=[bias_initializer] * gate_hidden_sz,
                activations=[gate_hidden_activations for _ in range(gate_hidden_sz - 1)] + [tf.nn.sigmoid],
                norms=[use_norm for _ in range(gate_hidden_sz)],
                use_bias=True,
            )(x)

        outputs = tf.multiply(gates*2, inputs, name=f"{name}_gate_multiply")
        if require_gate:
            return outputs, gates
        else:
            return outputs
