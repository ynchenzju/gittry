#!/usr/bin/env python
# -*- coding: utf-8 -*-
import tensorflow as tf
import ego
from numpy.ma.core import indices, masked

__tf_version = tf.__version__
if __tf_version >= '2.0':
    tf2 = tf
    tf = tf.compat.v1


def get_shape(inputs):
    dynamic_shape = tf.shape(inputs)
    static_shape = inputs.get_shape().as_list()
    shape = []
    for i, dim in enumerate(static_shape):
        shape.append(dim if dim is not None else dynamic_shape[i])
    return shape


def cosine_similarity(a, b):
    print(f"norm_a={a}, norm_b={b}")
    dot_product = tf.reduce_sum(tf.multiply(a, b), axis=-1)
    return dot_product

def simtier_bucket(queries, keys, mask, simtier_number=20, use_simtier=True, buckets=None, name="simtier_bucket"):
    '''
        queries:     [B, H]
        keys:        [B, T, H]
        keys_length: [B]
    '''
    with tf.variable_scope(f"{name}"):
        queries = tf.nn.l2_normalize(queries, axis=-1, epsilon=1e-6, name=f'q_l2_norm')
        keys = tf.nn.l2_normalize(keys, axis=-1, epsilon=1e-6, name=f'key_l2_norm')
        seq_len = keys.get_shape().as_list()[1]
        queries = tf.expand_dims(queries, axis=1)
        raw_weights = cosine_similarity(queries, keys) # (B, L)
        indices, sim_tier = None, None
        mask = tf.cast(mask, tf.float32)

        if isinstance(buckets, (list, tuple)) and len(buckets) > 0:
            N = len(buckets)
            buckets_tf = tf.constant([buckets], dtype=tf.float32) # [B]
            buckets_tf = tf.tile(buckets_tf, (tf.shape(raw_weights)[0], 1)) # [-1, N]
            weights = tf.reshape(raw_weights, [-1, seq_len]) # [-1, L]
            cmp = tf.greater_equal(tf.expand_dims(weights, axis=-1), tf.expand_dims(buckets_tf, axis=1)) # [-1, L, N]
            bucket_id = tf.reduce_sum(tf.cast(cmp, tf.int32), axis=-1) - 1 #[-1, L]
            indices = tf.cast(tf.clip_by_value(bucket_id, 0, N-1), tf.int32) # [-1, L]
            sim_weights = tf.one_hot(indices, depth=N, dtype=tf.float32) # [-1, L, N]
        else:
            if use_simtier:
                N = simtier_number[0] if isinstance(simtier_number, (list, tuple)) and len(simtier_number) == 1 else simtier_number
                indices = tf.reshape(tf.cast((raw_weights + 1) / 2 * N, dtype=tf.int32), (-1, seq_len)) # [-1, L]
                indices = tf.clip_by_value(indices, 0, N-1)
                sim_weights = tf.equal(tf.expand_dims(indices, axis=-1), tf.reshape(tf.range(0, N, 1), [1, 1, N])) # [-1, L, N]

        if mask is not None:
            sim_weights *= tf.expand_dims(mask, axis=-1)

        sim_tier = tf.reduce_sum(tf.cast(sim_weights, dtype=tf.float32), axis=1) / (tf.reduce_sum(mask, axis=-1, keepdims=True) + 0.0001)
    return raw_weights, indices, sim_tier


def dta_attention_module(query_id, keys_id, bins, bucket_N, mask=None, hidden_dim=None, softmax_with_tau=False, tau=1.0, name='dta_fusion'):
    with tf.variable_scope(name):
        H = keys_id.get_shape().as_list()[2]
        Q_H = query_id.get_shape().as_list()[1]
        if hidden_dim is None:
            hidden_dim = Q_H

        Wk = tf.get_variable("Wk", [H, hidden_dim])
        Wv = tf.get_variable("Wv", [H, hidden_dim])
        Wq = tf.get_variable("Wq", [Q_H, hidden_dim])

        Q = tf.expand_dims(tf.matmul(query_id, Wq), 1)
        K = tf.tensordot(keys_id, Wk, axes=[[2],[0]])
        V = tf.tensordot(keys_id, Wv, axes=[[2],[0]])

        E_table = tf.get_variable("DTA_bucket_" + name, [bucket_N, hidden_dim],initializer=tf.random_normal_initializer(),trainable=True)
        E = tf.nn.embedding_lookup(E_table, bins)
        K += E
        V += E

        Q = tf.nn.l2_normalize(Q,axis=-1)
        K_final = tf.nn.l2_normalize(K,axis=-1)

        scores = cosine_similarity(Q, K_final)
        if softmax_with_tau:
            scores = scores / tau

        mask_float = tf.cast(mask, tf.float32)
        padding = (1.0 - mask_float) * (-1e5)
        scores = scores + padding
        alpha = tf.nn.softmax(scores,axis=-1)
        dta_output = tf.squeeze(tf.matmul(tf.expand_dims(alpha, axis=1), V), axis=1)
    return dta_output

## https://github.com/zhougr1993/DeepInterestNetwork/blob/master/din/model_dice.py
def din_attention_mlp(queries, keys, keys_length, return_weight=False, use_l2_norm=True, qk_concat="default", output_dims=[80, 40, 1], name="din_layer_mlp"):
    '''
        queries:     [B, H]
        keys:        [B, T, H]
        keys_length: [B, 1]
    '''
    with tf.variable_scope(f"{name}"):
        if use_l2_norm:
            queries = tf.nn.l2_normalize(queries, axis=-1, epsilon=1e-6, name=f'q_l2_norm')
            keys = tf.nn.l2_normalize(keys, axis=-1, epsilon=1e-6, name=f'key_l2_norm')
        seq_len =  int(get_shape(keys)[1])
        queries = tf.expand_dims(queries, axis=1, name="q_expand_dims")
        queries = tf.tile(queries, [1, seq_len, 1], name="q_tile")
        if qk_concat == "default":
            din_all = tf.concat([queries, keys, queries-keys, queries*keys], axis=-1, name="q_k_concat")
        elif qk_concat == "qk":
            din_all = tf.concat([queries, keys], axis=-1, name="q_k_concat")
        elif qk_concat == "qk_i":
            din_all = tf.concat([ queries-keys, queries*keys], axis=-1, name="q_k_concat")
        else:
            raise RuntimeError

        param_initializer = tf.initializers.glorot_normal()
        bias_initializer = tf.zeros_initializer()

        d_layer_3_all = ego.DenseTower(name='f1_f2_f3_att',
                                       output_dims=output_dims,
                                       kernel_initializers=[param_initializer] * 3,
                                       bias_initializers=[bias_initializer] * 3,
                                       activations=[tf.nn.leaky_relu, tf.nn.leaky_relu, None],
                                       norms=[False, False, False],
                                       use_bias=True
                                       )(din_all)
        d_layer_3_all = tf.reshape(d_layer_3_all, [-1, 1, seq_len], name="logit_reshape")
        outputs = d_layer_3_all
        # Mask
        keys_length = tf.squeeze(keys_length, axis=1, name="key_sq")
        key_masks = tf.sequence_mask(keys_length, seq_len, name="key_mask")   # [B, T]
        key_masks = tf.expand_dims(key_masks, 1, name="key_expand_dims") # [B, 1, T]
        paddings = tf.ones_like(outputs) * (-2 ** 32 + 1)
        print("key_masks:", key_masks)
        print("outputs:", outputs)
        print("paddings:", paddings)
        outputs = tf.where(key_masks, outputs, paddings)  # [B, 1, T]

        # Scale
        # outputs = outputs / (keys.get_shape().as_list()[-1] ** 0.5)

        # Activation
        raw_weights = tf.nn.softmax(outputs, axis=-1, name="w_softmax")  # [B, 1, T]
        print("raw_weights:", raw_weights)
        # Weighted sum
        outputs = tf.matmul(raw_weights, keys)  # [B, 1, H]
        if return_weight:
            return tf.squeeze(outputs, axis=1, name="output_sq"), tf.squeeze(raw_weights, axis=1, name="weight_sq")
        return tf.squeeze(outputs, axis=1, name="output_sq")
