#!/usr/bin/env python
# -*- coding: utf-8 -*-


import tensorflow as tf
import ego
from ego import DenseTower
from ego import replace_gradient
from tensorflow.compiler.tf2xla.python.xla import shift_left

from utils.fg_tool import FGConf
from models.base_model import BaseModel
from utils.ops import ignore_grad, multihead_target_attention_auto_fold
from itertools import chain
from llm_utils.din import din_attention_cos
from tensorflow.python.keras.layers import LayerNormalization

def cross_entropy_loss(label, pred, epsilon = 1e-12):
    return tf.multiply(label, -tf.math.log(pred + epsilon)) + tf.multiply(tf.subtract(1.0, label), -tf.math.log(tf.subtract(1.0, pred) + epsilon))

def swish(x):
    return x * tf.nn.sigmoid(x)

def swiglu(x, out_dim, name, param_initializer):
    h = DenseTower(name=name,
                   output_dims=[out_dim * 2],
                   kernel_initializers=[param_initializer],
                   bias_initializers=[tf.zeros_initializer()],
                   activations=[None], norms=[False])(x)
    val, gate = tf.split(h, 2, axis=-1)
    return val * swish(gate)

def mean_square_loss(emb, target, alpha=1.0):
    mse = alpha*tf.reduce_sum(tf.square(target - emb), axis=-1, keepdims=True)
    return mse

def cosine_similarity(emb, target):
    cos_score = tf.reduce_sum(tf.multiply(emb, target), axis=-1, keepdims=True)
    return cos_score

# pred_x -> teacher, pred_y -> student
def distillation_loss(pred_x, pred_y, epsilon = 1e-12):
    return tf.multiply(pred_x, -tf.math.log(pred_y + epsilon)) + tf.multiply(tf.subtract(1.0, pred_x), -tf.math.log(tf.subtract(1.0, pred_y) + epsilon))

def mse_loss(pred_x, pred_y, epsilon = 1e-12):
    return (pred_x - pred_y) ** 2

class BaseModelRR(BaseModel):
    def __init__(self, fgconf: FGConf, mcyaml, *args, **kwargs):
        super().__init__(fgconf, mcyaml, *args, **kwargs)
        self.groups = [k for k in self.mcconf.keys()]
        self._phases = [{"name": "p1"}]
        for phase in self._phases:
            phase["block_layer_dict"] = {}
        self._attention_seq_input = []
        self.cur_phase=None
        self.clipnorm = kwargs.get('clipnorm', False)
        self.user_group_names = ["user", "user_session"]
        self.context_group_names = ["context"]
        self.target_group_names = ["target_item"] # cannot include recall
        self.recall_group_names = ["recall"]
        self.feature_indexes = {
            "user": 0, "ub_click": 9, "ub_order": 10, "ub_upstream": 11,
            "target_item": 1,
            "context": 2,
            "recall": 3,
            "cross_features": 4,
            "user_madnn": 5,
            "target_item_query_pretrain": 6,
            "ub_clk_pretrain_seq": 7,
            "ub_order_pretrain_seq": 8
        }
        self.feature_group_indexes = {
            "user_fea": 0, "item_fea": 1, "context_fea": 2, "recall_fea": 3,
            "interaction": 4,
            "user_madnn": 5,
            "item_pretrain": 6,
            "ub_click_pretrain": 7,
            "ub_order_pretrain": 8,
            "ub_click": 9, 'ub_order': 10, "ub_upstream": 11
        }
        self.sub_targets = {
            "click": [],
            "atc": [],
            "order": ["order_ads_oa", "paid_order"]
        }
        self.user_token_groups = [
            ["user_fea"],
            ["ub_click"],
            ["ub_order"],
            ["ub_upstream"],
            ["context_fea"],
            ["ub_click_pretrain"],
            ["ub_order_pretrain"]
        ]
        self.item_token_groups = [            
            ["item_fea", "recall_fea"],
            ["item_pretrain"]
        ]
        self.user_token_layers = 2
        self.item_token_layers = 2
        self.token_dim = 256
        self.split_group_num = 16
        self.label_index = {"click": 1, "cart": 3, "order": 5, "order_ads_oa": 6, "paid_order": 7}
        self.group_fea = []
        self.tower_dim = 64
        self.llm = 129
        self.assign_slot_id = [8002]
        self.tb = True
        self.scalar_tensor = []
        self.madnn_idx = 8 * 2
        self.madnn_loss, self.madnn_flag = None, False
        self.madnn_label, self.madnn_weight = None, None
        self.tokens = {}
        
    def build_inputs(self):
        super().build_inputs()
        assert len(self.used_slot_map) == len(self.sparse_input)
        self.sparse_feature_map = {
            list(self.used_slot_map.values())[i]: self.sparse_input[i]
            for i in range(len(self.used_slot_map))
        }
        for conf in chain(*self.mcconf.values()):
            if conf.get("back_propagation", True) == False:
                if conf["aggregator"] in ("tile", "tile_nf"):
                    slot = ignore_grad(self.sparse_feature_map[conf["name"]][0])
                    self.sparse_feature_map[conf["name"]] = (slot, self.sparse_feature_map[conf["name"]][1])
                else:
                    slot = ignore_grad(self.sparse_feature_map[conf["name"]])
                    self.sparse_feature_map[conf["name"]] = slot
                print("build_inputs: ignore grad for slot {}".format(conf["name"]))

    def build_group_input(self):
        self.group_inputs = {}
        self.sequence_group_inputs = {}
        self.sequence_lengths = {}

        for group_name in self.groups:
            tensor_list = [
                self.sparse_feature_map[conf["name"]]
                for conf in self.mcconf[group_name]
            ]
            if group_name.endswith("seq"):
                sequence_max_length_list = [
                    x[0].get_shape().as_list()[1] for x in tensor_list
                ]
                assert all(
                    [
                        length == sequence_max_length_list[0]
                        for length in sequence_max_length_list
                    ]
                )
                print(
                    "build_group_input: got sequence: {} with feature nums: {} and length: {}".format(
                        group_name, len(tensor_list), sequence_max_length_list[0]
                    )
                )
                self.sequence_group_inputs[group_name] = tf.concat(
                    [x[0] for x in tensor_list], axis=-1
                )
                sequence_lengths = tf.concat([x[1] for x in tensor_list], axis=-1)
                self.sequence_lengths[group_name] = tf.reduce_max(
                    sequence_lengths, axis=-1
                )
            else:
                print(
                    "build_group_input: got group: {} with feature nums: {}".format(
                        group_name, len(tensor_list)
                    )
                )
                res = tf.concat(tensor_list, axis=-1)
                self.group_inputs[group_name] = res

        if self.assign_slot_id:
            assign_slot = ego.get_slots(
                name="assign_slot_emb",
                slots=self.assign_slot_id,
                dims=[self.tower_dim] * len(self.assign_slot_id),
                poolings=[ego.Pooling.SUM] * len(self.assign_slot_id),
                is_assign_slot=True,
                feature_type=ego.FeatureType.ITEM,
            )
            self.assign_slot_embs = tf.concat(assign_slot, axis=-1)

    def build_sequence_mask(self):
        self.sequence_masks = {}
        for name in self.sequence_group_inputs.keys():
            lengths = self.sequence_lengths[name]
            max_lengths = self.sequence_group_inputs[name].get_shape().as_list()[1]
            length_mask = tf.sequence_mask(
                lengths, maxlen=max_lengths, dtype=tf.float32
            )
            self.sequence_masks[name] = length_mask

    def gate_layer(self, norm_input, control, slot_dims, param_initializer, ratio, name, phase):
        input_dim = norm_input.get_shape().as_list()[-1]
        slot_gate = DenseTower(name='Neural_Gate_{}_{}'.format(phase, name),
                               output_dims=[int(input_dim * ratio), len(slot_dims)],
                               kernel_initializers=[param_initializer] * 2,
                               bias_initializers=[tf.zeros_initializer()] * 2,
                               activations=[swish, swish],
                               norms=[False, False])(control)
        slot_gate = tf.split(slot_gate, len(slot_dims), 1)
        norm_input_slices = tf.split(norm_input,  slot_dims, 1)
        return tf.concat(list(map(lambda x, y : x * y, norm_input_slices, slot_gate)), 1)

    def norm_embs(self, fea_keys, op_name, use_l2_norm, use_bn):
        feats = []
        for k in fea_keys:
            idx = self.feature_group_indexes[k]
            if use_l2_norm:
                feat = tf.nn.l2_normalize(self.group_fea[idx], axis=-1, name=f"{k}_l2_norm")
            elif use_bn:
                feat = tf.clip_by_value(ego.Normalization("Batch_Norm_".format(op_name))(self.group_fea[idx]), -5, 5)
            else:
                feat = self.group_fea[idx]
            print(f"[get_item_embs] `{self.feature_group_indexes[k], k}`")
            feats.append(feat)
        return tf.concat(feats, axis=-1, name=op_name + "_concat")

    def norm_seq_embs(self, fea_keys, op_name, use_l2_norm):
        feats = []
        for k in fea_keys:
            idx = self.feature_group_indexes[k]
            if use_l2_norm:
                feat = tf.reduce_mean(tf.nn.l2_normalize(self.group_fea[idx], axis=-1, name=f"{k}_l2_norm"), axis=1, name='reduce_mean')
            else:
                feat = tf.reduce_mean(self.group_fea[idx], axis=1, name='reduce_mean')
            print(f"[get_item_embs] `{self.feature_group_indexes[k], k}` with avg pooling")
            feats.append(feat)
        return tf.concat(feats, axis=-1, name=op_name + "_concat")

    def get_item_attention_embs(self, item_query_key=None, seq_keys=["ub_clk_seq", "ub_cart_seq", "ub_order_seq"], op_name="get_item_attention_embs", seq_len=50):
        feats = []
        att_weights = []
        item_query_emb = self.group_fea[self.feature_group_indexes[item_query_key]]
        for k in seq_keys:
            keys = self.group_fea[self.feature_group_indexes[k]]
            print(f"[{op_name}, {self.feature_group_indexes[k]}, {k}]", keys.get_shape().as_list(), seq_len)
            feat, cos_sim, simtier_score = din_attention_cos(queries=item_query_emb, keys=keys, keys_length=seq_len, return_weight=True, use_simtier=True, simtier_number=100, use_agg=False, name=f"{k}_din_layer_cos")
            att_w = cos_sim
            # print(f"[{op_name}]", feat, cos_sim, simtier_score, att_w)
            feats.append(cos_sim) # T
            feats.append(simtier_score) # N
            att_weights.append(att_w)
        return tf.concat(feats, axis=-1, name=op_name + "_concat"), att_weights

    def get_cos_sim(self, emb_a, emb_b, op_name="get_cos_sim", use_l2_norm=False):
        if use_l2_norm:
            emb_a_norm = tf.nn.l2_normalize(emb_a, axis=-1, name=f"{op_name}_seq_a_l2_norm")
            emb_b_norm = tf.nn.l2_normalize(emb_b, axis=-1, name=f"{op_name}_seq_b_l2_norm")
            dot_product = tf.reduce_sum(tf.multiply(emb_a_norm, emb_b_norm), axis=-1)
        else:
            dot_product = tf.reduce_sum(tf.multiply(emb_a, emb_b), axis=-1)
        return dot_product

    def madnn_block(self, fea_names, madnn_names, dims, op_name, tower_out, use_tower=False):
        madnn_feas =  self.norm_embs(madnn_names, "get_madnn_" + op_name, False, False)
        pos_emb, neg_emb = tf.nn.l2_normalize(madnn_feas[:, : self.tower_dim], axis=-1), tf.nn.l2_normalize(madnn_feas[:, self.tower_dim: self.tower_dim*2], axis=-1)
        if use_tower:
            target_emb = tower_out
        else:
            param_initializer = tf.truncated_normal_initializer(stddev=0.001, dtype=tf.float32)
            orig_features = self.norm_embs(fea_names, "get_original_" + op_name, False, True)
            target_emb = ego.DenseTower(
                name='item_tower_' + op_name,
                output_dims=dims,
                kernel_initializers=[param_initializer] * len(dims),
                bias_initializers=[tf.zeros_initializer()] * len(dims),
                activations=[tf.nn.leaky_relu] * (len(dims) - 1) + [None],
                norms=False,
                use_bias=True
            )(orig_features)

        target_emb_ = tf.stop_gradient(tf.nn.l2_normalize(target_emb, axis=-1))
        label = tf.broadcast_to(self.madnn_label, tf.shape(pos_emb))
        weight = tf.broadcast_to(self.madnn_weight, tf.shape(pos_emb))
        madnn_emb = tf.where(label > 0, pos_emb, neg_emb)
        madnn_emb = tf.where(weight > 0, madnn_emb, target_emb_)
        mse_loss = mean_square_loss(madnn_emb, target_emb_, 0.05)
        print("op name {}: dim {}".format(op_name, mse_loss.get_shape().as_list()))
        if not self.madnn_flag:
            self.madnn_loss = mse_loss
            self.madnn_flag = True
        else:
            self.madnn_loss += mse_loss
        if self.tb:
            self.scalar_tensor.append(tf.identity(mse_loss, name='loss_'+ op_name ))
            zero_rate = tf.reduce_mean(tf.where(tf.abs(madnn_emb) < 0.0001, tf.ones_like(madnn_emb), tf.zeros_like(madnn_emb)))
            self.scalar_tensor.append(tf.identity(zero_rate, name='madnn_emb_zero_rate_'+ op_name))
        return tf.concat([madnn_feas, target_emb], axis=-1), cosine_similarity(madnn_emb, target_emb_)
    
    def tokenizer(self, tokens, tk_dim, layer_idx, split_group_num=None, name_prefix=''):
        n = len(tokens)
        if layer_idx == 0:
            tokens = [
                DenseTower(name=f'{name_prefix}token_proj_{layer_idx}_{i}',
                           output_dims=[tk_dim],
                           kernel_initializers=[self.param_initializer],
                           bias_initializers=[tf.zeros_initializer()],
                           activations=[None], norms=[False])(tk)
                for i, tk in enumerate(tokens)
            ]
            tokens_stacked = LayerNormalization(name=f'{name_prefix}token_proj_norm_{layer_idx}')(tf.stack(tokens, axis=1))
        else:
            tokens_stacked = tf.stack(tokens, axis=1)  # [B, n, tk_dim]

        sg = split_group_num if split_group_num is not None else n
        mixed_tk_dim = n * tk_dim // sg  # dim per mixed token: [B, sg, mixed_tk_dim]

        # 1. split + mix: [B, n, tk_dim] -> [B, n, sg, tk_dim//sg] -> [B, sg, n, tk_dim//sg] -> [B, sg, mixed_tk_dim]
        tokens_mixed = tf.reshape(
            tf.transpose(tf.reshape(tokens_stacked, [-1, n, sg, tk_dim // sg]), perm=[0, 2, 1, 3]),
            [-1, sg, mixed_tk_dim]
        )

        # 2. SwiGLU + norm (residual from tokens_mixed)
        mix_ffn = tf.stack([
            swiglu(tk, mixed_tk_dim, f'{name_prefix}token_mix_ffm_{layer_idx}_{i}', self.param_initializer)
            for i, tk in enumerate(tf.unstack(tokens_mixed, axis=1))
        ], axis=1)
        mix_out = LayerNormalization(name=f'{name_prefix}token_mix_norm_{layer_idx}')(mix_ffn + tokens_mixed)

        # 3. revert: [B, sg, mixed_tk_dim] -> [B, sg, n, tk_dim//sg] -> [B, n, sg, tk_dim//sg] -> [B, n, tk_dim]
        tokens_reverted = tf.reshape(
            tf.transpose(tf.reshape(mix_out, [-1, sg, n, tk_dim // sg]), perm=[0, 2, 1, 3]),
            [-1, n, tk_dim]
        )

        # 4. SwiGLU + norm (residual from tokens_stacked)
        outputs = tf.stack([
            swiglu(tk, tk_dim, f'{name_prefix}token_ffm_{layer_idx}_{i}', self.param_initializer)
            for i, tk in enumerate(tf.unstack(tokens_reverted, axis=1))
        ], axis=1)
        outputs_final = LayerNormalization(name=f'{name_prefix}token_ffm_mix_{layer_idx}')(outputs + tokens_stacked)

        return tf.unstack(outputs_final, axis=1)

    def build_network_inputs(self, i):
        feature_group_len = len(self.feature_group_indexes)
        used_cols = [[] for _ in range(feature_group_len)]
        used_names = [[] for _ in range(feature_group_len)]
        used_len = [[] for _ in range(feature_group_len)]
        layers = self._phases[i]["block_layer_dict"]
        for name, block in chain(self.group_inputs.items(), self.sequence_group_inputs.items(), layers.items()):
            shape = block.get_shape().as_list()
            print(
                "phrase {} build_networks: get block input {} with shape {}, group index {}".format(i, name, shape, self.feature_indexes[name])
            )
            used_cols[self.feature_indexes[name]].append(block)
            used_names[self.feature_indexes[name]].append([name, shape])
            used_len[self.feature_indexes[name]].append(shape[-1])

        for fea_name, idx in self.feature_group_indexes.items():
            print("phrase {} for {}, feature names: {}, feature total length: {}".format(i, fea_name, used_names[idx], used_len[idx]))
            self.group_fea.append(tf.concat(used_cols[idx], axis=-1) if used_cols[idx] else [])
        return used_len

    def build_esmm(self):
        param_initializer = tf.truncated_normal_initializer(stddev=0.001, dtype=tf.float32)
        ego.config_dump_tensor(with_sample_id=False)
        target_names = "click,atc,order".split(",")
        scalar_tensor = []

        nn_outputs, nn_outputs_t = [[]], [[]]
        loss, loss_t = [[]], [[]]
        labels, labels_t= [[]], [[]]
        loss_weights, loss_weights_t = [[]], [[]]

        for phase in range(len(self._phases)):
            used_dims = self.build_network_inputs(phase)
            item_vec =  self.norm_embs(["item_fea", "item_pretrain"], 'get_item_embs', False, True)
            item_vec = ego.DenseTower(
                name='item_tower',
                output_dims=[128, 64],
                kernel_initializers=[param_initializer] * 2,
                bias_initializers=[tf.zeros_initializer()] * 2,
                activations=[tf.nn.leaky_relu, None],
                norms=False,
                use_bias=True
            )(item_vec)
            cache_emb = self.assign_slot_embs[..., 0: self.tower_dim]
            if ego.is_training_mode():
                item_emb = replace_gradient(item_vec, cache_emb, item_vec)
            else:
                item_emb = cache_emb
            abs_val = tf.sqrt(tf.reduce_sum(abs(item_emb ** 2), axis=-1, keepdims=True))
            print("phrase {} abs val: dim {}".format(phase, abs_val.get_shape().as_list()))


            # ----------------------------------------SIM TIER--------------------------------------------------
            simtier_score, simtier_att_w = self.get_item_attention_embs("item_pretrain", ["ub_click_pretrain"], "get_item_attention_embs_pretrain")
            if self.tb:
                for idx, ws in enumerate(simtier_att_w):
                    zero_rate = tf.reduce_mean(tf.where(tf.abs(simtier_att_w[idx]) < 0.001, tf.ones_like(simtier_att_w[idx]), tf.zeros_like(simtier_att_w[idx])))
                    self.scalar_tensor.append(tf.identity(zero_rate, name='pretrain_attn_zero_'+ str(idx)))
            # ----------------------------------------SIM TIER--------------------------------------------------

            # ----------------------------------------  MADNN  --------------------------------------------------
            tower_outputs, sim_scores = [], []
            self.madnn_label, self.madnn_weight = ego.get_label_weight(target_name='label_{}'.format(self.madnn_idx), label_idx=self.madnn_idx)
            for fea_names, madnn_names, op_name in [(["user_fea"], ["user_madnn"], "user")]:
                tmp_out, sim_score = self.madnn_block(fea_names, madnn_names, [self.tower_dim*2, self.tower_dim], op_name, None, False)
                tower_outputs.append(tmp_out)
                sim_scores.append(sim_score)
            # ----------------------------------------  MADNN  --------------------------------------------------

            # ----------------------------------------RankMixer--------------------------------------------------
            # Phase 1: user-only tokens
            user_tokens = []
            for idx, token_group in enumerate(self.user_token_groups):
                if 'ub_click_pretrain' in token_group or 'ub_order_pretrain' in token_group:
                    orig_fea = self.norm_embs(token_group, 'get_user_embs_' + str(idx), False, False)
                    user_tokens.append(tf.reduce_mean(orig_fea, axis=1))
                else:
                    orig_fea = self.norm_embs(token_group, 'get_user_embs_' + str(idx), False, False)
                    user_tokens.append(orig_fea)
                print(token_group, '| get user features: ', orig_fea.get_shape())

            for idx in range(self.user_token_layers):
                print('user layer ' + str(idx))
                user_tokens = self.tokenizer(user_tokens, self.token_dim, idx, self.split_group_num, name_prefix='user_')

            # Phase 2: user + item combined tokens
            item_tokens = []
            for idx, token_group in enumerate(self.item_token_groups):
                if 'item_fea' in token_group:
                    orig_fea = self.norm_embs(["recall_fea"], 'get_item_embs_' + str(idx), False, False)
                    item_tokens.append(tf.concat([orig_fea, item_emb], axis=-1))
                else:
                    orig_fea = self.norm_embs(token_group, 'get_item_embs_' + str(idx), False, False)
                    item_tokens.append(orig_fea)
                print(token_group, '| get item features: ', orig_fea.get_shape())

            tokens = user_tokens + item_tokens
            for idx in range(self.item_token_layers):
                print('combined layer ' + str(idx))
                tokens = self.tokenizer(tokens, self.token_dim, idx, self.split_group_num, name_prefix='combined_')
            # ----------------------------------------RankMixer--------------------------------------------------

            # ------------------------------------- Concat ------------------------------------
            user_fea = self.norm_embs(["user_fea", "ub_click", "ub_order", "ub_upstream"], 'get_original_embs_user', False, True)
            context_fea = self.norm_embs(["context_fea"], 'get_original_embs_context', False, True)
            recall_fea = self.norm_embs(["recall_fea"], 'get_original_embs_recall', False, True)
            basic_feas = tf.concat([user_fea, context_fea, recall_fea], axis=-1)
            # basic_feas = self.neural_gate_layer(basic_feas_, basic_feas_, param_initializer, 0.25, 'basic_fea', phase)
            # ------------------------------------ Concat -----------------------------------

            student_shared = tf.concat(tokens + [item_emb, basic_feas, simtier_score] + tower_outputs, axis=-1)

            print(f"simtier_score", tokens[0].get_shape(),
                  "tower_outputs", tower_outputs[0].get_shape(),
                  "share_bottom", student_shared.get_shape())


            if ego.is_training_mode():
                raw_teacher_input = []
                for fea_name in ["user_fea", "item_fea", "context_fea", "recall_fea", 'interaction']:
                    raw_teacher_input.append(self.group_fea[self.feature_group_indexes[fea_name]])
                interaction_fea = tf.clip_by_value(ego.Normalization("Share_Bottom_{}_{}/input_norm".format(phase, 'interaction'))(tf.concat(raw_teacher_input, axis=-1)), -5, 5)
                print("phrase {} teacher shared input: dim {}".format(phase, interaction_fea.get_shape()))
                interaction_dim = used_dims[0] + used_dims[1] + used_dims[2] + used_dims[3] + used_dims[4]
                teacher_shared = self.gate_layer(interaction_fea, interaction_fea, interaction_dim,
                                                 param_initializer, 0.25, 'teacher_gate', phase)

            for idx, target in enumerate(target_names):
                pred_t = None
                if ego.is_training_mode():
                    label_idx = (idx * 2) * 2 # 0, 2, 4
                    ns = 'p{}_{}_t'.format(phase, target)
                    pred_t = DenseTower(name='p{}_{}_t'.format(phase,target),
                                        output_dims=[512, 256, 128, 1],
                                        kernel_initializers=[param_initializer] * 4,
                                        bias_initializers=[tf.zeros_initializer()] * 4,
                                        activations=[tf.nn.relu, tf.nn.relu, tf.nn.relu, tf.nn.sigmoid],
                                        norms=False)(teacher_shared)
                    nn_outputs_t[phase].append(tf.identity(pred_t, ns))
                    label_t, weight_t = ego.get_label_weight(target_name='label_{}_{}'.format(phase,label_idx), label_idx=label_idx)
                    labels_t[phase].append(label_t)
                    loss_weights_t[phase].append(weight_t)
                    loss_t[phase].append(cross_entropy_loss(label_t, pred_t))

                if len(self.sub_targets[target]) == 0:
                    label_idx = (idx * 2 + 1) * 2
                    label_s, weight_s = ego.get_label_weight(target_name='label_{}_{}'.format(phase,label_idx), label_idx=label_idx)
                    labels[phase].append(label_s)
                    loss_weights[phase].append(weight_s)
                    ns = 'p{}_{}_s'.format(phase, target)
                    print("target {}: index {}".format(ns, label_idx))
                    pred_s = DenseTower(name='p{}_{}_s'.format(phase,target),
                                        output_dims=[256, 64, 1],
                                        kernel_initializers=[param_initializer] * 3,
                                        bias_initializers=[tf.zeros_initializer()] * 3,
                                        activations=[tf.nn.relu, tf.nn.relu, tf.nn.sigmoid],
                                        norms=False)(student_shared)
                    nn_outputs[phase].append(tf.identity(pred_s, ns))
                    if ego.is_training_mode():
                        pred_t_ = tf.stop_gradient(pred_t)
                        loss[phase].append(tf.add(cross_entropy_loss(label_s, pred_s), 5 * mse_loss(pred_t_, pred_s)))
                    else:
                        loss[phase].append(cross_entropy_loss(label_s, pred_s))
                else:
                    label_idx = (idx * 2 + 1) * 2
                    label_s, weight_s = ego.get_label_weight(target_name='label_{}_{}'.format(phase,label_idx), label_idx=label_idx)
                    labels[phase].append(label_s)
                    loss_weights[phase].append(weight_s)
                    ns = 'p{}_{}_s'.format(phase, target)
                    print("target {}: index {}".format(ns, label_idx))
                    pred_s_mid = DenseTower(name='p{}_{}_mid_s'.format(phase,target),
                                            output_dims=[256, 64],
                                            kernel_initializers=[param_initializer] * 2,
                                            bias_initializers=[tf.zeros_initializer()] * 2,
                                            activations=[tf.nn.relu, None],
                                            norms=False)(student_shared)
                    pred_s = DenseTower(name='p{}_{}_s'.format(phase, target),
                                        output_dims=[64, 1],
                                        kernel_initializers=[param_initializer] * 2,
                                        bias_initializers=[tf.zeros_initializer()] * 2,
                                        activations=[tf.nn.relu, tf.nn.sigmoid],
                                        norms=False)(pred_s_mid)
                    nn_outputs[phase].append(tf.identity(pred_s, ns))
                    if ego.is_training_mode():
                        pred_t_ = tf.stop_gradient(pred_t)
                        loss[phase].append(tf.add(cross_entropy_loss(label_s, pred_s), 5 * mse_loss(pred_t_, pred_s)))
                    else:
                        loss[phase].append(cross_entropy_loss(label_s, pred_s))

                    for sub_target in self.sub_targets[target]:
                        label_idx = self.label_index[sub_target] * 2
                        label_sub, weight_sub = ego.get_label_weight(target_name='label_{}_{}'.format(phase,label_idx), label_idx=label_idx)
                        labels[phase].append(label_sub)
                        loss_weights[phase].append(weight_sub)
                        ns = 'p{}_{}_s'.format(phase, sub_target)
                        print("target {}: index {}".format(ns, label_idx))
                        pred_s_sub = DenseTower(name='p{}_{}_s'.format(phase,sub_target),
                                                output_dims=[64, 1],
                                                kernel_initializers=[param_initializer] * 2,
                                                bias_initializers=[tf.zeros_initializer()] * 2,
                                                activations=[tf.nn.relu, tf.nn.sigmoid],
                                                norms=False)(pred_s_mid)
                        nn_outputs[phase].append(tf.identity(pred_s_sub, ns))
                        loss[phase].append(cross_entropy_loss(label_sub, pred_s_sub))

                if ego.is_training_mode() and self.tb:
                    with tf.variable_scope(target):
                        loss_s_tb = tf.reduce_mean(cross_entropy_loss(label_s, pred_s), name = 'loss_s_' + target)
                        loss_t_tb = tf.reduce_mean(cross_entropy_loss(label_t, pred_t), name = 'loss_t_' + target)
                        loss_d_tb = tf.reduce_mean(mse_loss(pred_t, pred_s), name = 'loss_d_' + target)
                        self.scalar_tensor.extend([loss_s_tb, loss_t_tb, loss_d_tb])
                        print("*" * 82)
                        print("tensor boards shape {}, {}".format(len(self.scalar_tensor), self.scalar_tensor[0].get_shape()))
                        print("*" * 82)

        nn_outputs[phase].append(abs_val)
        madnn_score = tf.nn.sigmoid(tf.reduce_sum(tf.concat(sim_scores, axis=-1), axis=-1, keepdims=True))
        if ego.is_training_mode():
            self._phases[0]['scalar_tensor'] = scalar_tensor
            self._phases[0]["losses_t"] = [loss_t[0][0], loss_t[0][1], loss_t[0][2]]
            self._phases[0]["loss_weights_t"] = [loss_weights_t[0][0], loss_weights_t[0][1], loss_weights_t[0][2]]
            self._phases[0]["target_names_t"] = ['p0_click_t', 'p0_atc_t', 'p0_order_t']
            self._phases[0]["targets_t"] = [nn_outputs_t[0][0], nn_outputs_t[0][1], nn_outputs_t[0][2]]
            self._phases[0]["labels_t"] = [labels_t[0][0], labels_t[0][1], labels_t[0][2]]

            self._phases[0]["losses"] = [loss[0][0], loss[0][1], loss[0][2],
                                         loss[0][3], loss[0][4], self.madnn_loss]
            self._phases[0]["loss_weights"] = [loss_weights[0][0], loss_weights[0][1], loss_weights[0][2],
                                               loss_weights[0][3], loss_weights[0][4], self.madnn_weight]
            self._phases[0]["target_names"] = ['p0_click', 'p0_atc', 'p0_order',
                                               'p0_order_ads_oa', 'p0_paid_order', 'p0_madnn']
            self._phases[0]["targets"] = [nn_outputs[0][0], nn_outputs[0][1], nn_outputs[0][2],
                                          nn_outputs[0][3], nn_outputs[0][4], madnn_score]
            self._phases[0]["labels"] = [labels[0][0], labels[0][1], labels[0][2],
                                         labels[0][3], labels[0][4], self.madnn_label]
            self._phases[0]['scalar_tensor'] = self.scalar_tensor

            self._phases[0]["online_target_names"] = ["p0_click", "p0_atc", "p0_order", "p0_order_ads_oa", "p0_paid_order",
                                                      "p0_click_t", "p0_atc_t", "p0_order_t"]
            self._phases[0]["online_targets"] = [nn_outputs[0][0], nn_outputs[0][1], nn_outputs[0][2], nn_outputs[0][3], nn_outputs[0][4],
                                                 nn_outputs_t[0][0], nn_outputs_t[0][1], nn_outputs_t[0][2]]
            self._phases[0]["online_labels"] = [labels[0][0], labels[0][1], labels[0][2], labels[0][3], labels[0][4],
                                                labels_t[0][0], labels_t[0][1], labels_t[0][2]]
            self._phases[0]["online_weights"] = [loss_weights[0][0], loss_weights[0][1], loss_weights[0][2], loss_weights[0][3], loss_weights[0][4],
                                                 loss_weights_t[0][0], loss_weights_t[0][1], loss_weights_t[0][2]]

        else:
            self._phases[0]["losses"] = [loss[0][0], loss[0][1], loss[0][2],
                                         loss[0][3], loss[0][4], loss[0][0]]
            self._phases[0]["loss_weights"] = [loss_weights[0][0], loss_weights[0][1], loss_weights[0][2],
                                               loss_weights[0][3], loss_weights[0][4], loss_weights[0][0]]
            self._phases[0]["target_names"] = ['p0_click', 'p0_atc', 'p0_order',
                                               'p0_order_ads_oa', 'p0_paid_order', 'cache_vec']
            self._phases[0]["targets"] = [nn_outputs[0][0], nn_outputs[0][1], nn_outputs[0][2],
                                          nn_outputs[0][3], nn_outputs[0][4], nn_outputs[0][-1]]
            self._phases[0]["labels"] = [labels[0][0], labels[0][1], labels[0][2],
                                         labels[0][3], labels[0][4], labels[0][0]]

    def build_loss(self):
        for phase in self._phases:
            phase_loss = 0.0
            phase_loss_t = 0.0
            for i in range(len(phase["labels"])):
                phase_loss += tf.reduce_sum(phase["losses"][i] * phase["loss_weights"][i])
                if ego.is_training_mode() and i < len(phase["losses_t"]):
                    phase_loss_t += tf.reduce_sum(phase["losses_t"][i] * phase["loss_weights_t"][i])

            phase["phase_loss"] = -phase_loss
            phase["phase_loss_t"] = -phase_loss_t

    def format_ego_targets(self):
        for p in self._phases:
            if ego.is_training_mode():
                for i in range(len(p["target_names_t"])):
                    ego.Target(
                        p["target_names_t"][i],
                        tf.identity(p["targets_t"][i], p["target_names_t"][i]),
                        p["labels_t"][i], p["loss_weights_t"][i], p["losses_t"][i], ego.MetricType.GAUC
                    )
                for i in range(len(p["target_names"])):
                    ego.Target(
                        p["target_names"][i],
                        tf.identity(p["targets"][i], p["target_names"][i]),
                        p["labels"][i], p["loss_weights"][i], p["losses"][i], ego.MetricType.GAUC
                    )
                if "online_target_names" in p:
                    for i in range(len(p["online_target_names"])):
                        online_target_names = p["online_target_names"][i]
                        if online_target_names not in (p["target_names_t"] + p["target_names"]):
                            ego.Target(p["online_target_names"][i],
                                       tf.identity(p["online_targets"][i], p["online_target_names"][i]),
                                       p["online_labels"][i], p["online_weights"][i], None, ego.MetricType.GAUC)
            else:
                for i in range(len(p["target_names"])):
                    ego.Target(
                        p["target_names"][i],
                        tf.identity(p["targets"][i], p["target_names"][i]),
                        p["labels"][i], p["loss_weights"][i], None, None
                    )

    def build_graph(self):
        self.build_inputs()
        self.build_group_input()
        self.build_labels()
        self.build_sequence_mask()
        with tf.variable_scope("model", initializer=self.param_initializer, regularizer=self.param_regularizer):
            self.build_esmm()
        self.build_loss()
        self.format_ego_targets()
        self.print_total_params()
        return self._phases
