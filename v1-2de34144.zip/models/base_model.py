#!/usr/bin/env python
# -*- coding: utf-8 -*-


import tensorflow as tf
tf.compat.v1.disable_eager_execution()


import numpy as np
import ego
from ego import DenseTower
# import ego.layers as L

from utils.fg_tool import FGConf, ModelColumnUtil
from utils.tools import convert_pooling
from itertools import chain, zip_longest
from collections import OrderedDict


class BaseModel:
    def __init__(self, fgconf: FGConf, mcyaml, *args, **kwargs):
        # confs
        self.mcconf = mcyaml
        self.fgconf = fgconf
        self.mcutil = ModelColumnUtil(fgconf, mcyaml)
        self.used_slot_map = self.mcutil.used_slot_map
        self.col_slots = self.mcutil.col_slots
        self.col_dims = self.mcutil.col_dims
        self.col_aggregators = self.mcutil.col_aggregators
        self.hanging_slot_info = self.mcutil.hanging_slot_info
        self.multi_emb = 1
        self.dense_dim = kwargs.get('dense_dim', 72)
        self.onehot_dim = kwargs.get('onehot_dim', 56)
        self.register_hanging_slot = kwargs.get("register_hanging_slot", False)

        print("got {} feature columns".format(len(self.used_slot_map)))
        print("slots: \n{}".format(self.col_slots))
        print("dims: \n{}".format(self.col_dims))
        print("aggregators: \n{}".format(self.col_aggregators))
        print("get hanging slots: {}".format(self.hanging_slot_info))
        print("get non-fp slots: {}".format(list(self.mcutil.non_fp_col_conf_flat_map.keys())))

        # params
        self.param_initializer = tf.compat.v1.truncated_normal_initializer(
            stddev=0.001, dtype=tf.float32
        )
        self.param_regularizer = None

        self.label_idx_map = [("click", 0), ("cart", 2), ("order", 4)]
        self._phases = [{"name": "p1"}, {"name": "p2"}]
        self.metrics = []

    def build_inputs(self):
        if self.dense_dim > 0:
            self.dense_input = ego.get_dense_feature(name="dense", dim=self.dense_dim, feature_type=ego.FeatureType.ITEM)
        if self.onehot_dim > 0:
            self.onehot_input = ego.get_dense_feature(name="onehot", dim=self.onehot_dim, feature_type=ego.FeatureType.ITEM)
        hanging_ids = [conf["slot_id"] for conf in self.hanging_slot_info]
        hanging_dims = [conf["dim"] for conf in self.hanging_slot_info]
        hanging_aggs = [ego.Pooling for conf in self.hanging_slot_info]
        if self.multi_emb != 1:
            self.col_dims = [self.multi_emb * x for x in self.col_dims]
            hanging_dims = [self.multi_emb * x for x in hanging_dims]
        if not self.register_hanging_slot:
            assert(len(hanging_ids) == 0)
        elif len(hanging_ids):
            print("build_inputs: register hanging slots: {}".format(hanging_ids))
            ego.import_extra_slots(hanging_ids, hanging_dims)
        # ego.declare_slot_categories(self.col_slots + hanging_ids, self.col_dims + hanging_dims, self.col_aggregators + hanging_aggs)
        if ego.is_training_mode():
            # self.sparse_input = ego.get_slots(
            #     self.col_slots, folded=False
            # )
            non_tile_slots_id = []
            non_tile_slots_dims = []
            non_tile_slots_poolings = []
            tile_inputs = []
            tile_inputs_id = []

            for slot_id, dim, pooling in zip(self.col_slots, self.col_dims, self.col_aggregators):
                if pooling in ('tile', 'tile_nf'):
                    tile_inputs_id.append(slot_id)
                    slot = ego.get_slots(
                        name=str(slot_id),
                        slots=[slot_id],
                        dims=[dim],
                        poolings=[convert_pooling(pooling)],
                        feature_type=ego.FeatureType.ITEM
                    )
                    tile_inputs.append(slot)
                else:
                    non_tile_slots_id.append(slot_id)
                    non_tile_slots_dims.append(dim)
                    non_tile_slots_poolings.append(convert_pooling(pooling))
            non_tile_inputs = ego.get_slots(
                name='col_slots',
                slots=non_tile_slots_id,
                dims=non_tile_slots_dims,
                poolings=non_tile_slots_poolings,
                feature_type=ego.FeatureType.ITEM
            )
            non_tile_inputs = list(tf.split(non_tile_inputs, non_tile_slots_dims, axis=1))
            sparse_input_pairs = list(zip_longest(non_tile_slots_id, non_tile_inputs)) + list(zip_longest(tile_inputs_id, tile_inputs))
            self.sparse_input = [x[1] for x in sorted(sparse_input_pairs, key=lambda x: x[0])]

        else:
            shared_feature_names = set(self.mcutil.get_shared_names())
            # print("serving mode, shared feature names: ", shared_feature_names)
            print('len = ', len(shared_feature_names))
            shared_slots = []
            shared_dims = []
            shared_aggs = []
            non_shared_slots = []
            non_shared_dims = []
            non_shared_aggs = []
            shared_tile_inputs = []
            shared_tile_slots = []
            non_shared_tile_inputs = []
            non_shared_tile_slots = []
            for i, slot_id in enumerate(self.col_slots):
                if self.used_slot_map[slot_id] in shared_feature_names:
                    if self.col_aggregators[i] in ('tile', 'tile_nf'):
                        shared_tile_slots.append(slot_id)
                        shared_tile_input = ego.get_slots(
                            name=str(slot_id),
                            slots=[slot_id],
                            dims=[self.col_dims[i]],
                            poolings=[convert_pooling(self.col_aggregators[i])],
                            feature_type=ego.FeatureType.COMMON
                        )
                        shared_tile_inputs.append(shared_tile_input)
                    else:
                        shared_slots.append(slot_id)
                        shared_dims.append(self.col_dims[i])
                        shared_aggs.append(convert_pooling(self.col_aggregators[i]))
                else:
                    if self.col_aggregators[i] in ('tile', 'tile_nf'):
                        non_shared_tile_slots.append(slot_id)
                        non_shared_tile_input = ego.get_slots(
                            name=str(slot_id),
                            slots=[slot_id],
                            dims=[self.col_dims[i]],
                            poolings=[convert_pooling(self.col_aggregators[i])],
                            feature_type=ego.FeatureType.UNDEFINED
                        )
                        non_shared_tile_inputs.append(non_shared_tile_input)
                    else:
                        non_shared_slots.append(slot_id)
                        non_shared_dims.append(self.col_dims[i])
                        non_shared_aggs.append(convert_pooling(self.col_aggregators[i]))
            print("serving mode, shared slots: ", shared_slots + shared_tile_slots)
            shared_inputs = ego.get_slots(
                name="shared_inputs",
                slots=shared_slots,
                dims=shared_dims,
                poolings=shared_aggs,
                feature_type=ego.FeatureType.COMMON
            )
            non_shared_inputs = ego.get_slots(
                name="non_shared_inputs",
                slots=non_shared_slots,
                dims=non_shared_dims,
                poolings=non_shared_aggs,
                feature_type=ego.FeatureType.UNDEFINED
            )

            shared_inputs = list(tf.split(shared_inputs, shared_dims, axis=1))
            non_shared_inputs = list(tf.split(non_shared_inputs, non_shared_dims, axis=1))


            self.non_shared_batch_size = tf.shape(non_shared_inputs[0])[0]
            self.shared_batch_size = tf.shape(shared_inputs[0])[0]
            sparse_input_pairs = list(zip_longest(shared_slots, shared_inputs)) + list(zip_longest(non_shared_slots, non_shared_inputs)) + list(zip_longest(shared_tile_slots, shared_tile_inputs)) + list(zip_longest(non_shared_tile_slots, non_shared_tile_inputs))
            self.sparse_input = [x[1] for x in sorted(sparse_input_pairs, key=lambda x: x[0])]




        # print("got {} sparse features".format(self.sparse_input))

    def build_labels(self):
        self.labels = OrderedDict()
        self.loss_weights = OrderedDict()
        for name, idx in self.label_idx_map:
            # self.labels[name] = ego.get_label(name=name, label_idx=idx)
            # self.loss_weights[name] = ego.get_loss_weight(
            #     name="loss_weight_{}".format(name)
            # )
            self.labels[name], self.loss_weights[name] = ego.get_label_weight(target_name=name, label_idx=idx)
        for phase in self._phases:
            phase["labels"] = list(self.labels.values())

    def build_networks(self):
        sparse_embs = tf.concat(self.sparse_input, axis=-1)
        inputs = [
            tf.concat([self.dense_input, self.onehot_input, sparse_embs], axis=-1),
            sparse_embs,
        ]
        for i, phase in enumerate(self._phases):
            phase["logits"] = []
            bottom = DenseTower(
                name="p{}_bottom".format(phase["name"]),
                output_dims=[255, 127],
                kernel_initializers=[self.param_initializer] * 2,
                bias_initializers=[self.param_initializer] * 2,
                activations=[tf.nn.relu, tf.nn.relu],
                norms=[True, False],
            )(inputs[i])

            for label_name, _ in self.label_idx_map:
                logit = DenseTower(
                    name="p{}_{}".format(phase["name"], label_name),
                    output_dims=[63, 1],
                    kernel_initializers=[self.param_initializer] * 2,
                    bias_initializers=[self.param_initializer] * 2,
                    activations=[tf.nn.relu, None],
                    norms=[False, False],
                )(bottom)
                phase["logits"].append(logit)

    def build_loss(self):
        for phase in self._phases:
            phase["losses"] = []
            phase["loss_weights"] = list(self.loss_weights.values())
            reg_losses = tf.compat.v1.get_collection(
                tf.compat.v1.GraphKeys.REGULARIZATION_LOSSES
            )
            phase_loss = 0
            for i, (label_name, _) in enumerate(self.label_idx_map):
                loss = tf.nn.sigmoid_cross_entropy_with_logits(
                    labels=phase["labels"][i],
                    logits=phase["logits"][i],
                    name="{}_{}_loss".format(phase["name"], label_name),
                )
                phase["losses"].append(loss)
                phase_loss -= tf.reduce_sum(loss * phase["loss_weights"][i], name="{}_phase_loss".format(phase["name"]))
            if len(reg_losses):
                # reg_losses = [reg for reg in reg_losses if "pp1" in reg.name]
                print("got reg losses: ", reg_losses)
                phase_loss = phase_loss - tf.reduce_sum(reg_losses)
            phase["phase_loss"] = phase_loss

    def build_targets(self):
        for phase in self._phases:
            phase["targets"] = []
            phase["target_names"] = []
            for i, (label_name, _) in enumerate(self.label_idx_map):
                target_name = "{}_{}".format(phase["name"], label_name)
                predict = tf.sigmoid(
                    phase["logits"][i], name="{}_predict".format(target_name)
                )
                phase["target_names"].append(target_name)
                phase["targets"].append(predict)
            # phase["predict_node_name"] = '{}_predict_node'.format(phase["name"])
            # phase["predict_node"] = tf.identity(phase["targets"][0]**0.8*(phase["targets"][1]**1.2+phase["targets"][2]**1.2+0.4), phase["predict_node_name"])

    def format_ego_targets(self):
        for p in self._phases:
            for i in range(len(self.label_idx_map)):
                ego.Target(
                    p["target_names"][i],
                    tf.identity(p["targets"][i], p["target_names"][i]),
                    p["labels"][i],
                    p["loss_weights"][i],
                    p["losses"][i],
                    ego.MetricType.GAUC
                )
            # ego.Target(p["predict_node_name"], p["predict_node"], p["labels"][0], None, None)



    def build_metrics(self, phase):
        for i in range(len(phase["target_names"])):
            # auc, update_op = tf.contrib.metrics.streaming_auc(
            #     predictions=phase["targets"][i],
            #     labels=phase["labels"][i],
            #     name="AUC_{}".format(phase["target_names"][i])
            # )
            # self.metrics.append(auc)
            loss = tf.reduce_mean(
                phase["losses"][i] * phase["loss_weights"][i],
                axis=-1,
                name="loss_{}".format(phase["target_names"][i])
            )
            self.metrics.append(loss)


    def build_summary(self):
        self.build_metrics(self._phases[0])
        if len(self.metrics) < 1:
            return
        for metric in self.metrics:
            ego.add_print_scalar_vars_to_tensorboard(metric)

        ego.add_print_run_metadata_to_tensorboard()


    def format_predict_score(self, score, points = 1e6):
        assert points >= 1
        return tf.round(score * points) / points

    def fusion_scores(self, click, cart, order):
        return self.format_predict_score(click**0.9 * (cart**1.2 + order**1.2 + 0.4))

    def print_total_params(self):
        # total_parameters = 0
        # for variable in tf.trainable_variables():
        #     # shape is an array of tf.Dimension
        #     shape = variable.get_shape()
        #     print(variable.name)
        #     # print(len(shape))
        #     variable_parameters = 1
        #     for dim in shape:
        #         # print(dim)
        #         variable_parameters *= dim.value
        #     print(variable_parameters)
        #     total_parameters += variable_parameters
        print("total_parameters = ",
              np.sum([np.prod(v.get_shape().as_list()) for v in tf.compat.v1.trainable_variables()]))


    def build_graph(self):
        self.build_inputs()
        self.build_labels()
        self.build_networks()
        self.build_targets()
        self.build_loss()
        self.format_ego_targets()
        self.print_total_params()
        return self._phases
