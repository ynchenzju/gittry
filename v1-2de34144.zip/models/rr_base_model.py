#!/usr/bin/env python
# -*- coding: utf-8 -*-


import tensorflow as tf
import ego
from ego import DenseTower
from ego import replace_gradient

from utils.fg_tool import FGConf
from models.base_model import BaseModel
from utils.ops import ignore_grad, multihead_target_attention_auto_fold
from itertools import chain


def cross_entropy_loss(label, pred, epsilon = 1e-12):
    return tf.multiply(label, -tf.math.log(pred + epsilon)) + tf.multiply(tf.subtract(1.0, label), -tf.math.log(tf.subtract(1.0, pred) + epsilon))


def distance_loss(positive_emb, negative_emb, epsilon = 1e-12, alpha=1e-1):
    positive_emb = tf.nn.l2_normalize(positive_emb, axis=1, epsilon=epsilon)
    negative_emb = tf.nn.l2_normalize(negative_emb, axis=1, epsilon=epsilon)
    loss = positive_emb * negative_emb
    return alpha * tf.reduce_mean(loss)


class BaseModelRR(BaseModel):
    def __init__(self, fgconf: FGConf, mcyaml, *args, **kwargs):
        super().__init__(fgconf, mcyaml, *args, **kwargs)
        self.groups = [k for k in self.mcconf.keys()]
        self._phases = [{"name": "p1"}]
        for phase in self._phases:
            phase["block_layer_dict"] = {}
        self._attention_seq_input = ["user_session_click_seq"]
        self.cur_phase=None
        self.clipnorm = kwargs.get('clipnorm', False)
        self.user_group_names = ["user", "user_session_order"]
        self.context_group_names = ["context"]
        self.target_group_names = ["target_item"] # cannot include recall
        self.recall_group_names = ["recall"]
        self.tower_dim = 64
        self.assign_slot_id = [8001]

    def build_inputs(self):
        super().build_inputs()
        assert len(self.used_slot_map) == len(self.sparse_input)
        self.sparse_feature_map = {
            list(self.used_slot_map.values())[i]: self.sparse_input[i]
            for i in range(len(self.used_slot_map))
        }
        for conf in chain(*self.mcconf.values()):
            if conf.get("back_propagation", True) == False:
                if conf["aggregator"] in ("tile", "tile_nf"):
                    slot = ignore_grad(self.sparse_feature_map[conf["name"]][0])
                    self.sparse_feature_map[conf["name"]] = (slot, self.sparse_feature_map[conf["name"]][1])
                else:
                    slot = ignore_grad(self.sparse_feature_map[conf["name"]])
                    self.sparse_feature_map[conf["name"]] = slot
                print("build_inputs: ignore grad for slot {}".format(conf["name"]))

    def build_group_input(self):
        self.group_inputs = {}
        self.sequence_group_inputs = {}
        self.sequence_lengths = {}

        for group_name in self.groups:
            tensor_list = [
                self.sparse_feature_map[conf["name"]]
                for conf in self.mcconf[group_name]
            ]
            if group_name.endswith("seq"):
                sequence_max_length_list = [
                    x[0].get_shape().as_list()[1] for x in tensor_list
                ]
                assert all(
                    [
                        length == sequence_max_length_list[0]
                        for length in sequence_max_length_list
                    ]
                )
                print(
                    "build_group_input: got sequence: {} with feature nums: {} and length: {}".format(
                        group_name, len(tensor_list), sequence_max_length_list[0]
                    )
                )
                self.sequence_group_inputs[group_name] = tf.concat(
                    [x[0] for x in tensor_list], axis=-1
                )
                sequence_lengths = tf.concat([x[1] for x in tensor_list], axis=-1)
                self.sequence_lengths[group_name] = tf.reduce_max(
                    sequence_lengths, axis=-1
                )
            else:
                print(
                    "build_group_input: got group: {} with feature nums: {}".format(
                        group_name, len(tensor_list)
                    )
                )
                res = tf.concat(tensor_list, axis=-1)
                self.group_inputs[group_name] = res

        if self.assign_slot_id:
            assign_slot = ego.get_slots(
                name="assign_slot_emb",
                slots=self.assign_slot_id,
                dims=[self.tower_dim] * len(self.assign_slot_id),
                poolings=[ego.Pooling.SUM] * len(self.assign_slot_id),
                is_assign_slot=True,
                feature_type=ego.FeatureType.ITEM,
            )
            self.assign_slot_embs = tf.concat(assign_slot, axis=-1)

    def build_sequence_mask(self):
        self.sequence_masks = {}
        for name in self.sequence_group_inputs.keys():
            lengths = self.sequence_lengths[name]
            max_lengths = self.sequence_group_inputs[name].get_shape().as_list()[1]
            length_mask = tf.sequence_mask(
                lengths, maxlen=max_lengths, dtype=tf.float32
            )
            self.sequence_masks[name] = length_mask

    def target_attention_layer(self, sequence_name, query_name, hidden_dim=64, target_cache=False, shared_input=True, name_surffix=""):
        phase_name = self._phases[self.cur_phase]["name"]
        inputs = self.sequence_group_inputs[sequence_name]
        mask = self.sequence_masks[sequence_name]
        # todo for cache
        if target_cache:
            query_ = self.group_inputs[query_name]
            cache_emb = self.assign_slot_embs[..., 0: self.tower_dim]
            if ego.is_training_mode():
                param_initializer = tf.truncated_normal_initializer(stddev=0.001, dtype=tf.float32)
                share_bottom = DenseTower(name='Share_Bottom_{}'.format('pre_build'),
                                          output_dims=[self.tower_dim],
                                          kernel_initializers=[param_initializer],
                                          bias_initializers=[param_initializer],
                                          activations=[tf.nn.relu],
                                          norms=[False])(query_)
                query_cached = replace_gradient(share_bottom, cache_emb, share_bottom)
            else:
                query_cached = cache_emb
            self.group_inputs[query_name] = query_cached
            query_out = tf.stop_gradient(query_cached)
        else:
            query = self.group_inputs[query_name]
            query_out = tf.stop_gradient(query)
        print(
            "target_attention_layer: building with input {} and query {} with dim {}".format(
                sequence_name, query_name, query_out.get_shape().as_list()[-1]
            )
        )
        query_out = tf.expand_dims(query_out, 1)
        ta_output, ta_feature_map = multihead_target_attention_auto_fold(
            queries=query_out,
            keys=inputs,
            values=inputs,
            num_units=hidden_dim,
            activation_fn=None,
            key_masks=mask,
            name="{}_ta_phase_{}{}".format(sequence_name, phase_name, name_surffix),
        )
        ta_output = tf.squeeze(ta_output, 1)
        self._phases[self.cur_phase]["block_layer_dict"][
            "target_attention_layer_{}{}".format(sequence_name, name_surffix)
        ] = ta_output

    def seq_pooling_layer(self, sequence_name, hidden_dim=64, name_suffix=""):
        phase_name = self._phases[self.cur_phase]["name"]
        inputs = self.sequence_group_inputs[sequence_name]
        mask = self.sequence_masks[sequence_name]
        print("seq_pooling_layer: building with input: {}".format(sequence_name))
        seq_ln = DenseTower(
            name="seq_pooling_{}_phase_{}{}".format(sequence_name, phase_name, name_suffix),
            output_dims=[hidden_dim],
            activations=[None],
        )(inputs)
        res = tf.reduce_mean(seq_ln * tf.expand_dims(mask, axis=-1), axis=1)
        self._phases[self.cur_phase]["block_layer_dict"]["seq_pooling_layer_{}{}".format(sequence_name, name_suffix)] = res

    def simple_pooling_layer(self, sequence_name, name_suffix=""):
        inputs = self.sequence_group_inputs[sequence_name]
        mask = self.sequence_masks[sequence_name]
        res = tf.reduce_mean(inputs * tf.expand_dims(mask, axis=-1), axis=1)
        self._phases[self.cur_phase]["block_layer_dict"][
            "seq_pooling_layer_simple_{}_{}".format(sequence_name, name_suffix)] = res

    def build_network_inputs(self, i):
        used_user_cols, used_target_cols, used_context_cols, used_recall_cols, attention_cols = [], [], [], [], []
        used_user_names, used_target_names, used_context_names, used_recall_names, attention_names = [], [], [], [], []
        used_user_len, used_target_len, used_context_len, used_recall_len, attention_len = 0, 0, 0, 0, 0
        layers = self._phases[i]["block_layer_dict"]
        for name, block in chain(self.group_inputs.items(), layers.items()):
            shape = block.get_shape().as_list()
            print(
                "phrase {} build_networks: get block input {} with shape {}".format(i, name, shape)
            )
            if len(shape) == 2:
                if name in self.user_group_names:
                    used_user_cols.append(block)
                    used_user_names.append([name, shape])
                    used_user_len += shape[1]
                if name in self.target_group_names:
                    used_target_cols.append(block)
                    used_target_names.append([name, shape])
                    used_target_len += shape[1]
                if name in self.context_group_names:
                    used_context_cols.append(block)
                    used_context_names.append([name, shape])
                    used_context_len += shape[1]
                if name in self.recall_group_names:
                    used_recall_cols.append(block)
                    used_recall_names.append([name, shape])
                    used_recall_len += shape[1]

        for name, block in chain(layers.items()):
            shape = block.get_shape().as_list()
            print(
                "phrase {} build_networks: get block input {} with shape {}".format(i, name, shape)
            )
            if len(shape) == 2:
                attention_cols.append(block)
                attention_names.append([name, shape])
                attention_len += shape[1]

        print("dense_dim =", self.dense_dim)
        print("onehot_dim =", self.onehot_dim)
        print("phrase {} used_user_names = {}, used_target_names = {}, used_context_names = {}, used_recall_names = {} ".
              format(i, used_user_names, used_target_names, used_context_names, used_recall_names))
        print("phrase {} build_networks: used_user_len = {}, used_target_len = {}, used_context_len = {}, used_recall_len = {}".
              format(i, used_user_len, used_target_len, used_context_len, used_recall_len))

        return tf.concat(used_user_cols, axis=-1), tf.concat(used_target_cols, axis=-1), \
               tf.concat(used_context_cols, axis=-1), tf.concat(used_recall_cols, axis=-1), tf.concat(attention_cols, axis=-1)


    def build_esmm(self):
        param_initializer = tf.truncated_normal_initializer(stddev=0.001, dtype=tf.float32)

        target_names = "click,atc,order".split(",")

        nn_outputs = [[]]
        loss = [[]]
        labels = [[]]
        loss_weights = [[]]

        for phase in range(len(self._phases)):
            user_input, target_input, context_input, recall_input, att_input = self.build_network_inputs(phase)
            name_input_mapper = {
                "user": user_input,
                "target": target_input,
                "context": context_input,
                "recall": recall_input,
                "attention": att_input
            }
            out_vectors = {}

            for name, block_input in name_input_mapper.items():
                if self.clipnorm:
                    print("enable clip norm")
                    norm_input = tf.clip_by_value(ego.Normalization("Share_Bottom_{}_{}/input_norm".format(phase, name))(block_input), -5, 5)
                else:
                    norm_input = ego.Normalization("Share_Bottom_{}_{}/input_norm".format(phase, name))(block_input)
                # todo remove cache
                out_vectors[name] = norm_input

            fusion_input = tf.concat([out_vectors['user'], out_vectors['context'],
                                      out_vectors['target'], out_vectors['recall'], out_vectors['attention']], axis=-1)
            print("phrase {} fusion input: input_dim {}".format(phase, fusion_input.get_shape().as_list()[1]))

            for idx, target in enumerate(target_names):
                ns = 'p{}_{}'.format(phase, target)
                pred = DenseTower(name='p{}_{}'.format(phase,target),
                                  output_dims=[255, 63, 1],
                                  kernel_initializers=[param_initializer] * 3,
                                  bias_initializers=[param_initializer] * 3,
                                  activations=[tf.nn.relu, tf.nn.relu, tf.nn.sigmoid],
                                  norms=[False, False, False])(fusion_input)

                nn_outputs[phase].append(tf.identity(pred, ns))
                label_idx = idx * 2
                label, weight = ego.get_label_weight(target_name='label_{}_{}'.format(phase,label_idx), label_idx=label_idx)
                labels[phase].append(label)
                loss[phase].append(cross_entropy_loss(label, pred))
                loss_weights[phase].append(weight)

        self._phases[0]["losses"] = [loss[0][0], loss[0][1], loss[0][2]]
        self._phases[0]["loss_weights"] = [loss_weights[0][0], loss_weights[0][1], loss_weights[0][2]]
        self._phases[0]["target_names"] = ['p0_click', 'p0_atc', 'p0_order']
        self._phases[0]["targets"] = [nn_outputs[0][0], nn_outputs[0][1], nn_outputs[0][2]]
        self._phases[0]["labels"] = [labels[0][0], labels[0][1], labels[0][2]]

        self._phases[0]["predict_target_names"] = ["p0_click", "p0_atc", "p0_order"]
        self._phases[0]["predict_targets"] = [nn_outputs[0][0], nn_outputs[0][1], nn_outputs[0][2]]
        self._phases[0]["predict_labels"] = [labels[0][0], labels[0][1], labels[0][2]]
        self._phases[0]["predict_weights"] = [loss_weights[0][0], loss_weights[0][1], loss_weights[0][2]]

    def build_loss(self):
        for phase in self._phases:
            phase_loss = 0.0
            for i in range(len(phase["labels"])):
                phase_loss += tf.reduce_sum(phase["losses"][i] * phase["loss_weights"][i])

            phase["phase_loss"] = -phase_loss

    def format_ego_targets(self):
        for p in self._phases:
            for i in range(len(p["target_names"])):
                ego.Target(
                    p["target_names"][i],
                    tf.identity(p["targets"][i], p["target_names"][i]),
                    p["labels"][i],
                    p["loss_weights"][i],
                    p["losses"][i],
                    ego.MetricType.GAUC
                )
            if "predict_target_names" in p:
                for i in range(len(p["predict_target_names"])):
                    predict_target_name = p["predict_target_names"][i]
                    if predict_target_name not in p["target_names"]:
                        ego.Target(p["predict_target_names"][i],
                                   tf.identity(p["predict_targets"][i], p["predict_target_names"][i]),
                                   p["predict_labels"][i],
                                   p["predict_weights"][i],
                                   None,
                                   ego.MetricType.GAUC)

    def build_graph(self):
        self.build_inputs()
        self.build_group_input()
        self.build_labels()
        self.build_sequence_mask()
        with tf.variable_scope("model", initializer=self.param_initializer, regularizer=self.param_regularizer):
            for i in range(len(self._phases)):
                self.cur_phase = i
                for name in self.sequence_group_inputs.keys():
                    if name in self._attention_seq_input:
                        self.target_attention_layer(name, "target_item", hidden_dim=64, target_cache=True)
                        self.seq_pooling_layer(name, hidden_dim=64)
            self.build_esmm()
        self.build_loss()
        self.format_ego_targets()
        self.print_total_params()
        return self._phases
