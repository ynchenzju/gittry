#!/usr/bin/env python
# -*- coding: utf-8 -*-
from lib2to3.btm_utils import tokens

import tensorflow as tf
import ego
from ego import DenseTower
from ego import replace_gradient
from setuptools.extern import names

from utils.fg_tool import FGConf
from models.base_model import BaseModel
from utils.ops import ignore_grad
from itertools import chain
from llm_utils.din import din_attention_cos
from llm_utils.sum_log import summary_vector, summary_scalar
from tensorflow.python.keras.layers import LayerNormalization


def cross_entropy_loss(label, pred, epsilon = 1e-6):
    return tf.multiply(label, -tf.math.log(pred + epsilon)) + tf.multiply(tf.subtract(1.0, label), -tf.math.log(tf.subtract(1.0, pred) + epsilon))

def swish(x):
    return x * tf.nn.sigmoid(x)

def mse_loss(pred_x, pred_y):
    return (pred_x - pred_y) ** 2

def mae_loss(pred_x, pred_y):
    return tf.math.abs(pred_x - pred_y)

def mean_square_loss(emb, target, alpha=1.0):
    mse = alpha*tf.reduce_sum(tf.square(target - emb), axis=-1, keepdims=True)
    return mse

def cosine_similarity(emb, target):
    cos_score = tf.reduce_sum(tf.multiply(emb, target), axis=-1, keepdims=True)
    return cos_score


class BaseModelRR(BaseModel):
    def __init__(self, fgconf: FGConf, mcyaml, *args, **kwargs):
        super().__init__(fgconf, mcyaml, *args, **kwargs)
        self.groups = [k for k in self.mcconf.keys()]
        self._phases = [{"name": "p1"}]
        for phase in self._phases:
            phase["block_layer_dict"] = {}
        self.cur_phase=None
        self.clipnorm = kwargs.get('clipnorm', False)
        self.feature_indexes = {
            # todo add upstream
            "user": 0, "ub_click": 9, "ub_order": 10, "ub_upstream": 11,
            "target_item": 1, "context": 2, "recall": 3,
            "target_item_query_img": 4, "target_item_query_title": 5,
            "ub_clk_img_seq": 6, "ub_order_img_seq": 7,
            "context_item_img": 8,
            "user_madnn": 12,
            "item_cross": 13, "ub_upstream_cross": 14,
            "ub_click_cross": 15, "ub_order_cross": 16, "ranker_features": 17,
            "ub_clk_title_seq": 18, "ub_order_title_seq": 19
        }
        self.feature_group_indexes = {
            "user_fea": 0, "item_fea": 1, "context_fea": 2, "recall_fea": 3,
            "item_pretrain": 4, "item_pretrain_title": 5,
            "ub_click_pretrain": 6, "ub_order_pretrain": 7,
            "context_pretrain": 8,
            "ub_click": 9, "ub_order": 10, "ub_upstream": 11,
            "user_madnn": 12,
            "item_cross": 13, "ub_upstream_cross": 14,
            "ub_click_cross": 15, "ub_order_cross": 16, "ranker_features": 17,
            "ub_click_pretrain_title": 18, "ub_order_pretrain_title": 19
        }
        self.token_groups = [
            ["user_fea", "user_madnn"],
            ["item_fea", "item_pretrain", "recall_fea", "item_pretrain_title"],
            ["ub_click"], ["ub_order"], ["ub_upstream"],
            ["context_fea", "context_pretrain"], ["ub_click_pretrain"], ["ub_order_pretrain"]
        ]
        self.token_groups_t = [
            ["user_fea"], ["item_fea", "item_pretrain", "recall_fea", "item_pretrain_title", "item_cross"],
            ["ub_click"], ["ub_order"],
            ["ub_upstream", "ub_upstream_cross"], ["context_fea", "context_pretrain"],
            ["ub_click_cross"], ["ub_order_cross"]
        ]

        self.token_params = [
            [256, 0.25],
            [128, 0.25]
        ]
        self.tower_dim = 64
        self.assign_slot_id = [8002]
        self.llm_len = 33
        self.group_fea = []
        self.tb = True
        self.scalar_tensor = []
        self.madnn_idx = (3 + 3) * 2
        self.madnn_loss, self.madnn_flag = None, False
        self.madnn_label, self.madnn_weight = None, None
        self.tokens = {}
        self.layer_loss, self.layer_label, self.layer_weight = None, None, None
        self.dump_flag = True

    def build_inputs(self):
        super().build_inputs()
        assert len(self.used_slot_map) == len(self.sparse_input)
        self.sparse_feature_map = {
            list(self.used_slot_map.values())[i]: self.sparse_input[i]
            for i in range(len(self.used_slot_map))
        }
        for conf in chain(*self.mcconf.values()):
            if conf.get("back_propagation", True) == False:
                if conf["aggregator"] in ("tile", "tile_nf"):
                    slot = ignore_grad(self.sparse_feature_map[conf["name"]][0])
                    self.sparse_feature_map[conf["name"]] = (slot, self.sparse_feature_map[conf["name"]][1])
                else:
                    slot = ignore_grad(self.sparse_feature_map[conf["name"]])
                    self.sparse_feature_map[conf["name"]] = slot
                print("build_inputs: ignore grad for slot {}".format(conf["name"]))

    def build_group_input(self):
        self.group_inputs = {}
        self.sequence_group_inputs = {}
        self.sequence_lengths = {}

        for group_name in self.groups:
            tensor_list = [
                self.sparse_feature_map[conf["name"]]
                for conf in self.mcconf[group_name]
            ]
            if group_name.endswith("seq"):
                sequence_max_length_list = [
                    x[0].get_shape().as_list()[1] for x in tensor_list
                ]
                assert all(
                    [
                        length == sequence_max_length_list[0]
                        for length in sequence_max_length_list
                    ]
                )
                print(
                    "build_group_input: got sequence: {} with feature nums: {} and length: {}".format(
                        group_name, len(tensor_list), sequence_max_length_list[0]
                    )
                )
                self.sequence_group_inputs[group_name] = tf.concat(
                    [x[0] for x in tensor_list], axis=-1
                )
                sequence_lengths = tf.concat([x[1] for x in tensor_list], axis=-1)
                self.sequence_lengths[group_name] = tf.reduce_max(
                    sequence_lengths, axis=-1
                )
            else:
                print(
                    "build_group_input: got group: {} with feature nums: {}".format(
                        group_name, len(tensor_list)
                    )
                )
                res = tf.concat(tensor_list, axis=-1)
                self.group_inputs[group_name] = res

        if self.assign_slot_id:
            assign_slot = ego.get_slots(
                name="assign_slot_emb",
                slots=self.assign_slot_id,
                dims=[self.tower_dim] * len(self.assign_slot_id),
                poolings=[ego.Pooling.SUM] * len(self.assign_slot_id),
                is_assign_slot=True,
                feature_type=ego.FeatureType.ITEM,
            )
            self.assign_slot_embs = tf.concat(assign_slot, axis=-1)

    def build_sequence_mask(self):
        self.sequence_masks = {}
        for name in self.sequence_group_inputs.keys():
            lengths = self.sequence_lengths[name]
            max_lengths = self.sequence_group_inputs[name].get_shape().as_list()[1]
            length_mask = tf.sequence_mask(
                lengths, maxlen=max_lengths, dtype=tf.float32
            )
            self.sequence_masks[name] = length_mask

    def build_network_inputs(self, i):
        feature_group_indexes = len(self.feature_group_indexes)
        used_cols = [[] for _ in range(feature_group_indexes)]
        used_names = [[] for _ in range(feature_group_indexes)]
        used_len = [[] for _ in range(feature_group_indexes)]
        sequence_lens = [[] for _ in range(feature_group_indexes)]
        layers = self._phases[i]["block_layer_dict"]
        for name, block in chain(self.group_inputs.items(), self.sequence_group_inputs.items(), layers.items()):
            shape = block.get_shape().as_list()
            print(
                "phrase {} build_networks: get block input {} with shape {}, group index {}".format(i, name, shape, self.feature_indexes[name])
            )
            used_cols[self.feature_indexes[name]].append(block)
            used_names[self.feature_indexes[name]].append([name, shape])
            used_len[self.feature_indexes[name]].append(shape[-1]) # D, len, dim
            if name in self.sequence_lengths.keys():
                sequence_lens[self.feature_indexes[name]].append(self.sequence_lengths[name])

        for fea_name, idx in self.feature_group_indexes.items():
            print("phrase {} for {}, feature names: {}, feature total length: {}".format(i, fea_name, used_names[idx], used_len[idx]))
            self.group_fea.append(tf.concat(used_cols[idx], axis=-1) if used_cols[idx] else [])

        return sequence_lens

    def norm_embs(self, fea_keys, op_name, use_l2_norm):
        feats = []
        for k in fea_keys:
            idx = self.feature_group_indexes[k]
            if use_l2_norm:
                feat = tf.nn.l2_normalize(self.group_fea[idx], axis=-1, name=f"{k}_l2_norm")
            else:
                feat = self.group_fea[idx]
            print(f"[get_item_embs] `{self.feature_group_indexes[k], k}`")
            feats.append(feat)
        return tf.concat(feats, axis=-1, name=op_name + "_concat")

    def get_item_attention_embs(self, item_query_key=None, seq_keys=["ub_clk_seq", "ub_cart_seq", "ub_order_seq"], op_name="get_item_attention_embs", seq_len=50):
        feats = []
        att_weights = []
        item_query_emb = self.group_fea[self.feature_group_indexes[item_query_key]]
        for k in seq_keys:
            keys = self.group_fea[self.feature_group_indexes[k]]
            print(f"[{op_name}, {self.feature_group_indexes[k]}, {k}]", keys.get_shape().as_list(), seq_len)
            feat, cos_sim, simtier_score = din_attention_cos(queries=item_query_emb, keys=keys, keys_length=seq_len, return_weight=True, use_simtier=True, simtier_number=100, use_agg=False, name=f"{k}_din_layer_cos")
            att_w = cos_sim
            # print(f"[{op_name}]", feat, cos_sim, simtier_score, att_w)
            feats.append(cos_sim) # T
            feats.append(simtier_score) # N
            att_weights.append(att_w)
        return tf.concat(feats, axis=-1, name=op_name + "_concat"), att_weights

    def get_cos_sim(self, emb_a, emb_b, op_name="get_cos_sim", use_l2_norm=False):
        if use_l2_norm:
            emb_a_norm = tf.nn.l2_normalize(emb_a, axis=-1, name=f"{op_name}_seq_a_l2_norm")
            emb_b_norm = tf.nn.l2_normalize(emb_b, axis=-1, name=f"{op_name}_seq_b_l2_norm")
            dot_product = tf.reduce_sum(tf.multiply(emb_a_norm, emb_b_norm), axis=-1)
        else:
            dot_product = tf.reduce_sum(tf.multiply(emb_a, emb_b), axis=-1)
        return dot_product

    def neural_gate_layer(self, norm_input, control, param_initializer, ratio, name, phase):
        input_dim = norm_input.get_shape().as_list()[-1]
        neural_gate = DenseTower(name='Neural_Gate_{}_{}'.format(phase, name),
                                 output_dims=[int(input_dim * ratio), input_dim],
                                 kernel_initializers=[param_initializer] * 2,
                                 bias_initializers=[param_initializer] * 2,
                                 activations=[swish, swish],
                                 norms=[False, False])(control)
        return tf.multiply(neural_gate, norm_input)

    def tokenizer(self, tokens, tk_dim, k):
        tokens_proj = [] # T * len(tokens) * tk_dim
        param_initializer = tf.truncated_normal_initializer(stddev=0.001, dtype=tf.float32)
        for tk_name, tk in enumerate(tokens):
            tmp_proj = DenseTower(name='token_proj_{}'.format(tk_name),
                                  output_dims=[tk_dim],
                                  kernel_initializers=[param_initializer],
                                  bias_initializers=[param_initializer],
                                  activations=[None],
                                  norms=[True])(tk)
            tokens_proj.append(tmp_proj) # [T, tk_dim] * len(tokens)
        print('tokens_proj_len: ', len(tokens_proj), 'tokens_proj_dim', tokens_proj[0].get_shape())
        tokens_stacked = tf.stack(tokens_proj, axis=1) # [T, len(tokens), tk_dim]
        print('tokens_stacked: ', tokens_stacked.get_shape())
        tokens_splits = tf.split(tokens_stacked, len(tokens), -1) # [T, len(tokens), tk_dim / len()] * len(tokens)
        print('tokens_splits_len: ', len(tokens_splits), 'tokens_splits_dim', tokens_splits[0].get_shape())
        tokens_mix = LayerNormalization(name="token_mix")(tf.reshape(tf.stack(tokens_splits, axis=1), [-1, len(tokens), tk_dim]) + tokens_stacked) # [T, len(), tk_dim]
        print('tokens_mix: ', tokens_mix.get_shape())
        outputs = [] # [N, tk_dim*k] * len(tokens)
        for idx, tk in enumerate(tf.unstack(tokens_mix, axis=1)):
            tmp = DenseTower(name='token_ffm_{}'.format(str(idx)),
                             output_dims=[int(tk_dim*k), tk_dim],
                             kernel_initializers=[param_initializer]*2,
                             bias_initializers=[param_initializer]*2,
                             activations=[tf.nn.gelu, None],
                             norms=[True, False])(tk)
            outputs.append(tmp)
        print('outputs_len: ', len(outputs), 'outputs_dim', outputs[0].get_shape())
        return tf.unstack(tf.stack(outputs, axis=1) + tokens_mix,  axis=1)  # [N, len(tokens), tk_dim*k]

    def madnn_block(self, fea_names, madnn_names, dims, op_name, tower_out, use_tower=False):
        madnn_feas =  self.norm_embs(madnn_names, "get_madnn_" + op_name, False)
        pos_emb, neg_emb = tf.nn.l2_normalize(madnn_feas[:, : self.tower_dim], axis=-1), tf.nn.l2_normalize(madnn_feas[:, self.tower_dim: self.tower_dim*2], axis=-1)
        if use_tower:
            target_emb = tower_out
        else:
            param_initializer = tf.truncated_normal_initializer(stddev=0.001, dtype=tf.float32)
            orig_features = self.norm_embs(fea_names, "get_original_" + op_name, False)
            orig_features = tf.clip_by_value(ego.Normalization("share_input_norm_" + op_name)(orig_features), -5, 5)
            target_emb = ego.DenseTower(
                name='item_tower_' + op_name,
                output_dims=dims,
                kernel_initializers=[param_initializer] * len(dims),
                bias_initializers=[param_initializer] * len(dims),
                activations=[tf.nn.leaky_relu] * (len(dims) - 1) + [None],
                norms=False,
                use_bias=True
            )(orig_features)

        target_emb_ = tf.stop_gradient(tf.nn.l2_normalize(target_emb, axis=-1))
        label = tf.broadcast_to(self.madnn_label, tf.shape(pos_emb))
        weight = tf.broadcast_to(self.madnn_weight, tf.shape(pos_emb))
        madnn_emb = tf.where(label > 0, pos_emb, neg_emb)
        madnn_emb = tf.where(weight > 0, madnn_emb, target_emb_)
        mse_loss = mean_square_loss(madnn_emb, target_emb_, 0.03)
        print("op name {}: dim {}".format(op_name, mse_loss.get_shape().as_list()))
        if not self.madnn_flag:
            self.madnn_loss = mse_loss
            self.madnn_flag = True
        else:
            self.madnn_loss += mse_loss
        if self.tb:
            self.scalar_tensor.append(tf.identity(mse_loss, name='loss_'+ op_name ))
            zero_rate = tf.reduce_mean(tf.where(tf.abs(madnn_emb) < 0.0001, tf.ones_like(madnn_emb), tf.zeros_like(madnn_emb)))
            self.scalar_tensor.append(tf.identity(zero_rate, name='madnn_emb_zero_rate_'+ op_name))
        return tf.concat([madnn_feas, target_emb], axis=-1), cosine_similarity(madnn_emb, target_emb_)

    def build_esmm(self):
        ego.config_dump_tensor(with_sample_id=True)
        param_initializer = tf.truncated_normal_initializer(stddev=0.001, dtype=tf.float32)
        target_names = "click,atc,order".split(",")
        nn_outputs, nn_outputs_t = [[]], [[]]
        loss, loss_t = [[]], [[]]
        labels, labels_t = [[]], [[]]
        loss_weights, loss_weights_t = [[]], [[]]
        dump_vectors = []

        for phase in range(len(self._phases)):
            _ = self.build_network_inputs(phase)
            # ------------------------------------- ITEM CACHE ---------------------------------
            item_vec = self.norm_embs(["item_fea"], 'get_item_embs', False)
            item_vec = ego.DenseTower(
                name='item_tower',
                output_dims=[128, 64],
                kernel_initializers=[param_initializer] * 2,
                bias_initializers=[param_initializer] * 2,
                activations=[tf.nn.leaky_relu, None],
                norms=[True, False],
                use_bias=True
            )(item_vec)
            cache_emb = self.assign_slot_embs[..., 0: self.tower_dim]
            if ego.is_training_mode():
                item_emb = replace_gradient(item_vec, cache_emb, item_vec)
            else:
                item_emb = cache_emb
            abs_val = tf.sqrt(tf.reduce_sum(abs(item_emb ** 2), axis=-1, keepdims=True))
            print("phrase {} abs val: dim {}".format(phase, abs_val.get_shape().as_list()))
            # ------------------------------------- ITEM CACHE ---------------------------------

            # ------------------------------------- SIMTIER ---------------------------------
            pretrain_score, pretrain_att_w = self.get_item_attention_embs("item_pretrain", ["ub_click_pretrain", "ub_order_pretrain"], "get_item_attention_embs_pretrain")

            if self.tb:
                for idx, ws in enumerate(pretrain_att_w):
                    zero_rate = tf.reduce_mean(tf.where(tf.abs(pretrain_att_w[idx]) < 0.001, tf.ones_like(pretrain_att_w[idx]), tf.zeros_like(pretrain_att_w[idx])))
                    self.scalar_tensor.append(tf.identity(zero_rate, name='pretrain_attn_zero_'+ str(idx)))

            sim_tower_item = self.norm_embs(["item_pretrain"], 'sim_tower_get_item_embs', True)
            sim_tower_context = self.norm_embs(["context_pretrain"], 'sim_tower_get_context_embs', True)
            sim_score = self.get_cos_sim(sim_tower_item, sim_tower_context)
            # ------------------------------------- SIMTIER ---------------------------------

            # ------------------------------------- DUMP ---------------------------------
            if self.dump_flag:
                # IMAGE
                item_click_seq = pretrain_att_w[0][:, :50]
                item_order_seq = pretrain_att_w[1][:, :50]
                click_mask, order_mask = self.sequence_masks['ub_clk_img_seq'], self.sequence_masks['ub_order_img_seq']
                item_click_seq = tf.where(click_mask > 0, item_click_seq, tf.zeros_like(item_click_seq))
                item_order_seq = tf.where(order_mask > 0, item_order_seq, tf.zeros_like(item_order_seq))
                dump_vectors.append(tf.identity(item_click_seq, 'item_ub_click_sim'))
                dump_vectors.append(tf.identity(item_order_seq, 'item_ub_order_sim'))
                # TITLE
                pretrain_score_t, pretrain_att_w_t = self.get_item_attention_embs("item_pretrain_title", ["ub_click_pretrain_title", "ub_order_pretrain_title"], "get_item_attention_embs_pretrain_t")
                item_click_title_seq = pretrain_att_w_t[0][:, :50]
                item_order_title_seq = pretrain_att_w_t[1][:, :50]
                click_mask_title, order_mask_title = self.sequence_masks['ub_clk_title_seq'], self.sequence_masks['ub_order_title_seq']
                item_click_title_seq = tf.where(click_mask_title > 0, item_click_title_seq, tf.zeros_like(item_click_title_seq))
                item_order_title_seq = tf.where(order_mask_title > 0, item_order_title_seq, tf.zeros_like(item_order_title_seq))
                dump_vectors.append(tf.identity(item_click_title_seq, 'item_ub_click_sim_title'))
                dump_vectors.append(tf.identity(item_order_title_seq, 'item_ub_order_sim_title'))
            # ------------------------------------- DUMP ---------------------------------

            # ------------------------------------- RankMixer ---------------------------------
            tokens = []
            for idx, token_group in enumerate(self.token_groups):
                if 'item_fea' in token_group:
                    orig_fea = self.norm_embs(["recall_fea", "item_pretrain", "item_pretrain_title"], 'get_original_embs_' + str(idx), False)
                    tokens.append(tf.concat([orig_fea, item_emb], axis=-1))
                elif 'ub_click_pretrain' in token_group or 'ub_order_pretrain' in token_group:
                    orig_fea = self.norm_embs(token_group, 'get_original_embs_' + str(idx), False)
                    tokens.append(tf.reduce_mean(orig_fea, axis=1))
                else:
                    orig_fea = self.norm_embs(token_group, 'get_original_embs_' + str(idx), False)
                    tokens.append(orig_fea)
                print(token_group, '| get original features: ', orig_fea.get_shape())

            for idx, token_params in enumerate(self.token_params):
                print('layer ' + str(idx) + ': ', token_params)
                print('token len: ', len(tokens), ' shape: ', tokens[0].get_shape())
                dim, k_rate = token_params[0], token_params[1]
                tokens = self.tokenizer(tokens, dim, k_rate)
            # ------------------------------------- RankMixer ---------------------------------

            # ------------------------------------- Concat ------------------------------------
            user_fea = self.norm_embs(["user_fea"], 'get_original_embs_user', False)
            context_fea = self.norm_embs(["context_fea"], 'get_original_embs_context', False)
            recall_fea = self.norm_embs(["recall_fea"], 'get_original_embs_recall', False)
            basic_feas_ = tf.concat([user_fea, context_fea, recall_fea], axis=-1)
            basic_feas = self.neural_gate_layer(basic_feas_, basic_feas_, param_initializer, 0.25, 'basic_fea', phase)
            share_bottom = tf.concat(tokens + [item_emb, basic_feas, pretrain_score, tf.reshape(sim_score, [-1, 1])], axis=-1)
            print(f"pretrain_score", pretrain_score.get_shape(),
                  "sim_tower_item", sim_tower_item.get_shape(), "sim_tower_context", sim_tower_context.get_shape(), "sim_score", sim_score.get_shape(),
                  "share_bottom", share_bottom.get_shape())
            # ------------------------------------ Concat -----------------------------------

            # share  & MaDNN
            mid_out = DenseTower(name='p{}_mid'.format(phase),
                                 output_dims=[512, 256, 64],
                                 kernel_initializers=[param_initializer] * 3,
                                 bias_initializers=[param_initializer] * 3,
                                 activations=[tf.nn.leaky_relu, tf.nn.leaky_relu, tf.nn.leaky_relu],
                                 norms=[True, False, False])(share_bottom)

            # ------------------------------------- MA-DNN ---------------------------------
            madnn_scores = []
            self.madnn_label, self.madnn_weight = ego.get_label_weight(target_name='label_{}'.format(self.madnn_idx), label_idx=self.madnn_idx)
            _, madnn_score = self.madnn_block([], ["user_madnn"], [], "user", mid_out, True)
            madnn_scores.append(madnn_score)
            # ------------------------------------- MA-DNN ---------------------------------

            # ------------------------------------- Teacher ---------------------------------
            if ego.is_training_mode():
                tokens_t = []
                for idx, token_group in enumerate(self.token_groups_t):
                    orig_fea = self.norm_embs(token_group, 'get_original_embs_t_' + str(idx), False)
                    tokens_t.append(orig_fea)
                    print(token_group, '| get original features: ', orig_fea.get_shape())
                for idx, token_params in enumerate(self.token_params):
                    print('layer ' + str(idx) + ': ', token_params)
                    print('token len: ', len(tokens_t), ' shape: ', tokens_t[0].get_shape())
                    dim, k_rate = token_params[0], token_params[1]
                    tokens_t = self.tokenizer(tokens_t, dim, k_rate)
                item_fea_t = self.norm_embs(["item_fea"], 'get_original_embs_item', False)
                share_bottom_t = tf.concat(tokens_t + [item_fea_t, basic_feas_, pretrain_score, tf.reshape(sim_score, [-1, 1])], axis=-1)
                print('share_tottom_t, dim: ', share_bottom_t.get_shape())
                mid_out_t = DenseTower(name='p{}_mid_t'.format(phase),
                                       output_dims=[512, 256, 64],
                                       kernel_initializers=[param_initializer] * 3,
                                       bias_initializers=[param_initializer] * 3,
                                       activations=[tf.nn.leaky_relu, tf.nn.leaky_relu, tf.nn.leaky_relu],
                                       norms=[True, False, False])(share_bottom_t)
                self.layer_loss = mean_square_loss(mid_out, mid_out_t, 0.03)
                self.layer_weight = self.madnn_weight
                self.layer_label = self.madnn_label
                ranker_features_t = self.norm_embs(["ranker_features"], 'get_original_embs_ranker', False)
            # ------------------------------------- Teacher ---------------------------------

            for idx, target in enumerate(target_names):
                ns = 'p{}_{}'.format(phase, target)
                pred_t = None
                if ego.is_training_mode():
                    label_idx = (idx * 2) * 2
                    ns_t = ns + '_t'
                    pred_t_f = DenseTower(name='p{}_{}_t_feature'.format(phase,target),
                                          output_dims=[64, 1],
                                          kernel_initializers=[param_initializer] * 2,
                                          bias_initializers=[param_initializer] * 2,
                                          activations=[tf.nn.leaky_relu, tf.nn.leaky_relu],
                                          norms=False)(mid_out_t)
                    pred_t_s = DenseTower(name='p{}_{}_t_score'.format(phase,target),
                                          output_dims=[64, 1],
                                          kernel_initializers=[param_initializer] * 2,
                                          bias_initializers=[param_initializer] * 2,
                                          activations=[tf.nn.leaky_relu, tf.nn.leaky_relu],
                                          norms=False)(ranker_features_t)
                    pred_t = tf.nn.sigmoid(pred_t_f + pred_t_s)
                    nn_outputs_t[phase].append(tf.identity(pred_t, ns_t))
                    label_t, weight_t = ego.get_label_weight(target_name='label_{}_{}'.format(phase,label_idx), label_idx=label_idx)
                    labels_t[phase].append(label_t)
                    loss_weights_t[phase].append(weight_t)
                    loss_t[phase].append(cross_entropy_loss(label_t, pred_t))
                pred = DenseTower(name='p{}_{}_tower'.format(phase, target),
                                  output_dims=[64, 1],
                                  kernel_initializers=[param_initializer] * 2,
                                  bias_initializers=[param_initializer] * 2,
                                  activations=[tf.nn.leaky_relu, tf.nn.sigmoid],
                                  norms=[False, False])(mid_out)
                nn_outputs[phase].append(tf.identity(pred, ns))
                label_idx = (idx * 2 + 1) * 2
                label, weight = ego.get_label_weight(target_name='label_{}_{}'.format(phase,label_idx), label_idx=label_idx)
                labels[phase].append(label)
                loss_weights[phase].append(weight)
                if ego.is_training_mode():
                    dist_loss = mae_loss(tf.stop_gradient(pred_t), pred)
                    loss[phase].append(tf.add(cross_entropy_loss(label, pred), 1.5 * dist_loss))
                else:
                    loss[phase].append(cross_entropy_loss(label, pred))
                if self.tb and ego.is_training_mode():
                    with tf.variable_scope(target):
                        loss_s_tb = tf.reduce_mean(cross_entropy_loss(label, pred), name = 'loss_s')
                        loss_t_tb = tf.reduce_mean(cross_entropy_loss(label_t, pred_t), name = 'loss_t')
                        loss_d_tb = tf.reduce_mean(mae_loss(pred_t, pred), name = 'loss_d')
                        self.scalar_tensor.extend([loss_s_tb, loss_t_tb, loss_d_tb])

        madnn_score = tf.nn.sigmoid(tf.reduce_sum(tf.concat(madnn_scores, axis=-1), axis=-1, keepdims=True))
        if ego.is_training_mode():
            self._phases[0]['dump_vectors'] = dump_vectors
            self._phases[0]["losses_t"] = [loss_t[0][0], loss_t[0][1], loss_t[0][2]]
            self._phases[0]["loss_weights_t"] = [loss_weights_t[0][0], loss_weights_t[0][1], loss_weights_t[0][2]]
            self._phases[0]["target_names_t"] = ['p0_click_t', 'p0_atc_t', 'p0_order_t']
            self._phases[0]["targets_t"] = [nn_outputs_t[0][0], nn_outputs_t[0][1], nn_outputs_t[0][2]]
            self._phases[0]["labels_t"] = [labels_t[0][0], labels_t[0][1], labels_t[0][2]]

            self._phases[0]["losses"] = [loss[0][0], loss[0][1], loss[0][2],
                                         self.madnn_loss, self.layer_loss]
            self._phases[0]["loss_weights"] = [loss_weights[0][0], loss_weights[0][1], loss_weights[0][2],
                                               self.madnn_weight, self.layer_weight]
            self._phases[0]["target_names"] = ['p0_click', 'p0_atc', 'p0_order', 'p0_madnn', 'p0_layer']
            self._phases[0]["targets"] = [nn_outputs[0][0], nn_outputs[0][1], nn_outputs[0][2],
                                          madnn_score, nn_outputs[0][0]]
            self._phases[0]["labels"] = [labels[0][0], labels[0][1], labels[0][2],
                                         self.madnn_label, self.layer_label]

            self._phases[0]["predict_target_names"] = ["p0_click", "p0_atc", "p0_order",
                                                       "p0_click_t", "p0_atc_t", "p0_order_t"]
            self._phases[0]["predict_targets"] = [nn_outputs[0][0], nn_outputs[0][1], nn_outputs[0][2],
                                                  nn_outputs_t[0][0], nn_outputs_t[0][1], nn_outputs_t[0][2]]
            self._phases[0]["predict_labels"] = [labels[0][0], labels[0][1], labels[0][2],
                                                 labels_t[0][0], labels_t[0][1], labels_t[0][2]]
            self._phases[0]["predict_weights"] = [loss_weights[0][0], loss_weights[0][1], loss_weights[0][2],
                                                  loss_weights_t[0][0], loss_weights_t[0][1], loss_weights_t[0][2]]
            self._phases[0]['scalar_tensor'] = self.scalar_tensor
        else:
            self._phases[0]["online_target_names"] = ["p0_click", "p0_atc", "p0_order", "item_cache"]
            self._phases[0]["online_targets"] = [nn_outputs[0][0], nn_outputs[0][1], nn_outputs[0][2], abs_val]
            self._phases[0]["online_labels"] = [labels[0][0], labels[0][1], labels[0][2], labels[0][0]]
            self._phases[0]["online_weights"] = [loss_weights[0][0], loss_weights[0][1], loss_weights[0][2], loss_weights[0][0]]


    def build_loss(self):
        for phase in self._phases:
            phase_loss = 0.0
            phase_loss_t = 0.0
            print("phase_keys:", phase.keys())
            if ego.is_training_mode():
                for i in range(len(phase["labels"])):
                    phase_loss += tf.reduce_sum(phase["losses"][i] * phase["loss_weights"][i])
                for i in range(len(phase["labels_t"])):
                    phase_loss_t += tf.reduce_sum(phase["losses_t"][i] * phase["loss_weights_t"][i])
            phase["phase_loss"] = -phase_loss
            phase["phase_loss_t"] = -phase_loss_t

    def format_ego_targets(self):
        for p in self._phases:
            if ego.is_training_mode():
                for i in range(len(p["target_names"])):
                    ego.Target(
                        p["target_names"][i],
                        tf.identity(p["targets"][i], p["target_names"][i]),
                        p["labels"][i],
                        p["loss_weights"][i],
                        p["losses"][i],
                        ego.MetricType.GAUC
                    )
                for i in range(len(p["target_names_t"])):
                    ego.Target(
                        p["target_names_t"][i],
                        tf.identity(p["targets_t"][i], p["target_names_t"][i]),
                        p["labels_t"][i],
                        p["loss_weights_t"][i],
                        p["losses_t"][i],
                        ego.MetricType.GAUC
                    )
                if "predict_target_names" in p:
                    for i in range(len(p["predict_target_names"])):
                        predict_target_name = p["predict_target_names"][i]
                        if predict_target_name not in p["target_names"] + p["target_names_t"]:
                            ego.Target(p["predict_target_names"][i],
                                       tf.identity(p["predict_targets"][i], p["predict_target_names"][i]),
                                       p["predict_labels"][i],
                                       p["predict_weights"][i],
                                       None, None)
            else:
                for i in range(len(p["online_target_names"])):
                    ego.Target(p["online_target_names"][i],
                               tf.identity(p["online_targets"][i], p["online_target_names"][i]),
                               p["online_labels"][i],
                               p["online_weights"][i], None, None)

    def build_graph(self):
        self.build_inputs()
        self.build_group_input()
        self.build_labels()
        self.build_sequence_mask()
        with tf.variable_scope("model", initializer=self.param_initializer, regularizer=self.param_regularizer):
            self.build_esmm()
        self.build_loss()
        self.format_ego_targets()
        self.print_total_params()
        return self._phases
