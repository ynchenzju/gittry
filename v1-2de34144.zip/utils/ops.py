# ----------------------
# Created on Thu Dec 02 2021
# Author: Lu Yin
# ----------------------


import tensorflow as tf
import ego
from ego import DenseTower
#import ego.layers as L

def mask_block(
        name,
        emb_input,
        hidden_input,
        hidden_dim,
        output_dim,
        param_initializer,
        activation_fn=None,
        ratio=0.5
):
    if hidden_input is None:
        hidden_input = emb_input  # B * ( Length * Field ) BN

    mask_gate = DenseTower(name='Mask_Net_Gate_Proj_{}_1'.format(name),
                           output_dims=[int(hidden_dim*ratio), hidden_dim],
                           kernel_initializers=[param_initializer]*2,
                           bias_initializers=[param_initializer]*2,
                           activations=[activation_fn, None],
                           norms=[False, False])(hidden_input)
    v_masked = hidden_input * mask_gate

    v_masked_ = DenseTower(name='Mask_Net_gate_Proj_{}_2'.format(name),
                           output_dims=[output_dim],
                           activations=[None],
                           norms=[False])(v_masked)

    return tf.nn.relu(tf.keras.layers.LayerNormalization(axis=1)(v_masked_))


def multihead_self_attention(
        inputs,
        num_units=None,
        num_output_units=None,
        activation_fn=None,
        num_heads=8,
        name="multihead_self_attention",
        query_masks=None,
        key_masks=None,
):
    if num_units is None:
        num_units = inputs.get_shape().as_list()[-1]
    query_len = key_len = inputs.get_shape().as_list()[1]
    query_dim = inputs.get_shape().as_list()[-1]

    inputs_2d = tf.reshape(inputs, [-1, query_dim])
    Q = DenseTower(
        name="{}_ln_proj_q".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(inputs_2d)
    Q = tf.reshape(Q, [-1, query_len, num_units])
    K = DenseTower(
        name="{}_ln_proj_k".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(inputs_2d)
    K = tf.reshape(K, [-1, key_len, num_units])
    V = DenseTower(
        name="{}_ln_proj_v".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(inputs_2d)
    V = tf.reshape(V, [-1, key_len, num_units])
    Q_ = tf.concat(tf.split(Q, num_heads, axis=2), axis=0)
    K_ = tf.concat(tf.split(K, num_heads, axis=2), axis=0)
    V_ = tf.concat(tf.split(V, num_heads, axis=2), axis=0)

    # todo fix axis bug 1 -> -1
    Q_ = tf.keras.layers.LayerNormalization(axis=-1)(Q_)
    K_ = tf.keras.layers.LayerNormalization(axis=-1)(K_)

    feature_map = tf.matmul(Q_, K_, transpose_b=True)
    feature_map = feature_map * (num_units ** (-0.5))

    key_masks = tf.tile(
        tf.reshape(key_masks, [-1, 1, key_len]), [num_heads, query_len, 1]
    )
    paddings = tf.fill(
        tf.shape(feature_map), tf.constant(-(2 ** 20) + 1, dtype=tf.float32)
    )
    feature_map = tf.where(key_masks > 0, feature_map, paddings)
    feature_map = tf.nn.softmax(feature_map)
    query_masks = tf.tile(tf.reshape(query_masks, [-1, query_len]), [num_heads, 1])
    feature_map = tf.reshape(feature_map, [-1, key_len])
    paddings = tf.zeros_like(feature_map, dtype=tf.float32)
    feature_map = tf.where(tf.reshape(query_masks, [-1]) > 0, feature_map, paddings)
    feature_map = tf.reshape(feature_map, [-1, query_len, key_len])

    outputs = tf.matmul(feature_map, V_)
    outputs = tf.concat(tf.split(outputs, num_heads, axis=0), axis=2)
    return outputs, feature_map


def multihead_target_attention(
        queries,
        keys,
        values,
        num_units=None,
        num_output_units=None,
        activation_fn=None,
        num_heads=8,
        name="multihead_target_attention",
        key_masks=None,
        non_shared_batch_size=None,
        shared_batch_size=None
):
    if num_units is None:
        num_units = queries.get_shape().as_list()[-1]
    query_len = queries.get_shape().as_list()[1]
    query_dim = queries.get_shape().as_list()[-1]
    key_len = keys.get_shape().as_list()[1]
    key_dim = keys.get_shape().as_list()[-1]
    value_dim = values.get_shape().as_list()[-1]

    queries_2d = tf.reshape(queries, [-1, query_dim])
    keys_2d = tf.reshape(keys, [-1, key_dim])
    values_2d = tf.reshape(values, [-1, value_dim])

    Q = DenseTower(
        name="{}_ln_proj_q".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(queries_2d)
    Q = tf.reshape(Q, [-1, query_len, num_units])
    K = DenseTower(
        name="{}_ln_proj_k".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(keys_2d)
    K = tf.reshape(K, [-1, key_len, num_units])
    V = DenseTower(
        name="{}_ln_proj_v".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(values_2d)
    V = tf.reshape(V, [-1, key_len, num_units])

    key_masks_ = tf.tile(
        tf.reshape(key_masks, [-1, 1, key_len]), [num_heads, query_len, 1]
    )

    if non_shared_batch_size is not None:
        K = tf.tile(K, [non_shared_batch_size - shared_batch_size + 1, 1, 1], name="TILE_OPT_{}_K".format(name))
        V = tf.tile(V, [non_shared_batch_size - shared_batch_size + 1, 1, 1], name="TILE_OPT_{}_V".format(name))
        key_masks_ = tf.tile(tf.reshape(key_masks, [-1, 1, key_len]), [(non_shared_batch_size - shared_batch_size + 1) * num_heads, query_len, 1])

    Q_ = tf.concat(tf.split(Q, num_heads, axis=2), axis=0)
    K_ = tf.concat(tf.split(K, num_heads, axis=2), axis=0)
    V_ = tf.concat(tf.split(V, num_heads, axis=2), axis=0)

    Q_ = tf.keras.layers.LayerNormalization(axis=1)(Q_)
    K_ = tf.keras.layers.LayerNormalization(axis=1)(K_)


    feature_map = tf.matmul(Q_, K_, transpose_b=True)
    feature_map = feature_map * (num_units ** (-0.5))

    paddings = tf.fill(
        tf.shape(feature_map), tf.constant(-(2 ** 20) + 1, dtype=tf.float32)
    )
    feature_map = tf.where(key_masks_ > 0, feature_map, paddings)
    feature_map = tf.nn.softmax(feature_map)

    outputs = tf.matmul(feature_map, V_)
    outputs = tf.concat(tf.split(outputs, num_heads, axis=0), axis=2)
    return outputs, feature_map

def multihead_target_attention_auto_fold(
        queries,
        keys,
        values,
        num_units=None,
        num_output_units=None,
        activation_fn=None,
        num_heads=8,
        name="multihead_target_attention",
        key_masks=None,
):
    if num_units is None:
        num_units = queries.get_shape().as_list()[-1]
    query_len = queries.get_shape().as_list()[1]
    query_dim = queries.get_shape().as_list()[-1]
    key_len = keys.get_shape().as_list()[1]
    key_dim = keys.get_shape().as_list()[-1]
    value_dim = values.get_shape().as_list()[-1]

    queries_2d = tf.reshape(queries, [-1, query_dim])
    keys_2d = tf.reshape(keys, [-1, key_dim])
    values_2d = tf.reshape(values, [-1, value_dim])

    Q = DenseTower(
        name="{}_ln_proj_q".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(queries_2d)
    Q = tf.reshape(Q, [-1, query_len, num_units])
    K = DenseTower(
        name="{}_ln_proj_k".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(keys_2d)
    K = tf.reshape(K, [-1, key_len, num_units])
    V = DenseTower(
        name="{}_ln_proj_v".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(values_2d)
    V = tf.reshape(V, [-1, key_len, num_units])

    key_masks_ = tf.tile(
        tf.reshape(key_masks, [-1, 1, 1, key_len]), [1, num_heads, query_len, 1]
    )

    Q_ = tf.stack(tf.split(Q, num_heads, axis=2), axis=1)
    K_ = tf.stack(tf.split(K, num_heads, axis=2), axis=1)
    V_ = tf.stack(tf.split(V, num_heads, axis=2), axis=1)

    Q_ = tf.reshape(Q_, [-1, query_len, int(num_units / num_heads)])
    K_ = tf.reshape(K_, [-1, key_len, int(num_units / num_heads)])

    Q_ = tf.keras.layers.LayerNormalization(axis=1)(Q_)
    K_ = tf.keras.layers.LayerNormalization(axis=1)(K_)

    Q_ = tf.reshape(Q_, [-1, num_heads, query_len, int(num_units / num_heads)])
    K_ = tf.reshape(K_, [-1, num_heads, key_len, int(num_units / num_heads)])

    feature_map = tf.matmul(Q_, K_, transpose_b=True)
    feature_map = feature_map * (num_units ** (-0.5))

    paddings = tf.fill(
        tf.shape(feature_map), tf.constant(-(2 ** 20) + 1, dtype=tf.float32)
    )
    feature_map = tf.where(key_masks_ > 0, feature_map, paddings)
    feature_map = tf.nn.softmax(feature_map)

    outputs = tf.matmul(feature_map, V_)
    outputs = tf.concat(tf.unstack(outputs, axis=1), axis=-1)
    return outputs, feature_map

@tf.custom_gradient
def ignore_grad(x):
    def grad(upstream):
        return upstream * 0.0
    return x, grad


def multihead_target_attention_v2_auto_fold(
        queries,
        keys,
        values,
        num_units=None,
        num_output_units=None,
        activation_fn=None,
        num_heads=8,
        name="multihead_target_attention",
        key_masks=None,
):
    if num_units is None:
        num_units = queries.get_shape().as_list()[-1]
    query_len = queries.get_shape().as_list()[1]
    query_dim = queries.get_shape().as_list()[-1]
    key_len = keys.get_shape().as_list()[1]
    key_dim = keys.get_shape().as_list()[-1]
    value_dim = values.get_shape().as_list()[-1]

    queries_2d = tf.reshape(queries, [-1, query_dim])
    keys_2d = tf.reshape(keys, [-1, key_dim])
    values_2d = tf.reshape(values, [-1, value_dim])

    Q = DenseTower(
        name="{}_ln_proj_q".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(queries_2d)
    Q = tf.reshape(Q, [-1, query_len, num_units])
    K = DenseTower(
        name="{}_ln_proj_k".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(keys_2d)
    K = tf.reshape(K, [-1, key_len, num_units])
    V = DenseTower(
        name="{}_ln_proj_v".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(values_2d)
    V = tf.reshape(V, [-1, key_len, num_units])

    key_masks_ = tf.tile(
        tf.reshape(key_masks, [-1, 1, 1, key_len]), [1, num_heads, query_len, 1]
    )


    Q_ = tf.stack(tf.split(Q, num_heads, axis=2), axis=1)
    K_ = tf.stack(tf.split(K, num_heads, axis=2), axis=1)
    V_ = tf.stack(tf.split(V, num_heads, axis=2), axis=1)

    Q_ = tf.keras.layers.LayerNormalization(axis=-1)(Q_)
    K_ = tf.keras.layers.LayerNormalization(axis=-1)(K_)


    feature_map = tf.matmul(Q_, K_, transpose_b=True)
    feature_map = feature_map * (num_units ** (-0.5))

    paddings = tf.fill(
        tf.shape(feature_map), tf.constant(-(2 ** 20) + 1, dtype=tf.float32)
    )
    feature_map = tf.where(key_masks_ > 0, feature_map, paddings)
    feature_map = tf.nn.softmax(feature_map)

    outputs = tf.matmul(feature_map, V_)
    outputs = tf.concat(tf.unstack(outputs, axis=1), axis=-1)
    return outputs, feature_map
