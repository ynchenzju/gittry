from datetime import datetime
import warnings
import functools
import inspect
import ego

def translate_mcconf(mcconf):
    # enum of config
    for group_name in mcconf:
        for slot in mcconf[group_name]:
            if slot.get("is_shared", False) == True:
                slot["type"] = ego.FeatureType.COMMON
            else:
                slot["type"] = ego.FeatureType.ITEM
            slot["aggregator"] = convert_pooling(slot["aggregator"])

def convert_pooling(p):
    if p == 'sum' or p == ego.Pooling.SUM:
        return ego.Pooling.SUM
    elif p == 'avg' or p == ego.Pooling.AVG:
        return ego.Pooling.AVG
    elif p == 'max' or p == ego.Pooling.MAX:
        return ego.Pooling.MAX
    elif p == 'min' or p == ego.Pooling.MIN:
        return ego.Pooling.MIN
    elif p == 'tile' or p == ego.Pooling.TILE:
        return ego.Pooling.TILE
    elif p == 'tile_nf' or p == ego.Pooling.TILE_NF:
        return ego.Pooling.TILE_NF
    else:
        print(p)
        print("pooling method not implemented")
        exit()


string_types = (type(b''), type(u''))
def deprecated(reason):
    """
    This is a decorator which can be used to mark functions
    as deprecated. It will result in a warning being emitted
    when the function is used.
    """

    if isinstance(reason, string_types):

        # The @deprecated is used with a 'reason'.
        #
        # .. code-block:: python
        #
        #    @deprecated("please, use another function")
        #    def old_function(x, y):
        #      pass

        def decorator(func1):

            if inspect.isclass(func1):
                fmt1 = "Call to deprecated class {name} ({reason})."
            else:
                fmt1 = "Call to deprecated function {name} ({reason})."

            @functools.wraps(func1)
            def new_func1(*args, **kwargs):
                warnings.simplefilter('always', DeprecationWarning)
                warnings.warn(
                    fmt1.format(name=func1.__name__, reason=reason),
                    category=DeprecationWarning,
                    stacklevel=2
                )
                warnings.simplefilter('default', DeprecationWarning)
                return func1(*args, **kwargs)

            return new_func1

        return decorator

    elif inspect.isclass(reason) or inspect.isfunction(reason):

        # The @deprecated is used without any 'reason'.
        #
        # .. code-block:: python
        #
        #    @deprecated
        #    def old_function(x, y):
        #      pass

        func2 = reason

        if inspect.isclass(func2):
            fmt2 = "Call to deprecated class {name}."
        else:
            fmt2 = "Call to deprecated function {name}."

        @functools.wraps(func2)
        def new_func2(*args, **kwargs):
            warnings.simplefilter('always', DeprecationWarning)
            warnings.warn(
                fmt2.format(name=func2.__name__),
                category=DeprecationWarning,
                stacklevel=2
            )
            warnings.simplefilter('default', DeprecationWarning)
            return func2(*args, **kwargs)

        return new_func2

    else:
        raise TypeError(repr(type(reason)))
