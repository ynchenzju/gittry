# -*- coding:utf-8 -*-

"""Transformer-style SID prediction over RankMixer token memory."""

import math

import tensorflow as tf


def gelu(x):
    return tf.nn.gelu(x, approximate=True)


class ConcatenatedGlorotUniform(tf.keras.initializers.Initializer):
    """Initialize packed Dense columns as independent Glorot matrices."""

    def __init__(self, num_partitions):
        self.num_partitions = num_partitions

    def __call__(self, shape, dtype=None):
        shape = tf.TensorShape(shape).as_list()
        if shape[-1] % self.num_partitions != 0:
            raise ValueError(
                'output dim {} must be divisible by {} partitions'.format(
                    shape[-1], self.num_partitions
                )
            )
        partition_dim = shape[-1] // self.num_partitions
        partition_shape = shape[:-1] + [partition_dim]
        return tf.concat(
            [
                tf.keras.initializers.GlorotUniform()(
                    partition_shape, dtype=dtype
                )
                for _ in range(self.num_partitions)
            ],
            axis=-1,
        )

    def get_config(self):
        return {'num_partitions': self.num_partitions}


class GroupedDense(tf.keras.layers.Layer):
    """Independent Dense projections dispatched as one BatchMatMul.

    Input/output shapes are ``[B, G, input_dim]`` and
    ``[B, G, output_dim]``. Each group owns an independent kernel and bias.
    """

    def __init__(
        self,
        num_groups,
        output_dim,
        kernel_initializer='glorot_uniform',
        **kwargs
    ):
        super().__init__(**kwargs)
        self.num_groups = num_groups
        self.output_dim = output_dim
        self.kernel_initializer = tf.keras.initializers.get(
            kernel_initializer
        )
        self.kernel_initializer_config = tf.keras.initializers.serialize(
            self.kernel_initializer
        )

    def build(self, input_shape):
        input_shape = tf.TensorShape(input_shape)
        input_dim = input_shape[-1]
        static_num_groups = input_shape[-2]
        if input_dim is None:
            raise ValueError('GroupedDense requires a static input dimension')
        if (
            static_num_groups is not None
            and int(static_num_groups) != self.num_groups
        ):
            raise ValueError(
                'expected {} groups, got {}'.format(
                    self.num_groups, int(static_num_groups)
                )
            )

        # Initialize each [I, O] group separately so packing the weights does
        # not change the fan-in/fan-out used by Glorot initialization.
        group_shape = [int(input_dim), self.output_dim]
        self.kernel = self.add_weight(
            name='kernel',
            shape=[self.num_groups] + group_shape,
            initializer=lambda shape, dtype=None: tf.stack(
                [
                    tf.keras.initializers.deserialize(
                        self.kernel_initializer_config
                    )(group_shape, dtype=dtype)
                    for _ in range(self.num_groups)
                ],
                axis=0,
            ),
            trainable=True,
        )
        self.bias = self.add_weight(
            name='bias',
            shape=[self.num_groups, self.output_dim],
            initializer='zeros',
            trainable=True,
        )
        super().build(input_shape)

    def call(self, inputs):
        # [B, G, I] -> [G, B, I] x [G, I, O] -> [G, B, O].
        group_major_inputs = tf.transpose(inputs, perm=[1, 0, 2])
        outputs = tf.matmul(group_major_inputs, self.kernel)
        outputs = outputs + self.bias[:, tf.newaxis, :]
        return tf.transpose(outputs, perm=[1, 0, 2])


class SwiGLU(tf.keras.layers.Layer):
    """SwiGLU FFN projection: [B, L, D] -> [B, L, output_dim]."""

    def __init__(self, output_dim, **kwargs):
        super().__init__(**kwargs)
        self.projection = tf.keras.layers.Dense(
            output_dim * 2, name='projection'
        )

    def call(self, inputs):
        value, gate = tf.split(self.projection(inputs), 2, axis=-1)
        return value * tf.nn.silu(gate)


class DNN(tf.keras.layers.Layer):
    """The multi-layer perceptron used by each SID prediction head."""

    def __init__(
        self,
        hidden_units,
        activation=gelu,
        l2_reg=0,
        dropout_rate=0,
        use_bn=False,
        output_activation=None,
        seed=None,
        **kwargs
    ):
        self.hidden_units = hidden_units
        self.activation = activation
        self.l2_reg = l2_reg
        self.dropout_rate = dropout_rate
        self.use_dropout = self.dropout_rate > 0
        self.use_bn = use_bn
        self.output_activation = output_activation
        self.seed = seed
        super().__init__(**kwargs)

    def build(self, input_shape):
        input_size = input_shape[-1]
        hidden_units = [int(input_size)] + list(self.hidden_units)
        self.kernels = [
            self.add_weight(
                name='kernel' + str(i),
                shape=(hidden_units[i], hidden_units[i + 1]),
                initializer=tf.keras.initializers.glorot_normal(
                    seed=self.seed
                ),
                regularizer=tf.keras.regularizers.l2(self.l2_reg),
                trainable=True,
            )
            for i in range(len(self.hidden_units))
        ]
        self.bias = [
            self.add_weight(
                name='bias' + str(i),
                shape=(self.hidden_units[i],),
                initializer=tf.keras.initializers.Zeros(),
                trainable=True,
            )
            for i in range(len(self.hidden_units))
        ]
        if self.use_bn:
            self.bn_layers = [
                tf.keras.layers.BatchNormalization()
                for _ in range(len(self.hidden_units))
            ]
        if self.use_dropout:
            self.dropout_layers = [
                tf.keras.layers.Dropout(
                    self.dropout_rate, name='dropout_{}'.format(i)
                )
                for i in range(len(self.hidden_units))
            ]

        if len(self.hidden_units) == 0:
            self.activation_layers = []
        elif self.output_activation:
            self.activation_layers = [
                tf.keras.layers.Activation(self.activation)
                for _ in range(len(self.hidden_units) - 1)
            ] + [tf.keras.layers.Activation(self.output_activation)]
        else:
            self.activation_layers = [
                tf.keras.layers.Activation(self.activation)
                for _ in range(len(self.hidden_units))
            ]
        super().build(input_shape)

    def call(self, inputs, training=None, **kwargs):
        x = inputs
        for i in range(len(self.hidden_units)):
            x = tf.matmul(x, self.kernels[i]) + self.bias[i]
            if self.use_bn:
                x = self.bn_layers[i](x, training=training)
            x = self.activation_layers[i](x)
            if self.use_dropout:
                x = self.dropout_layers[i](x, training=training)
        return x

    def get_config(self):
        config = {
            'activation': self.activation,
            'hidden_units': self.hidden_units,
            'l2_reg': self.l2_reg,
            'use_bn': self.use_bn,
            'dropout_rate': self.dropout_rate,
            'output_activation': self.output_activation,
            'seed': self.seed,
        }
        base_config = super().get_config()
        base_config.update(config)
        return base_config


class MultiHeadAttention(tf.keras.layers.Layer):
    """多头注意力机制。"""

    def __init__(
        self,
        d_model=32,
        num_heads=8,
        name='multi_head_attention',
    ):
        super(MultiHeadAttention, self).__init__(name=name)
        if d_model % num_heads != 0:
            raise ValueError(
                'd_model={} must be divisible by num_heads={}'.format(
                    d_model, num_heads
                )
            )

        self.d_model = d_model
        self.num_heads = num_heads
        self.depth = d_model // num_heads
        self.scale = 1.0 / math.sqrt(float(self.depth))

        self.wq = tf.keras.layers.Dense(d_model, name='wq')
        self.dense = tf.keras.layers.Dense(d_model, name='output_dense')

    def split_heads(self, x, batch_size):
        """分割多头：[B, L, D] -> [B, H, L, D/H]。"""
        x = tf.reshape(
            x, (batch_size, -1, self.num_heads, self.depth)
        )
        return tf.transpose(x, perm=[0, 2, 1, 3])

    @staticmethod
    def _normalize_mask(mask):
        """将 [B, L] 或 [B, Q, L] mask 扩展到 attention logits。"""
        if mask is None:
            return None
        mask_rank = mask.shape.rank
        if mask_rank == 2:
            return mask[:, tf.newaxis, tf.newaxis, :]
        if mask_rank == 3:
            return mask[:, tf.newaxis, :, :]
        return mask

    def call(self, q_input, projected_memory_kv, mask=None):
        batch_size_q = tf.shape(q_input)[0]
        batch_size_kv = tf.shape(projected_memory_kv)[0]

        q = self.split_heads(self.wq(q_input), batch_size_q)
        k, v = tf.split(projected_memory_kv, 2, axis=-1)

        k = self.split_heads(k, batch_size_kv)
        v = self.split_heads(v, batch_size_kv)

        # batch_size_kv=1 时支持 serving 场景下的 batch broadcast。
        scaled_attention_logits = (
            tf.matmul(q, k, transpose_b=True) * self.scale
        )

        mask = self._normalize_mask(mask)
        if mask is not None:
            mask = tf.cast(mask, scaled_attention_logits.dtype)
            scaled_attention_logits += mask * -1e7

        attention_weights = tf.nn.softmax(
            scaled_attention_logits, axis=-1
        )
        attention = tf.matmul(attention_weights, v)
        attention = tf.transpose(attention, perm=[0, 2, 1, 3])
        concat_attention = tf.reshape(
            attention, (batch_size_q, -1, self.d_model)
        )
        return self.dense(concat_attention)


class CrossAttentionLayer(tf.keras.layers.Layer):
    """Cross Attention层：tar_seq作为query，inp作为key和value。"""

    def __init__(
        self,
        d_model=32,
        num_heads=8,
        dff=128,
        dropout_rate=0.1,
        name='cross_attention_layer',
    ):
        super(CrossAttentionLayer, self).__init__(name=name)

        # Cross attention: tar_seq (q) 与 inp (k, v)。
        self.cross_attn = MultiHeadAttention(
            d_model, num_heads, name='cross_attention'
        )

        # 前馈网络层：SwiGLU 将 d_model 映射到 dff，再投影回 d_model。
        self.ffn_swiglu = SwiGLU(dff, name='ffn_swiglu')
        self.ffn_dense2 = tf.keras.layers.Dense(
            d_model, name='ffn_dense2'
        )

        self.layernorm1 = tf.keras.layers.LayerNormalization(
            epsilon=1e-6, name='layernorm1'
        )
        self.layernorm2 = tf.keras.layers.LayerNormalization(
            epsilon=1e-6, name='layernorm2'
        )

        self.dropout1 = tf.keras.layers.Dropout(
            dropout_rate, name='dropout1'
        )
        self.dropout2 = tf.keras.layers.Dropout(
            dropout_rate, name='dropout2'
        )

    def call(
        self,
        tar_seq,
        projected_memory_kv,
        causal_mask=None,
        padding_mask=None,
        training=None,
    ):
        """
        Args:
            tar_seq: [B, tar_seq_len, d_model]，作为 query。
            projected_memory_kv: [B, inp_seq_len, 2*d_model]，已经融合投影的
                key/value；不同 Transformer block 仍使用独立参数。
            causal_mask: 保留兼容参数；cross attention 不使用 target causal mask。
            padding_mask: [B, inp_seq_len] 或可广播到 [B, H, Q, inp_seq_len]。
            training: 训练标记。
        Returns:
            out2: [B, tar_seq_len, d_model]。
        """
        del causal_mask

        # padding_mask 约束的是 memory 的 key/value 位置。
        attn_output = self.cross_attn(
            tar_seq, projected_memory_kv, padding_mask
        )
        attn_output = self.dropout1(attn_output, training=training)
        out1 = self.layernorm1(attn_output + tar_seq)

        # SwiGLU 前馈网络。
        ffn_output = self.ffn_swiglu(out1)
        ffn_output = self.ffn_dense2(ffn_output)
        ffn_output = self.dropout2(ffn_output, training=training)
        out2 = self.layernorm2(out1 + ffn_output)
        return out2


class TransformerModel(tf.keras.layers.Layer):
    """使用外部 RankMixer 序列进行 SID 自回归预估的 Transformer。"""

    def __init__(
        self,
        num_layers=2,
        d_model=256,
        num_heads=8,
        dff=768,
        target_vocab_size=(401, 401, 401),
        num_memory_tokens=7,
        dropout_rate=0.1,
        num_codebooks=3,
        name='transformer',
        sid_codebooks=None,
        sid_01_codebooks=None,
    ):
        super(TransformerModel, self).__init__(name=name)
        if sid_codebooks is None or len(sid_codebooks) != num_codebooks:
            raise ValueError(
                'sid_codebooks must contain {} codebooks'.format(
                    num_codebooks
                )
            )
        if sid_01_codebooks is None or len(sid_01_codebooks) != 1:
            raise ValueError('sid_01_codebooks must contain one codebook')
        if len(target_vocab_size) != num_codebooks:
            raise ValueError(
                'target_vocab_size must contain {} vocab sizes'.format(
                    num_codebooks
                )
            )
        if len(set(target_vocab_size)) != 1:
            raise ValueError(
                'grouped SID output requires equal target vocab sizes'
            )

        self.d_model = d_model
        self.num_layers = num_layers
        self.num_codebooks = num_codebooks
        self.num_memory_tokens = num_memory_tokens
        self.head_temperatures = [0.05] * num_codebooks
        self.length_penalty_alpha = 0.0
        self.diversity_penalty = 0.0
        self.scheduled_sampling_prob = 0.0

        self.dec_layers = [
            CrossAttentionLayer(
                d_model,
                num_heads,
                dff,
                dropout_rate,
                name='cross_attention_layer_{}'.format(i),
            )
            for i in range(num_layers)
        ]

        # All decoder blocks consume the same RankMixer memory. Packing their
        # independent K/V weights along the output dimension turns N memory
        # projections into one standard GEMM, then splits the projected K/V.
        self.memory_kv_projection = tf.keras.layers.Dense(
            num_layers * d_model * 2,
            kernel_initializer=ConcatenatedGlorotUniform(num_layers),
            name='memory_kv_projection',
        )

        self.target_vocab_size = list(target_vocab_size)
        self.num_categories = target_vocab_size[0]
        self.bos_embedding = self.add_weight(
            name='bos_embedding',
            shape=(1, d_model),
            initializer='glorot_normal',
            trainable=True,
        )

        self.sid_codebooks = sid_codebooks
        self.sid_01_codebooks = sid_01_codebooks
        sid_vocab_size = int(sid_codebooks[0].shape[0])
        cart_01_vocab_size = int(sid_01_codebooks[0].shape[0])

        # Standard SID codebooks provide SID0/SID1 queries. SID01 is added
        # below as the fourth query position; no SID2 query is constructed.
        self.semantic_id_embedding_layer = []
        for i in range(num_codebooks - 1):
            embedding_layer = CategoryEmbedding(
                i,
                sid_codebooks,
                vocab_size=sid_vocab_size,
                name='semantic_id_i{}_embedding'.format(i),
            )
            setattr(
                self,
                'semantic_id_{}_embedding'.format(i),
                embedding_layer,
            )
            self.semantic_id_embedding_layer.append([embedding_layer])
        self.target_seq_dense_layer = GroupedDense(
            # SID0, SID1 and SID01 are projected together while retaining
            # independent parameters for the three query types.
            num_groups=num_codebooks,
            output_dim=d_model,
            kernel_initializer='glorot_uniform',
            name='target_seq_grouped_dense',
        )

        self.semantic_id_01_embedding_layers = [
            CategoryEmbedding(
                k,
                sid_01_codebooks,
                vocab_size=cart_01_vocab_size,
                name='semantic_id_01_embedding_{}'.format(k),
            )
            for k in range(len(sid_01_codebooks))
        ]

        self.codebook_mlp = [
            DNN(
                hidden_units=(512,),
                activation=gelu,
                output_activation=gelu,
                l2_reg=0,
                dropout_rate=0,
                name='codebook{}_mlp'.format(i),
            )
            for i in range(num_codebooks)
        ]
        # The first MLP projections have different input widths. From 512
        # onward all three heads have identical shapes, so their independent
        # weights can be dispatched with one BatchMatMul per layer.
        self.codebook_hidden2 = GroupedDense(
            num_groups=num_codebooks,
            output_dim=256,
            kernel_initializer='glorot_normal',
            name='codebook_grouped_hidden2',
        )
        self.codebook_hidden3 = GroupedDense(
            num_groups=num_codebooks,
            output_dim=128,
            kernel_initializer='glorot_normal',
            name='codebook_grouped_hidden3',
        )
        self.codebook_dropout_layer = tf.keras.layers.Dropout(
            dropout_rate, name='codebook_grouped_dropout'
        )
        self.codebook_output_layer = GroupedDense(
            num_groups=num_codebooks,
            output_dim=target_vocab_size[0],
            kernel_initializer='glorot_uniform',
            name='codebook_grouped_output',
        )

    def _validate_input_shape(self, input_feature):
        shape = input_feature.shape
        if shape.rank is not None and shape.rank != 3:
            raise ValueError(
                'input_feature must have rank 3, got rank {}'.format(
                    shape.rank
                )
            )
        if shape.rank == 3 and shape[1] is not None:
            if int(shape[1]) != self.num_memory_tokens:
                raise ValueError(
                    'expected {} input tokens, got {}'.format(
                        self.num_memory_tokens, int(shape[1])
                    )
                )
        if shape.rank == 3 and shape[-1] is not None:
            if int(shape[-1]) != self.d_model:
                raise ValueError(
                    'expected input dim {}, got {}'.format(
                        self.d_model, int(shape[-1])
                    )
                )

    def call(
        self,
        input_feature,
        tar=None,
        enc_padding_mask=None,
        look_ahead_mask=None,
        dec_padding_mask=None,
        tar_01=None,
        training=None,
    ):
        del enc_padding_mask, look_ahead_mask
        if tar is None:
            return None
        if len(tar) != self.num_codebooks:
            raise ValueError(
                'tar must contain {} SID targets'.format(self.num_codebooks)
            )
        if tar_01 is None or len(tar_01) != 1:
            raise ValueError('tar_01 must contain one SID01 target')
        self._validate_input_shape(input_feature)

        batch_size = tf.shape(tar[0])[0]
        bos_emb = tf.expand_dims(
            tf.tile(self.bos_embedding, [batch_size, 1]), axis=1
        )

        # SID0, SID1 and SID01 are all [B, 1, 160]. Project them with one
        # grouped matmul to [B, 3, 256]; every query type keeps independent
        # parameters and no raw SID01 embedding is passed directly to a head.
        sid_embs = tf.stack(
            [
                tf.squeeze(
                    self.semantic_id_embedding_layer[i][0](tar[i]),
                    axis=1,
                )
                for i in range(self.num_codebooks - 1)
            ]
            + [
                tf.squeeze(
                    self.semantic_id_01_embedding_layers[0](tar_01[0]),
                    axis=1,
                )
            ],
            axis=1,
        )
        sid_embs = gelu(self.target_seq_dense_layer(sid_embs))
        sid_embs_3d = tf.split(
            sid_embs,
            num_or_size_splits=self.num_codebooks,
            axis=1,
        )

        # [BOS, SID0, SID1, SID01]，形状为 [B, 4, 256]。
        tar_seq_input = tf.concat([bos_emb] + sid_embs_3d, axis=1)

        # RankMixer 直接提供 [B, 7, 256] memory；其 mean pooling
        # 对齐参考 TransformerModel 中提供给各 SID MLP 的 sparse_input。
        user_seq = input_feature
        sparse_input = tf.reduce_mean(
            user_seq, axis=1, name='token_mean_pooling'
        )

        # RankMixer token 和 SID query 均不叠加 position encoding。
        inp = user_seq
        tar_seq = tar_seq_input

        # [B, 7, 256] -> [B, 7, num_layers * 2 * 256], then split into
        # independent [B, 7, 512] K/V tensors for the two decoder blocks.
        projected_memory_kv = self.memory_kv_projection(inp)
        projected_memory_kv = tf.split(
            projected_memory_kv,
            num_or_size_splits=self.num_layers,
            axis=-1,
        )

        for i in range(self.num_layers):
            tar_seq = self.dec_layers[i](
                tar_seq,
                projected_memory_kv[i],
                causal_mask=None,
                padding_mask=dec_padding_mask,
                training=training,
            )

        # Cross-attention transformed [BOS, SID0, SID1, SID01]. SID0 and SID1
        # consume their transformed autoregressive prefixes. SID2 consumes all
        # four transformed queries, including transformed SID01. No raw
        # pre-attention SID/SID01 embedding is concatenated into a head.
        transformed_sid_seq = tf.unstack(
            tar_seq,
            num=self.num_codebooks + 1,
            axis=1,
        )

        codebook_first_hidden = []
        for codebook_idx in range(self.num_codebooks):
            if codebook_idx < self.num_codebooks - 1:
                transformed_sid_prefix = transformed_sid_seq[
                    : codebook_idx + 1
                ]
            else:
                transformed_sid_prefix = transformed_sid_seq

            parts = transformed_sid_prefix + [sparse_input]
            emb_concat = tf.concat(parts, axis=1)
            x = self.codebook_mlp[codebook_idx](
                emb_concat, training=training
            )
            codebook_first_hidden.append(x)

        # 3 x ([B, 512] -> [B, 256] -> [B, 128] -> [B, V]) becomes
        # [B, 3, 512] followed by three grouped BatchMatMul operations.
        x = tf.stack(codebook_first_hidden, axis=1)
        x = gelu(self.codebook_hidden2(x))
        x = gelu(self.codebook_hidden3(x))
        x = self.codebook_dropout_layer(x, training=training)
        codebook_logits = self.codebook_output_layer(x)

        # Return temperature-scaled logits. The caller computes sparse CE,
        # GT probability and top-k directly without materializing 3 softmaxes.
        temperatures = tf.reshape(
            tf.constant(
                self.head_temperatures,
                dtype=codebook_logits.dtype,
            ),
            [1, self.num_codebooks, 1],
        )
        codebook_logits = codebook_logits / temperatures
        return tf.unstack(
            codebook_logits,
            num=self.num_codebooks,
            axis=1,
        )


class CategoryEmbedding(tf.keras.layers.Layer):
    def __init__(
        self,
        index,
        sid_codebooks,
        vocab_size=512,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.index = index
        self.sid_codebooks = sid_codebooks
        self.vocab_size = vocab_size

    def build(self, input_shape):
        super().build(input_shape)

    def call(self, idx):
        idx_int32 = tf.cast(idx, tf.int32)
        idx_int32 = idx_int32 % self.vocab_size
        return tf.gather(self.sid_codebooks[self.index], idx_int32)

    def get_config(self):
        config = {'index': self.index, 'vocab_size': self.vocab_size}
        base_config = super().get_config()
        base_config.update(config)
        return base_config
