# ----------------------
# Created on Thu Dec 02 2021
# Author: Lu Yin
# ----------------------
import yaml
from itertools import chain, groupby
from collections import OrderedDict
from utils.tools import deprecated

class FGConf:
    def __init__(self, fg_yaml_obj=None, mc_yaml_obj=None):
        self.fg_conf = fg_yaml_obj
        self.shared_names = None
        self.iterable_names = None

    def load(self, path):
        with open(path, "r") as fh:
            self.fg_conf = yaml.safe_load(fh)
        return self

    def get_conf(self, **kvs):
        res = []
        for conf in chain(self.fg_conf["shared"], self.fg_conf["iterable"]):
            if all(
                    [
                        key == "slot"
                        and conf.get("export")
                        and conf["export"]["slot"] == val
                        or conf.get(key) == val
                        for key, val in kvs.items()
                    ]
            ):
                res.append(conf)
        return res

    def get_matched_seq_confs(self, name, action_type):
        res = []
        for conf in chain(self.fg_conf["shared"], self.fg_conf["iterable"]):
            if (
                    name in conf["name"]
                    and conf.get("params")
                    and conf["params"].get("action_type") == action_type
            ):
                res.append(conf)
        if len(res) > 0:
            assert (
                x["params"]["history_len"] == res[0]["params"]["history_len"]
                for x in res
            )
        return res

    def get_slots(self, names):
        res = []
        for name in names:
            confs = self.get_conf(name=name)
            if not len(confs):
                raise KeyError("name: {} not found".format(name))
            if len(confs) > 1:
                raise KeyError("name: {} matchs multiple conf: {}".format(name, confs))
            res.append(confs[0]["export"]["slot"])
        return res

    def get_conf_by_slots(self, slots):
        res = []
        for slot in slots:
            confs = self.get_conf(slot=slot)
            if not len(confs):
                raise KeyError("slot: {} not found".format(slot))
            if len(confs) > 1:
                raise KeyError("slot: {} matchs multiple conf: {}".format(slot, confs))
            res.append(confs[0])
        return res

    def get_conf_by_slot_multi(self, slots):
        res = []
        for slot in slots:
            confs = self.get_conf(slot=slot)
            if not len(confs):
                raise KeyError("slot: {} not found".format(slot))
            if len(confs) > 1:
                print("slot: {} matchs multiple conf: {}".format(slot, confs))
            res += confs
        return res

    def get_shared_names(self):
        if not self.shared_names:
            self.shared_names = [conf["name"] for conf in self.fg_conf["shared"]]
        return self.shared_names

    def get_iterable_names(self):
        if not self.iterable_names:
            self.iterable_names = [conf["name"] for conf in self.fg_conf["iterable"]]
        return self.iterable_names

class FGConfV2(FGConf):
    def get_conf(self, **kvs):
        res = []
        for conf in self.fg_conf["nodes"]:
            if all(
                    [
                        key == "slot_id"
                        and conf.get("export_config_list")
                        and conf["export_config_list"][0]["slot_id"] == val
                        or conf.get(key) == val
                        for key, val in kvs.items()
                    ]
            ):
                res.append(conf)
        return res

    def get_matched_seq_confs(self, name, action_type):
        res = []
        for conf in self.fg_conf["nodes"]:
            if (
                    name in conf["name"]
                    and conf.get("operator_config")
                    and conf["operator_config"].get("action") == action_type
            ):
                res.append(conf)

        return res

    def get_slots(self, names):
        res = []
        for name in names:
            confs = self.get_conf(name=name)
            if not len(confs):
                raise KeyError("name: {} not found".format(name))
            if len(confs) > 1:
                raise KeyError("name: {} matchs multiple conf: {}".format(name, confs))
            res.append(confs[0]["export_config_list"][0]["slot_id"])
        return res

    def get_conf_by_slots(self, slots):
        res = []
        for slot in slots:
            confs = self.get_conf(slot=slot)
            if not len(confs):
                raise KeyError("slot: {} not found".format(slot))
            if len(confs) > 1:
                raise KeyError("slot: {} matchs multiple conf: {}".format(slot, confs))
            res.append(confs[0])
        return res

    def get_conf_by_slot_multi(self, slots):
        res = []
        for slot in slots:
            confs = self.get_conf(slot=slot)
            if not len(confs):
                raise KeyError("slot: {} not found".format(slot))
            if len(confs) > 1:
                print("slot: {} matchs multiple conf: {}".format(slot, confs))
            res += confs
        return res

    def get_shared_names(self):
        if not self.shared_names:
            self.shared_names = [conf["name"] for conf in self.fg_conf["nodes"] if conf["iterable_type"] == ""]
        return self.shared_names

    def get_iterable_names(self):
        if not self.iterable_names:
            self.iterable_names = [conf["name"] for conf in self.fg_conf["iterable"] if conf["iterable_type"] == "item"]
        return self.iterable_names





@deprecated("use ModelColumnUtil")
def to_export_yaml(fg_conf, mc_conf, dense_slots=None, onehot_slots=None):
    if not fg_conf or not mc_conf:
        raise AttributeError("conf not init")
    mc_used_cols = set([x["name"] for x in chain(*mc_conf.values())])
    sparse_ids = [
        conf["export"]["slot"]
        for conf in chain(fg_conf["shared"], fg_conf["iterable"])
        if conf["name"] in mc_used_cols
    ]
    sparse = {"export_name": "sparse", "slot_ids": sparse_ids}
    final_dense_slots = []
    if dense_slots is not None and dense_slots:
        dense = {
            "export_name": "dense",
            "slot_ids": dense_slots,
        }
        final_dense_slots.append(dense)
    if onehot_slots is not None and onehot_slots:
        onehot = {
            "export_name": "onehot",
            "slot_ids": onehot_slots,
        }
        final_dense_slots.append(onehot)


    export = {"sparse": [sparse]}
    if len(final_dense_slots) > 0:
        export["dense"] = final_dense_slots
    return export

@deprecated("use ModelColumnUtil")
def to_export_yaml_v2(fg_conf, mc_conf, dense_slots=None, onehot_slots=None):
    # to be deprecated, use ModelColumnUtil.to_export_yaml
    if not fg_conf or not mc_conf:
        raise AttributeError("conf not init")
    mc_used_cols = set([x["name"] for x in chain(*mc_conf.values())])
    sparse_ids = [
        conf["export_config_list"][0]["slot_id"]
        for conf in fg_conf["nodes"]
        if conf["name"] in mc_used_cols
    ]
    sparse = {"export_name": "sparse", "slot_ids": sparse_ids}
    final_dense_slots = []
    if dense_slots is not None and dense_slots:
        dense = {
            "export_name": "dense",
            "slot_ids": dense_slots,
        }
        final_dense_slots.append(dense)
    if onehot_slots is not None and onehot_slots:
        onehot = {
            "export_name": "onehot",
            "slot_ids": onehot_slots,
        }
        final_dense_slots.append(onehot)


    export = {"sparse": [sparse]}
    if len(final_dense_slots) > 0:
        export["dense"] = final_dense_slots
    return export

def get_hanging_hash_slot_confs_v2(fgyaml, mcyaml):
    mc_used_cols = {conf["name"]: conf for conf in chain(*mcyaml.values())}
    shared_id_pair = [[conf["name"],
                       conf["export_config_list"][0]["slot_id"],
                       conf["export_config_list"][0].get("sparse_hash_slot", conf["export_config_list"][0]["slot_id"])]
                      for conf in fgyaml["nodes"]
                      if "export_config_list" in conf]
    shared_conf_pair = [(slot_id, mc_used_cols[name], shared_id) for name, slot_id, shared_id in shared_id_pair
                        if name in mc_used_cols]
    shared_conf_pair = sorted(shared_conf_pair, key=lambda x: x[2])
    res = []
    for k, g in groupby(shared_conf_pair, key=lambda x: x[2]):
        ids, confs, _ = zip(*g)
        if len(ids) < 2:
            continue
        # print("hash_slot: {},\tshared_slots: {},\tmcconfs: {}".format(k, ids, confs))
        # assert len(set([conf["dim"] for conf in confs])) == 1
        if k not in ids:
            hanging = {
                "slot_id": k,
                "dim": confs[0]["dim"]
            }
            res.append(hanging)
    return res


class ModelColumnUtil:
    def __init__(self, fgconf, mcconf, mc_only=False):
        self.fgconf = fgconf
        self.mcconf = mcconf
        self.mc_only = mc_only
        self.hanging_slot_info = []
        self.fp_col_conf_flat_map = {
            conf["name"]: conf for conf in chain(*self.mcconf.values()) if conf.get("from_fp", False) == True
        }
        self.non_fp_col_conf_flat_map = {
            conf["name"]: conf for conf in chain(*self.mcconf.values()) if conf.get("from_fp", False) == False
        }
        if self.fgconf is None or self.mc_only:
            print("ModelColumnUtil: no fgconf given, goes to mcconf-only mode, please make sure all features in mcconf.yaml have been set from_fp=False")
            print("ModelColumnUtil: note in mcconf-only mode, hanging slot info can't be parsed")
            assert len(self.fp_col_conf_flat_map) == 0
            self.mc_only = True
        self.col_conf_flat_map = {**self.fp_col_conf_flat_map, **self.non_fp_col_conf_flat_map}
        fp_slot_pair = []
        if not self.mc_only:
            self.hanging_slot_info = get_hanging_hash_slot_confs_v2(fgconf.fg_conf, mcconf)
            fp_used_cols = list(self.fp_col_conf_flat_map.keys())
            fp_col_slots = self.fgconf.get_slots(fp_used_cols)
            fp_slot_pair = [(fp_col_slots[i], fp_used_cols[i]) for i in range(len(fp_used_cols))]
        non_fp_slot_pair = [(conf["slot_id"], conf["name"]) for conf in self.non_fp_col_conf_flat_map.values()]
        self.used_slot_map = OrderedDict(
            sorted(
                fp_slot_pair + non_fp_slot_pair,
                key=lambda x: x[0],
                )
        )

        self.col_slots = list(self.used_slot_map.keys())
        self.col_aggregators = []
        self.col_dims = []
        for name in self.used_slot_map.values():
            aggregator = self.col_conf_flat_map[name]["aggregator"]
            if aggregator in ("tile", "tile_nf"):
                if "length" in self.col_conf_flat_map[name]:
                    dim = (self.col_conf_flat_map[name]["length"], self.col_conf_flat_map[name]["dim"])
                else:
                    raise AttributeError("tile feature {} has no length".format(name))
            else:
                dim = self.col_conf_flat_map[name]["dim"]
            self.col_aggregators.append(aggregator)
            self.col_dims.append(dim)

        self.no_export_slots = [slot for slot, name in self.used_slot_map.items() if self.col_conf_flat_map[name].get("export", True) == False]

    def get_shared_names(self):
        fp_shared_names = []
        if not self.mc_only:
            fp_shared_names = self.fgconf.get_shared_names()
        non_fp_shared_names = [conf["name"] for conf in self.non_fp_col_conf_flat_map.values() if conf.get("is_shared", False) == True]
        return fp_shared_names + non_fp_shared_names

    def get_iterable_names(self):
        fp_iterable_names = []
        if not self.mc_only:
            fp_iterable_names = self.fgconf.get_iterabel_names()
        non_fp_iterable_names = [conf["name"] for conf in self.non_fp_col_conf_flat_map.values() if conf.get("is_shared", False) == False]
        return fp_iterable_names + non_fp_iterable_names

    def to_export_yaml(self, dense_slots=None, onehot_slots=None):
        sparse_ids = self.col_slots
        if len(self.no_export_slots):
            print("to_export_yaml: filter no_export_slots:", self.no_export_slots)
            sparse_ids = [slot for slot in sparse_ids if slot not in self.no_export_slots]
        sparse = {"export_name": "sparse", "slot_ids": sparse_ids}
        final_dense_slots = []
        if dense_slots is not None and dense_slots:
            dense = {
                "export_name": "dense",
                "slot_ids": dense_slots,
            }
            final_dense_slots.append(dense)
        if onehot_slots is not None and onehot_slots:
            onehot = {
                "export_name": "onehot",
                "slot_ids": onehot_slots,
            }
            final_dense_slots.append(onehot)


        export = {"sparse": [sparse]}
        if len(final_dense_slots) > 0:
            export["dense"] = final_dense_slots
        return export



if __name__ == "__main__":
    fgconf = FGConf().load("configs/convert_din_share_fgv2.yaml").fg_conf
    with open("configs/mcconf_din_share.yaml", "r") as fh:
        mcconf = yaml.safe_load(fh)
    print(get_hanging_hash_slot_confs_v2(fgconf, mcconf))
