# -*- coding: utf-8 -*-

"""RankMixer layers for producing a mixed token sequence."""

import tensorflow as tf
from tensorflow.python.keras.layers import LayerNormalization


def truncated_normal_initializer():
    return tf.keras.initializers.TruncatedNormal(stddev=0.001)


class GroupedSwiGLU(tf.keras.layers.Layer):
    """Apply independent SwiGLU projections with one batched matmul.

    Input/output shapes are ``[B, G, input_dim]`` and
    ``[B, G, output_dim]``.  The kernel shape is
    ``[G, input_dim, 2 * output_dim]``; consequently every group keeps its
    own parameters even though all group projections are dispatched as one
    ``BatchMatMul`` instead of ``G`` separate Dense ops.
    """

    def __init__(
        self,
        num_groups,
        output_dim,
        kernel_initializer=None,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.num_groups = num_groups
        self.output_dim = output_dim
        self.kernel_initializer = (
            kernel_initializer or truncated_normal_initializer()
        )

    def build(self, input_shape):
        input_shape = tf.TensorShape(input_shape)
        input_dim = input_shape[-1]
        static_num_groups = input_shape[-2]
        if input_dim is None:
            raise ValueError("GroupedSwiGLU requires a static input dimension")
        if (
            static_num_groups is not None
            and int(static_num_groups) != self.num_groups
        ):
            raise ValueError(
                "expected {} groups, got {}".format(
                    self.num_groups, int(static_num_groups)
                )
            )

        self.kernel = self.add_weight(
            name="kernel",
            shape=[self.num_groups, int(input_dim), self.output_dim * 2],
            initializer=self.kernel_initializer,
            trainable=True,
        )
        self.bias = self.add_weight(
            name="bias",
            shape=[self.num_groups, self.output_dim * 2],
            initializer="zeros",
            trainable=True,
        )
        super().build(input_shape)

    def call(self, inputs):
        # BatchMatMul over the group dimension:
        # [B, G, I] -> [G, B, I] x [G, I, 2O] -> [G, B, 2O].
        group_major_inputs = tf.transpose(inputs, perm=[1, 0, 2])
        projected = tf.matmul(group_major_inputs, self.kernel)
        projected = projected + self.bias[:, tf.newaxis, :]
        value, gate = tf.split(projected, 2, axis=-1)
        outputs = value * tf.nn.silu(gate)
        return tf.transpose(outputs, perm=[1, 0, 2])


class RankMixerLargeBlock(tf.keras.layers.Layer):
    """One large RankMixer block using a fixed number of split groups.

    Input/output shape: ``[B, N, D]``.

    The large variant splits every token into ``G`` groups rather than using
    the token count as the split count:

    ``[B, N, D] -> [B, N, G, D/G] -> [B, G, N*D/G]``.
    """

    def __init__(self, num_tokens, token_dim, split_group_num=8, **kwargs):
        super().__init__(**kwargs)
        if token_dim % split_group_num != 0:
            raise ValueError(
                "token_dim={} must be divisible by split_group_num={}".format(
                    token_dim, split_group_num
                )
            )

        self.num_tokens = num_tokens
        self.token_dim = token_dim
        self.split_group_num = split_group_num
        # 7 * 256 / 8 = 224
        self.mixed_token_dim = num_tokens * token_dim // split_group_num

        self.mix_ffn = GroupedSwiGLU(
            num_groups=split_group_num,
            output_dim=self.mixed_token_dim,
            name="mix_grouped_swiglu",
        )
        self.mix_norm = LayerNormalization(name="mix_norm")
        self.token_ffn = GroupedSwiGLU(
            num_groups=num_tokens,
            output_dim=token_dim,
            name="token_grouped_swiglu",
        )
        self.token_norm = LayerNormalization(name="token_norm")

    def call(self, tokens):
        # [B, N, D] -> [B, G, N*D/G]
        # [B, 7, 256] -> [B, 8, 224]
        tokens_mixed = tf.reshape(
            tf.transpose(
                tf.reshape(
                    tokens,
                    [
                        -1,
                        self.num_tokens,
                        self.split_group_num,
                        self.token_dim // self.split_group_num,
                    ],
                ),
                perm=[0, 2, 1, 3],
            ),
            [-1, self.split_group_num, self.mixed_token_dim],
        )

        mixed_ffn = self.mix_ffn(tokens_mixed) # (B, 8, 224)
        mixed_output = self.mix_norm(mixed_ffn + tokens_mixed)

        # [B, G, N*D/G] -> [B, N, D]
        tokens_reverted = tf.reshape(
            tf.transpose(
                tf.reshape(
                    mixed_output,
                    [
                        -1,
                        self.split_group_num,
                        self.num_tokens,
                        self.token_dim // self.split_group_num,
                    ],
                ),
                perm=[0, 2, 1, 3],
            ),
            [-1, self.num_tokens, self.token_dim],
        )

        token_ffn = self.token_ffn(tokens_reverted)
        return self.token_norm(token_ffn + tokens)


class RankMixerLargeEncoder(tf.keras.layers.Layer):
    """Encode heterogeneous tokens as a mixed ``[B, N, D]`` sequence."""

    def __init__(
        self,
        num_tokens,
        token_dim=256,
        num_blocks=1,
        split_group_num=8,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.num_tokens = num_tokens
        self.token_dim = token_dim
        self.token_projections = [
            tf.keras.layers.Dense(
                token_dim,
                kernel_initializer=truncated_normal_initializer(),
                bias_initializer="zeros",
                name="token_projection_{}".format(i),
            )
            for i in range(num_tokens)
        ]
        self.input_norm = LayerNormalization(name="input_norm")
        self.blocks = [
            RankMixerLargeBlock(
                num_tokens=num_tokens,
                token_dim=token_dim,
                split_group_num=split_group_num,
                name="block_{}".format(i),
            )
            for i in range(num_blocks)
        ]

    def call(self, token_inputs):
        if len(token_inputs) != self.num_tokens:
            raise ValueError(
                "expected {} tokens, got {}".format(
                    self.num_tokens, len(token_inputs)
                )
            )

        # Heterogeneous [B, D_i] inputs -> [B, N, D].
        tokens = tf.stack(
            [
                projection(token)
                for projection, token in zip(
                    self.token_projections, token_inputs
                )
            ],
            axis=1,
        )
        tokens = self.input_norm(tokens)
        for block in self.blocks:
            tokens = block(tokens)

        return tokens  # [B, N, D], currently [B, 7, 256].
