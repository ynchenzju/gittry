# from ego.variable import Variable
import tensorflow as tf

def cross_entropy_loss(label,pred):
    return tf.multiply(label, -tf.log(pred + 1e-8)) + tf.multiply(tf.subtract(1.0, label), -tf.log(tf.subtract(1.0, pred) + 1e-8))

def default_fusion(click, cart, order):
    return click**0.8 * (cart**1.2 + order**1.2 + 0.4)

def multitask_loss(losses, loss_weights, target_names):
    multitask = []
    for loss, loss_weight, target_name in list(zip(losses, loss_weights, target_names)):
        loss = tf.math.reduce_sum(loss, name=target_name + "_batchloss")
        multitask.append(loss * -loss_weight)
    return sum(multitask)


def grad_norm(losses, shared_inputs, phase, loss_names=None, scale=1.0, loss_pow=2.0, relative_diff=False):
    '''
    final_loss = weighted_loss + gnorm_loss
    @params:
        losses: list of losses without weighting
        shared_inputs: list of weights which are shared
        loss_names:
        scale: the weight for grad norm loss
    '''
    if len(losses) <= 1:
        raise ValueError('len(losses) must be larger than 1')
    if not loss_names:
        loss_names = [str(i) for i in range(len(losses))]
    if len(loss_names) != len(losses):
        raise ValueError('len(loss_names) != len(losses)')
    if not isinstance(shared_inputs, list):
        share_inputs = [shared_inputs]
    n = len(losses)
    def get_norm(grad):
        return (tf.reduce_sum(tf.multiply(grad, grad)))**0.5
    print('losses: ', losses)
    print('shared_inputs: ', shared_inputs)
    #weight = ego.get_variable('grad_norm_weights', [n], initializers.Zeros())
    weights = tf.get_variable(f'p{phase}_grad_norm_weights', shape=n, initializer=tf.zeros_initializer())

    weights = tf.nn.softmax(weights)
    print('weights: ', weights)
    grads = [tf.gradients(loss, shared_inputs) for loss in losses]
    print('grads: ', grads)
    grads = [tf.concat(gs, axis=1) for gs in grads]
    print('grads: ', grads)
    gnorms = [get_norm(g) for g in grads]
    print('gnorms: ', gnorms)
    print('tf.stack(gnorms, axis=0)', tf.stack(gnorms, axis=0))
    gnorms = tf.stop_gradient(tf.stack(gnorms, axis=0))
    print('gnorms: ', gnorms)
    avgnorm = tf.reduce_sum(gnorms * weights) / n
    print('avgnorm: ', avgnorm)
    wgnorms = gnorms * weights

    # the loss can be very small since the gradients are small, we need to scale it to a larger value to avoid optimization problem
    grad_diff = tf.abs(wgnorms - avgnorm)
    if relative_diff:
        grad_diff = grad_diff / (avgnorm + 1e-6)
    gnorm_loss = tf.reduce_sum(grad_diff ** loss_pow) * scale
    weighted_loss = tf.reduce_sum(tf.stack(losses, axis=0) * tf.stop_gradient(weights))
    #for i in range(n):
    #tf.summary.scalar('gradnorm/weight_{}'.format(loss_names[i]), weights[i])
    return gnorm_loss, weighted_loss, weights

