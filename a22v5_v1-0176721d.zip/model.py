from typing import Dict, List
import json

import tensorflow as tf
import ego
from layer_xla import TransformerModel
import config as C



## beamsearch_metric
user_beamsearch_metric = False
dump_tensor = []
print(f"[user_beamsearch_metric]: {user_beamsearch_metric}")
# OTHER
USE_CKPT = True

MM_FEATURES = "8000,8001,10002,10502,11002,10003,10503,11003,12345,12346,11502,11503".strip().split(",")
MM_FEATURES = [e.strip() for e in MM_FEATURES]

# use tensorboard
USE_TB = True   
TB_SCALARS = []

param_initializer = tf.keras.initializers.glorot_normal()
bias_initializer = tf.keras.initializers.Zeros()
# dropout_rate_all = 0.1


def load_yaml(path, load_keys=None):
    import yaml 
    with open(path, mode="r") as f:
        configs = yaml.safe_load(f)

    res = []
    res_all = []
    res_dict = {}
    print("[load_yaml] keys =", configs.keys())
    for k, vals in configs.items():
        for v in vals:
            assert 'slot_id' in v
            slot_id = v['slot_id']
            if load_keys and k in load_keys:
                res.append(slot_id)   
                assert 'dim' in v
                assert slot_id not in res_dict, f"[!] {slot_id} is exist res_dict"
                res_dict[slot_id] = v['dim']
            res_all.append(slot_id)

    return res, res_dict, res_all

feature_groups = ["ub_seq_pooling", "user",  
'ub_clk_img_seq', 'ub_clk_title_seq', 'ub_cart_img_seq', 'ub_cart_title_seq', 'ub_order_img_seq', 'ub_order_title_seq',
'ub_clk_500_img_seq', 'ub_clk_500_title_seq'
]
full_user_slot_ids, full_user_slot_dict, all_slot_ids = load_yaml("config/mcconf_v2000.yaml", load_keys=feature_groups)

print(f"[all_slot_ids] {all_slot_ids}")
print(f"[full_user_slot_ids] {full_user_slot_ids}")
print(f"[full_user_slot_dict] {full_user_slot_dict}")

HIT_SLOT_IDS = []
LONG_HIT_SLOT_IDS = []

SLOT_IDS = full_user_slot_ids + HIT_SLOT_IDS + LONG_HIT_SLOT_IDS

slot_id_list = SLOT_IDS


# 2104 2204 2304 hash slot 不同
SEQ_FEAT_DICT = {
    "ub_click_long_term": {2211: 2001, 2104: 2010, 10002: 8000, 10003: 8001},
    "ub_cart_long_term":  {2212: 2001, 2204: 2010, 10502: 8000, 10503: 8001},
    "ub_order_long_term": {2213: 2001, 2304: 2010, 11002: 8000, 11003: 8001},
}
# SEQ_FEAT_DICT = {
#     "ub_click_long_term": {2211: 2001, 2104: 2010, 2132: 3001, 10002: 8000, 10003: 8001},
#     "ub_cart_long_term":  {2212: 2001, 2204: 2010, 2232: 3001, 10502: 8000, 10503: 8001},
#     "ub_order_long_term": {2213: 2001, 2304: 2010, 2332: 3001, 11002: 8000, 11003: 8001},
# }

# 2104 2204 2304 hash slot 不同
SEQ_FEAT_DICT = {
    "ub_click_long_term": {2211: 2001, 2104: 2010, 10002: 8000, 10003: 8001},
    "ub_cart_long_term":  {2212: 2001, 2204: 2010, 10502: 8000, 10503: 8001},
    "ub_order_long_term": {2213: 2001, 2304: 2010, 11002: 8000, 11003: 8001},
}
# SEQ_FEAT_DICT = {
#     "ub_click_long_term": {2211: 2001, 2104: 2010, 2132: 3001, 10002: 8000, 10003: 8001},
#     "ub_cart_long_term":  {2212: 2001, 2204: 2010, 2232: 3001, 10502: 8000, 10503: 8001},
#     "ub_order_long_term": {2213: 2001, 2304: 2010, 2332: 3001, 11002: 8000, 11003: 8001},
# }


SEQ_FEAT_LEN = {
    "ub_click_long_term": 50,
    "ub_cart_long_term": 20,
    "ub_order_long_term": 20,
}


# [2001, 2011, 8000, 8001]
# EXPO_SEQ_FEAT_DICT = {
#     "ub_unclick_long_term": {1276: 2001, 28542: 2010, 11502: 8000, 11503: 8001},
# }


# EXPO_SEQ_FEAT_LEN = {
#     "ub_unclick_long_term": 20
# }

# din slot ids
delete_slots = []
for d in SEQ_FEAT_DICT.values():
    delete_slots.extend(list(d.keys()))
print("SEQ_FEAT_DICT delete slot: ", delete_slots)


############# [long seq features]
FEATURE_LIST = [24771, 24776, 12345, 12346]
# ults_origin_click_itemid	ID:24771 [SPARSE] Shared Sparse Slot ID:2001
# ults_origin_order_itemid	ID:24776 [SPARSE] Shared Sparse Slot ID:2001

delete_slots += FEATURE_LIST
# expo din slot
# for d in EXPO_SEQ_FEAT_DICT.values():
#     delete_slots.extend(list(d.keys()))
# print("EXPO_SEQ_FEAT_DICT delete slot: ", delete_slots)


ego.config_default_nn_optimizer(learning_rate=0.005)
ego.import_extra_slots([2001, 2004, 2010, 3001, 2011, 16001, 8000, 8001], dims=[32, 32, 32, 32, 32, 32, 33, 33])  # 导入可能使用的embedding
ego.config_feature_admission_evict(vec_create_threshold=1, delete_threshold=0,
                                   delete_after_unseen_days=90 * 24)  # 用来控制embedding的准入准出
SLOT_IDS = [i for i in SLOT_IDS if i not in delete_slots]

user_slot_ids = [item for item in SLOT_IDS if item in full_user_slot_ids]
sparse_slot_ids = [item for item in SLOT_IDS if item not in full_user_slot_ids]

# print("begin to check the list")
# print(set(user_slot_ids) - set(full_user_slot_ids))
# total_set = set(user_slot_ids).union(set(sparse_slot_ids))
# print(len(user_slot_ids), len(sparse_slot_ids), len(SLOT_IDS), len(total_set), total_set == set(SLOT_IDS))
slot_dims = [33 if str(slot) in MM_FEATURES else 32 for slot in user_slot_ids]
user_input = ego.get_slots(name='user_input',
                             slots=user_slot_ids,
                             dims=slot_dims,
                             poolings=[ego.Pooling.SUM] * len(user_slot_ids),
                             feature_type=ego.FeatureType.UNDEFINED)  # [TODO] ego.FeatureType.COMMON ?


user_inputs = tf.split(user_input, len(user_slot_ids), axis=1)
sf_dict = {**dict(zip(user_slot_ids, user_inputs))}
sparse_input = tf.concat([sf_dict[id] for id in user_slot_ids], axis = 1)

sparse_input = ego.BatchNormalization(name="sparse_input_bn", epsilon=1e-3)(sparse_input) 


"""创建用于类目预测的Transformer模型"""

# 输入：[batch, seq_len, d_model]

d_model=128
num_heads=4 
num_layers=3 
dff=int(3*128)
num_categories=4000
subcat_num_categories = 282
thirdcat_num_categories = 1203

num_codebooks=3
beam_code_len=4
dropout_rate=0.01


outs = []
for index in range(len(FEATURE_LIST)):
    slot = FEATURE_LIST[index]
    dim = 32
    new_dim = dim
    if str(slot) in MM_FEATURES:
        print(f"[MM_FEATURES_LONG] {slot}")
        new_dim = dim + 1
       
    print(f"[GET_SLOTS_LONG] slot={slot}, dim={dim}, new_dim={new_dim}")  
    out, _ = (
        ego.get_slots(name=f"{slot}_{index}", slots=[FEATURE_LIST[index]], dims=[(200, new_dim)],
                    poolings=[ego.Pooling.TILE_NF], feature_type=ego.FeatureType.UNDEFINED))
    if new_dim > dim:
        out = tf.stop_gradient(out, name=f"{slot}_{index}_stop_gradient")
        out = out[:, :, 1:]
        out_norm = tf.nn.l2_normalize(out, axis=-1, epsilon=1e-6, name=f'{slot}_{index}_l2_norm')
    else:
        out_norm = ego.BatchNormalization(name=f"batch_norm_{slot}_{index}", epsilon=1e-3)(out) 
    outs.append(out_norm)
user_long_seq = tf.concat(outs, axis=-1) #[batch_size, seq_len, emb_dim]

user_long_seq_pooling = tf.reduce_mean(user_long_seq, axis=1) #[batch_size, emb_dim]
    


############## short seq features
emb_dim = 32

# SEQ_FEAT_DICT = {
#     "video_product_click": {41187: 2602, 41196: 3306, 41229: 3305, 41676: 3303},
#     "video_product_cart": {41188: 2602, 41202: 3306, 41230: 3305, 41675: 3303},
#     "video_product_order": {41189: 2602, 41171: 3306, 41232: 3305, 41674: 3303},
#     "video_ecom_session": {3105: 2602, 3108: 3306, 3107: 3305, 3106: 3303},
#     "video_sequence_dd_click": {40545: 1591, 40547: 1614, 40546: 1593, 40549: 1737, 40550: 1738, 40551: 1741},
#     "video_sequence_click": {3332: 1591, 3333: 1614, 3338: 1593, 3334: 1737, 3335: 1738, 3336: 1741},
#     "video_sequence_like": {2149: 1591, 2151: 1614, 2152: 1593, 2154: 1737, 2156: 1738, 2158: 1741},
# }
# EXPO_SEQ_FEAT_DICT = {
#     "ecom_seq_atc_click": {24973: 2602, 60663: 3304, 24439: 3303, 44151: 3305},
#     "ecom_seq_buynow_click": {26844: 3304, 13158: 3305, 2939: 2602, 64020: 3303},
#     "ecom_seq_finish_new": {44186: 3303, 44349: 3304, 18190: 2602, 2810: 3305}
# }

item_slot_list=[2602, 3303, 3305, 3306]
expo_item_slot_list=[2602, 3303, 3305, 3304]

expo_video_slot_list=[1591, 1593, 1737, 1738]
din_input_dict = {} # [batch, seq, emb_dim]


item_slot_list = [2001, 2010, 8000, 8001]
for _, v in SEQ_FEAT_DICT.items():
    assert len(item_slot_list) == len(v)
expo_item_slot_list=[2001, 2010, 8000, 8001]
# din_input_dict = {} # [batch, seq, emb_dim]

user_short_seq_dict = {}
user_short_seq_key = []
user_short_seq_pooling_list = []
for key, v in SEQ_FEAT_DICT.items():
    max_seq_length = SEQ_FEAT_LEN[key]
    fs = []
    outs = []
    target_dict = {}
    for index, (f, slot) in enumerate(v.items()):  # {41187: 2602, 41196: 3306, 41229: 3305, 41676: 3303}
        new_emb_dim = emb_dim
        if str(slot) in MM_FEATURES:
            new_emb_dim = emb_dim + 1
            print(f"[MM_FEATURES] {slot}")
        print(f"[GET_SLOTS] slot={slot}, emb_dim={emb_dim}, new_emb_dim={new_emb_dim}")  
        out, _ = (
            ego.get_slots(name="%s_din" % key + "_" + str(index), slots=[f], dims=[(max_seq_length, new_emb_dim)],
                        poolings=[ego.Pooling.TILE_NF], feature_type=ego.FeatureType.COMMON))

        if new_emb_dim > emb_dim:
            out = tf.stop_gradient(out, name=f"{key}_{index}_sg")
            out = out[:, :, 1:]
            out_norm = tf.nn.l2_normalize(out, axis=-1, epsilon=1e-6, name=f'{key}_{f}_l2_norm')
        else:
            out_norm = ego.BatchNormalization(name="batch_norm_%s_%s" % (key, f), epsilon=1e-3)(out) 
        target_dict[slot] = out_norm

    for slot in item_slot_list:
        outs.append(target_dict[slot])
    
    din_input = tf.concat(outs, axis=-1)
    user_short_seq_dict[key] = din_input # [[batch_size, seq_len, emb_dim]]
    user_short_seq_pooling_list.append(tf.reduce_mean(din_input, axis=1)) #[batch_size, emb_dim]
    user_short_seq_key.append(key)

# user_short_seq = tf.concat(user_short_seq, axis=1) #[batch_size, seq_len, emb_dim*feauture_size]
user_short_seq_pooling = tf.concat(user_short_seq_pooling_list, axis=1) #[batch_size, emb_dim*feauture_size]


def cross_entropy(y_true, y_pred, a=1):
    y_true = tf.cast(y_true, tf.float32)
    loss = - y_true * tf.math.log(y_pred + 1e-8) - (a - y_true) * tf.math.log(1.0 - y_pred + 1e-8)
    loss = tf.math.reduce_sum(loss, axis=-1, keepdims=True)
    return loss

def cross_entropy_weighted(y_true, y_pred, w_neg, a=1):
    y_true = tf.cast(y_true, tf.float32)
    loss = - y_true * tf.math.log(y_pred + 1e-8) - w_neg * (a - y_true) * tf.math.log(1.0 - y_pred + 1e-8)
    loss = tf.math.reduce_sum(loss, axis=-1, keepdims=True)
    return loss

def focal_entropy(y_true, y_pred, a=1):
    y_true = tf.cast(y_true, tf.float32)
    loss = - y_true * (1 - y_pred) * tf.math.log(y_pred + 1e-8) - (a - y_true) * y_pred * tf.math.log(
        1.0 - y_pred + 1e-8)
    loss = tf.math.reduce_sum(loss, axis=-1, keepdims=True)
    return loss


# 计算损失
# # multitask:0:1:0:1:0:0:0:0
if USE_CKPT:
    ITEM_LABEL_SLOTS = [8400]
    ego.config_feature_admission_evict(slots=ITEM_LABEL_SLOTS, create_clk_prob=0, create_nonclk_prob=0, delete_after_unseen_days=24*93)
    ITEM_LABEL_SLOT_DIM = 8
    ITEM_LABEL_NAME = "_".join([str(_) for _ in ITEM_LABEL_SLOTS])
    item_labels_raw = ego.get_slots(name=ITEM_LABEL_NAME,
                             slots=ITEM_LABEL_SLOTS,
                             dims=[ITEM_LABEL_SLOT_DIM] * len(ITEM_LABEL_SLOTS),
                             poolings=[ego.Pooling.SUM] * len(ITEM_LABEL_SLOTS),
                             feature_type=ego.FeatureType.UNDEFINED)

    item_labels = tf.stop_gradient(item_labels_raw, name="item_labe_stop_gradient")
    print("item_labels", item_labels)
    # item_labels = tf.cast(item_labels, dtype=tf.int32)
    _, label0, label1, label2, label3, label4, _label5, _label6 = tf.split(item_labels, axis=1, num_or_size_splits=ITEM_LABEL_SLOT_DIM)
    label_weights = [tf.ones_like(label0, name=f"label_weight_{i}", dtype=tf.float32) for i in range(ITEM_LABEL_SLOT_DIM)]
    CTR_LABEL_IDX = 0
    weigthed_label, click_w = ego.get_label_weight(target_name="label", label_idx=CTR_LABEL_IDX)
    ctr_label = tf.identity(weigthed_label, name="ctr_label_inp")
    CVR_LABEL_IDX = 2

    cvr_label, _ = ego.get_label_weight(target_name="cvr_label", label_idx=CVR_LABEL_IDX)
    print("ctr_label", ctr_label)
    print("cvr_label", cvr_label)
    print("click_w", click_w)
    print("weigthed_label", weigthed_label)
    print("label_weights", label_weights)
    new_label_weights = [tf.where(ctr_label > 0.5, 2.0 * wgt, wgt) for wgt in label_weights]
    new_label_weights = [tf.where(cvr_label > 0.5, 5.0 * wgt, wgt) for wgt in new_label_weights]
    w0, w1, w2, w3, w4, w5, w6, w7 = new_label_weights 
else:
    label0, w0 = ego.get_label_weight(target_name="video_item_semantic_id_v2_4000_0", label_idx=0)  # 选取multitask的第label_idx个label和对应的权重
    label1, w1 = ego.get_label_weight(target_name="video_item_semantic_id_v2_4000_1", label_idx=2)
    label2, w2 = ego.get_label_weight(target_name="video_item_semantic_id_v2_4000_2", label_idx=4)
    label3, w3 = ego.get_label_weight(target_name="item_internal_idx_v2_4000", label_idx=6)
    label3 = label3 % num_categories 
    label4, w4 = ego.get_label_weight(target_name="video_internal_idx_v2_4000", label_idx=8)
    label4 = label4 % num_categories 
    weigthed_label, click_w = ego.get_label_weight(target_name="label", label_idx=10)


#   - video_item_semantic_id_0
#   - video_item_semantic_id_1
#   - video_item_semantic_id_2
#   - item_internal_idx
#   - video_internal_idx
#   - label

# Transformer模型
# 真实序列

model = TransformerModel(
        num_layers=num_layers,
        d_model=d_model,
        num_heads=num_heads,
        dff=dff,
        target_vocab_size=[num_categories, num_categories, num_categories, num_categories, num_categories],
        dropout_rate=dropout_rate,
        num_codebooks=num_codebooks,
        user_short_seq_key=user_short_seq_key,
        name='category_transformer'
    )
# if ego.is_training_mode():
# target_seq = tf.cast(tf.concat(, axis=1), tf.int32) # [batch_size, 5, 32]


# 增加评估指标
def get_label_probabilities(category_predictions, label):
    """
    根据label索引从category_predictions中取出对应概率
    Args:
        category_predictions: [batch_size, num_classes] 
        label: [batch_size, 1] 或 [batch_size]
    Returns:
        label_probs: [batch_size] - 对应索引位置的概率
    """
    # 处理label形状，确保是[batch_size]
    if len(label.shape) == 2:
        label_flat = tf.squeeze(label, axis=1)  # [batch_size, 1] -> [batch_size]
    else:
        label_flat = label
    
    # 检查并处理NaN值，将NaN替换为0
    label_flat = tf.where(tf.math.is_nan(label_flat), tf.zeros_like(label_flat), label_flat)
    label_flat = tf.cast(label_flat, tf.int32)
    
    # 确保索引在有效范围内
    num_classes = tf.shape(category_predictions)[1]
    label_flat = tf.clip_by_value(label_flat, 0, num_classes - 1)
    
    # 创建索引对 [batch_idx, class_idx]
    batch_size = tf.shape(category_predictions)[0]
    batch_indices = tf.range(batch_size)  # [0, 1, 2, ..., batch_size-1]
    indices = tf.stack([batch_indices, label_flat], axis=1)  # [batch_size, 2]

    
    # 使用tf.gather_nd取出对应位置的概率
    label_probs = tf.gather_nd(category_predictions, indices)  # [batch_size]
    label_probs = tf.expand_dims(label_probs, axis=1)  # [batch_size, 1]
    
    return label_probs

def hr_topk(category_predictions, label, k=3):
    # 检查并处理NaN值，将NaN替换为0
    label_clean = tf.where(tf.math.is_nan(label), tf.zeros_like(label), label)
    
    topk_indices = tf.nn.top_k(category_predictions, k=k).indices  # [batch_size, k]
    true_labels = tf.cast(label_clean, tf.int32)  # [batch_size]
    
    # 确保标签在有效范围内
    num_classes = tf.shape(category_predictions)[1]
    true_labels = tf.clip_by_value(true_labels, 0, num_classes - 1)
    
    true_labels_expanded = true_labels
    top_k_match = tf.reduce_any(tf.equal(topk_indices, true_labels_expanded), axis=1)  # [batch_size]
    top_k_accuracy = tf.expand_dims(tf.cast(top_k_match, tf.float32), axis=1)  # [batch_size, 1]

    return top_k_accuracy

def user_level_infonce_loss(uid, scores, labels, temperature=1):
    """
    用户级别的InfoNCE损失函数
    
    Args:
        uid: [batch_size] 用户ID
        scores: [batch_size] 模型输出的分数
        labels: [batch_size] 标签，1表示正样本，0表示负样本
        temperature: 温度参数，控制分布的尖锐程度
    
    Returns:
        loss: 用户级别的InfoNCE损失
    """
    batch_size = tf.shape(uid)[0]
    
    # 确保输入维度正确
    uid = tf.reshape(uid, [-1])
    scores = tf.reshape(scores, [-1])
    labels = tf.reshape(labels, [-1])
    
    # 创建用户分组mask
    uid_expanded = tf.expand_dims(uid, 1)  # [batch_size, 1]
    uid_transposed = tf.expand_dims(uid, 0)  # [1, batch_size]
    user_mask = tf.equal(uid_expanded, uid_transposed)  # [batch_size, batch_size]
    
    # 计算相似度矩阵 (使用分数作为相似度)
    scores_expanded = tf.expand_dims(scores, 1)  # [batch_size, 1]
    similarity_matrix = tf.matmul(scores_expanded, tf.transpose(scores_expanded))  # [batch_size, batch_size]
    
    # 应用温度参数
    similarity_matrix = similarity_matrix / temperature
    
    # 创建正样本mask (同一用户内，正样本与正样本的相似度)
    labels_expanded = tf.expand_dims(labels, 1)  # [batch_size, 1]
    labels_transposed = tf.expand_dims(labels, 0)  # [1, batch_size]
    
    # 正样本对：同一用户且都是正样本
    positive_mask = tf.cast(
        tf.logical_and(
            tf.logical_and(user_mask, tf.equal(labels_expanded, 1)),
            tf.equal(labels_transposed, 1)
        ),
        tf.float32
    )
    
    # 移除对角线 (自己与自己的相似度)
    identity_matrix = tf.eye(batch_size, dtype=tf.float32)
    positive_mask = positive_mask * (1.0 - identity_matrix)
    
    # 计算InfoNCE损失
    exp_sim = tf.exp(similarity_matrix)
    
    # 对于每个样本，计算其与所有正样本的相似度
    positive_sim = tf.reduce_sum(exp_sim * positive_mask, axis=1, keepdims=True)
    
    # 计算每个用户组内的总相似度 (用于归一化)
    user_sim = tf.reduce_sum(exp_sim * tf.cast(user_mask, tf.float32), axis=1, keepdims=True)
    
    # 避免除零
    positive_sim = tf.maximum(positive_sim, 1e-8)
    user_sim = tf.maximum(user_sim, 1e-8)
    
    # 计算InfoNCE损失
    loss = -tf.reduce_sum(tf.math.log(positive_sim / user_sim))
    
    return loss

def get_beam_search_metric(beams, labels, sematic_size=4):
    """
    计算beam search的hit rate指标
    
    Args:
        beams: [batch_size, 4*200] 按分数排序的beam search结果
        labels: [batch_size, 4] 真实标签
    
    Returns:
        hit_rate_100: [batch_size, 1] top100的hit rate
        hit_rate_200: [batch_size, 1] top200的hit rate
    """
    batch_size = tf.shape(beams)[0]
    
    # 将beams reshape为 [batch_size, 200, 4]
    beams_reshaped = tf.reshape(beams, [batch_size, 200, sematic_size])
    
    # 确保labels是int32类型
    beams_reshaped = tf.cast(beams_reshaped, tf.int32)
    labels = tf.cast(labels, tf.int32)
    
    # 扩展labels维度用于比较: [batch_size, 1, 4]
    labels_expanded = tf.expand_dims(labels, 1)  # [batch_size, 1, 4]
    
    # 计算top100的hit rate
    beams_top100 = beams_reshaped[:, :100, :]  # [batch_size, 100, 4]
    
    # 比较top100: [batch_size, 100, 4] vs [batch_size, 1, 4]
    matches_100 = tf.reduce_all(tf.equal(beams_top100, labels_expanded), axis=2)  # equal结果是[batch_size, 100, 4] [batch_size, 100]
    hit_rate_100 = tf.reduce_any(matches_100, axis=1)  # [batch_size]
    hit_rate_100 = tf.expand_dims(tf.cast(hit_rate_100, tf.float32), axis=1)  # [batch_size, 1]
    
    # 计算top200的hit rate
    # 比较top200: [batch_size, 200, 4] vs [batch_size, 1, 4]
    matches_200 = tf.reduce_all(tf.equal(beams_reshaped, labels_expanded), axis=2)  # [batch_size, 200]
    hit_rate_200 = tf.reduce_any(matches_200, axis=1)  # [batch_size]
    hit_rate_200 = tf.expand_dims(tf.cast(hit_rate_200, tf.float32), axis=1)  # [batch_size, 1]
    
    return hit_rate_100, hit_rate_200


if ego.is_training_mode():
    training = True

    # sparse_input #[batch_size, emb_dim*feauture_size]
    # user_long_seq #[batch_size, seq_len, emb_dim]
    # user_short_seq #[batch_size, seq_len*n, emb_dim]

    sparse_input_concat = tf.concat([sparse_input, user_long_seq_pooling, user_short_seq_pooling], axis=1)

    category_predictions_0, category_predictions_1, category_predictions_2, category_predictions_3, category_predictions_4 = model([sparse_input_concat, user_long_seq, user_short_seq_dict], [label0, label1, label2, label3, label4], training=training)
    category_predictions_0 = tf.identity(category_predictions_0, name="semantic_id_0_probs")
    category_predictions_1 = tf.identity(category_predictions_1, name="semantic_id_1_probs")
    category_predictions_2 = tf.identity(category_predictions_2, name="semantic_id_2_probs")
    category_predictions_3 = tf.identity(category_predictions_3, name="semantic_id_3_probs")
    category_predictions_4 = tf.identity(category_predictions_4, name="semantic_id_4_probs")


    # topk命中率
    hit_ratio_0 = hr_topk(category_predictions_0, label0, k=3)
    hit_ratio_1 = hr_topk(category_predictions_1, label1, k=3)
    hit_ratio_2 = hr_topk(category_predictions_2, label2, k=3)
    hit_ratio_3 = hr_topk(category_predictions_3, label3, k=3)
    hit_ratio_4 = hr_topk(category_predictions_4, label4, k=3)

    ori_p0 = get_label_probabilities(category_predictions_0, label0)
    ori_p1 = get_label_probabilities(category_predictions_1, label1)
    ori_p2 = get_label_probabilities(category_predictions_2, label2)
    ori_p3 = get_label_probabilities(category_predictions_3, label3)
    ori_p4 = get_label_probabilities(category_predictions_4, label4)

    # codebook1_logits_raw =get_label_probabilities(codebook1_logits_raw, label2)
    # codebook2_logits_raw =get_label_probabilities(codebook2_logits_raw, label3)
    # codebook3_logits_raw =get_label_probabilities(codebook3_logits_raw, label3)
    # codebook4_logits_raw =get_label_probabilities(codebook4_logits_raw, label4)

    # all_logits = tf.identity(codebook1_logits_raw * codebook2_logits_raw * codebook3_logits_raw * codebook4_logits_raw, name="all_logits")

    semantic_id_0_prob = tf.identity(100 * ori_p0, name="semantic_id_0_prob")
    semantic_id_1_prob = tf.identity(100 * ori_p1, name="semantic_id_1_prob")
    semantic_id_2_prob = tf.identity(100 * ori_p2, name="semantic_id_2_prob")
    semantic_id_3_prob = tf.identity(100 * ori_p3, name="semantic_id_3_prob")
    semantic_id_4_prob = tf.identity(100 * ori_p4, name="semantic_id_4_prob")

    p0 = tf.identity(semantic_id_0_prob, name="union_p0")
    p1 = tf.identity(p0 * semantic_id_1_prob, name="union_p1")
    p2 = tf.identity(p1 * semantic_id_2_prob, name="union_p2")
    p3 = tf.identity(p2 * semantic_id_3_prob, name="union_p3")
    p4 = tf.identity(p3 * semantic_id_4_prob, name="union_p4")

    p0_v2 = tf.identity(ori_p0, name="union_p0_v2")
    p1_v2 = tf.identity(p0_v2 * ori_p1, name="union_p1_v2")
    p2_v2 = tf.identity(p1_v2 * ori_p2, name="union_p2_v2")
    p3_v2 = tf.identity(p2_v2 * ori_p3, name="union_p3_v2")
    p4_v2 = tf.identity(p3_v2 * ori_p4, name="union_p4_v2")

    # uid = ego.get_dense_feature(name="int64_hash_userid", dim=1, use_nsc=False, feature_type=ego.FeatureType.UNDEFINED, dtype=tf.int64)
    # infonce_loss = - user_level_infonce_loss(uid, p3, weigthed_label)

    # 负负得正，原始loss是-log(ori_p)，loss = -w * -log(ori_p) = w * log(ori_p)
    alpha0 = tf.constant(1.0, dtype=tf.float32)
    alpha1 = tf.constant(1.0, dtype=tf.float32)
    alpha2 = tf.constant(1.0, dtype=tf.float32)
    alpha3 = tf.constant(1.0, dtype=tf.float32)
    alpha4 = tf.constant(1.0, dtype=tf.float32)
    

    ntp_loss_p0 = alpha0 * w0 * tf.math.log(ori_p0 + 1e-8)
    ntp_loss_p1 = alpha1 * w1 * tf.math.log(ori_p1 + 1e-8)
    ntp_loss_p2 = alpha2 * w2 * tf.math.log(ori_p2 + 1e-8)

    ntp_loss = ntp_loss_p0 + ntp_loss_p1 + ntp_loss_p2
        #    alpha3 * w3 * tf.math.log(ori_p3 + 1e-8) + \
        #    alpha4 * w4 * tf.math.log(ori_p4 + 1e-8)

    # final_loss = ntp_loss + infonce_loss
    # ntp_loss = tf.reduce_sum(ntp_loss)
    # infonce_loss = tf.reduce_sum(infonce_loss)
    final_loss = tf.reduce_sum(ntp_loss)
    del sparse_input_concat

    if user_beamsearch_metric:
    ################### 增加beam search metric
        training = False
        beam_width = 200
        sparse_input_concat = tf.concat([sparse_input, user_long_seq_pooling, user_short_seq_pooling], axis=1)

        category_predictions_0, category_predictions_1, category_predictions_2, category_predictions_3, category_predictions_4 = model([sparse_input_concat, user_long_seq, user_short_seq_dict], [label0, label1, label2, label3, label4], training=training)

        beam_search_results, beams, scores = model.beam_search_decode(inputs=[sparse_input_concat, user_long_seq, user_short_seq_dict],
            beam_width=beam_width,
            max_len=num_codebooks, #没有使用 num_codebooks
            beam_code_len=beam_code_len,
            training=training,
            record_details=True)

        beam_search_results = tf.identity(beam_search_results, name="beam_search_results")

        beam_search_results_dump = tf.cast(tf.identity(beam_search_results, name="beam_search_results_dump"), tf.float32)

        # 选取解码码本，全部四个语义ID（删除前两个类目后）
        # beams = beams[:, :, 0:]  # ✅ 修复：现在只有4个输出，全部使用
        beams_p2 = beams[:, :, :beam_code_len] #到itemid前3个语义ID
        beams_p2 = tf.reshape(beams_p2, [-1, beam_width*beam_code_len]) # batch, beam_width * 3
        beams_p2 = tf.identity(tf.cast(beams_p2, tf.float32), name="beams_p2")

        beams = tf.reshape(beams, [-1, beam_width*beam_code_len]) # batch, beam_width * 4

        # beams = tf.cast(beams, tf.float32)
        beams = tf.identity(tf.cast(beams, tf.float32), name="beams")
        scores = tf.identity(tf.cast(scores, tf.float32), name="scores")

        
        # p3_hit_rate_100, p3_hit_rate_200 = get_beam_search_metric(beams, tf.concat([label0, label1, label2, label5], axis=1), sematic_size=4)

        p2_hit_rate_100, p2_hit_rate_200 = get_beam_search_metric(beams_p2, tf.concat([label0, label1, label2, tf.cast(tf.zeros_like(label0), tf.float32)], axis=1), sematic_size=beam_code_len)

        dump_tensor.extend([beams_p2, beams, scores, tf.concat([label0, label1, label2, tf.cast(tf.zeros_like(label0), tf.float32)], axis=1), p2_hit_rate_100, p2_hit_rate_200])

else:
    # print("[beam search]")
    training = False
    # batch, 200 * 3
    # 进行beam search解码
    beam_width = 200
    try:
        with open('online_compile_config.json') as f:
            cfg = json.load(f)
        b_width = int(cfg.get('beam_width', -1))
        if beam_width > 0:
            beam_width = b_width
        print(f"[!] using {beam_width}")
    except Exception as e:
        print(f"[{e}] loading fail, use default {beam_width}")

    sparse_input = tf.concat([sparse_input, user_long_seq_pooling, user_short_seq_pooling], axis=1)

    category_predictions_0, category_predictions_1, category_predictions_2, category_predictions_3, category_predictions_4 = model([sparse_input, user_long_seq, user_short_seq_dict], [label0, label1, label2, label3, label4], training=training)
    beam_search_results, beams, scores = model.beam_search_decode(inputs=[sparse_input, user_long_seq, user_short_seq_dict],
        beam_width=beam_width,
        max_len=num_codebooks, #没有使用 num_codebooks
        beam_code_len=beam_code_len,
        training=training,
        record_details=True)

    beam_search_results = tf.identity(beam_search_results, name="beam_search_results")

    beam_search_results_dump = tf.cast(tf.identity(beam_search_results, name="beam_search_results_dump"), tf.float32)

    # 选取解码码本，全部四个语义ID（删除前两个类目后）
    # beams = beams[:, :, 0:]  # ✅ 修复：现在只有4个输出，全部使用
    beams = tf.reshape(beams, [-1, beam_width*beam_code_len])
    # beams = tf.cast(beams, tf.float32)
    beams = tf.identity(tf.cast(beams, tf.float32), name="beams")
    beam_scores = tf.identity(tf.cast(scores, tf.float32), name="beam_scores")


variables = tf.get_collection(tf.compat.v1.GraphKeys.TRAINABLE_VARIABLES)
for i in variables:
    print(i)


ego.config_dump_tensor(with_sample_id=True)


if ego.is_training_mode():
    ego.Target("p0_predictions", p0, tf.identity(weigthed_label), tf.identity(click_w), hit_ratio_0, ego.MetricType.GAUC)
    ego.Target("p1_predictions", p1, tf.identity(weigthed_label), tf.identity(click_w), hit_ratio_1, ego.MetricType.GAUC)
    ego.Target("p2_predictions", p2, tf.identity(weigthed_label), tf.identity(click_w), hit_ratio_2, ego.MetricType.GAUC)
    # ego.Target("p3_predictions", p3, tf.identity(weigthed_label), tf.identity(click_w), hit_ratio_3, ego.MetricType.GAUC)
    # ego.Target("p4_predictions", p4, tf.identity(weigthed_label), tf.identity(click_w), hit_ratio_4, ego.MetricType.GAUC)

    # 看全样本
    # 看点击样本
    ego.Target("p0_pred_v2", p0_v2, tf.identity(weigthed_label), tf.identity(click_w), tf.identity(hit_ratio_0), ego.MetricType.GAUC)
    ego.Target("p1_pred_v2", p1_v2, tf.identity(weigthed_label), tf.identity(click_w), tf.identity(hit_ratio_1), ego.MetricType.GAUC)
    ego.Target("p2_pred_v2", p2_v2, tf.identity(weigthed_label), tf.identity(click_w), tf.identity(hit_ratio_2), ego.MetricType.GAUC)
    ego.Target("union_ntp", tf.identity(p2_v2), tf.identity(weigthed_label), tf.identity(click_w), ntp_loss, ego.MetricType.GAUC)

    ego.Target("ori_p0", ori_p0, tf.identity(weigthed_label), tf.identity(click_w), ntp_loss_p0, ego.MetricType.GAUC)
    ego.Target("ori_p1", ori_p1, tf.identity(weigthed_label), tf.identity(click_w), ntp_loss_p1, ego.MetricType.GAUC)
    ego.Target("ori_p2", ori_p2, tf.identity(weigthed_label), tf.identity(click_w), ntp_loss_p2, ego.MetricType.GAUC)

    target_list = ["p0_predictions", "p1_predictions", "p2_predictions", "p0_pred_v2", "p1_pred_v2", "p2_pred_v2", "union_ntp", "ori_p0", "ori_p1", "ori_p2"]
    if user_beamsearch_metric:
        ego.Target("p2_pred_beam_hr100", tf.identity(p2_v2), tf.identity(weigthed_label), tf.identity(click_w), p2_hit_rate_100, ego.MetricType.GAUC)
        ego.Target("p2_pred_beam_hr200", tf.identity(p2_v2), tf.identity(weigthed_label), tf.identity(click_w), p2_hit_rate_200, ego.MetricType.GAUC)
        target_list.extend(["p2_pred_beam_hr100", "p2_pred_beam_hr200"])

    round0 = ego.OfflineRound(name="eval", targets=target_list, dump_tensors_to_hdfs=dump_tensor)
    # round0 = ego.OfflineRound(name="eval", targets=target_list)
    round1 = ego.OfflineRound(name="train1",
                              targets=target_list,  # 添加beam search总损失
                              final_loss=final_loss,
                              train_sparse=True)
    ego.compile(rounds=[round0, round1])

else:
    ego.Target("beams", beams, None, None, None, ego.MetricType.RMSE)
    # ego.Target("beam_scores", beam_scores, None, None, None, ego.MetricType.RMSE)
    round1 = ego.OnlineRound(name="online", targets=["beams"])
    ego.compile(rounds=[round1])
