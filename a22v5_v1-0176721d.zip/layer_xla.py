# -*- coding:utf-8 -*-

import tensorflow as tf
import numpy as np
import config as C
import math


dropout_rate_all = 0


def gelu(x):
    """自定义GELU激活函数"""
    return 0.5 * x * (1.0 + tf.math.tanh(
        tf.math.sqrt(2.0 / math.pi) * (x + 0.044715 * tf.math.pow(x, 3))
    ))


def silu(x):
    return x * tf.math.sigmoid(x)


def get_init_op(init_name, param_dicts=None):
    if param_dicts is None:
        param_dicts = {}

    if init_name == "truncated_normal":
        stddev = param_dicts.get("stddev", 0.001)
        return tf.truncated_normal_initializer(stddev=stddev, dtype=tf.float32)
    elif init_name == "zeros":
        return tf.zeros_initializer(dtype=tf.float32)
    elif init_name == "xavier_normal" or init_name == "glorot_normal":
        return tf.initializers.glorot_normal()
    elif init_name == "xavier_uniform" or init_name == "glorot_uniform":
        return tf.initializers.glorot_uniform()
    else:
        raise ValueError(f"[wrong init_op={init_name}] param_dicts = {param_dicts}")


def get_act_op(act_name, param_dicts=None):
    if param_dicts is None:
        param_dicts = {}
    
    if act_name == "relu":
        return tf.nn.relu
    elif act_name == "gelu":
        return gelu
    elif act_name == "silu" or act_name == "swish":
        return silu
    elif act_name == "lrelu":
        return tf.nn.leaky_relu
    else:
        raise ValueError(f"[wrong act_name={act_name}] param_dicts = {param_dicts}")


class Similarity(tf.keras.layers.Layer):
    """
      Input shape
        - A list of two 2D tensor with shape: ``(batch_size, input_dim)``.

      Output shape
        - 2D tensor with shape: ``(batch_size, 1)``.
    """

    def __init__(self, use_sigmoid=False, **kwargs):
        self.use_sigmoid = use_sigmoid
        super().__init__(**kwargs)

    def call(self, inputs, **kwargs):
        user_emb, item_emb = inputs
        output = tf.reduce_sum(tf.multiply(user_emb, item_emb), axis=-1, keepdims=True)
        if self.use_sigmoid:
            output = tf.sigmoid(output)
        return output

    def get_config(self):
        config = {'use_sigmoid': self.use_sigmoid}
        base_config = super().get_config()
        base_config.update(config)
        return base_config


class DNN(tf.keras.layers.Layer):
    """The Multi Layer Percetron

      Input shape
        - nD tensor with shape: ``(batch_size, ..., input_dim)``. The most common situation would be a 2D input with shape ``(batch_size, input_dim)``.

      Output shape
        - nD tensor with shape: ``(batch_size, ..., hidden_size[-1])``. For instance, for a 2D input with shape ``(batch_size, input_dim)``, the output would have shape ``(batch_size, hidden_size[-1])``.

      Arguments
        - **hidden_units**:list of positive integer, the layer number and units in each layer.

        - **activation**: Activation function to use.

        - **l2_reg**: float between 0 and 1. L2 regularizer strength applied to the kernel weights matrix.

        - **dropout_rate**: float in [0,1). Fraction of the units to dropout.

        - **use_bn**: bool. Whether use BatchNormalization before activation or not.

        - **output_activation**: Activation function to use in the last layer.If ``None``,it will be same as ``activation``.

        - **seed**: A Python integer to use as random seed.
    """

    def __init__(self, hidden_units, activation=gelu, l2_reg=0, dropout_rate=0, use_bn=False, output_activation=None,
                 seed=None, **kwargs):
        self.hidden_units = hidden_units
        self.activation = activation
        self.l2_reg = l2_reg
        self.dropout_rate = dropout_rate
        self.use_dropout = self.dropout_rate > 0
        self.use_bn = use_bn
        self.output_activation = output_activation
        self.seed = seed

        super().__init__(**kwargs)

    def build(self, input_shape):
        input_size = input_shape[-1]
        hidden_units = [int(input_size)] + list(self.hidden_units)
        self.kernels = [self.add_weight(name='kernel' + str(i), shape=(hidden_units[i], hidden_units[i + 1]),
                                        initializer=tf.keras.initializers.glorot_normal(seed=self.seed),
                                        regularizer=tf.keras.regularizers.l2(self.l2_reg), trainable=True) for i in
                        range(len(self.hidden_units))]
        self.bias = [self.add_weight(name='bias' + str(i), shape=(self.hidden_units[i],),
                                     initializer=tf.keras.initializers.Zeros(), trainable=True) for i in
                     range(len(self.hidden_units))]
        if self.use_bn:
            self.bn_layers = [tf.keras.layers.BatchNormalization() for _ in range(len(self.hidden_units))]
        if self.use_dropout:
            if self.seed is not None:
                tf.random.set_seed(self.seed)  # 统一设置随机种子
            self.dropout_rate = self.dropout_rate

        if len(self.hidden_units) == 0:
            self.activation_layers = []
        elif self.output_activation:
            self.activation_layers = [tf.keras.layers.Activation(self.activation) for _ in
                                      range(len(self.hidden_units) - 1)] + [
                                         tf.keras.layers.Activation(self.output_activation)]
        else:
            self.activation_layers = [tf.keras.layers.Activation(self.activation) for _ in
                                      range(len(self.hidden_units))]

        super().build(input_shape)

    def call(self, inputs, training=None, **kwargs):
        x = inputs
        for i in range(len(self.hidden_units)):
            x = tf.nn.bias_add(tf.tensordot(x, self.kernels[i], axes=(-1, 0)), self.bias[i])
            if self.use_bn:
                x = self.bn_layers[i](x, training=training)
            x = self.activation_layers[i](x)
            if self.use_dropout:
                x = tf.nn.dropout(x, rate=self.dropout_rate if training else 0.0)
        return x

    def get_config(self):
        config = {'activation': self.activation, 'hidden_units': self.hidden_units, 'l2_reg': self.l2_reg,
                  'use_bn': self.use_bn, 'dropout_rate': self.dropout_rate, 'output_activation': self.output_activation,
                  'seed': self.seed}
        base_config = super().get_config()
        base_config.update(config)
        return base_config


class MMOE(tf.keras.layers.Layer):
    """
      Input shape
        - 2D tensor with shape: ``(batch_size, input_dim)``.

      Output shape
        - A list of 2D tensor with shape: ``(batch_size, expert_dnn_units[-1])``.
    """

    def __init__(self, num_tasks, num_experts=2, expert_dnn_units=(32,), gate_dnn_units=(), expert_dnn_params=None,
                 gate_dnn_params=None, **kwargs):
        self.num_tasks = num_tasks
        self.num_experts = num_experts
        self.expert_dnn_units = expert_dnn_units
        self.gate_dnn_units = list(gate_dnn_units) + [self.num_experts]
        self.expert_dnn_params = {}
        if expert_dnn_params:
            self.expert_dnn_params.update(expert_dnn_params)
        self.gate_dnn_params = {'output_activation': 'softmax'}
        if gate_dnn_params:
            self.gate_dnn_params.update(gate_dnn_params)

        super().__init__(**kwargs)

    def build(self, input_shape):
        self.expert_nets = [DNN(self.expert_dnn_units, name='expert{}'.format(i), **self.expert_dnn_params) for i in
                            range(self.num_experts)]
        self.gate_nets = [DNN(self.gate_dnn_units, name='task{}_gate'.format(i), **self.gate_dnn_params) for i in
                          range(self.num_tasks)]

        super().build(input_shape)

    def call(self, inputs, training=None, **kwargs):
        expert_outs = [net(inputs, training=training) for net in self.expert_nets]
        expert_outs = tf.stack(expert_outs, axis=-2)  # (batch_size, num_experts, expert_dim)
        task_outs = []
        for i in range(self.num_tasks):
            gate_out = self.gate_nets[i](inputs, training=training)
            gate_out = tf.expand_dims(gate_out, axis=-1)  # (batch_size, num_experts, 1)
            # for j in range(self.gate_dnn_units[-1]):
            #     self.add_metric(gate_out[...,j], name='{}_task{}_gate{}'.format(self.name, i, j))
            task_out = tf.reduce_sum(tf.multiply(expert_outs, gate_out), axis=-2)  # (batch_size, expert_dim)
            task_outs.append(task_out)
        return task_outs

    def get_config(self):
        config = {'num_tasks': self.num_tasks, 'num_experts': self.num_experts,
                  'expert_dnn_units': self.expert_dnn_units, 'gate_dnn_units': self.gate_dnn_units,
                  'expert_dnn_params': self.expert_dnn_params, 'gate_dnn_params': self.gate_dnn_params}
        base_config = super().get_config()
        base_config.update(config)
        return base_config


class PLE(tf.keras.layers.Layer):
    """
      Input shape
        - 2D tensor with shape: ``(batch_size, input_dim)``.

      Output shape
        - A list of 2D tensor with shape: ``(batch_size, expert_dnn_units[-1])``.
    """



    def __init__(self, num_tasks, num_shared_experts=2, num_specific_experts=2, expert_dnn_units=(32,),
                 gate_dnn_units=(), expert_dnn_params=None, gate_dnn_params=None, **kwargs):
        self.num_tasks = num_tasks
        self.num_shared_experts = num_shared_experts
        self.num_specific_experts = num_specific_experts
        self.expert_dnn_units = expert_dnn_units
        self.gate_dnn_units = list(gate_dnn_units) + [self.num_shared_experts + self.num_specific_experts]
        self.expert_dnn_params = {}
        if expert_dnn_params:
            self.expert_dnn_params.update(expert_dnn_params)
        self.gate_dnn_params = {'output_activation': 'softmax'}
        if gate_dnn_params:
            self.gate_dnn_params.update(gate_dnn_params)

        super().__init__(**kwargs)

    def build(self, input_shape):
        self.shared_expert_nets = [
            DNN(self.expert_dnn_units, name='shared_expert{}'.format(i), **self.expert_dnn_params) for i in
            range(self.num_shared_experts)]
        self.specific_expert_nets = [
            [DNN(self.expert_dnn_units, name='task{}_expert{}'.format(i, j), **self.expert_dnn_params) for j in
             range(self.num_specific_experts)] for i in range(self.num_tasks)]
        self.gate_nets = [DNN(self.gate_dnn_units, name='task{}_gate'.format(i), **self.gate_dnn_params) for i in
                          range(self.num_tasks)]

        super().build(input_shape)

    def call(self, inputs, training=None, **kwargs):
        shared_expert_outs = [net(inputs, training=training) for net in self.shared_expert_nets]
        task_outs = []
        for i in range(self.num_tasks):
            specific_expert_outs = [net(inputs, training=training) for net in self.specific_expert_nets[i]]
            expert_outs = tf.stack(shared_expert_outs + specific_expert_outs,
                                   axis=-2)  # (batch_size, num_experts, expert_dim)
            gate_out = self.gate_nets[i](inputs, training=training)
            # for j in range(self.gate_dnn_units[-1]):
            #     self.add_metric(gate_out[...,j], name='{}_task{}_gate{}'.format(self.name, i, j))
            gate_out = tf.expand_dims(gate_out, axis=-1)  # (batch_size, num_experts, 1)
            task_out = tf.reduce_sum(tf.multiply(expert_outs, gate_out), axis=-2)  # (batch_size, expert_dim)
            task_outs.append(task_out)
        return task_outs

    def get_config(self):
        config = {'num_tasks': self.num_tasks, 'num_shared_experts': self.num_shared_experts,
                  'num_specific_experts': self.num_specific_experts, 'expert_dnn_units': self.expert_dnn_units,
                  'gate_dnn_units': self.gate_dnn_units, 'expert_dnn_params': self.expert_dnn_params,
                  'gate_dnn_params': self.gate_dnn_params}
        base_config = super().get_config()
        base_config.update(config)
        return base_config


class FM(tf.keras.layers.Layer):
    """
      Input shape
        - A list of 2D tensor with shape: ``(batch_size, embedding_size)``.
      Output shape
        - 2D tensor with shape: ``(batch_size, 1)``.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def call(self, inputs, **kwargs):
        x = inputs
        x = tf.stack(x, axis=1)
        square_of_sum = tf.square(tf.reduce_sum(x, axis=1, keepdims=True))
        sum_of_square = tf.reduce_sum(tf.square(x), axis=1, keepdims=True)
        cross_term = 0.5 * tf.reduce_sum(square_of_sum - sum_of_square, axis=2, keepdims=False)
        return cross_term


class SENET(tf.keras.layers.Layer):
    """
      Input shape
        - A list of 2D tensor with shape: ``(batch_size, embedding_size)``.
      Output shape
        - A list of 2D tensor with shape: ``(batch_size, embedding_size)``.
    """

    def __init__(self, reduction_ratio=3, **kwargs):
        self.reduction_ratio = reduction_ratio
        super().__init__(**kwargs)

    def build(self, input_shape):
        self.field_size = len(input_shape)
        self.reduction_size = max(1, self.field_size // self.reduction_ratio)
        # self.reduction_size = 260 // 3
        self.fc1 = tf.keras.layers.Dense(self.reduction_size, activation=gelu)
        self.fc2 = tf.keras.layers.Dense(self.field_size, activation='sigmoid')
        super().build(input_shape)

    def call(self, inputs, **kwargs):
        inputs = tf.stack(inputs, axis=1) #[-1, n, k]
        x = tf.reduce_mean(inputs, axis=-1) #[-1, n]
        x = self.fc1(x)
        x = self.fc2(x) * 2
        weight = x
        x = tf.multiply(inputs, tf.expand_dims(x, axis=2)) # [-1, n, k] * [-1, n, 1] = [-1, n, k]
        return [tf.squeeze(tensor, axis=1) for tensor in tf.split(x, self.field_size, axis=1)], weight

    def get_config(self):
        config = {'reduction_ratio': self.reduction_ratio}
        base_config = super().get_config()
        base_config.update(config)
        return base_config

class Bilinear(tf.keras.layers.Layer):
    def __init__(self, input_dim, emb_size):
        super(Bilinear, self).__init__()
        self.input_dim = input_dim
        self.emb_size = emb_size
        self.fc_layer = tf.keras.layers.Dense(self.input_dim, kernel_initializer='glorot_normal', activation='linear',
                                              name='bilinear_fc')

    def call(self, feature1, feature2):
        # feature: [-1, input_dim, emb_size]
        feature1 = tf.transpose(feature1, perm=[0, 2, 1])  # [-1, emb_size, input_dim]
        bilinear1 = self.fc_layer(feature1)  # [-1, emb_size, input_dim]
        bilinear1 = tf.reshape(tf.transpose(bilinear1, perm=[0, 2, 1]), [-1, self.input_dim, self.emb_size])
        bilinear1 = bilinear1 * feature2
        return bilinear1

class PositionalEncoding(tf.keras.layers.Layer):
    """位置编码层"""
    def __init__(self, max_seq_len=1000, d_model=32, name='positional_encoding'):
        super(PositionalEncoding, self).__init__(name=name)
        self.max_seq_len = max_seq_len
        self.d_model = d_model
        
    def build(self, input_shape):
        # 创建位置编码矩阵
        pos = tf.range(self.max_seq_len, dtype=tf.float32)[:, tf.newaxis]
        div_term = tf.exp(tf.range(0, self.d_model, 2, dtype=tf.float32) * 
                         -(tf.math.log(10000.0) / self.d_model))
        
        pe = tf.zeros((self.max_seq_len, self.d_model))
        pe = tf.Variable(pe, trainable=False, name='pe')
        
        # 设置正弦和余弦编码
        sin_vals = tf.sin(pos * div_term)
        cos_vals = tf.cos(pos * div_term)
        
        # 更新位置编码矩阵
        indices_sin = tf.range(0, self.d_model, 2)
        indices_cos = tf.range(1, self.d_model, 2)
        
        pe_updates_sin = tf.scatter_nd(
            tf.stack([tf.tile(tf.range(self.max_seq_len)[:, tf.newaxis], [1, tf.shape(indices_sin)[0]]), 
                     tf.tile(indices_sin[tf.newaxis, :], [self.max_seq_len, 1])], axis=2),
            sin_vals,
            [self.max_seq_len, self.d_model]
        )
        
        pe_updates_cos = tf.scatter_nd(
            tf.stack([tf.tile(tf.range(self.max_seq_len)[:, tf.newaxis], [1, tf.shape(indices_cos)[0]]), 
                     tf.tile(indices_cos[tf.newaxis, :], [self.max_seq_len, 1])], axis=2),
            cos_vals,
            [self.max_seq_len, self.d_model]
        )
        
        self.pe = pe_updates_sin + pe_updates_cos
        super(PositionalEncoding, self).build(input_shape)
        
    def call(self, x):
        # 确保输入是三维张量 [batch_size, seq_len, d_model]
        if len(x.shape) == 2:
            # 如果输入是 [batch_size, d_model]，扩展为 [batch_size, 1, d_model]
            x = tf.expand_dims(x, axis=1)
        
        seq_len = tf.shape(x)[1]
        return x + self.pe[:seq_len, :]


class MultiHeadAttention(tf.keras.layers.Layer):
    """多头注意力机制"""
    def __init__(self, d_model=32, num_heads=8, name='multi_head_attention'):
        super(MultiHeadAttention, self).__init__(name=name)
        assert d_model % num_heads == 0
        
        self.d_model = d_model
        self.num_heads = num_heads
        self.depth = d_model // num_heads
        
        self.wq = tf.keras.layers.Dense(d_model, name='wq')
        self.wk = tf.keras.layers.Dense(d_model, name='wk') 
        self.wv = tf.keras.layers.Dense(d_model, name='wv')
        self.dense = tf.keras.layers.Dense(d_model, name='output_dense')
        
    def split_heads(self, x, batch_size):
        """分割头"""
        x = tf.reshape(x, (batch_size, -1, self.num_heads, self.depth))
        return tf.transpose(x, perm=[0, 2, 1, 3])
    
    def call(self, v, k, q, mask=None):
        batch_size = tf.shape(q)[0]
        
        q = self.wq(q)
        k = self.wk(k)
        v = self.wv(v)
        
        q = self.split_heads(q, batch_size)
        k = self.split_heads(k, batch_size)
        v = self.split_heads(v, batch_size)
        
        # 计算注意力权重
        matmul_qk = tf.matmul(q, k, transpose_b=True)
        dk = tf.cast(self.depth, tf.float32)
        scaled_attention_logits = matmul_qk / tf.math.sqrt(dk)
        
        # 应用mask
        if mask is not None:
            scaled_attention_logits += (mask * -1e9)
            
        attention_weights = tf.nn.softmax(scaled_attention_logits, axis=-1)
        attention = tf.matmul(attention_weights, v)
        
        # 合并头
        attention = tf.transpose(attention, perm=[0, 2, 1, 3])
        concat_attention = tf.reshape(attention, (batch_size, -1, self.d_model))
        
        output = self.dense(concat_attention)
        return output


class TransformerEncoderLayer(tf.keras.layers.Layer):
    """Transformer编码器层"""
    def __init__(self, d_model=32, num_heads=8, dff=128, dropout_rate=0.1, name='encoder_layer'):
        super(TransformerEncoderLayer, self).__init__(name=name)
        
        self.mha = MultiHeadAttention(d_model, num_heads, name='self_attention')
        # 前馈网络层 - 不使用Sequential
        self.ffn_dense1 = tf.keras.layers.Dense(dff, activation=gelu, name='ffn_dense1')
        self.ffn_dense2 = tf.keras.layers.Dense(d_model, name='ffn_dense2')
        
        self.layernorm1 = tf.keras.layers.LayerNormalization(epsilon=1e-3, name='layernorm1')
        self.layernorm2 = tf.keras.layers.LayerNormalization(epsilon=1e-3, name='layernorm2')
        
        self.dropout1 = tf.keras.layers.Dropout(dropout_rate, name='dropout1')
        self.dropout2 = tf.keras.layers.Dropout(dropout_rate, name='dropout2')
        
    def call(self, x, mask=None, training=None):
        attn_output = self.mha(x, x, x, mask)
        attn_output = self.dropout1(attn_output, training=training)
        out1 = self.layernorm1(x + attn_output)
        
        # 前馈网络
        ffn_output = self.ffn_dense1(out1)
        ffn_output = self.ffn_dense2(ffn_output)
        ffn_output = self.dropout2(ffn_output, training=training)
        out2 = self.layernorm2(out1 + ffn_output)
        
        return out2


class TransformerDecoderLayer(tf.keras.layers.Layer):
    """Transformer解码器层（保留用于兼容性）"""
    def __init__(self, d_model=32, num_heads=8, dff=128, dropout_rate=0.1, name='decoder_layer'):
        super(TransformerDecoderLayer, self).__init__(name=name)
        
        self.mha1 = MultiHeadAttention(d_model, num_heads, name='masked_self_attention')
        self.mha2 = MultiHeadAttention(d_model, num_heads, name='cross_attention')
        
        # 前馈网络层 - 不使用Sequential
        self.ffn_dense1 = tf.keras.layers.Dense(dff, activation=gelu, name='ffn_dense1')
        self.ffn_dense2 = tf.keras.layers.Dense(d_model, name='ffn_dense2')
        
        self.layernorm1 = tf.keras.layers.LayerNormalization(epsilon=1e-3, name='layernorm1')
        self.layernorm2 = tf.keras.layers.LayerNormalization(epsilon=1e-3, name='layernorm2')
        self.layernorm3 = tf.keras.layers.LayerNormalization(epsilon=1e-3, name='layernorm3')
        
        self.dropout1 = tf.keras.layers.Dropout(dropout_rate, name='dropout1')
        self.dropout2 = tf.keras.layers.Dropout(dropout_rate, name='dropout2')
        self.dropout3 = tf.keras.layers.Dropout(dropout_rate, name='dropout3')
        
    def call(self, x, enc_output, look_ahead_mask=None, padding_mask=None, training=None):
        # 带mask的自注意力
        attn1 = self.mha1(x, x, x, look_ahead_mask)
        attn1 = self.dropout1(attn1, training=training)
        out1 = self.layernorm1(attn1 + x)
        
        # 交叉注意力
        attn2 = self.mha2(enc_output, enc_output, out1, padding_mask)
        attn2 = self.dropout2(attn2, training=training)
        out2 = self.layernorm2(attn2 + out1)
        
        # 前馈网络
        ffn_output = self.ffn_dense1(out2)
        ffn_output = self.ffn_dense2(ffn_output)
        ffn_output = self.dropout3(ffn_output, training=training)
        out3 = self.layernorm3(ffn_output + out2)
        
        return out3


class DecoderOnlyLayer(tf.keras.layers.Layer):
    """Decoder-only架构的层（只包含自注意力和FFN，类似GPT）"""
    def __init__(self, d_model=32, num_heads=8, dff=128, dropout_rate=0.1, name='decoder_only_layer'):
        super(DecoderOnlyLayer, self).__init__(name=name)
        
        self.mha = MultiHeadAttention(d_model, num_heads, name='masked_self_attention')
        
        # 前馈网络层
        self.ffn_dense1 = tf.keras.layers.Dense(dff, activation=gelu, name='ffn_dense1')
        self.ffn_dense2 = tf.keras.layers.Dense(d_model, name='ffn_dense2')
        
        self.layernorm1 = tf.keras.layers.LayerNormalization(epsilon=1e-3, name='layernorm1')
        self.layernorm2 = tf.keras.layers.LayerNormalization(epsilon=1e-3, name='layernorm2')
        
        self.dropout1 = tf.keras.layers.Dropout(dropout_rate, name='dropout1')
        self.dropout2 = tf.keras.layers.Dropout(dropout_rate, name='dropout2')
        
    def call(self, x, look_ahead_mask=None, padding_mask=None, training=None):
        # 带mask的自注意力（支持look_ahead_mask和padding_mask的组合）
        # 如果同时提供了look_ahead_mask和padding_mask，需要合并它们
        if look_ahead_mask is not None and padding_mask is not None:
            # 合并两个mask（取最大值，即更严格的mask）
            combined_mask = tf.maximum(look_ahead_mask, padding_mask)
        elif look_ahead_mask is not None:
            combined_mask = look_ahead_mask
        elif padding_mask is not None:
            combined_mask = padding_mask
        else:
            combined_mask = None
            
        attn_output = self.mha(x, x, x, combined_mask)
        attn_output = self.dropout1(attn_output, training=training)
        out1 = self.layernorm1(attn_output + x)
        
        # 前馈网络
        ffn_output = self.ffn_dense1(out1)
        ffn_output = self.ffn_dense2(ffn_output)
        ffn_output = self.dropout2(ffn_output, training=training)
        out2 = self.layernorm2(out1 + ffn_output)
        
        return out2


class CrossAttentionLayer(tf.keras.layers.Layer):
    """Cross Attention层：tar_seq作为query（带causal mask），inp作为key和value"""
    def __init__(self, d_model=32, num_heads=8, dff=128, dropout_rate=0.1, name='cross_attention_layer'):
        super(CrossAttentionLayer, self).__init__(name=name)
        
        # Cross attention: tar_seq (q) 与 inp (k, v)
        self.cross_attn = MultiHeadAttention(d_model, num_heads, name='cross_attention')
        
        # 前馈网络层
        self.ffn_dense1 = tf.keras.layers.Dense(dff, activation=gelu, name='ffn_dense1')
        self.ffn_dense2 = tf.keras.layers.Dense(d_model, name='ffn_dense2')
        
        self.layernorm1 = tf.keras.layers.LayerNormalization(epsilon=1e-3, name='layernorm1')
        self.layernorm2 = tf.keras.layers.LayerNormalization(epsilon=1e-3, name='layernorm2')
        
        self.dropout_rate = dropout_rate
        self.dropout1 = tf.keras.layers.Dropout(dropout_rate, name='dropout1')
        self.dropout2 = tf.keras.layers.Dropout(dropout_rate, name='dropout2')
        
    def call(self, tar_seq, inp, causal_mask=None, padding_mask=None, training=None):
        """
        Args:
            tar_seq: [batch_size, tar_seq_len, d_model] - 作为query
            inp: [batch_size, inp_seq_len, d_model] - 作为key和value
            causal_mask: [tar_seq_len, tar_seq_len] - causal mask for tar_seq
            padding_mask: padding mask
            training: training flag
        Returns:
            out2: [batch_size, tar_seq_len, d_model]
        """
        # Cross attention: tar_seq (q) attends to inp (k, v)
    
        attn_output = self.cross_attn(inp, inp, tar_seq, causal_mask)
        if training and self.dropout_rate > 0:
            attn_output = self.dropout1(attn_output, training=training)
        out1 = self.layernorm1(attn_output + tar_seq)
        
        # 前馈网络
        ffn_output = self.ffn_dense1(out1)
        ffn_output = self.ffn_dense2(ffn_output)
        if training and self.dropout_rate > 0:
            ffn_output = self.dropout2(ffn_output, training=training)
        out2 = self.layernorm2(out1 + ffn_output)
        
        return out2


def create_look_ahead_mask(size):
    """创建前瞻mask"""
    mask = 1 - tf.linalg.band_part(tf.ones((size, size)), -1, 0)

    # mask = tf.linalg.band_part(tf.ones((size, size)), 0, -1)
    return mask


def create_padding_mask(seq):
    """创建padding mask"""
    seq = tf.cast(tf.math.equal(seq, 0), tf.float32)
    return seq[:, tf.newaxis, tf.newaxis, :]


class TransformerModel(tf.keras.layers.Layer):
    """完整的Transformer模型"""
    def __init__(self, num_layers=6, d_model=32, num_heads=8, dff=128, 
                 input_vocab_size=8500, target_vocab_size=[4000]*5, 
                 pe_input=1000, pe_target=1000, dropout_rate=0.1, 
                 num_codebooks=4, user_short_seq_key = [],name='transformer'):
        super(TransformerModel, self).__init__(name=name)
        
        self.d_model = d_model
        self.num_layers = num_layers
        self.num_codebooks = num_codebooks
        self.user_short_seq_key = user_short_seq_key
        # Hyperparameters (exposed)
        self.head_temperatures = [1, 1, 1, 1, 1]  # tau per head
        self.length_penalty_alpha = 0.0  # beam length penalty
        self.diversity_penalty = 0.0     # optional diversity penalty across beams
        self.scheduled_sampling_prob = 0.0  # 0.0-0.3 recommended
        
        # 位置编码（decoder-only架构中，输入和target使用同一个位置编码）
        self.pos_encoding = PositionalEncoding(pe_input, d_model, name='pos_encoding')
        self.pos_encoding_target = PositionalEncoding(pe_target, d_model, name='pos_encoding_target')
        
        # Cross Attention层：tar_seq作为query（带causal mask），inp作为key和value
        self.dec_layers = [CrossAttentionLayer(d_model, num_heads, dff, dropout_rate,
                                             name=f'cross_attention_layer_{i}')
                          for i in range(num_layers)]
        
        self.pos_encoding_short = {}
        self.pos_encoding_short_target = {}
        self.dec_layers_short = {}

        for short_seq_key in self.user_short_seq_key:
            self.pos_encoding_short[short_seq_key] = PositionalEncoding(pe_input, d_model, name='pos_encoding_short_{}'.format(short_seq_key))
            self.pos_encoding_short_target[short_seq_key] = PositionalEncoding(pe_target, d_model, name='pos_encoding_short_target_{}'.format(short_seq_key))
            self.dec_layers_short[short_seq_key] = [CrossAttentionLayer(d_model, num_heads, dff, dropout_rate,
                                             name=f'cross_attention_layer_short_{short_seq_key}_{j}')
                          for j in range(num_layers)]

        self.dropout = tf.keras.layers.Dropout(dropout_rate, name='dropout')
        
        # 三层码本预测头
        self.codebook0_dense = tf.keras.layers.Dense(128, activation=gelu, name='codebook0_dense')
        self.codebook0_dropout = tf.keras.layers.Dropout(dropout_rate, name='codebook0_dropout')
        self.codebook0_output = tf.keras.layers.Dense(target_vocab_size[0], name='codebook0_output')

        self.codebook1_dense = tf.keras.layers.Dense(128, activation=gelu, name='codebook1_dense')
        self.codebook1_dropout = tf.keras.layers.Dropout(dropout_rate, name='codebook1_dropout')
        self.codebook1_output = tf.keras.layers.Dense(target_vocab_size[1], name='codebook1_output')
        
        self.codebook2_dense = tf.keras.layers.Dense(128, activation=gelu, name='codebook2_dense')
        self.codebook2_dropout = tf.keras.layers.Dropout(dropout_rate, name='codebook2_dropout')
        self.codebook2_output = tf.keras.layers.Dense(target_vocab_size[2], name='codebook2_output')
        
        self.codebook3_dense = tf.keras.layers.Dense(128, activation=gelu, name='codebook3_dense')
        self.codebook3_dropout = tf.keras.layers.Dropout(dropout_rate, name='codebook3_dropout')
        self.codebook3_output = tf.keras.layers.Dense(target_vocab_size[3], name='codebook3_output')

        self.codebook4_dense = tf.keras.layers.Dense(128, activation=gelu, name='codebook4_dense')
        self.codebook4_dropout = tf.keras.layers.Dropout(dropout_rate, name='codebook4_dropout')
        self.codebook4_output = tf.keras.layers.Dense(target_vocab_size[4], name='codebook4_output')

        self.codebook0_ppnet = tf.keras.layers.Dense(target_vocab_size[0], name='codebook0_logits_raw')

        self.codebook_dense_layer = [self.codebook0_dense, self.codebook1_dense, self.codebook2_dense, self.codebook3_dense, self.codebook4_dense]
        self.codebook_dropout_layer = [self.codebook0_dropout, self.codebook1_dropout, self.codebook2_dropout, self.codebook3_dropout, self.codebook4_dropout]
        self.codebook_output_layer = [self.codebook0_output, self.codebook1_output, self.codebook2_output, self.codebook3_output, self.codebook4_output]

        # self.codebook5_dense = tf.keras.layers.Dense(128, activation=gelu, name='codebook5_dense')
        # self.codebook5_dropout = tf.keras.layers.Dropout(dropout_rate, name='codebook5_dropout')
        # self.codebook5_output = tf.keras.layers.Dense(target_vocab_size[4], name='codebook5_output')

        # self.codebook6_dense = tf.keras.layers.Dense(128, activation=gelu, name='codebook6_dense')
        # self.codebook6_dropout = tf.keras.layers.Dropout(dropout_rate, name='codebook6_dropout')
        # self.codebook6_output = tf.keras.layers.Dense(target_vocab_size[5], name='codebook6_output')

        self.target_vocab_size = target_vocab_size #每个解码的输出类别数，长度为5的list

        self.num_categories=4000
        self.subcat_num_categories = 282
        self.thirdcat_num_categories = 1203
        
        # # 初始化不同类型的CategoryEmbedding，与model.py中保持一致
        # self.subcat_embedding = CategoryEmbedding(vocab_size=self.subcat_num_categories, emb_size=32, name='subcat_embedding')
        # self.thirdcat_embedding = CategoryEmbedding(vocab_size=self.thirdcat_num_categories, emb_size=32, name='thirdcat_embedding')
        
        self.bos_embedding = self.add_weight(
            name='bos_embedding',
            shape=(1, 128),
            initializer='glorot_normal',
            trainable=True
        )
        self.semantic_id_0_embedding = CategoryEmbedding(vocab_size=self.num_categories, emb_size=128, name='semantic_id_0_embedding')
        self.semantic_id_1_embedding = CategoryEmbedding(vocab_size=self.num_categories, emb_size=128, name='semantic_id_1_embedding')
        self.semantic_id_2_embedding = CategoryEmbedding(vocab_size=self.num_categories, emb_size=128, name='semantic_id_2_embedding')
        self.semantic_id_3_embedding = CategoryEmbedding(vocab_size=self.num_categories, emb_size=128, name='semantic_id_3_embedding')
        self.semantic_id_4_embedding = CategoryEmbedding(vocab_size=self.num_categories, emb_size=128, name='semantic_id_4_embedding')

        # pairwise embeddings for (0,1) and (1,2)
        self.hash_01_size = int(self.num_categories * int(self.num_categories * 0.25) + 1) 
        self.semantic_id_01_embedding = CategoryEmbedding(vocab_size=self.hash_01_size, emb_size=8, name='semantic_id_01_embedding')
        self.semantic_id_01_dnn =  DNN(hidden_units=(32, 16), activation=gelu, output_activation=gelu, l2_reg=0, dropout_rate=0, name="semantic_id_01_dnn")
        # self.semantic_id_12_embedding = CategoryEmbedding(vocab_size=self.num_categories * self.num_categories, emb_size=8, name='semantic_id_12_embedding')
        # self.semantic_id_23_embedding = CategoryEmbedding(vocab_size=self.num_categories * self.num_categories, emb_size=8, name='semantic_id_23_embedding')

        self.semantic_id_embedding_layer = [
            [self.semantic_id_0_embedding],
            [self.semantic_id_1_embedding],
            [self.semantic_id_2_embedding],
            [self.semantic_id_3_embedding],
            [self.semantic_id_4_embedding]
        ]

        self.target_seq_0_dense = tf.keras.layers.Dense(self.d_model, activation=gelu)
        self.target_seq_1_dense = tf.keras.layers.Dense(self.d_model, activation=gelu)
        self.target_seq_2_dense = tf.keras.layers.Dense(self.d_model, activation=gelu)
        self.target_seq_3_dense = tf.keras.layers.Dense(self.d_model, activation=gelu)
        self.target_seq_4_dense = tf.keras.layers.Dense(self.d_model, activation=gelu)

        self.target_seq_dense_layer = [self.target_seq_0_dense, self.target_seq_1_dense, self.target_seq_2_dense, self.target_seq_3_dense, self.target_seq_4_dense]
        # self.target_seq_5_dense = tf.keras.layers.Dense(self.d_model, activation=gelu)
        # self.target_seq_6_dense = tf.keras.layers.Dense(self.d_model, activation=gelu)

        # self.subcat_embedding = tf.keras.layers.Dense(32, name='subcat_embedding')
        # self.thirdcat_embedding = tf.keras.layers.Dense(32, name='thirdcat_embedding')
        # self.semantic_id_0_embedding = tf.keras.layers.Dense(32, name='semantic_id_0_embedding')
        # self.semantic_id_1_embedding = tf.keras.layers.Dense(32, name='semantic_id_1_embedding')
        # self.semantic_id_2_embedding = tf.keras.layers.Dense(32, name='semantic_id_2_embedding')
        
        # 为beam search使用的通用category_embedding（使用最大的词汇表大小以兼容所有类型）
        self.category_embedding = CategoryEmbedding(vocab_size=max(self.num_categories, self.subcat_num_categories, self.thirdcat_num_categories), emb_size=32, name='category_embedding')

        # rank params
        # codebook0
        # num_codebooks
        self.rank_ln = {}
        self.rank_masknet = {}
        self.rank_senet = {}
        self.rank_ple = {}
        self.rank_dnn_logits = {}
        self.emb_all_size = [3904, 4032, 4184] # [7456, 7584, 7720]
        self.rank_dnn_logits_ppnet = {}
        for i in range(self.num_codebooks):
            tower_name = "codebook%s" % i
            self.rank_ln[tower_name] = tf.keras.layers.LayerNormalization(epsilon=1e-3, name=f"rank_ln_{i}")
            self.rank_masknet[tower_name] = DNN((64, self.emb_all_size[i]), activation='linear', output_activation='sigmoid', l2_reg=0, dropout_rate=0,
                        name='igm_1_{}'.format(tower_name))

            self.rank_senet[tower_name] = SENET(reduction_ratio=3)
            self.rank_ple[tower_name] = PLE(name='ple_{}'.format(tower_name), num_tasks=len(C.task_names), num_shared_experts=2,
                            num_specific_experts=2, expert_dnn_units=(256, 128), gate_dnn_units=(64,),
                            expert_dnn_params=dict(dropout_rate=dropout_rate_all),
                            gate_dnn_params=dict(dropout_rate=dropout_rate_all))

            self.rank_dnn_logits[tower_name] = [DNN((128,), output_activation=gelu, l2_reg=0, dropout_rate=dropout_rate_all,
                        name='{}_{}_emb'.format(task_name, tower_name)) for i, task_name in
                    enumerate(C.task_names)]

            self.rank_dnn_logits_ppnet[tower_name] = [DNN((128,), output_activation='sigmoid', l2_reg=0, dropout_rate=0,
                        name='{}_{}_emb_ppnet'.format(task_name, tower_name)) for i, task_name in
                    enumerate(C.task_names)]


    def hash_l1_l2_int32(self, l1_cat, l2_cat, num_buckets):
        # 1. 确保输入是整数类型 (推荐 int64 防止溢出)
        s1 = tf.cast(l1_cat, tf.int32)
        s2 = tf.cast(l2_cat, tf.int32)

        # 2. 定义一个大质数作为“盐”或者权重 (类似于 polynomial rolling hash)
        # 这样可以保证 (1, 2) 和 (2, 1) 产生不同的结果
        prime_factor = 131071  # 或者其他大质数，如 100003

        # 3. 数值计算代替字符串拼接
        # 逻辑： hash = (s1 * prime + s2) % num_buckets
        # 这种纯算术操作 TensorRT 完美支持
        combined = s1 * prime_factor + s2
        
        # 4. 取模得到 bucket id
        # 使用 tf.math.floormod 确保结果为正
        h = tf.math.floormod(combined, num_buckets)

        # 5. 转回 float32 (保持和你原函数输出一致)
        h = tf.cast(h, tf.float32)
        
        return h

    def get_embedding_for_layer(self, layer_idx):
        """
        根据层索引返回对应的embedding层
        
        Args:
            layer_idx: 层索引 (0-4)
            
        Returns:
            对应的CategoryEmbedding层
        """
        embedding_map = {
            # 0: self.subcat_embedding,           # 第1层：subcat
            # 1: self.thirdcat_embedding,         # 第2层：thirdcat  
            0: self.semantic_id_0_embedding,    # 第3层：semantic_id_0
            1: self.semantic_id_1_embedding,    # 第4层：semantic_id_1
            2: self.semantic_id_2_embedding,    # 第5层：semantic_id_2
            3: self.semantic_id_3_embedding,     # 第6层：semantic_id_3
            4: self.semantic_id_4_embedding     # 第7层：semantic_id_4
        }
        return embedding_map.get(layer_idx, self.category_embedding)

    def create_tower(self, emb_concat, tower_name, ppnet_input = None, training=None):

            emb_concat = self.rank_ln[tower_name](emb_concat, training=training)

            igm_1 = self.rank_masknet[tower_name](emb_concat, training=training)
            maskNet_mul_1 = tf.multiply(emb_concat, igm_1)
            maskNet_out = tf.split(maskNet_mul_1, int(maskNet_mul_1.shape[-1]) // 8, axis=1)

            emb_list, emb_weight = self.rank_senet[tower_name](maskNet_out, training=training)

            weight_concat = tf.keras.layers.Concatenate(name='weight_concat_{}'.format(tower_name), axis=-1)(emb_list)

            ple_outputs = self.rank_ple[tower_name](weight_concat, training=training)

            logits = [dnn_param(ple_outputs[i], training=training) for i, dnn_param in enumerate(self.rank_dnn_logits[tower_name])]

            if ppnet_input is not None:
                ppnet_outputs = [dnn_param(ppnet_input, training=training) for i, dnn_param in enumerate(self.rank_dnn_logits_ppnet[tower_name])]
                logits = [tf.multiply(logits[i], 2*ppnet_outputs[i]) for i in range(len(logits))]

            # 在线需要通过tensor name获取output，将output的tensor name重新命名一下
            outputs = {}
            for output, task_name in zip(logits, C.task_names):
                outputs["{}_logit".format(task_name)] = tf.identity(output, name="{}_{}_logit".format(task_name, tower_name))
            return outputs  
        
    def call(self, input_feature, tar=None, enc_padding_mask=None, 
             look_ahead_mask=None, dec_padding_mask=None, training=None):  
        
        # 训练时：将输入和target拼接后通过decoder-only处理
        tar_embedding = []
        tar_for_output = []
        if tar is not None:
            # 确保tar的数据类型是int32，避免浮点数传递给embedding
            # tar = tf.cast(tar, tf.int32)
            
            # tar_embedding.append(self.subcat_embedding(tar[0]))
            # tar_embedding.append(self.thirdcat_embedding(tar[1]))
            # 将 bos_embedding 扩展到与 semantic_id_0_embedding 相同的形状 [batch_size, 128]
            batch_size = tf.shape(tar[0])[0]
            bos_emb = tf.tile(self.bos_embedding, [batch_size, 1])  # [batch_size, 128]
            bos_emb = tf.expand_dims(bos_emb, axis=1)  # [batch_size, 1, 128]
            tar_embedding.append(bos_emb)
            tar_embedding.append(self.semantic_id_0_embedding(tar[0]))
            tar_embedding.append(self.semantic_id_1_embedding(tar[1]))
            tar_embedding.append(self.semantic_id_2_embedding(tar[2]))
            tar_embedding.append(self.semantic_id_3_embedding(tar[3]))
            tar_embedding.append(self.semantic_id_4_embedding(tar[4])) # not use
            tar_embedding = tf.concat(tar_embedding, axis=1)


            tar_for_output.append(bos_emb)
            tar_for_output.append(tf.concat([bos_emb, self.semantic_id_0_embedding(tar[0])], axis=2))
            emb_0 = self.semantic_id_0_embedding(tar[0])
            emb_1 = self.semantic_id_1_embedding(tar[1])
            emb_01_raw = self.hash_l1_l2_int32(tar[0], tar[1], num_buckets=self.hash_01_size) 
            # print(f"[emb_01_raw] {emb_01_raw}")
            emb_01 = self.semantic_id_01_embedding(emb_01_raw)
            emb_01_dnn = self.semantic_id_01_dnn(tf.concat([emb_0, emb_1], axis=2))
            # print("[!!!]", emb_01, bos_emb)
            tar_for_output.append(tf.concat([bos_emb, emb_0, emb_1, emb_01, emb_01_dnn], axis=2))
            # tar_for_output.append(tf.concat([bos_emb, self.semantic_id_0_embedding(tar[0]),self.semantic_id_1_embedding(tar[1]), self.semantic_id_01_embedding(tar[0]*self.num_categories+tar[1]),self.semantic_id_2_embedding(tar[2]), self.semantic_id_12_embedding(tar[1]*self.num_categories+tar[2])], axis=2))
            # tar_for_output.append(tf.concat([bos_emb, self.semantic_id_0_embedding(tar[0]),self.semantic_id_1_embedding(tar[1]), self.semantic_id_01_embedding(tar[0]*self.num_categories+tar[1]),self.semantic_id_2_embedding(tar[2]), self.semantic_id_12_embedding(tar[1]*self.num_categories+tar[2]),
            # self.semantic_id_3_embedding(tar[3]), self.semantic_id_23_embedding(tar[2]*self.num_categories+tar[3])], axis=2))
            # tar_for_output.append(self.semantic_id_3_embedding(tar[3]))
        
        tar = tar_embedding
        
        # Decoder-only架构：将输入和target拼接在一起
        # 输入: [batch_size, inp_seq_len, d_model]
        # target: [batch_size, tar_seq_len, d_model] (需要先转换为embedding)
        # 拼接: [batch_size, inp_seq_len + tar_seq_len, d_model]
        
        # 将target转换为序列形式 [batch_size, tar_seq_len, d_model]
        # tar的形状是[batch_size, num_codebooks, emb_dim]，需要转换为[batch_size, num_codebooks, d_model]
        # 由于tar已经是embedding，我们需要确保它是正确的形状
        if len(tar.shape) == 2:
            # tar是[batch_size, emb_dim]，需要扩展为[batch_size, 1, d_model]
            tar_seq_input = tf.expand_dims(tar, axis=1)  # [batch_size, 1, d_model]
        elif len(tar.shape) == 3:
            # tar是[batch_size, num_codebooks, emb_dim]
            tar_seq_input = tar  # [batch_size, num_codebooks, d_model]
        else:
            # 默认情况：假设tar是[batch_size, emb_dim]
            tar_seq_input = tf.expand_dims(tar, axis=1)  # [batch_size, 1, d_model]
        
        ######################## rank #############
        sparse_input = input_feature[0]
        user_long_seq = input_feature[1]
        user_short_seq = input_feature[2]        

        inp = user_long_seq
        # Cross Attention架构：tar_seq作为query（带causal mask），inp作为key和value
        # 不再拼接，分别处理
        
        # 位置编码：分别对 inp 和 tar_seq 应用位置编码

        ####### 长序列 cross attention #######
        inp = self.pos_encoding(inp)
        
        tar_seq = self.pos_encoding_target(tar_seq_input)
        
        # 通过cross attention层处理
        for i in range(self.num_layers):
            tar_seq = self.dec_layers[i](tar_seq, inp,
                                        causal_mask=None,
                                        padding_mask=dec_padding_mask,
                                        training=training)
        
        ####### 短序列 cross attention #######

        short_seq_cross_output = []
        for short_seq_key in user_short_seq.keys():
            short_seq = user_short_seq[short_seq_key]
            short_seq = self.pos_encoding_short[short_seq_key](short_seq)
            short_target_seq = self.pos_encoding_short_target[short_seq_key](tar_seq_input)

            for i in range(self.num_layers):
                short_target_seq = self.dec_layers_short[short_seq_key][i](short_target_seq, short_seq,
                                            causal_mask=None,
                                            padding_mask=dec_padding_mask,
                                            training=training)

            short_seq_cross_output.append(short_target_seq)


        # 存储所有层的logits和raw logits
        codebook_logits_list = []
        codebook_logits_raw_list = []
        
        # 第一层码本：使用inp的平均池化输出
        tar_output = tar_seq[:, 0:1, :]  # [batch_size, 1, d_model]
        pooled_output = tf.reduce_mean(tar_output, axis=1)  # [batch_size, d_model]
        short_seq_cross =  tf.concat([tf.reduce_mean(short_seq_cross_output[i][:, 0:1, :], axis=1) for i in range(len(short_seq_cross_output))], axis=1)
        
        # 获取第一层的层对象
        codebook_dropout = self.codebook_dropout_layer[0]
        codebook_output = self.codebook_output_layer[0]        
        
        # 第一层码本预测
        emb_concat = tf.concat([pooled_output, tf.squeeze(tar_for_output[0], axis=1), short_seq_cross,sparse_input], axis=1)
        x = self.create_tower(emb_concat, "codebook0", tf.squeeze(tar_for_output[0], axis=1), training=training)["click_logit"]
        x = codebook_dropout(x, training=training)
        codebook_logits = codebook_output(x)
        codebook_logits_raw = tf.identity(codebook_logits, name="codebook0_logits_raw")
        codebook_logits_raw_list.append(codebook_logits_raw)
        codebook_logits = tf.nn.softmax(codebook_logits / self.head_temperatures[0], axis=1)
        codebook_logits_list.append(codebook_logits)
        
        # 第一层decoder处理：使用tar_seq的第一个位置
        # tar_seq已经通过cross attention层处理，包含了从inp获取的信息
        tar_output = tar_seq[:, 1:2, :]  # [batch_size, 1, d_model]
        dec_output = tf.reduce_mean(tar_output, axis=1)  # [batch_size, d_model]
        short_seq_cross =  tf.concat([tf.reduce_mean(short_seq_cross_output[i][:, 1:2, :], axis=1) for i in range(len(short_seq_cross_output))], axis=1)
        
        # 循环处理后续层（第2层到第num_codebooks层）
        for layer_idx in range(1, self.num_codebooks):
            # 获取当前层的层对象
            

            codebook_dropout = self.codebook_dropout_layer[layer_idx]
            codebook_output = self.codebook_output_layer[layer_idx]            
            
            # 当前层码本预测
            emb_concat = tf.concat([dec_output, tf.squeeze(tar_for_output[layer_idx], axis=1), short_seq_cross, sparse_input], axis=1)
            x = self.create_tower(emb_concat, "codebook%s" % layer_idx, tf.squeeze(tar_for_output[layer_idx], axis=1), training=training)["click_logit"]
            x = codebook_dropout(x, training=training)
            codebook_logits = codebook_output(x)
            codebook_logits_raw = tf.identity(codebook_logits, name=f"codebook{layer_idx}_logits_raw")
            codebook_logits_raw_list.append(codebook_logits_raw)
            codebook_logits = tf.nn.softmax(codebook_logits / self.head_temperatures[layer_idx], axis=1)
            codebook_logits_list.append(codebook_logits)

            if  layer_idx >= self.num_codebooks-1:
                continue
            
            # 当前层decoder处理：使用tar_seq中对应位置的输出
            # tar_seq已经通过cross attention层处理，包含了从inp获取的信息
            # 使用对应target位置的输出（对应layer_idx）
            tar_pos_idx = layer_idx+1 # for next token
            if tar_pos_idx < tf.shape(tar_seq)[1]:
                dec_output = tar_seq[:, tar_pos_idx:tar_pos_idx+1, :]  # [batch_size, 1, d_model]
                dec_output = tf.reduce_mean(dec_output, axis=1)  # [batch_size, d_model]
                short_seq_cross =  tf.concat([tf.reduce_mean(short_seq_cross_output[i][:, tar_pos_idx:tar_pos_idx+1, :], axis=1) for i in range(len(short_seq_cross_output))], axis=1)
            else:
                # 如果位置超出，使用最后一个target位置的输出
                dec_output = tar_seq[:, -1:, :]  # [batch_size, 1, d_model]
                dec_output = tf.reduce_mean(dec_output, axis=1)  # [batch_size, d_model]
                short_seq_cross =  tf.concat([tf.reduce_mean(short_seq_cross_output[i][:, -1:, :], axis=1) for i in range(len(short_seq_cross_output))], axis=1)
        
        # 解包logits列表（支持动态扩展）
        # 根据实际实现的层数返回对应的logits
        if self.num_codebooks <= 4:
            # codebook0_logits = codebook_logits_list[0]
            # codebook1_logits = codebook_logits_list[1]
            # codebook2_logits = codebook_logits_list[2]

            last_logits = codebook_logits_list[-1]
            for res in range(5-self.num_codebooks):
                codebook_logits_list.append(last_logits)

            # 如果codebook5未实现，返回一个占位符（与原始返回值保持一致）
            # 动态返回所有层的logits
        return tuple(codebook_logits_list)
        # codebook1_logits_raw, codebook2_logits_raw, codebook3_logits_raw, codebook4_logits_raw #, codebook5_logits, codebook6_logits 

    def beam_search_decode(self, inputs, beam_width=20, max_len=5, beam_code_len=4, training=None, record_details=None,enc_padding_mask=None, look_ahead_mask=None, dec_padding_mask=None, return_tensors=None):
        """
        五层码本串行beam search解码（带详细记录）
        
        Args:
            inp: 输入序列 [batch_size, seq_len, d_model]
            beam_width: beam大小，默认20
            max_len: 最大解码长度，默认5（五层码本）
            enc_padding_mask: 编码器padding mask
            training: 是否训练模式
            record_details: 是否记录详细的beam search过程
            return_tensors: 是否返回tensor格式的日志（仅当record_details=True时有效）
            
        Returns:
            results: 包含最终结果的列表
            beam_search_log: 详细的beam search记录
                - 如果return_tensors=True: 返回包含TensorFlow张量的日志
                - 如果return_tensors=False: 返回可序列化的numpy数组格式日志
                - 如果record_details=False: 返回None
        """
        
        return self._batch_beam_search_decode(inputs, beam_width=beam_width, max_len=max_len, beam_code_len=beam_code_len, training=training)
    
    def _batch_beam_search_decode(self, input_feature, beam_width, max_len, beam_code_len, enc_padding_mask=None, look_ahead_mask=None, dec_padding_mask=None, training=True, record_details=True, return_tensors=None):
        """
        使用TensorFlow原生操作的批处理beam search（Decoder-only架构）
        """

        ######################## rank #############
        # sparse_input = input_feature[0]
        user_long_seq = input_feature[1]
        # user_short_seq = input_feature[2]

        batch_size = tf.shape(user_long_seq)[0]
        inp_seq_len = tf.shape(user_long_seq)[1]
        
        # Decoder-only架构：输入直接通过位置编码和dropout
        # 不需要encoder，直接处理输入序列
        
        
        # 初始化beam search状态
        # beams: [batch_size, beam_width, max_len] 存储max_len个码本的值
        # scores: [batch_size, beam_width] 存储累积分数
        beams = tf.zeros([batch_size, beam_width, beam_code_len], dtype=tf.int32) # max_len = num_codebooks
        scores = tf.zeros([batch_size, beam_width], dtype=tf.float32)
        # 逐层解码
        for layer_idx in range(max_len):
            beams, scores = self._decode_layer(
                input_feature, beams, scores, layer_idx, beam_width, look_ahead_mask, dec_padding_mask, beam_code_len, inp_seq_len, training
            )
        
        # 获取最终结果
        results = self._extract_final_results(beams, scores)
        
        # if record_details:
            # 创建简化的日志（因为计算图模式下难以记录详细过程）
            # return results, beams, scores
            # beam_search_log = {
            #     'total_candidates': beam_width * 5,  # 简化统计
            #     'final_beams': beams,
            #     'final_scores': scores
            # }
            # if return_tensors:
            #     return results, beam_search_log
            # else:
            #     # 转换为numpy格式
            #     log_numpy = {
            #         'total_candidates': beam_width * 5,
            #         'final_beams': beams.numpy() if hasattr(beams, 'numpy') else beams,
            #         'final_scores': scores.numpy() if hasattr(scores, 'numpy') else scores
            #     }
            #     return results, log_numpy
        # else:
        #     return results

        return results, beams, scores
    
    def _decode_layer(self, input_feature, beams, scores, layer_idx, beam_width, look_ahead_mask, dec_padding_mask, beam_code_len, inp_seq_len, training):
        """
        解码单层码本（Decoder-only架构）
        """

        sparse_input = input_feature[0]
        user_long_seq = input_feature[1]
        user_short_seq = input_feature[2]

        batch_size = tf.shape(user_long_seq)[0]
        
        # 确保输入的beams是int32类型
        beams = tf.cast(beams, tf.int32)
        
        if layer_idx == 0:
            # 第一层：使用输入序列的池化输出
            
            inp = user_long_seq
            ####### 长序列 cross attention #######

            bos_emb = tf.tile(self.bos_embedding, [batch_size, 1])  # [batch_size, 128]
            bos_emb = tf.expand_dims(bos_emb, axis=1)  # [batch_size, 1, 128]

            tar_seq_input = bos_emb
            tar_for_output = [bos_emb]
            inp = self.pos_encoding(inp)
            tar_seq = self.pos_encoding_target(tar_seq_input)

            # 通过cross attention层处理
            for i in range(self.num_layers):
                tar_seq = self.dec_layers[i](tar_seq, inp,
                                            causal_mask=None,
                                            padding_mask=dec_padding_mask,
                                            training=training)
            
            ####### 短序列 cross attention #######

            short_seq_cross_output = []
            for short_seq_key in user_short_seq.keys():
                short_seq = user_short_seq[short_seq_key]
                short_seq = self.pos_encoding_short[short_seq_key](short_seq)
                short_target_seq = self.pos_encoding_short_target[short_seq_key](tar_seq_input)

                for i in range(self.num_layers):
                    short_target_seq = self.dec_layers_short[short_seq_key][i](short_target_seq, short_seq,
                                                causal_mask=None,
                                                padding_mask=dec_padding_mask,
                                                training=training)

                short_seq_cross_output.append(short_target_seq)


            # 存储所有层的logits和raw logits
            codebook_logits_list = []
            codebook_logits_raw_list = []
            
            # 第一层码本：使用inp的平均池化输出
            tar_output = tar_seq[:, 0:1, :]  # [batch_size, 1, d_model]
            pooled_output = tf.reduce_mean(tar_output, axis=1)  # [batch_size, d_model]
            short_seq_cross =  tf.concat([tf.reduce_mean(short_seq_cross_output[i][:, 0:1, :], axis=1) for i in range(len(short_seq_cross_output))], axis=1)
            
            # 获取第一层的层对象
            # codebook_dropout = self.codebook_dropout_layer[0]
            codebook_output = self.codebook_output_layer[0]
            
            # 第一层码本预测
            emb_concat = tf.concat([pooled_output, tf.squeeze(tar_for_output[0], axis=1), short_seq_cross,sparse_input], axis=1)
            x = self.create_tower(emb_concat, "codebook0", tf.squeeze(tar_for_output[0], axis=1), training=training)["click_logit"]
            # x = codebook_dropout(x, training=training)
            logits = codebook_output(x)

        else:
            # 第四层
            # 确保beams的索引是int32类型
            beams_int32 = tf.cast(beams, tf.int32)
            # cb1_emb = tf.expand_dims(self.subcat_embedding(beams_int32[:, :, 0]), axis=2)
            # cb2_emb = tf.expand_dims(self.thirdcat_embedding(beams_int32[:, :, 1]), axis=2)
            
            beam_size = tf.shape(beams_int32)[1]

            bos_emb = tf.expand_dims(self.bos_embedding, axis=1)  # [1, 1, 128]
            bos_emb = tf.tile(bos_emb, [batch_size, beam_size, 1])  # [batch_size, beam_size, 128]
            bos_emb = tf.expand_dims(bos_emb, axis=2)  # [batch_size, beam_size, 1, 128]

            sparse_input = tf.expand_dims(sparse_input, axis=1)  # [batch_size, 1, 128]
            sparse_input = tf.tile(sparse_input, [1, beam_size, 1]) #[b, beam, 128]
            sparse_input_flat = tf.reshape(sparse_input, [-1, sparse_input.shape[-1]]) #[b*beam_size, 128]

            tar_embedding = [bos_emb]
            tar_for_output = [bos_emb] #[b, beam, 1, 128]

            ############# here need to get target embedding #############
            if layer_idx == 1:
                cb0_emb = tf.expand_dims(self.semantic_id_0_embedding(beams_int32[:, :, 0]), axis=2)
                tar_embedding.append(cb0_emb)
                tar_for_output.append(cb0_emb)
                combined_emb = tf.concat(tar_embedding, axis=2) #[b, beam, 2, 128]
                tar_for_output_concat = tf.squeeze(tf.concat(tar_for_output, axis=3), axis=2) #[b, beam, 128*2]
            elif layer_idx == 2:
                c0_emb = self.semantic_id_0_embedding(beams_int32[:, :, 0])
                c1_emb = self.semantic_id_1_embedding(beams_int32[:, :, 1])
                # print("[!!!] beam_search_serving to_hash_bucket_fast")
                cb_01_emb_dnn = self.semantic_id_01_dnn(tf.concat([c0_emb, c1_emb], axis=2))
                cb_01_emb_dnn = tf.expand_dims(cb_01_emb_dnn, axis=2)
                cb_01_emb_raw = self.hash_l1_l2_int32(beams_int32[:, :, 0], beams_int32[:, :, 1], num_buckets=self.hash_01_size) 
                cb_01_emb = self.semantic_id_01_embedding(cb_01_emb_raw)
                cb_01_emb = tf.expand_dims(cb_01_emb, axis=2) 
                cb0_emb = tf.expand_dims(c0_emb, axis=2)
                cb1_emb = tf.expand_dims(c1_emb, axis=2)
                # cb_01_emb = tf.expand_dims(self.semantic_id_01_embedding(beams_int32[:, :, 0]*self.num_categories+beams_int32[:, :, 1]), axis=2)
                tar_embedding.append(cb0_emb)
                tar_embedding.append(cb1_emb)
                tar_for_output.append(cb0_emb)
                tar_for_output.append(cb1_emb)
                tar_for_output.append(cb_01_emb)
                tar_for_output.append(cb_01_emb_dnn)
                combined_emb = tf.concat(tar_embedding, axis=2) #[b, beam, 3, 128]
                tar_for_output_concat = tf.squeeze(tf.concat(tar_for_output, axis=3), axis=2) #[b, beam, 128*2]
            # else:
            #     cb0_emb = tf.expand_dims(self.semantic_id_0_embedding(beams_int32[:, :, 0]), axis=2)
            #     cb1_emb = tf.expand_dims(self.semantic_id_1_embedding(beams_int32[:, :, 1]), axis=2)
            #     cb2_emb = tf.expand_dims(self.semantic_id_2_embedding(beams_int32[:, :, 2]), axis=2)
            #     cb_01_emb = tf.expand_dims(self.semantic_id_01_embedding(beams_int32[:, :, 0]*self.num_categories+beams_int32[:, :, 1]), axis=2)
            #     cb_12_emb = tf.expand_dims(self.semantic_id_12_embedding(beams_int32[:, :, 1]*self.num_categories+beams_int32[:, :, 2]), axis=2)
            #     tar_embedding.append(cb0_emb)
            #     tar_embedding.append(cb1_emb)
            #     tar_embedding.append(cb2_emb)
            #     tar_for_output.append(cb0_emb)
            #     tar_for_output.append(cb1_emb)
            #     tar_for_output.append(cb_01_emb)
            #     tar_for_output.append(cb2_emb)
            #     tar_for_output.append(cb_12_emb)
            #     combined_emb = tf.concat(tar_embedding, axis=2) #[b, beam, 3, 128]
            #     tar_for_output_concat = tf.squeeze(tf.concat(tar_for_output, axis=3), axis=2) #[b, beam, 128*3]
            combined_emb_flat = tf.reshape(combined_emb, [-1, combined_emb.shape[-2], combined_emb.shape[-1]]) #[b*beam_size, target_len, 128]
            tar_for_output_concat = tf.reshape(tar_for_output_concat, [-1, tar_for_output_concat.shape[-1]]) #[b*beam_size, 128*3]

            # target_seq: [batch_size * beam_width, tar_seq_len, d_model]
            
            # Cross Attention架构：tar_seq作为query（带causal mask），inp作为key和value
            # 扩展输入以匹配beam维度

            inp = user_long_seq
            inp_seq_len_dynamic = tf.shape(inp)[1]  # 动态获取输入序列长度
            inp_expanded = tf.tile(tf.expand_dims(inp, 1), [1, beam_width, 1, 1])
            # [batch_size, beam_width, inp_seq_len, d_model]
            inp_flat = tf.reshape(inp_expanded, [-1, inp_seq_len_dynamic, self.d_model])
            # [batch_size * beam_width, inp_seq_len, d_model]
            
            # 位置编码：分别对 inp 和 target_seq 应用位置编码
            inp_flat = self.pos_encoding(inp_flat)
            
            target_seq = self.pos_encoding_target(combined_emb_flat)
            
            
            # 通过cross attention层处理
            for i in range(self.num_layers):
                target_seq = self.dec_layers[i](target_seq, inp_flat,
                                                causal_mask=None,
                                                padding_mask=dec_padding_mask,
                                                training=training)
            
            ####### 短序列 cross attention #######

            short_seq_cross_output = []


            for short_seq_key in user_short_seq.keys():
                short_seq = user_short_seq[short_seq_key]
                short_seq_len_dynamic = tf.shape(short_seq)[1]
                short_seq_expanded = tf.tile(tf.expand_dims(short_seq, 1), [1, beam_width, 1, 1])
                short_seq_flat = tf.reshape(short_seq_expanded, [-1, short_seq_len_dynamic, self.d_model])
                
                short_seq = self.pos_encoding_short[short_seq_key](short_seq_flat)
                short_target_seq = self.pos_encoding_short_target[short_seq_key](combined_emb_flat)

                for i in range(self.num_layers):
                    short_target_seq = self.dec_layers_short[short_seq_key][i](short_target_seq, short_seq,
                                                causal_mask=None,
                                                padding_mask=dec_padding_mask,
                                                training=training)

                short_seq_cross_output.append(short_target_seq)


            # 存储所有层的logits和raw logits
            codebook_logits_list = []
            codebook_logits_raw_list = []
            
            # 第i层码本：使用inp的平均池化输出
            tar_output = target_seq[:, layer_idx:layer_idx+1, :]  # [batch_size, 1, d_model]
            pooled_output = tf.reduce_mean(tar_output, axis=1)  # [batch_size, d_model]
            short_seq_cross =  tf.concat([tf.reduce_mean(short_seq_cross_output[i][:, layer_idx:layer_idx+1, :], axis=1) for i in range(len(short_seq_cross_output))], axis=1)

            # 获取第i层的层对象
            # codebook_dropout = self.codebook_dropout_layer[layer_idx]
            codebook_output = self.codebook_output_layer[layer_idx]        
            
            # 第i层码本预测
            emb_concat = tf.concat([pooled_output, tar_for_output_concat, short_seq_cross,sparse_input_flat], axis=1)
            x = self.create_tower(emb_concat, "codebook%s" % layer_idx, tar_for_output_concat, training=training)["click_logit"]
            # x = codebook_dropout(x, training=training)
            codebook_logits = codebook_output(x)

            logits = tf.reshape(codebook_logits, [batch_size, beam_width, -1])
                
        # 计算log概率
        if layer_idx == 0:
            log_probs = tf.nn.log_softmax(logits / self.head_temperatures[0], axis=1)  # [batch_size, vocab_size]
            # 选择top-k候选
            top_k_probs, top_k_indices = tf.nn.top_k(log_probs, k=beam_width)
            top_k_indices = tf.cast(top_k_indices, tf.int32)
            
            # 更新beams和scores
            new_beams = tf.zeros([batch_size, beam_width, beam_code_len], dtype=tf.int32)
            
            # 创建索引张量，确保形状匹配
            batch_indices = tf.tile(tf.range(batch_size)[:, None], [1, beam_width])  # [batch_size, beam_width]
            beam_indices = tf.tile(tf.range(beam_width)[None, :], [batch_size, 1])   # [batch_size, beam_width]
            layer_indices = tf.zeros([batch_size, beam_width], dtype=tf.int32)       # [batch_size, beam_width]
            
            # 构建更新索引 [batch_size, beam_width, 3]
            update_indices = tf.stack([batch_indices, beam_indices, layer_indices], axis=-1)
            
            # 确保所有数据类型正确
            top_k_indices = tf.cast(top_k_indices, tf.int32)
            update_indices = tf.cast(update_indices, tf.int32)
            
            new_beams = tf.tensor_scatter_nd_update(
                new_beams, 
                update_indices,
                top_k_indices
            )
            # 确保返回的beams是int32类型
            new_beams = tf.cast(new_beams, tf.int32)
            new_scores = top_k_probs
        else:
            # apply temperature per head at each layer
            tau = self.head_temperatures[layer_idx]
            # 这里每一次解码，logits都是当前层的logits,且<0
            log_probs = tf.nn.log_softmax(logits / tau, axis=-1)  # [batch_size, beam_width, vocab_size]
            
            ############ Top-5 masking: 只保留每个beam中分数最大的5个token，其他设置为非常小的值
            if layer_idx == 4: #解码到videoid的唯一编码再做这个限制
                top_k = 3
                batch_size_shape = tf.shape(log_probs)[0]
                beam_width_shape = tf.shape(log_probs)[1]
                vocab_size_shape = tf.shape(log_probs)[2]
                
                # 将log_probs reshape为[batch_size * beam_width, vocab_size]以便使用top_k
                log_probs_2d = tf.reshape(log_probs, [-1, vocab_size_shape])  # [batch_size * beam_width, vocab_size]
                
                # 找到每个beam的前5个最大分数的索引
                _, top_k_indices = tf.nn.top_k(log_probs_2d, k=top_k)  # [batch_size * beam_width, 5]
                
                # 使用one_hot编码创建mask，标记前5个位置
                mask_2d = tf.reduce_sum(tf.one_hot(top_k_indices, depth=vocab_size_shape, dtype=tf.float32), axis=1)  # [batch_size * beam_width, vocab_size]
                
                # 将mask reshape回原始形状
                mask = tf.reshape(mask_2d, [batch_size_shape, beam_width_shape, vocab_size_shape])  # [batch_size, beam_width, vocab_size]
                
                # 只保留前5个位置的log_probs，其他位置设置为非常小的值
                very_small_value = tf.constant(-1e7, dtype=tf.float32)
                log_probs = tf.where(tf.cast(mask, tf.bool), log_probs, tf.fill(tf.shape(log_probs), very_small_value))
                ############ Top-5 masking: 只保留每个beam中分数最大的5个token，其他设置为非常小的值
            
            # 扩展当前分数
            expanded_scores = tf.expand_dims(scores, -1)  # [batch_size, beam_width, 1]
            candidate_scores = expanded_scores + log_probs  # [batch_size, beam_width, vocab_size]

            # Diversity penalty (optional): penalize tokens already used in the same beam
            if self.diversity_penalty > 0.0 and layer_idx > 0:
                beams_int32 = tf.cast(beams, tf.int32)
                used_tokens = beams_int32[:, :, :layer_idx]  # [b, bw, L]
                vocab_size = tf.shape(log_probs)[-1]
                used_one_hot = tf.reduce_sum(tf.one_hot(used_tokens, depth=vocab_size, dtype=tf.float32), axis=2)  # [b,bw,v]
                candidate_scores = candidate_scores - self.diversity_penalty * used_one_hot
            
            # 展平以选择全局top-k
            # Apply length penalty
            if self.length_penalty_alpha != 0.0:
                length = tf.cast(layer_idx + 1, tf.float32)
                penalty = tf.pow(5.0 + length, self.length_penalty_alpha) / tf.pow(6.0, self.length_penalty_alpha)
                candidate_scores = candidate_scores / penalty
            flat_scores = tf.reshape(candidate_scores, [batch_size, -1])  # [batch_size, beam_width*vocab_size]
            top_k_scores, top_k_flat_indices = tf.nn.top_k(flat_scores, k=beam_width)
            
            # 恢复beam和token索引
            beam_indices = tf.cast(top_k_flat_indices // tf.shape(logits)[-1], tf.int32)
            token_indices = tf.cast(top_k_flat_indices % tf.shape(logits)[-1], tf.int32)
            
            # 更新beams
            batch_indices_gather = tf.tile(tf.range(batch_size)[:, None], [1, beam_width])
            gather_indices = tf.stack([batch_indices_gather, beam_indices], axis=-1)
            new_beams = tf.gather_nd(beams, gather_indices)
            
            # 更新当前层的token
            batch_indices_update = tf.tile(tf.range(batch_size)[:, None], [1, beam_width])  # [batch_size, beam_width]
            beam_indices_update = tf.tile(tf.range(beam_width)[None, :], [batch_size, 1])   # [batch_size, beam_width]
            layer_indices = tf.fill([batch_size, beam_width], layer_idx)                    # [batch_size, beam_width]
            
            update_indices = tf.stack([batch_indices_update, beam_indices_update, layer_indices], axis=-1)
            
            # 确保所有数据类型正确
            update_indices = tf.cast(update_indices, tf.int32)
            token_indices = tf.cast(token_indices, tf.int32)
            new_beams = tf.cast(new_beams, tf.int32)
            
            new_beams = tf.tensor_scatter_nd_update(new_beams, update_indices, token_indices)
            # 确保返回的beams是int32类型
            new_beams = tf.cast(new_beams, tf.int32)
            
            new_scores = top_k_scores
        
        return new_beams, new_scores
    
    def _extract_final_results(self, beams, scores):
        """
        提取最终结果
        """
        # 选择每个batch中得分最高的beam
        best_beam_indices = tf.cast(tf.argmax(scores, axis=1), tf.int32)  # [batch_size]
        batch_indices = tf.cast(tf.range(tf.shape(beams)[0]), tf.int32)
        gather_indices = tf.stack([batch_indices, best_beam_indices], axis=1)
        
        best_beams = tf.gather_nd(beams, gather_indices)  # [batch_size, 5]
        
        # 直接返回张量格式，让调用者处理转换
        return best_beams


class CategoryEmbedding(tf.keras.layers.Layer):
    def __init__(self, vocab_size=501, emb_size=61, **kwargs):
        super().__init__(**kwargs)
        self.vocab_size = int(vocab_size)  # 确保是整数
        self.emb_size = int(emb_size)      # 确保是整数

    def build(self, input_shape):
        # 确保vocab_size和emb_size是整数
        vocab_size_int = int(self.vocab_size)
        emb_size_int = int(self.emb_size)
        
        # 创建embedding权重
        self.embedding_weights = self.add_weight(
            name='embedding_weights',
            shape=(vocab_size_int, emb_size_int),
            initializer='glorot_normal',
            trainable=True
        )
        super().build(input_shape)

    def call(self, idx):
        """
        idx: [...] 形状的索引张量，值范围 0-(vocab_size-1)
        返回: [..., emb_size] 形状的embedding
        """
        # 调试信息：检查输入类型（已禁用）
        # tf.print("CategoryEmbedding input dtype:", idx.dtype, "shape:", tf.shape(idx))

        # 安全的索引处理
        idx_int32 = tf.cast(idx, tf.int32)
        
        # 确保索引在有效范围内 [0, vocab_size-1]

        idx_int32 = idx_int32 % self.vocab_size
        idx_int32 = tf.clip_by_value(idx_int32, 0, self.vocab_size - 1)

        idx_int32 = tf.cast(idx_int32, tf.int32)
        
        embeddings = tf.nn.embedding_lookup(self.embedding_weights, idx_int32)

        # 返回embedding结果，保持原始形状 + embedding维度
        # 输入形状 [...] -> 输出形状 [..., emb_size]
        return embeddings

    def get_config(self):
        config = {'vocab_size': self.vocab_size, 'emb_size': self.emb_size}
        base_config = super().get_config()
        base_config.update(config)
        return base_config
