import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const source = await readFile(new URL('../lib/client.js', import.meta.url), 'utf8');
const tick = () => new Promise(resolve => setImmediate(resolve));
const coder = { name: 'coder', host: 'devbox.example.internal', workspace: '/root', localPort: 18080, remotePort: 18080 };
const entry = { ...coder, url: 'http://127.0.0.1:18080/?token=fixture' };
const registrationKey = (slot, name) => `${slot}#ssh-remotes:${encodeURIComponent(name)}`;

function nodes(tree) {
  if (Array.isArray(tree)) return tree.flatMap(nodes);
  if (!tree || typeof tree !== 'object' || !tree.children) return [];
  return [tree, ...tree.children.flatMap(nodes)];
}
function surface(tree) {
  return nodes(tree).find(node => node.type?.name === 'RemoteSurface');
}
function button(tree, label) {
  const result = nodes(tree).find(node => node.type === 'button' && node.children.includes(label));
  assert.ok(result, `missing ${label} button`);
  return result;
}

// Exercise the real plugin apply/requests/registrations with deferred responses.
// Keep React elements as descriptors so type, key and presence reveal remounts.
function fixture(initialRemotes = [coder]) {
  const registrations = new Map(), changes = [], enters = [], cleanups = [];
  let remotes = initialRemotes, plugin, mounting = false, mountEffects = [];
  const React = {
    createElement: (type, props, ...children) => ({ type, props: props || {}, children }),
    useSyncExternalStore: (_subscribe, snapshot) => snapshot(),
    useEffect: callback => { if (mounting) mountEffects.push(callback); }
  };
  const slots = {
    inject: (_slot, callback) => callback(),
    register(options, component) {
      const key = `${options.name}#${options.key || options.id}`;
      assert.equal(registrations.has(key), false, `duplicate registration ${key}`);
      const record = { options, component };
      registrations.set(key, record);
      changes.push({ action: 'register', key, record });
      return () => {
        if (registrations.get(key) !== record) return;
        registrations.delete(key);
        changes.push({ action: 'dispose', key, record });
      };
    }
  };
  const locale = { register: () => () => {}, bind: () => key => key };
  const ctx = {
    get: key => ({ slots, locale, layout: { selectPanel() {} } })[key],
    effect(callback) { const cleanup = callback(); if (typeof cleanup === 'function') cleanups.push(cleanup); }
  };
  const response = (payload, ok = true) => ({ ok, json: async () => payload });
  const fetch = async (_url, options) => {
    const { action, args } = JSON.parse(options.body);
    if (action === 'entries') return response({ ok: true, remotes: remotes.map(remote => ({ ...remote })) });
    assert.equal(action, 'enter');
    return new Promise(resolve => enters.push({
      name: args.name,
      succeed: value => resolve(response({ ok: true, entry: value })),
      fail: error => resolve(response({ ok: false, error }, false))
    }));
  };
  vm.runInNewContext(source, {
    console, URL, document: { baseURI: 'http://127.0.0.1:19387/' }, fetch,
    window: { __ModuleLoader__: { load(registration) { plugin = registration.factory(name => { assert.equal(name, 'react'); return React; }); } } }
  });
  plugin.apply(ctx);
  const render = (name = 'coder') => registrations.get(registrationKey('main', name)).component({ name });
  return {
    registrations, changes, enters, render,
    mount(name = 'coder') {
      mounting = true;
      const tree = render(name);
      mounting = false;
      const pending = mountEffects;
      mountEffects = [];
      for (const callback of pending) callback();
      return tree;
    },
    async refresh(nextRemotes) {
      remotes = nextRemotes;
      const manager = registrations.get('main#ssh-remotes').component({});
      await button(manager, 'refresh').props.onClick();
    },
    dispose() { for (const cleanup of cleanups.toReversed()) cleanup(); }
  };
}

async function connectedFixture() {
  const f = fixture();
  await tick();
  f.mount();
  assert.equal(f.enters.length, 1);
  f.enters.shift().succeed(entry);
  await tick();
  assert.ok(surface(f.render()));
  return f;
}

test('pending and failed reconnect keep the existing remote surface mounted', async () => {
  const f = await connectedFixture();
  const before = surface(f.render());
  button(f.render(), 'reconnect').props.onClick();
  const pending = f.render();
  assert.equal(surface(pending)?.type, before.type);
  assert.equal(surface(pending)?.props.key, before.props.key);
  assert.equal(surface(pending)?.props.entry, before.props.entry);
  assert.equal(button(pending, 'reconnect').props.disabled, true);
  assert.ok(nodes(pending).some(node => node.props.role === 'status' && node.children.includes('loading')));
  f.enters.shift().fail('fixture reconnect failure');
  await tick();
  const failed = f.render();
  assert.equal(surface(failed)?.type, before.type);
  assert.equal(surface(failed)?.props.key, before.props.key);
  assert.equal(surface(failed)?.props.entry, before.props.entry);
  assert.equal(button(failed, 'reconnect').props.disabled, false);
  assert.ok(nodes(failed).some(node => node.props.role === 'alert' && node.children.includes('fixture reconnect failure')));
  f.dispose();
});

test('reconnect retains the surface key until a changed login URL succeeds', async () => {
  const f = await connectedFixture();
  const before = surface(f.render());
  button(f.render(), 'reconnect').props.onClick();
  f.enters.shift().succeed({ ...entry });
  await tick();
  assert.equal(surface(f.render()).props.key, before.props.key);
  button(f.render(), 'reconnect').props.onClick();
  assert.equal(surface(f.render()).props.key, before.props.key);
  const updated = { ...entry, url: 'http://127.0.0.1:18080/?token=updated' };
  f.enters.shift().succeed(updated);
  await tick();
  assert.equal(surface(f.render()).props.key, updated.url);
  assert.notEqual(surface(f.render()).props.key, before.props.key);
  f.dispose();
});

test('unchanged and reordered workspace refreshes retain both registration identities', async () => {
  const other = { ...coder, name: 'other', host: 'other.example', workspace: '/srv' };
  const f = fixture([coder, other]);
  await tick();
  const before = new Map(f.registrations);
  const changesBefore = f.changes.length;
  await f.refresh([{ ...other }, { ...coder }]);
  assert.equal(f.changes.length, changesBefore);
  for (const [key, record] of before) assert.equal(f.registrations.get(key), record);
  f.dispose();
  assert.equal(f.registrations.size, 0);
});

test('adding and removing workspaces leaves surviving panel and sidebar rows intact', async () => {
  const other = { ...coder, name: 'other', workspace: '/srv' };
  const added = { ...coder, name: 'added', workspace: '/opt' };
  const f = fixture([coder, other]);
  await tick();
  const panelBefore = f.registrations.get(registrationKey('main', 'coder'));
  const rowBefore = f.registrations.get(registrationKey('sidebar.panellist', 'coder'));
  await f.refresh([added, { ...coder }]);
  assert.equal(f.registrations.get(registrationKey('main', 'coder')), panelBefore);
  assert.equal(f.registrations.get(registrationKey('sidebar.panellist', 'coder')), rowBefore);
  for (const slot of ['main', 'sidebar.panellist']) {
    assert.equal(f.registrations.has(registrationKey(slot, 'other')), false);
    assert.ok(f.registrations.has(registrationKey(slot, 'added')));
  }
  assert.equal(f.changes.filter(change => change.action === 'dispose').length, 2);
  f.dispose();
  assert.equal(f.registrations.size, 0);
});

test('changed workspace identity replaces only that workspace and updates its row label', async () => {
  const other = { ...coder, name: 'other', workspace: '/srv' };
  const f = fixture([coder, other]);
  await tick();
  const before = new Map(f.registrations);
  await f.refresh([{ ...coder, workspace: '/new-root' }, other]);
  for (const slot of ['main', 'sidebar.panellist']) {
    assert.notEqual(f.registrations.get(registrationKey(slot, 'coder')), before.get(registrationKey(slot, 'coder')));
    assert.equal(f.registrations.get(registrationKey(slot, 'other')), before.get(registrationKey(slot, 'other')));
  }
  assert.equal(f.registrations.get(registrationKey('sidebar.panellist', 'coder')).options.label(), '/new-root · coder');
  assert.equal(f.changes.filter(change => change.action === 'dispose').length, 2);
  f.dispose();
  assert.equal(f.registrations.size, 0);
});
