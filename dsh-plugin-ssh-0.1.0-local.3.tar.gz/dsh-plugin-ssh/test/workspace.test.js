import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { workspaceEntryUrl, enterRemoteWorkspace } from '../lib/workspace.js';
import { remoteLogPath } from '../lib/config.js';
import { healthCheck, launchRemote, stopRemote, waitHealthy } from '../lib/remote.js';

const remote = {host:'devbox.example.internal',workspace:'/root',remotePort:18080,localPort:18080,logPath:'/root/dsh_tool/dsh-web.log',attachOnly:true};

test('a plain workspace remote resolves the same log the launcher writes', async () => {
  const plain = { host: 'box', workspace: '/srv/app', remotePort: 3080, localPort: 0 };
  assert.equal(remoteLogPath(plain, 'box'), '/srv/app/.dsh-ssh.log');
  assert.equal(remoteLogPath({ ...plain, workspace: '/srv/app/' }, 'box'), '/srv/app/.dsh-ssh.log');
  assert.equal(remoteLogPath({ host: 'box' }, 'box'), '~/.dsh/remotes/box.log');
  assert.equal(remoteLogPath(remote, 'coder'), '/root/dsh_tool/dsh-web.log');
  assert.equal(remoteLogPath({ host: 'box' }, undefined), null);
  const seen = [];
  const entry = await enterRemoteWorkspace(plain, 'box', {
    async runRemote(_r, command) { seen.push(command); return 'dsh web: http://127.0.0.1:3080/?token=t'; },
    async connect() { return { localPort: 3080 }; }
  });
  assert.match(seen[0], /tail -c 32768 -- '\/srv\/app\/\.dsh-ssh\.log'/);
  assert.equal(entry.url, 'http://127.0.0.1:3080/?token=t');
});

test('a missing login URL keeps the log path in the message', async () => {
  await assert.rejects(
    enterRemoteWorkspace({ host: 'box', workspace: '/srv/app', remotePort: 3080 }, 'box', {
      async runRemote() { return 'starting…'; },
      async connect() { return { localPort: 3080 }; }
    }),
    /\/srv\/app\/\.dsh-ssh\.log/
  );
});

test('only accepts a loopback auth URL for the configured remote port', () => {
  const url=workspaceEntryUrl('dsh web: http://127.0.0.1:18080/?token=auth_one\n',18080,18080);
  assert.equal(url,'http://127.0.0.1:18080/?token=auth_one');
  assert.throws(()=>workspaceEntryUrl('https://attacker.example/?token=x',18080,18080));
  assert.throws(()=>workspaceEntryUrl('http://127.0.0.1:3999/?token=x',18080,18080));
  assert.throws(()=>workspaceEntryUrl('http://127.0.0.1:18080/?token='+ 'x'.repeat(300),18080,18080));
});

test('opening a workspace reuses remote Harness without launching or opening a browser',async()=>{
  let launches=0;
  let connects=0;
  const entry=await enterRemoteWorkspace(remote,'fixture',{
    async runRemote(_remote,command){ assert.match(command,/tail -c 32768/); assert.doesNotMatch(command,/npm|launch|nohup|settings.yaml/); launches++; return 'dsh web: http://127.0.0.1:18080/?token=latest_auth'; },
    async connect(_remote,_name,options){ connects++; assert.equal(options.open,false);return {localPort:18080}; }
  });
  assert.equal(launches,1);assert.equal(connects,1);
  assert.equal(entry.workspace,'/root');assert.equal(entry.localPort,18080);
  assert.equal(new URL(entry.url).searchParams.get('token'),'latest_auth');
});

test('shared Harness cannot be killed or started twice by plugin lifecycle commands',()=>{
  assert.throws(()=>launchRemote(remote,'shared'),/现有 Harness/);
  assert.throws(()=>stopRemote(remote,'shared'),/共用实例/);
});

test('health probe recognises DSH auth fence but rejects a generic 401',async t=>{
  let dsh=true;
  const server=createServer((_req,res)=>{res.writeHead(401);res.end(dsh?'dsh web authentication required; reopen the URL printed by dsh web.':'unauthorized');});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  t.after(()=>new Promise(resolve=>server.close(resolve)));
  const port=server.address().port;
  assert.equal((await healthCheck(port)).isDsh,true);
  dsh=false;assert.equal((await healthCheck(port)).isDsh,false);
});

test('dead SSH startup cannot borrow health from an unrelated DSH listener',async t=>{
  let requests=0;
  const server=createServer((_req,res)=>{requests++;res.end('__DSH_BOOT__');});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  t.after(()=>new Promise(resolve=>server.close(resolve)));
  const result=await waitHealthy(server.address().port,{attempts:1,isTunnelAlive:()=>false});
  assert.equal(result.up,false);assert.match(result.error,/ssh tunnel exited/);assert.equal(requests,0);
});

test('SSH exiting during health verification is still a failed startup',async t=>{
  let alive=true;
  const server=createServer((_req,res)=>{alive=false;res.end('__DSH_BOOT__');});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  t.after(()=>new Promise(resolve=>server.close(resolve)));
  const result=await waitHealthy(server.address().port,{attempts:1,isTunnelAlive:()=>alive});
  assert.equal(result.up,false);assert.match(result.error,/ssh tunnel exited/);
});

test('health probe aborts a stalled peer within its timeout',async t=>{
  const sockets=new Set();
  const server=createServer(()=>{});
  server.on('connection',s=>{sockets.add(s);s.on('close',()=>sockets.delete(s));});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  t.after(()=>{for(const socket of sockets)socket.destroy();server.close();});
  const started=Date.now();
  const result=await healthCheck(server.address().port,{timeoutMs:80});
  assert.equal(result.up,false);assert.ok(Date.now()-started<1000);
});
