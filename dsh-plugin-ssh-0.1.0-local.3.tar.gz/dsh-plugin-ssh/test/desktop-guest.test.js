import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const source=(await readFile(new URL('../lib/client.js',import.meta.url),'utf8')).replace('return { name: "ssh-remote-workspaces",','return { test: { DesktopGuest }, name: "ssh-remote-workspaces",');
const tick=()=>new Promise(resolve=>setImmediate(resolve));

function fixture(acquire) {
  const events=[];let cleanup;let component;let node;
  class Guest extends EventTarget {
    constructor(){super();this.style={};this.dataset={};this.attributes={};}
    setAttribute(name,value){this.attributes[name]=value;}
    async loadURL(url){events.push(['load',url]);}
    remove(){events.push(['remove']);}
  }
  const bridge={
    acquire,
    async release(lease){events.push(['release',lease]);},
    onOpenRequested(lease){events.push(['listen',lease]);return ()=>events.push(['unsubscribe',lease]);}
  };
  const holder={appendChild(element){events.push(['append',element.attributes.src,element.attributes.partition]);node=element;}};
  const React={createElement:(...args)=>args,useRef:()=>({current:holder}),useEffect:fn=>{cleanup=fn();}};
  const context={AbortController,console,dshDesktop:{browser:bridge},document:{createElement(tag){assert.equal(tag,'webview');return new Guest();}},window:{__ModuleLoader__:{load(registration){component=registration.factory(name=>{assert.equal(name,'react');return React;}).test.DesktopGuest;}}}};
  vm.runInNewContext(source,context);
  return {component,events,get node(){return node;},cleanup:()=>cleanup()};
}

test('desktop guest uses approved lease then loads remote only after dom-ready',async()=>{
  const f=fixture(async identity=>{assert.equal(identity,'ssh-workspace:devbox.example.internal:/root');return {lease:'approved-lease',partition:'approved-partition'};});
  let ready=0;
  f.component({entry:{host:'devbox.example.internal',workspace:'/root',url:'http://127.0.0.1:18080/?token=sample'},onReady:()=>ready++,onError:error=>assert.fail(error)});
  await tick();
  assert.deepEqual(f.events.find(e=>e[0]==='append'),['append','about:blank#approved-lease','approved-partition']);
  assert.equal(f.events.filter(e=>e[0]==='load').length,0);
  f.node.dispatchEvent(new Event('dom-ready'));
  await tick();
  assert.deepEqual(f.events.find(e=>e[0]==='load'),['load','http://127.0.0.1:18080/?token=sample']);
  f.node.dispatchEvent(new Event('dom-ready'));
  assert.equal(ready,1);
  assert.equal(f.events.filter(e=>e[0]==='load').length,1);
  f.cleanup();await tick();
  assert.equal(f.events.filter(e=>e[0]==='release').length,1);
  assert.equal(f.node.attributes.preload,undefined);
  assert.equal(f.node.attributes.nodeintegration,undefined);
});

test('closing a panel while lease acquisition is pending releases the late lease',async()=>{
  let resolve;
  const f=fixture(()=>new Promise(r=>resolve=r));
  f.component({entry:{host:'devbox.example.internal',workspace:'/root',url:'http://127.0.0.1:18080/'},onReady:()=>{},onError:error=>assert.fail(error)});
  f.cleanup();resolve({lease:'late-lease',partition:'p'});await tick();
  assert.deepEqual(f.events,[['release','late-lease']]);
});
