#!/bin/sh
# Install this dsh-plugin-ssh folder into a DSH profile, for the machine you run it on.
#
#   ./install.sh                  # profile "desktop" (DeepSeek Harness app)
#   ./install.sh web              # profile "web" (dsh web from a terminal)
#   ./install.sh desktop --copy  # first copy the folder to ~/plugins/dsh-plugin-ssh
#
# The profile stores a link: dependency, so the folder must stay where it lands.
set -eu

profile="desktop"
copy=0
for arg in "$@"; do
  case "$arg" in
    --copy) copy=1 ;;
    -h|--help) sed -n '2,8p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    -*) echo "install: unknown flag $arg" >&2; exit 2 ;;
    *) profile="$arg" ;;
  esac
done

here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
target="$here"

if [ "$copy" -eq 1 ]; then
  target="$HOME/plugins/dsh-plugin-ssh"
  if [ -e "$target" ]; then
    echo "install: $target already exists; remove it or install from there directly" >&2
    exit 1
  fi
  mkdir -p "$(dirname "$target")"
  cp -R "$here" "$target"
  echo "install: copied plugin to $target"
fi

# --- locate a dsh launcher -------------------------------------------------
dsh_bin=""
for candidate in "$(command -v dsh 2>/dev/null || true)" \
                 "/Applications/DeepSeek Harness.app/Contents/Resources/runtime/cli/bin/dsh"; do
  [ -n "$candidate" ] && [ -x "$candidate" ] && { dsh_bin="$candidate"; break; }
done
if [ -z "$dsh_bin" ]; then
  cat >&2 <<'EOF'
install: no `dsh` on PATH.
  - Desktop app: open the app, go to 设置 → 插件管理 → 从本地目录安装, pick this folder.
  - CLI: install @deepseek-ai/dsh (npm i -g @deepseek-ai/dsh), or symlink it onto PATH.
EOF
  exit 1
fi

# --- pnpm: dsh plugin shells out to it -------------------------------------
if ! command -v pnpm >/dev/null 2>&1; then
  bundled="/Applications/DeepSeek Harness.app/Contents/Resources/runtime/primary-runtime/dependencies/pnpm/bin/pnpm.cjs"
  if [ -f "$bundled" ]; then
    shim_dir="${TMPDIR:-/tmp}/dsh-ssh-bin"
    mkdir -p "$shim_dir"
    printf '#!/bin/sh\nexec "%s" "$@"\n' "$bundled" > "$shim_dir/pnpm"
    chmod +x "$shim_dir/pnpm"
    PATH="$shim_dir:$PATH"
    export PATH
    echo "install: using the pnpm bundled with the desktop app"
  else
    echo "install: pnpm not found; install it with 'npm i -g pnpm' and rerun" >&2
    exit 1
  fi
fi

echo "install: $dsh_bin plugin --profile $profile add $target"
"$dsh_bin" plugin --profile "$profile" add "$target"

cat <<EOF

Installed into profile "$profile".
Fully quit and reopen DSH, then check the sidebar for "SSH 远端".
Next: register a remote, e.g.

  node "$target/bin/dsh-ssh.js" add prod --host my-server --user deploy --workspace /srv/app
  node "$target/bin/dsh-ssh.js" setup prod --copy-settings
EOF
