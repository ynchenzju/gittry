# dsh-plugin-ssh（侧栏 SSH 远端版）

把远端机器上的 DeepSeek Harness 当作工作区，直接在本地 DSH 里用。侧栏会出现：

- **SSH 远端**：已登记远端的总览。
- **`<工作区> · <名字>`**：每台远端一个入口，点进去就在 App 内打开**远端自己的** Harness。

远端负责模型调用、工具执行、技能和会话记录，本机只是薄客户端；链路是
`本机浏览器 → SSH 隧道 → 远端 dsh web`，两端都只监听 `127.0.0.1`。

## 安装

前置：DSH ≥ 0.1.0-rc.6、`ssh` 在 PATH 上、pnpm（`dsh plugin` 报缺 pnpm 时先装）。
桌面版自带一份 pnpm，在
`…/DeepSeek Harness.app/Contents/Resources/runtime/primary-runtime/dependencies/pnpm/bin/pnpm.cjs`。

**方式一：命令行（推荐，可复核）**

```sh
# 把整个目录放到一个长期保留的位置（profile 会记录该路径，之后不要移动）
mv dsh-plugin-ssh ~/plugins/dsh-plugin-ssh

# 装进正在用的 profile：桌面版是 desktop，命令行版是 web
dsh plugin --profile desktop add ~/plugins/dsh-plugin-ssh
```

安装后**完全退出并重开 DSH**（不是只刷新页面），侧栏才会出现新条目。

**方式二：GUI**

设置 → 插件管理 → 从本地目录安装 → 选中该文件夹 → 启用。

> 桌面版的 `desktop` profile 由 App 独占，命令行对它会报
> “managed exclusively by the Electron application”。装进桌面版请用 GUI，
> 或先完全退出 App 再执行 `dsh plugin --profile desktop add …`。

**只用命令行、不装 UI 也可以**：

```sh
node ~/plugins/dsh-plugin-ssh/bin/dsh-ssh.js list
```

## 配置一台远端

```sh
DSH_SSH="node ~/plugins/dsh-plugin-ssh/bin/dsh-ssh.js"

# 1) 登记主机（host 可直接用 ~/.ssh/config 里的别名）
$DSH_SSH add prod --host my-server --user deploy --workspace /srv/app

# 2) 远端准备：查 node、装 dsh、建工作区、带上模型凭据、启动服务
$DSH_SSH setup prod --copy-settings
```

此时侧栏会自动出现 `prod` 的入口，无需再填别的配置：GUI 从
`<workspace>/.dsh-ssh.log` 读登录地址，这正是 `setup`/`start` 写日志的位置。

如果远端 Harness 是你自己用 tmux 常驻的共用实例，就别让插件去启停它：

```sh
$DSH_SSH add shared --host my-server --workspace /root \
  --remote-port 18080 --local-port 18080 \
  --log-path /root/dsh_tool/dsh-web.log \
  --start-command 'sh /root/dsh_tool/dsh-start.sh' \
  --attach-only
```

| 参数 | 作用 |
|---|---|
| `--log-path` | GUI 从哪个日志读登录 token（默认 `<workspace>/.dsh-ssh.log`） |
| `--start-command` | 读日志前先跑的**幂等**启动脚本（已在跑时只报告地址） |
| `--attach-only` | 禁止插件启动/停止远端，只建隧道 + 读日志 |

## 常用命令

```sh
$DSH_SSH list                 # 所有远端及连接状态
$DSH_SSH status prod          # 隧道 / 远端进程 / HTTP 健康
$DSH_SSH connect prod         # 建隧道并在系统浏览器打开（--no-open 只建隧道）
$DSH_SSH logs prod            # 看远端日志
$DSH_SSH disconnect prod      # 断开隧道（--all 全断）
$DSH_SSH rm prod              # 删除远端登记
```

## 必须提前知道的几件事

- **只支持密钥登录**：所有 ssh 调用都带 `BatchMode=yes`，不弹密码提示。
  先把公钥放到远端（`ssh-copy-id`）或用 ssh-agent。
- **端口要和登录 cookie 一致**：DSH 的登录 cookie 绑定了
  `127.0.0.1:<端口>`。想复用已有登录状态，远端与本地就用同一个端口
  （上面例子都用 18080）；换端口就要重新用 token 登录一次。
- **模型凭据在远端**：远端 Harness 只读它自己的 `~/.dsh/settings.yaml` 和
  工作目录下的 `.env`。`setup --copy-settings` 可以拷一次，但之后远端是独立
  的，改模型/加 key 要改远端那份。
- **远端只绑 127.0.0.1**：不要为了省事改成 `0.0.0.0`，隧道才是唯一入口。
- **令牌只在内存**：登录 token 每次进入时现读日志，只用于拼进入 URL，
  不写进配置、不硬编码在代码里。
- **Host key**：首次连接用 `StrictHostKeyChecking=accept-new`，之后仍按
  `known_hosts` 校验。

## 卸载

```sh
dsh plugin --profile desktop remove dsh-plugin-ssh
```

远端如需清理：`$DSH_SSH disconnect --all`，再按需删除远端
`~/.dsh/remotes/<name>.json` 和 `<workspace>/.dsh-ssh.log`。

## 目录结构

| 路径 | 作用 |
|---|---|
| `lib/index.js` | 宿主端：`sshRemotes` 服务 + `/ssh-remotes` HTTP 路由 |
| `lib/client.js` | 浏览器端：侧栏入口、远端面板、桌面 webview guest |
| `lib/workspace.js` | 进入远端：读日志取 token、建隧道、拼进入 URL |
| `lib/remote.js` | 远端生命周期：健康检查、连接、provision、启停、日志 |
| `lib/tunnel.js` | OpenSSH 封装（隧道 + 一次性远端命令） |
| `lib/config.js` | `$DSH_HOME/remotes.json` 读写与默认值 |
| `bin/dsh-ssh.js` | 独立 CLI |
| `cordis.patch.yml` | profile bundle 层（路径保持相对，勿写死本机绝对路径） |
| `test/` | `npm test` / `node --test test/*.test.js` |
