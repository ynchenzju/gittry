#!/usr/bin/env python
# -*- coding: utf-8 -*-

from models.hinet_v3 import HiNetModel
import os
import tensorflow as tf
import ego
from tools.feature import FeatureManager
from utils.get_emb import get_item_embs
from utils.get_emb import get_item_attention_embs
from utils.get_emb import get_item_long_seq_att_embs
from utils.sum_log import summary_vector
from utils.sum_log import summary_scalar

print("ego training mode: {}".format(ego.is_training_mode()))

MC_PATH = "configs/mcconf_v3.yaml"
fm = None
if os.path.exists(MC_PATH):
    fm = FeatureManager(MC_PATH, "configs/convert.yaml")

assert fm is not None

shared_dense_slots = [
    101,102,103,104,602
]
iterable_dense_slots = [
    301, 302, 303, 304, 305, 306,
    311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330,
    501, 502, 503, 504, 505, 506, 507, 551
]
shared_onehot_slots = [
    100
]
iterable_onehot_slots = [
    201,202,203,204,401,402,403,404
]

SHARED_DENSE_DIM = 53
ITERABLE_DENSE_DIM = 39
SHARED_ONEHOT_DIM = 13
ITERABLE_ONEHOT_DIM = 26
BUNDLE_DIM = 7

SCEN_EXPERT_NUM = 4
TASK_EXPERT_NUM = 2
BUNDLE_INDEX_MAPPING = {"cart": 0, "osp": 1, "buya": 2, "mpp": 3, "odp": 4}

BUNDLE_INDICATOR = [1000]

model = HiNetModel(fm,
                   shared_dense_dim=SHARED_DENSE_DIM, iterable_dense_dim=ITERABLE_DENSE_DIM,
                   shared_onehot_dim=SHARED_ONEHOT_DIM, iterable_onehot_dim=ITERABLE_ONEHOT_DIM,
                   bundle_dim=BUNDLE_DIM,
                   scen_expert_num=SCEN_EXPERT_NUM, task_expert_num=TASK_EXPERT_NUM,
                   bundle_index_mapping=BUNDLE_INDEX_MAPPING,
                   bundle_indicator=BUNDLE_INDICATOR)
p0 = model.build_graph()[0]
debug_nodes = model.get_debug_nodes()
scalar_tensor = model.get_scalar_tensor()
print(['cache_flag'] + p0['nodes'] + debug_nodes)
print(scalar_tensor)
if ego.is_training_mode():

    eval_round = ego.OfflineRound(name="eval",
                                  targets=p0["nodes"] + debug_nodes, 
                                  final_loss = None, 
                                  dump_scalar_tensors_to_tensorboard = scalar_tensor)
    
    r1 = ego.OfflineRound(name="p0", 
                          targets=p0["nodes"] + debug_nodes, 
                          final_loss=p0["final_loss"], 
                          dump_scalar_tensors_to_tensorboard = scalar_tensor, 
                          train_sparse=True)
    ego.compile(rounds=[eval_round, r1])
else:
    r = ego.OnlineRound(name="online", targets=(['cache_flag'] + p0['nodes']))
    ego.compile(rounds=[r])
