import tensorflow as tf
import ego
import numpy as np
from tensorflow.python.keras.layers import LayerNormalization


def get_shape(inputs):
    dynamic_shape = tf.shape(inputs)
    static_shape = inputs.get_shape().as_list()
    shape = []
    for i, dim in enumerate(static_shape):
        shape.append(dim if dim is not None else dynamic_shape[i])
    return shape


def get_init_op(init_name, param_dicts=None):
    if param_dicts is None:
        param_dicts = {}

    if init_name == "truncated_normal":
        stddev = param_dicts.get("stddev", 0.001)
        return tf.truncated_normal_initializer(stddev=stddev, dtype=tf.float32)
    elif init_name == "random_uniform":
        min_val = param_dicts.get("min_val", -0.05)
        max_val = param_dicts.get("max_val", -0.05)
        return tf.random_uniform_initializer(min_val=min_val, max_val=max_val, dtype=tf.float32)
    elif init_name == "random_normal":
        mean = param_dicts.get("mean", 0.0)
        stddev = param_dicts.get("stddev", 0.05)
        seed = param_dicts.get("seed", 123)
        return tf.random_normal_initializer(mean=mean, stddev=stddev, seed=seed)
    elif init_name == "ones":
        return tf.ones_initializer(dtype=tf.float32)
    elif init_name == "zeros":
        return tf.zeros_initializer(dtype=tf.float32)
    elif init_name == "constant":
        value = param_dicts.get("value", 0.1)
        return tf.constant_initializer(value=value, dtype=tf.float32, verify_shape=True)
    elif init_name == "xavier_normal" or init_name == "glorot_normal":
        return tf.initializers.glorot_normal()
    elif init_name == "xavier_uniform" or init_name == "glorot_uniform":
        return tf.initializers.glorot_uniform()
    else:
        raise ValueError(f"[wrong init_op={init_op}] param_dicts = {param_dicts}")


def get_act_op(act_name, param_dicts=None):
    if param_dicts is None:
        param_dicts = {}
    
    if act_name == "relu":
        return tf.nn.relu
    elif act_name == "relu6":
        return tf.nn.relu6
    elif act_name == "elu":
        return tf.nn.elu
    elif act_name == "selu":
        return tf.nn.selu
    elif act_name == "gelu":
        return tf.nn.gelu
    elif act_name == "lrelu":
        return tf.nn.leaky_relu
    elif act_name == "silu":
        return tf.nn.silu
    elif act_name == "tanh":
        return tf.nn.tanh
    elif act_name == "sigmoid":
        return tf.nn.sigmoid
    else:
        raise ValueError(f"[wrong act_name={act_name}] param_dicts = {param_dicts}")


class FFN(tf.keras.layers.Layer):
    def __init__(self, d_model, num_token, ffn_type, ffn_act, init_op, layer_idx):
        super(FFN, self).__init__()
        assert ffn_type in ("share_all", "per_token")
        self.ffn_type = ffn_type
        self.num_token = num_token
        self.d_model = d_model
        print("[FFN]", d_model)
        if self.ffn_type == "share_all":
            print(f"[FFN {self.ffn_type}], {layer_idx}")
            self.ffn = ego.DenseTower(
                name=f"{ffn_type}_{layer_idx}_ffn",
                output_dims=[d_model],
                kernel_initializers=[get_init_op(init_op)],
                bias_initializers=[get_init_op("zeros")],
                activations=[get_act_op(ffn_act)],
                norms=[True],
                use_bias=[True]
            )
        elif self.ffn_type == "per_token":
            self.ffn = []
            print(f"[FFN {self.ffn_type}], {layer_idx}")
            for token_idx in range(num_token):
                ffn_layer = ego.DenseTower(
                        name=f"{ffn_type}_{layer_idx}_{token_idx}_ffn",
                        output_dims=[d_model],
                        kernel_initializers=[get_init_op(init_op)],
                        bias_initializers=[get_init_op("zeros")],
                        activations=[get_act_op(ffn_act)],
                        norms=[True], # [False, True], [False, False]
                        use_bias=[True]
                )
                self.ffn.append(ffn_layer)

    def call(self, inp):
        if self.ffn_type == "share_all":
            out = self.ffn(inp)
        elif self.ffn_type == "per_token":
            inp_list = tf.split(inp, self.num_token, axis=1)
            out_list = [ffn(inp) for inp, ffn in zip(inp_list, self.ffn)]
            out = tf.concat(out_list, axis=1)
        else:
            raise ValueError
        return out


class FieldPairSpecializedAttention(tf.keras.layers.Layer):
    def __init__(self, d_model, num_fields, num_head,layer_name=None):
        super(FieldPairSpecializedAttention, self).__init__()
        self.d_model = d_model
        self.num_head = num_head
        self.num_fields = num_fields
        self.depth = d_model // num_head
        self.layer_name = layer_name if layer_name else "mhtm"
        
        # Field-specific q/k/v
        self.q_layers = [tf.keras.layers.Dense(d_model, use_bias=False) for _ in range(num_fields)]
        self.k_layers = [tf.keras.layers.Dense(d_model, use_bias=False) for _ in range(num_fields)]
        self.v_layers = [tf.keras.layers.Dense(d_model, use_bias=False) for _ in range(num_fields)]
        
        # Field-pair scalar
        self.field_pair_scale = tf.Variable(tf.ones([num_fields, num_fields]),dtype=tf.float32, name="field_pair_scale")
        
        
    def split_heads(self, x, batch_size):
        x = tf.reshape(x, (batch_size, -1, self.num_head, self.depth))
        return tf.transpose(x, perm=[0, 2, 1, 3])

        
    def call(self, inp):
        """_summary_

        Args:
            inp (_type_):[B, F, D]
        """
        batch_size = tf.shape(inp)[0]
        
        q_list, k_list, v_list = [], [], []
        for i in range(self.num_fields):
            q_list.append(self.q_layers[i](inp[:, i, :]))  
            k_list.append(self.k_layers[i](inp[:, i, :]))
            v_list.append(self.v_layers[i](inp[:, i, :]))
        q = tf.stack(q_list, axis=1) 
        k = tf.stack(k_list, axis=1)
        v = tf.stack(v_list, axis=1)

        q = self.split_heads(q, batch_size)  # (batch_size, num_heads, seq_len_q, depth)
        k = self.split_heads(k, batch_size)  # (batch_size, num_heads, seq_len_k, depth)
        v = self.split_heads(v, batch_size)  # (batch_size, num_heads, seq_len_v, depth)

        matmul_qk = tf.matmul(q, k, transpose_b=True)  # (..., seq_len_q, seq_len_k)

        dk = tf.cast(tf.shape(k)[-1], tf.float32)
        attn_logits = matmul_qk / tf.math.sqrt(dk)

        scalar = tf.expand_dims(self.field_pair_scale, axis=0)  # [1, F, F]
        attn_logits = attn_logits * scalar

        attention_weights = tf.nn.softmax(attn_logits, axis=-1)  # (..., seq_len_q, seq_len_k)

        attn_output = tf.matmul(attention_weights, v) 

        attn_output = tf.transpose(attn_output, perm=[0, 2, 1, 3])  # (batch_size, seq_len_q, num_heads, depth)
        attn_output = tf.reshape(attn_output, (batch_size, -1, self.d_model))  # (batch_size, seq_len_q, d_model)

        return attn_output



class FAT(tf.keras.layers.Layer):
    def __init__(self, d_model, num_token, num_head, ffn_type, ffn_act, init_op, num_layers, field_bias = True, use_res=True, mix_ln=False, ffn_ln=False, ln_eps=1e-6):
        super(FAT, self).__init__()
        
        self.mhtm_list = [FieldPairSpecializedAttention(d_model, num_token, num_head) for _layer_idx in range(num_layers)]
        self.ffn_list = [FFN(d_model, num_token, ffn_type, ffn_act, init_op, layer_idx=_layer_idx) for _layer_idx in range(num_layers)]

        self.use_res = use_res
        self.d_model = d_model
        self.num_token = num_token
        self.num_head = num_head
        self.field_bias = field_bias
        self.mix_ln = mix_ln
        self.ffn_ln = ffn_ln
        self.ln_eps = ln_eps
        print(f"[FAT] self.use_res = {self.use_res}, self.mix_ln = {self.mix_ln}, self.ffn_ln = {self.ffn_ln}, self.ln_eps = {self.ln_eps}")

    def call(self, inp):
        """_summary_

        Args:
            inp (_type_): (batch_size, num_field, d_model)

        Returns:
            _type_: _description_
        """
        if self.field_bias:
            self.field_pair_bias = tf.Variable(
                tf.zeros([self.num_token, self.d_model], dtype=tf.float32), name="field_pair_bias"
            )
            inp += self.field_pair_bias

        print("[FAT] inp", inp)
        for i, (mhtm_layer, ffn) in enumerate(zip(self.mhtm_list, self.ffn_list)):
            # out = ffn(mix_layer(inp, is_list=False))
            if self.use_res:
                out1 = mhtm_layer(inp)
                if self.mix_ln:
                    out1 = LayerNormalization(epsilon=self.ln_eps, name=f"mix{i}_ln")(out1)  # TODO: RMSNorm
                out1 = out1 + inp
                out = ffn(out1)
                out = out + out1
            else:
                out = ffn(mhtm_layer(inp))

            print(f"[FAT{i}]", inp)
            print(f"[FAT{i}]", out)
            if self.use_res:
                out += inp
            
            if self.ffn_ln:
                out = LayerNormalization(epsilon=self.ln_eps, name=f"pffn{i}_ln")(out) 
            
            inp = out
        return out
