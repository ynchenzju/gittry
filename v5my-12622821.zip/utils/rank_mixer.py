import tensorflow as tf
import ego
import numpy as np
from tensorflow.python.keras.layers import LayerNormalization


def get_shape(inputs):
    dynamic_shape = tf.shape(inputs)
    static_shape = inputs.get_shape().as_list()
    shape = []
    for i, dim in enumerate(static_shape):
        shape.append(dim if dim is not None else dynamic_shape[i])
    return shape


def get_init_op(init_name, param_dicts=None):
    if param_dicts is None:
        param_dicts = {}

    if init_name == "truncated_normal":
        stddev = param_dicts.get("stddev", 0.001)
        return tf.truncated_normal_initializer(stddev=stddev, dtype=tf.float32)
    elif init_name == "random_uniform":
        min_val = param_dicts.get("min_val", -0.05)
        max_val = param_dicts.get("max_val", -0.05)
        return tf.random_uniform_initializer(min_val=min_val, max_val=max_val, dtype=tf.float32)
    elif init_name == "random_normal":
        mean = param_dicts.get("mean", 0.0)
        stddev = param_dicts.get("stddev", 0.05)
        seed = param_dicts.get("seed", 123)
        return tf.random_normal_initializer(mean=mean, stddev=stddev, seed=seed)
    elif init_name == "ones":
        return tf.ones_initializer(dtype=tf.float32)
    elif init_name == "zeros":
        return tf.zeros_initializer(dtype=tf.float32)
    elif init_name == "constant":
        value = param_dicts.get("value", 0.1)
        return tf.constant_initializer(value=value, dtype=tf.float32, verify_shape=True)
    elif init_name == "xavier_normal" or init_name == "glorot_normal":
        return tf.initializers.glorot_normal()
    elif init_name == "xavier_uniform" or init_name == "glorot_uniform":
        return tf.initializers.glorot_uniform()
    else:
        raise ValueError(f"[wrong init_op={init_op}] param_dicts = {param_dicts}")


def get_act_op(act_name, param_dicts=None):
    if param_dicts is None:
        param_dicts = {}
    
    if act_name == "relu":
        return tf.nn.relu
    elif act_name == "relu6":
        return tf.nn.relu6
    elif act_name == "elu":
        return tf.nn.elu
    elif act_name == "selu":
        return tf.nn.selu
    elif act_name == "gelu":
        return tf.nn.gelu
    elif act_name == "lrelu":
        return tf.nn.leaky_relu
    elif act_name == "silu":
        return tf.nn.silu
    elif act_name == "tanh":
        return tf.nn.tanh
    elif act_name == "sigmoid":
        return tf.nn.sigmoid
    else:
        raise ValueError(f"[wrong act_name={act_name}] param_dicts = {param_dicts}")


class FFN(tf.keras.layers.Layer):
    def __init__(self, d_model, num_token, ffn_type, ffn_act, ffn_scale_ratio, init_op, layer_idx):
        super(FFN, self).__init__()
        assert ffn_type in ("share_all", "per_token")
        self.ffn_type = ffn_type
        self.num_token = num_token
        self.d_model = d_model
        h_d_model = int(ffn_scale_ratio * d_model)
        print("[FFN]", h_d_model, d_model)
        if self.ffn_type == "share_all":
            print(f"[FFN {self.ffn_type}], {layer_idx}")
            self.ffn = ego.DenseTower(
                name=f"{ffn_type}_{layer_idx}_ffn",
                output_dims=[h_d_model, d_model],
                kernel_initializers=[get_init_op(init_op), get_init_op(init_op)],
                bias_initializers=[get_init_op("zeros"), get_init_op("zeros")],
                activations=[get_act_op(ffn_act), get_act_op(ffn_act)],
                norms=[True, True],
                use_bias=[True, True]
            )
        elif self.ffn_type == "per_token":
            self.ffn = []
            print(f"[FFN {self.ffn_type}], {layer_idx}")
            for token_idx in range(num_token):
                ffn_layer = ego.DenseTower(
                        name=f"{ffn_type}_{layer_idx}_{token_idx}_ffn",
                        output_dims=[h_d_model, d_model],
                        kernel_initializers=[get_init_op(init_op), get_init_op(init_op)],
                        bias_initializers=[get_init_op("zeros"), get_init_op("zeros")],
                        activations=[get_act_op(ffn_act), get_act_op(ffn_act)],
                        norms=[True, True], # [False, True], [False, False]
                        use_bias=[True, True]
                )
                self.ffn.append(ffn_layer)

    def call(self, inp):
        if self.ffn_type == "share_all":
            out = self.ffn(inp)
        elif self.ffn_type == "per_token":
            inp_list = tf.split(inp, self.num_token, axis=1)
            out_list = [ffn(inp) for inp, ffn in zip(inp_list, self.ffn)]
            out = tf.concat(out_list, axis=1)
        else:
            raise ValueError
        return out


class MultiHeadTokenMixing(tf.keras.layers.Layer):
    def __init__(self, d_model, num_token, h, layer_name=None):
        super(MultiHeadTokenMixing, self).__init__()
        self.num_token = num_token
        self.d_model = d_model
        self.h = h
        self.layer_name = layer_name if layer_name else "mhtm"
        assert h == num_token and d_model % num_token == 0

    def call(self, inp, is_list=True):
        # inp (bs, num_token, d_model)
        inp_list = tf.split(inp, self.h, axis=2) # h x (bs, num_token, d_model // h)
        
        out = tf.concat([tf.reshape(e, (-1, 1, self.d_model)) for e in inp_list], axis=1)
        print("[multi_head_token_mixer] inp", inp_list)
        print("[multi_head_token_mixer] out", out)
        return out


class RankMixer(tf.keras.layers.Layer):
    def __init__(self, d_model, num_token, ffn_type, ffn_act, ffn_scale_ratio, init_op, num_layers, use_res=True, mix_ln=False, ffn_ln=False, ln_eps=1e-6):
        super(RankMixer, self).__init__()
        self.mhtm_list = [MultiHeadTokenMixing(d_model, num_token, h=num_token) for _layer_idx in range(num_layers)]
        self.ffn_list = [FFN(d_model, num_token, ffn_type, ffn_act, ffn_scale_ratio, init_op, layer_idx=_layer_idx) for _layer_idx in range(num_layers)]

        self.use_res = use_res
        self.d_model = d_model
        self.h = num_token
        self.mix_ln = mix_ln
        self.ffn_ln = ffn_ln
        self.ln_eps = ln_eps
        print(f"[RankMixer] self.use_res = {self.use_res}, self.mix_ln = {self.mix_ln}, self.ffn_ln = {self.ffn_ln}, self.ln_eps = {self.ln_eps}")

    def call(self, inp):
        # inp_list (bs, num_token, d_model // h)
        # _shape_list = [get_shape(_e)[1] for _e in inp_list]
        # assert len(set(_shape_list)) == 1
        inp_list = inp
        print("[Rank_Mixer] inp", inp)
        for i, (mix_layer, ffn) in enumerate(zip(self.mhtm_list, self.ffn_list)):
            # out = ffn(mix_layer(inp, is_list=False))
            if self.use_res:
                out1 = mix_layer(inp, is_list=False)
                out1 = out1 + inp
                if self.mix_ln:
                    out1 = LayerNormalization(epsilon=self.ln_eps, name=f"mix{i}_ln")(out1) 
                out = ffn(out1)
            else:
                out = ffn(mix_layer(inp, is_list=False))

            print(f"[Rank_Mixer{i}]", inp)
            print(f"[Rank_Mixer{i}]", out)
            if self.use_res:
                out += inp
            
            if self.ffn_ln:
                out = LayerNormalization(epsilon=self.ln_eps, name=f"pffn{i}_ln")(out) 
            
            inp = out
        return out
