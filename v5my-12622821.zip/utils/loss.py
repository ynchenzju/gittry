# -*- coding: utf-8 -*-
#!/usr/bin/env python
import tensorflow as tf


def comp_list_cnt(session_id, name=None):
    session_id = tf.reshape(session_id, (-1, 1))
    masks = tf.equal(session_id, tf.transpose(session_id))
    row_w = tf.reduce_sum(tf.cast(masks, dtype=tf.float32), axis=1)
    list_cnt = tf.reduce_sum(1.0 / row_w, name=name)
    return list_cnt


def absolute_error(label, pred, name="absolute_error"):
    with tf.compat.v1.variable_scope(name + "_loss"):
        return tf.abs(tf.subtract(pred, label))


def square_error(label, pred, name="square_error"):
    with tf.compat.v1.variable_scope(name + "_loss"):
        return tf.square(tf.subtract(pred, label))


def _prob2logits(p):
    return tf.log(p / ( 1 - p))


## https://github.com/alibaba/EasyRec/blob/f6f1870835519c568b39803d056256c7a7cb0c17/easy_rec/python/loss/jrc_loss.py
def jrc_loss(labels,
             probs,
             ## logits,
             session_ids,
            #  alpha=0.5,
            #  loss_weight_strategy='fixed',
             sample_weights=1.0,
             same_label_loss=True,
             only_listwise=True,
             name=''):
    """Joint Optimization of Ranking and Calibration with Contextualized Hybrid Model.

        https://arxiv.org/abs/2208.06164

    Args:
        labels: a `Tensor` with shape [batch_size]. e.g. click or not click in the session.
        probs:  a `Tensor` with shape [batch_size, 1] or [batch_size, 2]. e.g. click or not click in the session.
        logits: a `Tensor` with shape [batch_size, 2]. e.g. the value of last neuron before activation.
        session_ids: a `Tensor` with shape [batch_size]. Session ids of each sample, used to max GAUC metric. e.g. user_id
        alpha: the weight to balance ranking loss and calibration loss
        loss_weight_strategy: str, the loss weight strategy to balancing between ce_loss and ge_loss
        sample_weights: Coefficients for the loss. This must be scalar or broadcastable to
        `labels` (i.e. same rank and each dimension is either 1 or the same).
        same_label_loss: enable ge_loss for sample with same label in a session or not.
        name: the name of loss
    """
    if only_listwise:
        name = f"{name}_listwise"
    else:
        name = f"{name}_jrc"
    with tf.compat.v1.variable_scope(name + "_loss"):
        loss_name = name if name else 'jrc_loss'
        
        if not only_listwise:
            logits = _prob2logits(probs)
            labels = tf.cast(labels, tf.int32)
            ce_loss = tf.compat.v1.losses.sparse_softmax_cross_entropy(labels, logits, weights=sample_weights, reduction=tf.compat.v1.losses.Reduction.NONE)
            ce_loss = tf.expand_dims(ce_loss, axis=1)
        else:
            logits = tf.concat([tf.zeros_like(probs) + 1e-6, _prob2logits(probs) + 1e-6], axis=1)
            ce_loss = tf.multiply(labels, -tf.math.log(probs + 1e-8)) + tf.multiply(tf.subtract(1.0, labels), -tf.math.log(tf.subtract(1.0, probs) + 1e-8))
        print(f'[{loss_name}] logits = {logits}, ce_loss = {ce_loss}, labels = {labels}')
        ## labels = tf.expand_dims(labels, 1)  # [B, 1]
        labels = tf.concat([1 - labels, labels], axis=1)  # [B, 2]

        batch_size = tf.shape(logits)[0]

        # Mask: shape [B, B], mask[i,j]=1 indicates the i-th sample
        # and j-th sample are in the same context
        mask = tf.equal(
            tf.expand_dims(session_ids, 1), tf.expand_dims(session_ids, 0))
        mask = tf.to_float(mask)

        # Tile logits and label: [B, 2]->[B, B, 2]
        logits = tf.tile(tf.expand_dims(logits, 1), [1, batch_size, 1])
        y = tf.tile(tf.expand_dims(labels, 1), [1, batch_size, 1])

        # Set logits that are not in the same context to -inf
        mask3d = tf.expand_dims(mask, 2)
        y = tf.to_float(y) * mask3d
        logits = logits + (1 - mask3d) * -1e9
        y_neg, y_pos = y[:, :, 0], y[:, :, 1]
        l_neg, l_pos = logits[:, :, 0], logits[:, :, 1]

        if tf.is_numeric_tensor(sample_weights):
            print('[%s] use sample weight' % loss_name)
            weights = tf.expand_dims(tf.cast(sample_weights, tf.float32), 0)
            pairwise_weights = tf.tile(weights, tf.stack([batch_size, 1]))
            y_pos *= pairwise_weights
            y_neg *= pairwise_weights
        else:
            assert sample_weights == 1.0, 'invalid sample_weight %d' % sample_weights

        # Compute list-wise generative loss -log p(x|y, z)
        if same_label_loss:
            print(f'[{loss_name}] enable same_label_loss')
            loss_pos = -tf.reduce_sum(y_pos * tf.nn.log_softmax(l_pos, axis=0), axis=0)
            loss_neg = -tf.reduce_sum(y_neg * tf.nn.log_softmax(l_neg, axis=0), axis=0)
            if not only_listwise:
                ## ge_loss = tf.reduce_mean((loss_pos + loss_neg) / tf.reduce_sum(mask, axis=0))
                ge_loss = (loss_pos + loss_neg) / tf.reduce_sum(mask, axis=0)
                # ge_loss = (loss_pos + loss_neg) * tf.reduce_sum(mask, axis=0)
            else:
                ## ge_loss = tf.reduce_mean(loss_pos / tf.reduce_sum(mask, axis=0))
                ge_loss = loss_pos / tf.reduce_sum(mask, axis=0)
                # ge_loss = loss_pos
        else:
            print('[%s] disable same_label_loss' % loss_name)
            diag = tf.one_hot(tf.range(batch_size), batch_size)
            l_pos = l_pos + (1 - diag) * y_pos * -1e9
            l_neg = l_neg + (1 - diag) * y_neg * -1e9
            loss_pos = -tf.linalg.diag_part(y_pos * tf.nn.log_softmax(l_pos, axis=0))
            loss_neg = -tf.linalg.diag_part(y_neg * tf.nn.log_softmax(l_neg, axis=0))
            if not only_listwise:
                # ge_loss = tf.reduce_mean(loss_pos + loss_neg)
                ge_loss = loss_pos + loss_neg
            else:
                # ge_loss = tf.reduce_mean(loss_pos)
                ge_loss = loss_pos

        ge_loss = tf.expand_dims(ge_loss, axis=1)
        print(f"[ge_loss] ge_loss:{ge_loss}, ce_loss: {ce_loss}")

        # The final JRC model
        # if loss_weight_strategy == 'fixed':
        #     loss = alpha * ce_loss + (1 - alpha) * ge_loss
        return ce_loss, ge_loss


def rank_loss(labels, preds=None, logits=None, session_ids=None):
    if preds is not None:
        logits = _prob2logits(preds)
    eps = 1e-10
    logits = tf.reshape(logits, shape=[-1, 1])  ## [B, 1] 
    labels = tf.reshape(labels, shape=[-1, 1])  ## [B, 1]   
    pairwise_logits = logits - tf.transpose(logits)  ## [B, B]
    pairwise_labels = labels - tf.transpose(labels)  ## [B, B]
    
    pairwise_mask = tf.greater(pairwise_labels, eps) ## [B, B]	    
    if session_ids is not None:
        print('[rank_loss] use session ids')
        session_ids = tf.reshape(session_ids, (-1,))
        group_equal = tf.equal(tf.expand_dims(session_ids, -1), tf.expand_dims(session_ids, 0))
        pairwise_mask = tf.logical_and(pairwise_mask, group_equal)
    pairwise_logits = tf.boolean_mask(pairwise_logits, pairwise_mask)  

    psudu_pairwise_labels = tf.ones_like(pairwise_logits)   
    rank_loss = tf.nn.sigmoid_cross_entropy_with_logits(
    			    labels=psudu_pairwise_labels,
    			    logits=pairwise_logits)
    sum_loss = tf.reduce_sum(rank_loss)
    return tf.where(tf.is_nan(sum_loss), tf.zeros_like(sum_loss), sum_loss) 


def listwise_loss(labels, preds=None, logits=None, session_ids=None):
    """
    logits_in:[B, 1]
    labels_in:[B, 1]
    masks: [B, B]
    """
    _EPS = 1e-10
    assert session_ids is not None, "[!] session_ids is None"
    if preds is not None:
        logits = _prob2logits(preds)
    listwise_loss_w = 1.0
    print("listwise_loss_w:", listwise_loss_w)
    session_ids = tf.reshape(session_ids, [-1, 1])
    masks = tf.equal(session_ids, tf.transpose(session_ids))
    logits_bb = tf.subtract(tf.expand_dims(logits, 1), tf.zeros_like(tf.expand_dims(logits, 0)))
    logits_bb = tf.squeeze(logits_bb, [2])
    logit_final = tf.where(masks, logits_bb, tf.log(_EPS) * tf.ones_like(logits_bb))    
    labels_bb = tf.subtract(tf.expand_dims(labels, 1), tf.zeros_like(tf.expand_dims(labels, 0)))
    labels_bb = tf.squeeze(labels_bb, [2])
    labels_final = tf.where(masks, labels_bb, tf.zeros_like(labels_bb))  ## [B, B]  
    label_sum = tf.reduce_sum(labels_final, axis=0, keep_dims=True) ## [B, 1]
    nonzero_mask = tf.greater(tf.reshape(label_sum, [-1]), 0.0)    ## [B]
    padded_labels = tf.where(nonzero_mask, labels_final, _EPS * tf.ones_like(labels_final)) * tf.cast(masks, dtype=tf.float32)  ## [B, B]   
    padded_label_sum = tf.reduce_sum(padded_labels, axis=0, keep_dims=True)
    normalized_labels = padded_labels / padded_label_sum    
    exps = tf.exp(listwise_loss_w * logit_final) * tf.cast(masks, dtype=tf.float32)
    softmax = tf.divide(exps, tf.reduce_sum(exps, axis=0))  
    losses = - tf.reduce_sum(normalized_labels *tf.log(softmax + _EPS) * tf.cast(masks, dtype=tf.float32), axis=0)  
    per_row_weights = tf.reduce_sum(tf.cast(masks, dtype=tf.float32), axis=1)
    list_cnt = tf.reduce_sum(1.0 / per_row_weights) 
    listwise_sum_loss = tf.reduce_sum(losses / per_row_weights)
    listwise_avg_loss = listwise_sum_loss / list_cnt    
    ## return list_cnt, listwise_sum_loss, listwise_avg_loss
    return listwise_sum_loss


def cross_entropy_loss(label, pred=None, logit=None, name=None):
    score_name = f"cross_entropy_loss" if name is None else  f"cross_entropy_loss_{name}"
    with tf.variable_scope(score_name):
        if logit is not None:
            return tf.nn.sigmoid_cross_entropy_with_logits(labels=label, logits=logit)
        return tf.multiply(label, -tf.log(pred + 1e-8)) + tf.multiply(tf.subtract(1.0, label), -tf.log(tf.subtract(1.0, pred) + 1e-8))


def multi_loss_func(losses, loss_weights, target_names, extra_params):
    final_loss = None
    for loss, loss_weight, target_name in list(zip(losses, loss_weights, target_names)):
        ## loss_weight = tf.where(loss_weight > 0.5, tf.ones_like(loss_weight), tf.zeros_like(loss_weight))
        print(loss_weight, target_name)
        loss = tf.multiply(loss, -loss_weight, name=target_name + "_loss")
        loss = tf.reduce_sum(loss, name=target_name + "_batchloss")
        if final_loss is not None:
            final_loss = loss + final_loss
        else:
            final_loss = loss
    return final_loss