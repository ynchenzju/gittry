#!/usr/bin/env python
# -*- coding: utf-8 -*-
import tensorflow as tf
import ego
import yaml
import numpy as np
import random
import json


_local_param_initializer = tf.truncated_normal_initializer(stddev=0.001, dtype=tf.float32)


def get_shape(inputs):
    dynamic_shape = tf.shape(inputs)
    static_shape = inputs.get_shape().as_list()
    shape = []
    for i, dim in enumerate(static_shape):
        shape.append(dim if dim is not None else dynamic_shape[i])
    return shape


## https://github.com/reczoo/FuxiCTR/blob/main/model_zoo/multitask/PLE/src/PLE.py
def cgc_layer(inputs, 
                num_shared_experts, 
                num_specific_experts, 
                num_tasks, 
                target_names,
                expert_hidden_units, 
                gate_hidden_units, 
                hidden_activations,
                gate_hidden_activations, 
                gate_output_activations,
                # net_dropout, 
                use_norm, 
                require_gate, 
                final_flag):
    """
    x: list, len(x)==num_tasks+1 if flag_flag == False else num_tasks
    """
    x = inputs
    param_initializer = tf.initializers.glorot_normal()
    bias_initializer = tf.zeros_initializer()
    specific_expert_outputs = [] 
    shared_expert_outputs = []
    # specific experts
    for i in range(num_tasks):
        target_n = target_names[i]
        task_expert_outputs = []
        with tf.variable_scope(f"specific_{target_n}"):
            for j in range(num_specific_experts):
                _out = ego.DenseTower(
                            name=f"specific_{target_n}_{i}_{j}",
                            output_dims=expert_hidden_units,
                            kernel_initializers=[param_initializer] * len(expert_hidden_units),
                            bias_initializers=[bias_initializer] * len(expert_hidden_units),
                            activations=[hidden_activations for _ in range(len(expert_hidden_units))],
                            norms=[use_norm for _ in range(len(expert_hidden_units))],
                            use_bias=True,
                        )(x[i])
                task_expert_outputs.append(_out)
                # task_expert_outputs.append(self.specific_experts[i][j](x[i]))
            specific_expert_outputs.append(task_expert_outputs)
    # shared experts 
    with tf.variable_scope(f"shared"):
        for i in range(num_shared_experts):
            _out = ego.DenseTower(
                name=f"shared_expert_{i}",
                output_dims=expert_hidden_units,
                kernel_initializers=[param_initializer] * len(expert_hidden_units),
                bias_initializers=[bias_initializer] * len(expert_hidden_units),
                activations=[hidden_activations for _ in range(len(expert_hidden_units))],
                norms=[use_norm for _ in range(len(expert_hidden_units))],
                use_bias=True,
            )(x[-1])
            shared_expert_outputs.append(_out)
        # shared_expert_outputs.append(self.shared_experts[i](x[-1]))
    # gate 
    cgc_outputs = [] 
    gates = [] 
    for i in range(num_tasks if final_flag else num_tasks + 1):
        target_n = target_names[i] if i < num_tasks else "total"
        with tf.variable_scope(f"gate_{target_n}"):
            gate_hidden_sz = len(gate_hidden_units) + 1
            gate_output_dim = len(specific_expert_outputs[i] + shared_expert_outputs if i < num_tasks else shared_expert_outputs)
            print(i, target_n, gate_hidden_sz, gate_output_dim)
            if i < num_tasks:
                # for specific experts
                # gate_input: (?, num_specific_experts+num_shared_experts, dim)
                gate_input = tf.stack(shared_expert_outputs + specific_expert_outputs[i], axis=1)
                # gate = gate_activation(gate[i](x[i])) # (?, num_specific_experts+num_shared_experts)
            else:
                # for shared experts 
                gate_input = tf.stack(shared_expert_outputs, axis=1) # (?, num_shared_experts, dim)
                # gate = gate_activation(gate[i](x[-1])) # (?, num_shared_experts)
            gate = ego.DenseTower(
                name=f"gate_{target_n}",
                output_dims=gate_hidden_units + [gate_output_dim],
                kernel_initializers=[param_initializer] * gate_hidden_sz,
                bias_initializers=[bias_initializer] * gate_hidden_sz,
                activations=[gate_hidden_activations for _ in range(gate_hidden_sz - 1)] + [gate_output_activations],
                norms=[use_norm for _ in range(gate_hidden_sz)],
                use_bias=True,
            )(x[i])

            # gates.append((f"{target_n}", tf.reduce_mean(gate, axis=0)))
            gates.append((f"{target_n}", gate))
            cgc_output = tf.reduce_sum(tf.expand_dims(gate, -1) * gate_input, axis=1) # (?, dim)
            cgc_outputs.append(cgc_output)
    if require_gate:
        return cgc_outputs, gates 
    else: 
        return cgc_outputs


def ple_layer(inputs, 
              inputs_list,
              num_level, 
              num_shared_experts, 
              num_specific_experts, 
              num_tasks, 
              target_names,
              expert_hidden_units,
              gate_hidden_units,
              hidden_activations,
              gate_hidden_activations,
              gate_output_activations,
              use_norm):
    ple_gates = []
    if inputs_list is None:
        cgc_outputs = [inputs for _ in range(num_tasks + 1)] 
    else:
        cgc_inputs = inputs_list 
        assert len(cgc_inputs) == num_tasks + 1
    for i in range(num_level):
        final_flag = True if i == num_level - 1 else False
        cgc_outputs, cgc_gates = cgc_layer(inputs=cgc_inputs, 
                                        num_shared_experts=num_shared_experts, 
                                        num_specific_experts=num_specific_experts, num_tasks=num_tasks, target_names=target_names, 
                                        expert_hidden_units=expert_hidden_units, gate_hidden_units=gate_hidden_units, 
                                        hidden_activations=hidden_activations, gate_hidden_activations=gate_hidden_activations, gate_output_activations=gate_output_activations,
                                        use_norm=use_norm, require_gate=True, final_flag=final_flag)
        cgc_inputs = cgc_outputs
        ple_gates.append(cgc_gates)
    
    return cgc_outputs, ple_gates


def _get_fields(field_num, gate_output_dim, field_dims):
    if field_dims is None:
        field_dim = gate_output_dim // field_num
        assert field_dim * field_num == field_dim, f"field_dim={field_dim},field_num={field_num},gate_output_dim={gate_output_dim}"
        field_dims = [field_dim for _ in range(field_num)]
        print(f"[auto cumpute] gate_output_dim = {gate_output_dim}, field_num={field_num}, field_dims = {field_dims}")
    elif isinstance(field_dims, (int, float)):
        field_dims = [field_dim for _ in range(int(field_num))]
        print(f"[use same dim for each field ] gate_output_dim = {gate_output_dim}, field_num={field_num}, field_dims = {field_dims}")
    elif isinstance(field_dims, (list, tuple)):
        assert sum(field_dims) == gate_output_dim
        print(f"[use udf dim for each field ] gate_output_dim = {gate_output_dim}, field_num={field_num}, field_dims = {field_dims}")
    else:
        raise ValueError(f"invalid pooling method {field_dims}")
    return field_dims


def gatenet_layer_bitwise(inputs, 
                gate_inputs,
                gate_hidden_units, 
                gate_hidden_activations, 
                use_norm,
                require_gate,
                norm_type="ego",
                name="",
                ):
    
    if gate_inputs is None:
        x = inputs
    else:
        x = gate_inputs

    with tf.variable_scope(f"{name}_bitwise_layer"):
        print(f"bitwise {x}")
        gate_output_dim = int(get_shape(inputs)[-1])
        print(f"gate_output_dim = {gate_output_dim}")
        gate_hidden_sz = len(gate_hidden_units) + 1
        param_initializer = tf.initializers.glorot_normal()
        bias_initializer = tf.zeros_initializer()
        with tf.variable_scope(f"{name}_bitwise_layer"):
            if use_norm and norm_type == "ego":
                gates = ego.DenseTower(
                    name=f"{name}_bitwise_mlp",
                    output_dims=gate_hidden_units + [gate_output_dim],
                    kernel_initializers=[param_initializer] * gate_hidden_sz,
                    bias_initializers=[bias_initializer] * gate_hidden_sz,
                    activations=[gate_hidden_activations for _ in range(gate_hidden_sz - 1)] + [tf.nn.sigmoid],
                    norms=[use_norm for _ in range(gate_hidden_sz)],
                    use_bias=True,
                )(x)
            else:
                gates = ego.DenseTower(
                    name=f"{name}_bitwise_mlp",
                    output_dims=gate_hidden_units + [gate_output_dim],
                    kernel_initializers=[param_initializer] * gate_hidden_sz,
                    bias_initializers=[bias_initializer] * gate_hidden_sz,
                    activations=[gate_hidden_activations for _ in range(gate_hidden_sz - 1)] + [tf.nn.sigmoid],
                    norms=[use_norm for _ in range(gate_hidden_sz)],
                    use_bias=True,
                )(x)

            outputs = tf.multiply(gates*2, inputs, name=f"{name}_gate_multiply")
            if require_gate:
                return outputs, gates 
            else: 
                return outputs


def gatenet_layer_fieldwise(inputs, 
                gate_inputs,
                gate_hidden_units, 
                gate_hidden_activations, 
                use_norm,
                require_gate,
                norm_type="ego",
                field_names=None,
                field_num=-1,
                field_dims=None,
                tile_replace_repeat=False,
                name="",
                ):
    """
    field_dims: each field dimension 
    """

    assert field_names is None or field_num > 0
    assert len(field_names) == field_num
    if gate_inputs is None:
        x = inputs
    else:
        x = gate_inputs
    del gate_inputs

    with tf.variable_scope(f"{name}_fieldwise_layer"):
        print(f"fieldwise {x}")
        gate_input_dim = int(get_shape(x)[-1])
        print(f"gate_input_dim = {gate_input_dim}")
        field_dims = _get_fields(field_num, gate_input_dim, field_dims)
        assert len(field_dims) == len(field_names)
        gate_output_dim = field_num

        gate_hidden_sz = len(gate_hidden_units) + 1
        param_initializer = tf.initializers.glorot_normal()
        bias_initializer = tf.zeros_initializer()
        with tf.variable_scope(f"{name}_fieldwise_layer"):
            if use_norm and norm_type == "ego":
                gates = ego.DenseTower(
                    name=f"{name}_fieldwise_mlp",
                    output_dims=gate_hidden_units + [gate_output_dim],
                    kernel_initializers=[param_initializer] * gate_hidden_sz,
                    bias_initializers=[bias_initializer] * gate_hidden_sz,
                    activations=[gate_hidden_activations for _ in range(gate_hidden_sz - 1)] + [tf.nn.sigmoid],
                    norms=[use_norm for _ in range(gate_hidden_sz)],
                    use_bias=True,
                )(x)
            else:
                gates = ego.DenseTower(
                    name=f"{name}_fieldwise_mlp",
                    output_dims=gate_hidden_units + [gate_output_dim],
                    kernel_initializers=[param_initializer] * gate_hidden_sz,
                    bias_initializers=[bias_initializer] * gate_hidden_sz,
                    activations=[gate_hidden_activations for _ in range(gate_hidden_sz - 1)] + [tf.nn.sigmoid],
                    norms=[use_norm for _ in range(gate_hidden_sz)],
                    use_bias=True,
                )(x)
            assert gate_input_dim == sum(field_dims)
            print(f"[gatenet_layer_fieldwise {name}]", gates)
            print(f"[gatenet_layer_fieldwise {name}]", field_dims)

            if tile_replace_repeat:
                print(f"[gatenet_layer_fieldwise {name} tile_replace_repeat]", tile_replace_repeat)
                expanded = [] # 初始化一个空列表用于存储结果
                # 逐列重复
                for i in range(gate_output_dim):
                    value = gates[:, i:i+1]  # 保持二维形状
                    repeated_values = tf.tile(value, [1, field_dims[i]], name=f"{name}_{field_names[i]}_tile") # 使用 tf.tile 创建重复的元素
                    expanded.append(repeated_values)
                expands_gates = tf.concat(expanded, axis=1, name=f"{name}_gate_expands_concat")# 合并结果
            else:
                expands_gates = tf.repeat(gates, repeats=field_dims, axis=1, name=f"{name}_gate_expands")
            print(f"[gatenet_layer_fieldwise {name}]", expands_gates)
            # expands_gates = tf.reshape(expands_gates, (-1, gate_input_dim), name=f"{name}_reshape")
            outputs = tf.multiply(expands_gates*2, inputs, name=f"{name}_gate_multiply")
            if require_gate:
                return outputs, gates
            else: 
                return outputs