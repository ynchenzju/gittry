#!/usr/bin/env python
# -*- coding: utf-8 -*-

import tensorflow as tf
import ego
import yaml
import numpy as np
import random
import json

from tensorflow.python.debug.cli.base_ui import BaseUI

__tf_version = tf.__version__
if __tf_version >= '2.0':
    tf2 = tf
    tf = tf.compat.v1


local_param_initializer = tf.truncated_normal_initializer(stddev=0.001, dtype=tf.float32)


def get_shape(inputs):
    dynamic_shape = tf.shape(inputs)
    static_shape = inputs.get_shape().as_list()
    shape = []
    for i, dim in enumerate(static_shape):
        shape.append(dim if dim is not None else dynamic_shape[i])
    return shape

@tf.custom_gradient
def ignore_grad(x):
    def grad(upstream):
        return upstream * 0.0

    return x, grad

def get_ego_layer(layername, dim):
    return ego.DenseTower(
        name=layername,
        output_dims=[dim],
        kernel_initializers=[local_param_initializer] * 1,
        bias_initializers=[local_param_initializer] * 1,
        activations=[None],
        norms=[False],
        use_bias=True,
    )


def positional_encoding(max_position, d_model):
    position = np.arange(max_position)[:, np.newaxis]
    div_term = np.exp(np.arange(0, d_model, 2) * -(np.log(10000.0) / d_model))

    sin_encoding = np.sin(position * div_term)
    cos_encoding = np.cos(position * div_term)

    pos_encoding = np.zeros((max_position, d_model))
    pos_encoding[:, 0::2] = sin_encoding
    pos_encoding[:, 1::2] = cos_encoding

    return tf.cast(pos_encoding, dtype=tf.float32)


def scaled_dot_product_attention(q, k, v, mask, causality, ns_len):
    # (B, num_heads, q_seq, k_seq)
    matmul_qk = tf.matmul(q, k, transpose_b=True)
    dk = tf.shape(k)[-1]
    scaled_attention_logits = matmul_qk / tf.math.sqrt(tf.cast(dk, tf.float32))
    if mask is not None:
        # (B, k_seq)
        paddings = 1.0 - mask
        scaled_attention_logits += (paddings[:, tf.newaxis, tf.newaxis, :] * -1e4)
    if causality:
        id_matrix = tf.ones_like(scaled_attention_logits[0, 0, :, :])
        lower_tril = tf.linalg.LinearOperatorLowerTriangular(id_matrix).to_dense()
        L = tf.shape(lower_tril)[0]
        diag = tf.concat([
            tf.zeros([ns_len], dtype=lower_tril.dtype),          # first ns_len → 0
            tf.zeros([L - ns_len], dtype=lower_tril.dtype)      # rest → 0
        ], axis=0)
        mask = tf.linalg.set_diag(lower_tril, diag)
        scaled_attention_logits += (mask[tf.newaxis, tf.newaxis, ...] * -1e4)
        
    attention_weights = tf.nn.softmax(scaled_attention_logits, axis=-1)
    # (B, num_heads, q_seq, k_seq) (B, num_heads, k_seq, dim)
    output = tf.matmul(attention_weights, v) # (B, num_heads, q_seq, dim)
    return output, attention_weights


class RotaryPositionEmbedding(tf.keras.layers.Layer):
    def __init__(self, dim=64, max_seq_len=50, theta=10000.0, **kwargs):
        super().__init__(**kwargs)
        if dim % 2 != 0:
            raise ValueError(f"RoPE要求dim为偶数，但收到dim={dim}")
        self.dim = dim
        self.max_seq_len = max_seq_len
        self.theta = float(theta)

    def build(self, input_shape):
        half_dim = self.dim // 2

        indices = tf.range(0, half_dim, dtype=tf.float32)
        inv_freq = 1.0 / (self.theta ** (2.0 * indices / self.dim))

        positions = tf.range(self.max_seq_len, dtype=tf.float32)

        # equal to tf.matmul(positions[:, tf.newaxis], theta_i[:, tf.newaxis], transpose_b=True)
        angles = tf.einsum('i,j->ij', positions, inv_freq)

        # (max_seq_len, dim / 2)
        self.cos_cached = tf.constant(tf.cos(angles))
        self.sin_cached = tf.constant(tf.sin(angles))
        super().build(input_shape)

    def call(self, x):

        # x shape: [B, H, T, D]
        x_even = x[..., ::2]
        x_odd = x[..., 1::2]

        cos = self.cos_cached[tf.newaxis, tf.newaxis, :, :]
        sin = self.sin_cached[tf.newaxis, tf.newaxis, :, :]

        x_rotated_even = x_even * cos - x_odd * sin
        x_rotated_odd = x_even * sin + x_odd * cos
        # [B, H, T, D/2, 2]
        x_rotated = tf.stack([x_rotated_even, x_rotated_odd], axis=-1)
        x_rotated = tf.reshape(x_rotated, tf.concat([tf.shape(x)[:-1], [self.dim]], axis=0))
        return x_rotated


class LLaMARoPE(tf.keras.layers.Layer):
    def __init__(self, dim=64, max_seq_len=50, base=10000, scaling_factor=1.0, **kwargs):
        super().__init__(**kwargs)
        if dim % 2 != 0:
            raise ValueError("dim must be even")
        self.dim = dim
        self.max_position_embeddings = max_seq_len
        self.base = base
        self.scaling_factor = scaling_factor

    def build(self, input_shape):
        half_dim = self.dim // 2
        # 预计算 inv_freq
        inv_freq = 1.0 / (self.base ** (tf.range(0, self.dim, 2, dtype=tf.float32) / self.dim))
        t = tf.range(self.max_position_embeddings, dtype=tf.float32) / self.scaling_factor
        # [max_seq_len, half_dim]
        freqs = tf.einsum('i,j->ij', t, inv_freq)
        emb = tf.concat([freqs, freqs], axis=-1)       # [max_seq_len, dim]
        # 预计算 cos/sin 缓存
        self.cos_cached = tf.cos(emb)
        self.sin_cached = tf.sin(emb)
        super().build(input_shape)

    def call(self, x):
        """
        x: [batch, num_heads, seq_len, head_size] or [batch, seq_len, dim]
        """
        x1 = x[..., : self.dim // 2]
        x2 = x[..., self.dim // 2:]
        x_rotated = tf.concat([-x2, x1], axis=-1)
        cos = self.cos_cached[tf.newaxis, tf.newaxis, :, :]
        sin = self.sin_cached[tf.newaxis, tf.newaxis, :, :]
        return x * cos + x_rotated * sin


class RMSNorm(tf.keras.layers.Layer):
    def __init__(self, epsilon=1e-6, **kwargs):
        super(RMSNorm, self).__init__(**kwargs)
        self.epsilon = epsilon

    def build(self, input_shape):
        dim = input_shape[-1]
        self.gamma = self.add_weight(
            name='RMSNorm_gamma',
            shape=(dim,),
            initializer=tf.ones_initializer(),
            trainable=ego.is_training_mode()
        )
        super().build(input_shape)

    def call(self, x):
        rms = tf.sqrt(tf.reduce_mean(tf.square(x), axis=-1, keepdims=True) + self.epsilon)
        return self.gamma * (x / rms)


class SwiGLU(tf.keras.layers.Layer):
    """
    SwiGLU gating:
    """
    def __init__(self, hidden_dim, layer_idx, **kwargs):
        super().__init__(**kwargs)
        self.w = get_ego_layer("SwiGLU_" + str(layer_idx), hidden_dim * 2)

    def call(self, x):
        x = self.w(x)
        out, gate = tf.split(x, num_or_size_splits=2, axis=-1)
        return out * tf.nn.relu(gate) # silu


class MultiHeadAttention(tf.keras.layers.Layer):
    def __init__(self, d_model, num_heads, ns_length, layer_idx, maximum_position_encoding):
        super(MultiHeadAttention, self).__init__()
        self.num_heads = num_heads
        self.d_model = d_model
        self.ns_length = ns_length
        self.depth = d_model // self.num_heads
        self.wq_s = get_ego_layer("Q_S" + str(layer_idx), d_model)
        self.wk_s = get_ego_layer("K_S" + str(layer_idx), d_model)
        self.wv_s = get_ego_layer("V_S" + str(layer_idx), d_model)

        self.kernel_initializer = tf.keras.initializers.get("glorot_uniform")
        self.kernel_regularizer = tf.keras.regularizers.get(None)
        self.kernel_constraint = tf.keras.constraints.get(None)
        self.q_ns_kernel = self.add_weight(
            name="query_kernel",
            shape=[self.ns_length, self.d_model, self.d_model],
            initializer=self.kernel_initializer,
            regularizer=self.kernel_regularizer,
            constraint=self.kernel_constraint,
        )
        self.k_ns_kernel = self.add_weight(
            name="key_kernel",
            shape=[self.ns_length, self.d_model, self.d_model],
            initializer=self.kernel_initializer,
            regularizer=self.kernel_regularizer,
            constraint=self.kernel_constraint,
        )
        self.v_ns_kernel = self.add_weight(
            name="value_kernel",
            shape=[self.ns_length, self.d_model, self.d_model],
            initializer=self.kernel_initializer,
            regularizer=self.kernel_regularizer,
            constraint=self.kernel_constraint,
        )

        self.wq_ns = get_ego_layer("Q_NS" + str(layer_idx), d_model)
        self.wk_ns = get_ego_layer("K_NS" + str(layer_idx), d_model)
        self.wv_ns = get_ego_layer("V_NS" + str(layer_idx), d_model)

        self.dense = get_ego_layer("O" + str(layer_idx), d_model)
        #self.rope = LLaMARoPE(dim=self.depth, max_seq_len=maximum_position_encoding)

    def split_heads(self, x, batch_size):
        x = tf.reshape(x, (batch_size, -1, self.num_heads, self.depth))
        return tf.transpose(x, perm=[0, 2, 1, 3])

    def call(self, v_s, k_s, q_s, v_ns, k_ns, q_ns, cache, training, mask, causality):
        batch_size = get_shape(v_s)[0]
        s_len, ns_len = get_shape(v_s)[1], get_shape(v_ns)[1]

        q_ns = tf.einsum('bij,ijk->bik', q_ns, self.q_ns_kernel)
        k_ns = tf.einsum('bij,ijk->bik', k_ns, self.k_ns_kernel)
        v_ns = tf.einsum('bij,ijk->bik', v_ns, self.v_ns_kernel)

        q_s = self.wq_s(q_s)
        k_s = self.wk_s(k_s)
        v_s = self.wv_s(v_s)
        # [B, L, D] -> [B, num, -1, D//num]
        q = tf.concat([self.split_heads(q_ns, batch_size), self.split_heads(q_s, batch_size)], axis=2)
        k = tf.concat([self.split_heads(k_ns, batch_size), self.split_heads(k_s, batch_size)], axis=2)
        v = self.split_heads(tf.concat([v_ns, v_s], axis=1), batch_size)

        attention_output, _ = scaled_dot_product_attention(q, k, v, mask, causality, ns_len)
        scaled_attention = tf.transpose(attention_output, perm=[0, 2, 1, 3])
        concat_attention = tf.reshape(scaled_attention, (batch_size, -1, self.d_model))
        output = self.dense(concat_attention)
        # else:
        #     mask_s, mask_ns = tf.split(mask, split_pos, -1)
        #     if cache is None:
        #         q_s = self.rope(self.wq_s(q_s))
        #         k_s = self.rope(self.wk_s(k_s))
        #         v_s = self.wv_s(v_s)
        #         q_s = self.split_heads(q_s, batch_size)
        #         k_s = self.split_heads(k_s, batch_size)
        #         v_s = self.split_heads(v_s, batch_size)
        #         attention_output_s, _ = scaled_dot_product_attention(q_s, k_s, v_s, mask, causality)
        #         scaled_attention_s = tf.transpose(attention_output_s, perm=[0, 2, 1, 3])
        #         concat_attention_s = tf.reshape(scaled_attention_s, (batch_size, -1, self.d_model))
        #         output_s = self.dense(concat_attention_s)
        #         cache = (output_s, k_s, v_s)
        #     q_ns = self.split_heads(q_ns, batch_size)
        #     k = self.split_heads(tf.concat([cache[1], k_ns], axis=1), batch_size)
        #     v = self.split_heads(tf.concat([cache[2], v_ns], axis=1), batch_size)
        #     attention_output_ns, _ = scaled_dot_product_attention(q_ns, k, v, mask_ns, causality) # (B, num_heads, q_seq, dim)
        #     scaled_attention_ns = tf.transpose(attention_output_ns, perm=[0, 2, 1, 3]) # (B, q_seq, num_heads, dim)
        #     concat_attention_ns = tf.reshape(scaled_attention_ns, (batch_size, -1, self.d_model))
        #     output_ns = self.dense(concat_attention_ns)
        #     output = tf.concat([cache[0], output_ns], axis=1)
        return tf.split(output, [ns_len, s_len], 1)

class EncoderLayer(tf.keras.layers.Layer):
    def __init__(self, d_model, num_heads, ns_length, layer_idx, maximum_position_encoding, rate=0.1):
        super(EncoderLayer, self).__init__()
        self.d_model = d_model
        self.mha = MultiHeadAttention(d_model, num_heads, ns_length, layer_idx, maximum_position_encoding)
        self.swi_glu = SwiGLU(hidden_dim=d_model, layer_idx = layer_idx)
        self.ns_length = ns_length

        self.out_proj = ego.DenseTower(
            name="out_proj" + str(layer_idx),
            output_dims=[d_model],
            kernel_initializers=[local_param_initializer],
            bias_initializers=[local_param_initializer],
            activations=[None],
            norms=[False],
            use_bias=True
        )

        self.layernorm1 = RMSNorm()
        self.layernorm2 = RMSNorm()
        self.layernorm3 = RMSNorm()
        self.layernorm4 = RMSNorm()

        self.kernel_initializer = tf.keras.initializers.get("glorot_uniform")
        self.kernel_regularizer = tf.keras.regularizers.get(None)
        self.kernel_constraint = tf.keras.constraints.get(None)

        self.dropout1 = tf.keras.layers.Dropout(rate)
        self.dropout2 = tf.keras.layers.Dropout(rate)
        self.dropout3 = tf.keras.layers.Dropout(rate)
        self.dropout4 = tf.keras.layers.Dropout(rate)

        self.ns_kernel = self.add_weight(
            name="ffn_kernel",
            shape=[self.ns_length, self.d_model, self.d_model],
            initializer=self.kernel_initializer,
            regularizer=self.kernel_regularizer,
            constraint=self.kernel_constraint,
        )

    def call(self, x_s, x_ns, cache, training, mask, causality):
        x_s = self.layernorm1(x_s)
        x_ns = self.layernorm2(x_ns)
        print('debug info | x_ns, x_s', x_ns.get_shape(), x_s.get_shape())
        ns_output, s_output = self.mha(x_s, x_s, x_s, x_ns, x_ns, x_ns, cache, training, mask, causality)
        print('debug info | ns_output, s_output', ns_output.get_shape(), s_output.get_shape())
        s_output = self.dropout1(s_output, training=training)
        ns_output = self.dropout2(ns_output, training=training)
        out_s = x_s + s_output
        out_ns = x_ns + ns_output

        out2_s = self.layernorm3(out_s)
        out2_ns = self.layernorm4(out_ns)
        ffn_output_s = self.out_proj(self.swi_glu(out2_s))
        ffn_output_ns = tf.einsum('bij,ijk->bik', self.swi_glu(out2_ns), self.ns_kernel)
        ffn_output_s = self.dropout3(ffn_output_s, training=training)
        ffn_output_ns = self.dropout4(ffn_output_ns, training=training)
        return out_s + ffn_output_s, out_ns + ffn_output_ns


class Transformer(tf.keras.layers.Layer):
    def __init__(self, num_layers, d_model, num_heads, ns_length, ns_dim, action_types, maximum_position_encoding = 50, rate=0.1):
        super(Transformer, self).__init__()
        self.ns_dim = ns_dim
        self.d_model = d_model
        self.num_layers = num_layers
        self.ns_length = ns_length
        self.action_types = action_types
        self.enc_layers = [EncoderLayer(d_model, num_heads, ns_length, layer_idx, maximum_position_encoding, rate) for layer_idx in range(num_layers)]
        self.proj_layer_s = []
        self.sep_embs = []
        self.position_emb_s = []
        for action in action_types:
            self.proj_layer_s.append(get_ego_layer("proj_layer_s_" + action, d_model))
            self.sep_embs.append(self.add_weight(name='sep_embs_' + action, shape=(1, d_model),
                                                 initializer=local_param_initializer, trainable=True))
            self.position_emb_s.append(self.add_weight(name='position_s_' + action, shape=(maximum_position_encoding, d_model),
                                                  initializer=local_param_initializer, trainable=True))
        self.kernel_initializer = tf.keras.initializers.get("glorot_uniform")
        self.kernel_regularizer = tf.keras.regularizers.get(None)
        self.kernel_constraint = tf.keras.constraints.get(None)
        self.position_emb_ns = self.add_weight(name='position_ns', shape=(ns_length, d_model),
                                               initializer=local_param_initializer, trainable=True)
        # [ns_l, dim, d_model]
        self.ns_kernel = self.add_weight(
            name="proj_kernel",
            shape=[self.ns_length, self.ns_dim, self.d_model],
            initializer=self.kernel_initializer,
            regularizer=self.kernel_regularizer,
            constraint=self.kernel_constraint,
        )


    # caches: [(attn, k, v), (attn, k, v) ...]
    # x_s: [order, atc, click]
    # x_ns: [B, seq_ns, d]
    # todo (x_s, x_ns, x_item) inputs = [a, b, c], various qkvs
    def call(self, inputs, training = True, causality = True):
        assert len(inputs) == len(self.action_types) + 1 + 2
        x_ns, caches, mask = inputs[-3], inputs[-2], inputs[-1]
        x_s = []
        B = tf.shape(x_ns)[0]
        for idx, action_seq in enumerate(self.action_types):
            x_s_ = tf.add(self.proj_layer_s[idx](inputs[idx]), tf.expand_dims(self.position_emb_s[idx], axis=0))
            x_s.extend([tf.broadcast_to(self.sep_embs[idx], [B, 1, self.d_model]), x_s_])
        x_s = tf.concat(x_s, axis=1)
        print('debug info | x_s', x_s.get_shape())
        x_ns = tf.add(tf.einsum('bij,ijk->bik', x_ns, self.ns_kernel), self.position_emb_ns)
        for i in range(self.num_layers):
            x_s, x_ns = self.enc_layers[i](x_s, x_ns, caches[i], training, mask, causality)

        return x_s, x_ns


