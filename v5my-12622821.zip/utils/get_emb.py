#!/usr/bin/env python
# -*- coding: utf-8 -*-
import tensorflow as tf
import ego
from utils.din import din_attention_cos


def get_user_embs(group_names, key="user", seq_keys=["ub_clk_seq", "ub_cart_seq", "ub_order_seq"], seq_agg="sum", op_name="get_user_embs"):
    assert key in group_names
    feats = [group_names[key]]
    for k in seq_keys:
        print(f"[{op_name}]", k)
        assert k in group_names
        feat, _ = group_names[k]
        if seq_agg == "sum":
            feat = tf.reduce_sum(feat, axis=1, name=f"{k}_sum_pool")
            print(f"[{op_name}]", k, feat)
        feats.append(feat)
    return tf.concat(feats, axis=-1, name=op_name + "_concat") 


def get_item_embs(group_names, keys=["item_features", "target_item_query"], op_name="get_item_embs", norm_keys=[]):
    feats = []
    for k in keys:
        assert k in group_names
        if k in norm_keys:
            feat = tf.nn.l2_normalize(group_names[k], axis=-1, name=f"{k}_l2_norm")
            print(f"[get_item_embs] `{k}` use l2_norm")
        else:
            feat = group_names[k]
        feats.append(feat)
    print(f"[get_item_embs] feats = {feats}")
    return tf.concat(feats, axis=-1, name=op_name + "_concat")


def get_item_query_embs(group_names, key="target_item_query", op_name="get_item_query_embs"):
    assert key in group_names
    return group_names[key]


def get_item_attention_embs(group_names, item_query_emb=None, seq_keys=["ub_clk_seq", "ub_cart_seq", "ub_order_seq"], tiers=20, use_sim=True, use_simtier=True, op_name="get_item_attention_embs"):
    feats = []
    att_weights = []
    for k in seq_keys:
        assert k in group_names
        keys, seq_len = group_names[k]
        print(f"[{op_name}]", keys, seq_len)
        feat, cos_sim, simtier_score = din_attention_cos(queries=item_query_emb, keys=keys, keys_length=seq_len, return_weight=True, use_simtier=True, simtier_number=tiers, use_agg=False, name=f"{k}_din_layer_cos")
        att_w = cos_sim
        print(f"[{op_name}]", feat, cos_sim, simtier_score, att_w)
        # feats.append(feat)
        if use_sim:
            feats.append(cos_sim)
        if use_simtier:
            feats.append(simtier_score)
        att_weights.append(att_w)
    
    return tf.concat(feats, axis=-1, name=op_name + "_concat"), att_weights


def get_item_long_seq_att_embs(group_names, item_query_emb=None, seq_keys=None, tiers=[], use_sim=True, use_simtier=True, op_name="get_item_long_seq_att_embs", shared_name_for_keys=None):
    """shared_name_for_keys: optional dict mapping seq_key -> shared scope name so those keys share the same KQV (e.g. din layer)."""
    shared_name_for_keys = shared_name_for_keys or {}
    print(f"[{op_name}] item_query_emb = {item_query_emb}, seq_keys = {seq_keys}, tiers = {tiers}, shared_name_for_keys = {shared_name_for_keys}")
    feats = []
    att_weights = []
    for k in seq_keys:
        assert k in group_names
        keys, seq_len = group_names[k]
        din_name = shared_name_for_keys.get(k, k)
        print(f"[{op_name}]", keys, seq_len, "din_name=", din_name)
        feat, cos_sim, simtier_score = din_attention_cos(queries=item_query_emb, keys=keys, keys_length=seq_len, return_weight=True, use_simtier=True, simtier_number=tiers, use_agg=False, name=f"{din_name}_din_layer_cos")
        att_w = cos_sim
        print(f"[{op_name}]", feat, cos_sim, simtier_score, att_w)
        # feats.append(feat)
        if use_sim:
            feats.append(cos_sim)
        if use_simtier:
            feats.append(simtier_score)
        att_weights.append(att_w)
    
    return tf.concat(feats, axis=-1, name=op_name + "_concat"), att_weights

# def get_item_attention_embs_mha(group_names, item_query_emb=None, seq_keys=["ub_clk_seq", "ub_cart_seq", "ub_order_seq"], op_name="get_item_attention_embs", max_seq_len=50):
#     feats = []
#     att_weights = []
#     for k in seq_keys:
#         assert k in group_names
#         keys, seq_len = group_names[k]
#         print(f"[{op_name}]", keys, seq_len)
#         with tf.variable_scope(f"{k}_{op_name}"):
#             mask = tf.sequence_mask(seq_len, max_seq_len, dtype=tf.float32)
#             query, inputs, mask = item_query_emb, keys, mask
#             expand_flag = len(query.shape) == 2

#             if expand_flag:
#                 print('expand query: ', query)
#                 query = tf.expand_dims(query, axis=1, name=f"{k}_expand")
#             feat = MultiHeadAttention(head_size=8, num_heads=4)([
#                 query, inputs
#             ], mask=mask, training=ego.is_training_mode())

#         print(f"[{op_name}]", feat)
#         if expand_flag:
#             feat = tf.squeeze(feat, axis=1, name=f"{k}_sq")
#         feats.append(feat)
    
#     return tf.concat(feats, axis=-1, name=op_name + "_concat")


def get_feature_from_index(inp, embed_layer=None, vocab_size=2049, embed_dim=32, name="get_embed_from_index", embed_name="embed_name", initializer=tf.initializers.glorot_normal()):
    with tf.variable_scope(f"{name}"):
        if embed_layer is None:
            print(f"[{name}##{embed_name}] initializer = {initializer}")
            embed_layer = tf.get_variable(name=f"{embed_name}", shape=(vocab_size, embed_dim), initializer=initializer)
        out = tf.nn.embedding_lookup(embed_layer, inp)
        return out, embed_layer


def get_feature_mlp(inp, mlp_layer=None, vocab_size=2049, embed_dim=32, name="get_feature_mlp", embed_name="embed_name"):
    with tf.variable_scope(f"{name}"):
        if mlp_layer is None:
            print(f"[{name}_{embed_name}] vocab_size = {vocab_size}, embed_dim = {embed_dim}")
            local_param_initializer = tf.truncated_normal_initializer(stddev=0.001, dtype=tf.float32)
            local_bias_initializer = tf.zeros_initializer()
            mlp_layer = ego.DenseTower(
                                    name=f'{name}_{embed_name}',
                                    output_dims=[vocab_size, embed_dim],
                                    kernel_initializers=[local_param_initializer] * 2,
                                    ## bias_initializers=[local_bias_initializer] * 2,
                                    activations=[None, None],
                                    norms=[True, False],
                                    use_bias=False
                                )
        out = mlp_layer(inp)
        return out, mlp_layer


def aggregator_function(seq_features, seq_len, reduce_type, use_mask, max_seq_len=50):
    """
    seq_features: (?, seq_len, dim). This is after padding
    seq_len: (?, 1)
    reduce_type: one of  (sum, max, min, mean)
    use_mask: False or True
    """
    if use_mask:
        # 创建 mask
        mask = tf.sequence_mask(tf.squeeze(seq_len, axis=-1), maxlen=max_seq_len)
        # 扩展 mask 的维度以匹配输入张量
        mask_expanded = tf.expand_dims(mask, -1)
        # 应用 mask
        masked_input = seq_features * tf.cast(mask_expanded, dtype=tf.float32)
    else:
        masked_input = seq_features

    if reduce_type == "sum":
        return tf.reduce_sum(masked_input, axis=1)
    elif reduce_type == "mean":
        return tf.reduce_mean(masked_input, axis=1)
    elif reduce_type == "max":
        return tf.reduce_max(masked_input, axis=1)
    elif reduce_type == "min":
        return tf.reduce_min(masked_input, axis=1)
    else:
        print(f"[aggregator_function] wrong {reduce_type}")
        raise RuntimeError