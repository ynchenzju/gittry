import tensorflow as tf
import ego
import tensorflow.python.keras.layers
from ego import DenseTower

def mask_block(
        name,
        emb_input,
        hidden_input,
        hidden_dim,
        output_dim,
        param_initializer,
        activation_fn=None,
        ratio=0.5,
        region='other'
):
    if hidden_input is None:
        hidden_input = emb_input  # B * ( Length * Field ) BN

    mask_gate = DenseTower(name='Mask_Net_Gate_Proj_{}_1_{}'.format(name, region),
                           output_dims=[int(hidden_dim*ratio), hidden_dim],
                           kernel_initializers=[param_initializer]*2,
                           bias_initializers=[param_initializer]*2,
                           activations=[activation_fn, None],
                           norms=[False, False])(hidden_input)
    v_masked = hidden_input * mask_gate

    v_masked_ = DenseTower(name='Mask_Net_gate_Proj_{}_2_{}'.format(name, region),
                           output_dims=[output_dim],
                           activations=[None],
                           norms=[False])(v_masked)

    return tf.nn.leaky_relu(tf.keras.layers.LayerNormalization(axis=1)(v_masked_))

