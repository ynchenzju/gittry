#!/usr/bin/env python
# -*- coding: utf-8 -*-
import ego
import numpy as np
import tensorflow as tf


def split_sparse(emb, adf_dim, lr_dim=1):
    if isinstance(emb, tuple):
        adf_data = emb[0][:, :, lr_dim:lr_dim + adf_dim]
        adf_data = tf.reduce_sum(adf_data, axis=1)
        lr_mf_data = (tf.concat([emb[0][:, :, :lr_dim], emb[0][:, :, lr_dim + adf_dim:]], -1), emb[1])
    else:
        adf_data = emb[:, lr_dim:lr_dim + adf_dim]
        lr_mf_data = tf.concat([emb[:, :lr_dim], emb[:, lr_dim + adf_dim:]], -1)
    return adf_data, lr_mf_data


def take_log_and_ratio(adf_data, ratios, smoothing_factor=1):
    # adf_data shape is batch x slot_num x adf_dim
    # assert adf_data.get_shape()[-1] == len(ratios)
    dim = adf_data.get_shape()[-1]
    slot_num = adf_data.get_shape()[-2]
    # [raw] + [numerators] + [denominators]
    expand_mtx = np.eye(dim, dim + 2 * len(ratios), dtype="float32")
    for i, pair in enumerate(ratios):
        expand_mtx[pair[0], dim + i] = 1
        expand_mtx[pair[1], dim + len(ratios) + i] = 1
    adf_data = tf.matmul(tf.reshape(adf_data, [-1, dim]), expand_mtx)
    adf_data = tf.log(adf_data + smoothing_factor)

    ratio_mtx = np.eye(dim + 2 * len(ratios), dim + len(ratios), dtype="float32")
    for i in range(len(ratios)):
        ratio_mtx[dim + len(ratios) + i, dim + i] = -1
    # [log(imp), log(click), log(atc), log(order), log(click)-log(imp), log(atc)-log(click), log(order)-log(click)]
    return tf.reshape(tf.matmul(adf_data, ratio_mtx), [-1, slot_num, dim + len(ratios)])


def get_embs_from_dict(emb_dict, slot_ids):
    embs = [emb_dict.get(slot, None) for slot in slot_ids]
    for emb in embs:
        assert emb is not None
    return embs


def convert_pooling(p):
    if p == 'sum' or p == ego.Pooling.SUM:
        return ego.Pooling.SUM
    elif p == 'avg' or p == ego.Pooling.AVG:
        return ego.Pooling.AVG
    elif p == 'max' or p == ego.Pooling.MAX:
        return ego.Pooling.MAX
    elif p == 'min' or p == ego.Pooling.MIN:
        return ego.Pooling.MIN
    elif p == 'tile' or p == ego.Pooling.TILE:
        return ego.Pooling.TILE
    elif p == 'tile_nf' or p == ego.Pooling.TILE_NF:
        return ego.Pooling.TILE_NF
    else:
        print(p)
        print("pooling method not implemented")
        exit()
