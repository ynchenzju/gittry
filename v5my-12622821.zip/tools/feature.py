# Created on Jul 26 2023
# Author: vincent.ruan

import sys
from collections import defaultdict, OrderedDict
import tensorflow as tf
import ego
# from utils.ops import ignore_grad, load
import yaml

def load(path):
    f = open(path, "r")
    conf = yaml.safe_load(f)
    f.close()
    return conf


@tf.custom_gradient
def ignore_grad(x):
    def grad(upstream):
        return upstream * 0.0
    return x, grad

class Shape(object):
    def __init__(self, dim, length=0) -> None:
        self._length = length
        self._dim = dim

    def __add__(self, other):
        if self.length != other.length:
            raise ValueError("lengths do not match")
        return Shape(self.dim + other.dim, self.length)

    @property
    def value(self):
        if self.length:
            return (self.length, self.dim)
        return self.dim

    @property
    def length(self):
        return self._length

    @property
    def dim(self):
        return self._dim


class Feature(object):
    def __init__(self, **kwargs):
        self._aggregator = None
        self._dim = 0
        self._length = 50
        self._name = ""
        self._from_fp = True
        self._slot_id = 0
        self._indice = 0
        self._is_shared = False
        self._back_propagation = True
        self._flag = 1

        for key, value in kwargs.items():
            setattr(self, f"_{key}", value)

        self._tensor = None

    def __str__(self):
        return f"{self.name}:{self.slot_id}:{self.indice}"

    @staticmethod
    def key(name, slot_id, indice):
        return f"{name}:{slot_id}:{indice}"

    def __hash__(self):
        return int(self._slot_id)

    @property
    def tensor(self):
        return self._tensor

    @property
    def pooling(self):
        if self._aggregator == "sum" or self._aggregator == ego.Pooling.SUM:
            return ego.Pooling.SUM
        elif self._aggregator == "avg" or self._aggregator == ego.Pooling.AVG:
            return ego.Pooling.AVG
        elif self._aggregator == "max" or self._aggregator == ego.Pooling.MAX:
            return ego.Pooling.MAX
        elif self._aggregator == "min" or self._aggregator == ego.Pooling.MIN:
            return ego.Pooling.MIN
        elif self._aggregator == "tile" or self._aggregator == ego.Pooling.TILE:
            return ego.Pooling.TILE
        elif self._aggregator == "tile_nf" or self._aggregator == ego.Pooling.TILE_NF:
            return ego.Pooling.TILE_NF
        raise TypeError(f"invalid pooling method {self._aggregator}")

    @property
    def shape(self):
        if self.pooling in (ego.Pooling.TILE, ego.Pooling.TILE_NF):
            if self._length:
                return Shape(self._dim, self._length)
            else:
                raise AttributeError("tile feature {name} has no length")
        return Shape(self._dim)

    @property
    def flag(self):
        return self._flag

    @property
    def name(self):
        return self._name

    @property
    def from_fp(self):
        return self._from_fp

    def set_slot_id(self, slot_id):
        self._slot_id = slot_id

    @property
    def slot_id(self):
        return self._slot_id

    @property
    def indice(self):
        return self._indice

    def set_shared(self, shared):
        self._is_shared = shared

    @property
    def shared(self):
        return self._is_shared

    @property
    def back_propagation(self):
        return self._back_propagation


class FeatureManager(object):
    def __init__(self, mc_path, fg_path=""):
        if fg_path:
            self._fg_conf = load(fg_path)
        else:
            self._fg_conf = {}
        self._mc_conf = load(mc_path)
        self._pool_sum_slot = defaultdict(list)
        self._tile_slot = defaultdict(list)
        self._group_emb = defaultdict(OrderedDict)
        self._group_name = defaultdict(list)
        self._group_dim = defaultdict(list)
        self._all_slotid = []
        self.fg_conf_map = self.get_fg_conf()
        self.hash_slot_ids = []
        self.hash_slot_dims = []
        self.init_feature()

    def get_fg_conf(self):
        fg_conf_map = {}
        for conf in self._fg_conf["nodes"]:
            if not conf.get("export_config_list"):
                continue
            for export_conf in conf.get("export_config_list"):
                slot_id = export_conf["slot_id"]
                if export_conf.get("sparse_hash_slot", None) != None:
                    fg_conf_map[slot_id] = {
                        "sparse_hash_slot": export_conf.get("sparse_hash_slot", None)
                    }
        return fg_conf_map


    def init_feature(self):
        slotid2dim = {}
        for g in self._mc_conf:
            for i in range(len(self._mc_conf[g])):
                slot_id = self._mc_conf[g][i]['slot_id']
                dim = self._mc_conf[g][i]['dim']
                slotid2dim[slot_id] = dim

        for g, confs in self._mc_conf.items():
            for conf in confs:
                if conf['slot_id'] in self.fg_conf_map:
                    hash_slotid = self.fg_conf_map[conf['slot_id']]['sparse_hash_slot']
                    conf['dim'] = slotid2dim[hash_slotid]
                    self.hash_slot_ids.append(hash_slotid)
                    self.hash_slot_dims.append(slotid2dim[hash_slotid])
                feature = Feature(**conf)
                # fg_conf = self.get_conf_from_fg(feature.name)
                # slot_id = fg_conf["export_config_list"][0]["slot_id"]
                # if slot_id != feature.slot_id:
                #     raise ValueError("feature %s slot_id is %d, not consistent with %d in conf" % (feature.name, slot_id, feature.slot_id))

                if g.endswith("seq"):
                    self._tile_slot[g].append(feature)
                else:
                    self._pool_sum_slot[g].append(feature)
                self._all_slotid.append(feature.slot_id)

    def build_input(self, group_name, feature_type = ego.FeatureType.UNDEFINED, seq_len = 10000, is_assign_slot = False):
        if group_name.endswith('seq'):
            return self.build_tile_input(group_name, feature_type, seq_len)
        else:
            return self.build_pool_input(group_name, feature_type, is_assign_slot)

    def build_pool_input(self, group_name, feature_type = ego.FeatureType.UNDEFINED, is_assign_slot_flag = False):
        dim_list = []
        embs_list = []
        for feature in self._pool_sum_slot[group_name]:
            slot_id, shape, pooling = feature.slot_id, feature.shape, feature.pooling
            emb = ego.get_slots(
                name=str(slot_id),
                slots=[slot_id],
                dims=[shape.dim],
                poolings=[pooling],
                feature_type=feature_type,
                is_assign_slot = is_assign_slot_flag
            )
            if feature.back_propagation is False:
                print(f"[build_pool_input] {slot_id} back_propagation is false and ignore_grad")
                emb = ignore_grad(emb)
            self._group_emb[group_name][slot_id] = emb
            embs_list.append(emb)
            dim_list.append(shape.dim)

        return tf.concat(embs_list, axis = -1), embs_list, dim_list

    def build_tile_input(self, group_name, feature_type = ego.FeatureType.UNDEFINED, seq_len = 10000):
        embs_list = []
        slot_len_list = []
        for feature in self._tile_slot[group_name]:
            slot_id, shape, pooling = feature.slot_id, feature.shape, feature.pooling
            print(slot_id, shape, pooling )
            dim, length = shape.dim, shape.length
            length = min(length, seq_len)
            emb, slot_len = ego.get_slots(
                                name=str(slot_id),
                                slots=[slot_id],
                                dims=[(length, dim)],
                                poolings=[pooling],
                                feature_type=feature_type
                            )
            self._group_emb[group_name][slot_id] = [emb, slot_len]
            if feature.back_propagation is False:
                print(f"[build_tile_input] {slot_id} back_propagation is false and ignore_grad")
                emb = ignore_grad(emb)
            embs_list.append(emb)
            slot_len_list.append(slot_len)
            field_name = f"{feature.name}__sep__{slot_id}"
            self._group_name[group_name].append(field_name)
            self._group_dim[group_name].append(shape.dim)

        seq_emb = tf.concat(embs_list, axis = -1) # (B, length, dim_sum)
        seq_len = tf.reduce_max(tf.concat(slot_len_list, axis = -1), axis = 1, keepdims=True) # (B, 1)
        return (seq_emb, seq_len)


    def build_target_item_input(self, group_name = 'target_item_query', nsc_flag = False):
        target_item_slotids = []
        dim_list = []
        pooling_list = []
        for feature in self._pool_sum_slot[group_name]:
            slot_id, shape, pooling = feature.slot_id, feature.shape, feature.pooling
            target_item_slotids.append(slot_id)
            dim_list.append(shape.dim)
            pooling_list.append(pooling)

        embs = ego.get_slots(
            name=group_name,
            slots=target_item_slotids,
            dims=dim_list,
            poolings=pooling_list,
            feature_type=ego.FeatureType.ITEM,
            use_nsc = nsc_flag
        )
        return embs, target_item_slotids, dim_list

    def get_group_emb(self, group_name):
        return self._group_emb[group_name]

    def to_export_yaml(self, shared_dense_slots=None, iterable_dense_slots=None, shared_onehot_slots=None, iterable_onehot_slots=None):
        sparse_slot_ids = []
        for g in self._group_emb:
            sparse_slot_ids += list(self._group_emb[g].keys())

        sparse = {
            "export_name": "sparse",
            "slot_ids": sparse_slot_ids
        }
        shared_dense = {
            "export_name": "shared_dense",
            "slot_ids": shared_dense_slots
        }
        iterable_dense = {
            "export_name": "iterable_dense",
            "slot_ids": iterable_dense_slots
        }
        shared_onehot = {
            "export_name": "shared_onehot",
            "slot_ids": shared_onehot_slots
        }
        iterable_onehot = {
            "export_name": "iterable_onehot",
            "slot_ids": iterable_onehot_slots
        }
        export = {"sparse": [sparse], "dense": [shared_dense, iterable_dense, shared_onehot, iterable_onehot]}
        return export


