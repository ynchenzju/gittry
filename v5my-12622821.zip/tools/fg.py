#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from itertools import chain, groupby
import ego
import sys


class FG:
    def __init__(self, fg_conf=None, slot_conf=None):
        self.fg_conf = fg_conf
        self.slot_conf = slot_conf

        self.fg_conf_map = self.get_fg_conf()

        # {12506: {'aggregator': 'sum', 'dim': 16, 'name': 'st_ub_click_price_bucket_1d', 'slot_id': 12506}, 12516: {'aggregator': 'sum', 'dim': 16, 'name': 'st_ub_cart_price_bucket_1d', 'slot_id': 12516}}
        self.slot_conf_map = {
            conf["slot_id"]: conf for conf in chain(*self.slot_conf.values())
        }
        self.used_shared_slotids = self.read_ordered_dict(self.slot_conf['shared_slot'])
        self.used_iterable_slotids = self.read_ordered_dict(slot_conf['iterable_slot'])
        self.used_online_slotids = self.read_ordered_dict(slot_conf['item_online_fea'])
        self.used_item_cacheid = self.read_ordered_dict(slot_conf['item_cache_slot'])
        self.used_context_slotids = self.read_ordered_dict(slot_conf['indicator_fea'])
        self.pooling_map = {'sum': ego.Pooling.SUM, 'avg': ego.Pooling.AVG, 'max': ego.Pooling.MAX,
                'min': ego.Pooling.MIN, 'tile': ego.Pooling.TILE, 'tile_nf': ego.Pooling.TILE_NF}

    def read_ordered_dict(self, used_slotids):
        tmp = OrderedDict()
        for slot in used_slotids:
            tmp[slot['slot_id']] = slot
        return tmp

    def get_fg_conf(self):
        fg_conf_map = {}
        for conf in self.fg_conf["nodes"]:
            if not conf.get("export_config_list"):
                continue
            for export_conf in conf.get("export_config_list"):
                slot_id = export_conf["slot_id"]
                fg_conf_map[slot_id] = {
                    "sparse_hash_slot": export_conf.get("sparse_hash_slot", None)
                }
        return fg_conf_map

    def gen_export_yaml(self, shared_dense_slots=None, iterable_dense_slots=None, shared_onehot_slots=None, iterable_onehot_slots=None):
        if not self.fg_conf or not self.slot_conf:
            raise AttributeError("conf not init")

        sparse_slot_ids = list(self.used_shared_slotids.keys()) + list(self.used_iterable_slotids.keys()) + list(self.used_online_slotids.keys()) + list(self.used_item_cacheid.keys())
        sparse = {
            "export_name": "sparse",
            "slot_ids": sparse_slot_ids
        }
        shared_dense = {
            "export_name": "shared_dense",
            "slot_ids": shared_dense_slots
        }
        iterable_dense = {
            "export_name": "iterable_dense",
            "slot_ids": iterable_dense_slots
        }
        shared_onehot = {
            "export_name": "shared_onehot",
            "slot_ids": shared_onehot_slots
        }
        iterable_onehot = {
            "export_name": "iterable_onehot",
            "slot_ids": iterable_onehot_slots
        }
        export = {"sparse": [sparse], "dense": [shared_dense, iterable_dense, shared_onehot, iterable_onehot]}
        return export

    def gen_slot_conf(self, used_slot_map, adf_dim=0):
        slot_ids, slot_dims, pooling_methods = [], [], []
        lr_dim = 1
        for slot_id in used_slot_map:
            conf = used_slot_map[slot_id]
            aggregator = conf["aggregator"]
            if aggregator == "tile":
                if "history_len" in conf:
                    dim = (conf["history_len"], conf["dim"] + adf_dim + lr_dim)
                else:
                    raise AttributeError("tile feature {} {} has no history_len".format(slot_id, conf['name']))
            else:
                dim = conf["dim"] + adf_dim + lr_dim
            slot_ids.append(slot_id)
            slot_dims.append(dim)
            pooling_methods.append(self.pooling_map[aggregator])

        print("slots: \n{}".format(slot_ids))
        print("dims: \n{}".format(slot_dims))
        print("aggregators: \n{}".format(pooling_methods))
        return slot_ids, slot_dims, pooling_methods

    def gen_hash_slot_conf(self, used_slot_map, adf_dim=0):
        hash_slot_conf = []
        for slot_id in used_slot_map:
            conf = used_slot_map[slot_id]
            hash_slot_id = self.fg_conf_map[slot_id].get("sparse_hash_slot")
            hash_slot_id = slot_id if hash_slot_id is None else hash_slot_id
            hash_slot_conf.append((slot_id, conf, hash_slot_id))
        hash_slot_conf = sorted(hash_slot_conf, key=lambda x: x[2])

        slot_ids, slot_dims, pooling_methods = [], [], []
        lr_dim = 1
        for k, g in groupby(hash_slot_conf, key=lambda x: x[2]):
            ids, confs, _ = zip(*g)
            ids = set(ids)
            if len(ids) > 1 or (k not in ids):
                slot_ids.append(k)
                slot_dims.append(confs[0]["dim"] + adf_dim + lr_dim)
                pooling_methods.append(self.pooling_map["sum"])

        print("got {} hash feature columns".format(len(slot_ids)))
        print("slots: \n{}".format(slot_ids))
        print("dims: \n{}".format(slot_dims))
        print("aggregators: \n{}".format(pooling_methods))
        return slot_ids, slot_dims, pooling_methods
