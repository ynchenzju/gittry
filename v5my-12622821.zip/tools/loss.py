import tensorflow as tf


def cross_entropy_loss(label, pred, name=""):
    with tf.compat.v1.variable_scope(name + "_loss"):
        pred_safe = tf.clip_by_value(pred, 1e-5, 1.0 - 1e-5)
        return tf.multiply(label, -tf.math.log(pred_safe)) + tf.multiply(tf.subtract(1.0, label), -tf.math.log(tf.subtract(1.0, pred_safe)))


def multi_loss_func(losses, loss_weights, target_names):
    final_loss = None
    for loss, loss_weight, target_name in list(zip(losses, loss_weights, target_names)):
        loss_weight = tf.clip_by_value(loss_weight, -100.0, 100.0)
        loss = tf.multiply(loss, -loss_weight, name="loss_" + target_name)
        loss = tf.math.reduce_sum(loss, name="batch_loss_" + target_name)
        if final_loss is not None:
            final_loss = loss + final_loss
        else:
            final_loss = loss
    return final_loss


def multi_loss_func_weighted(losses, loss_weights, target_names):
    final_loss = None
    for loss, loss_weight, target_name in list(zip(losses, loss_weights, target_names)):
        loss_weight = tf.clip_by_value(loss_weight, -100.0, 100.0)
        loss = tf.multiply(loss, -loss_weight, name="loss_" + target_name)
        loss = tf.math.reduce_sum(loss, name="batch_loss_" + target_name)
        weight = tf.get_variable(name="loss_weight_" + target_name, shape=[1], initializer=tf.ones_initializer(), trainable=True)
        if final_loss is not None:
            final_loss = loss * weight + final_loss
        else:
            final_loss = loss * weight
    return final_loss
