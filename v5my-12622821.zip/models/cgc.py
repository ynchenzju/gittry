import ego
import tensorflow as tf
from models.base import BaseModel
from tools.fg import FG
from tools.func import get_embs_from_dict
from tools.loss import cross_entropy_loss


@tf.custom_gradient
def ignore_grad(x):
    def grad(upstream):
        return upstream * 0.0

    return x, grad


class CGCNetModel(BaseModel):
    def __init__(self, fg: FG, **kwargs):
        super().__init__(fg, **kwargs)

        self.scen_shared_expert_num = kwargs.get("scen_shared_expert_num", 4)
        self.scen_task_expert_num = kwargs.get("scen_task_expert_num", 2)

        self.slot_conf = fg.slot_conf

        self.gate_input_dct = {}
        # self.bundle_sparse_input_dct, self.gate_input_dct = {}, {}
        # self.shared_sparse_input = None

    def build_inputs(self):
        super().build_inputs()
        # scenario features input
        slot_embs = list(tf.split(self.sparse_norm_input, self.slot_dims, axis=1))
        embs_dict = {slot: emb for slot, emb in zip(self.slot_ids, slot_embs)}

        cart_slot_ids = [conf["slot_id"] for conf in self.slot_conf["cart_feat"]]
        print("cart sparse slots: \n{}".format(cart_slot_ids))
        osp_slot_ids = [conf["slot_id"] for conf in self.slot_conf["osp_feat"]]
        print("osp sparse slots: \n{}".format(osp_slot_ids))
        mpp_slot_ids = [conf["slot_id"] for conf in self.slot_conf["mpp_feat"]]
        print("mpp sparse slots: \n{}".format(mpp_slot_ids))
        # shared_slot_ids = [x for x in self.slot_ids if x not in cart_slot_ids and x not in osp_slot_ids and x not in mpp_slot_ids]
        # print("shared sparse slots: \n{}".format(shared_slot_ids))

        # self.bundle_sparse_input_dct["cart"] = tf.concat(get_embs_from_dict(embs_dict, cart_slot_ids), axis=1)
        # self.bundle_sparse_input_dct["osp"] = tf.concat(get_embs_from_dict(embs_dict, osp_slot_ids), axis=1)
        # self.bundle_sparse_input_dct["mpp"] = tf.concat(get_embs_from_dict(embs_dict, mpp_slot_ids), axis=1)
        # self.shared_sparse_input = tf.concat(get_embs_from_dict(embs_dict, shared_slot_ids), axis=1)

        # no bp for gate inputs: common + scenario features
        gate_input = get_embs_from_dict(embs_dict, self.gate_slots)
        self.gate_input_dct["default"] = tf.concat([ignore_grad(emb) for i, emb in enumerate(gate_input)], axis=1)
        cart_gate_input = get_embs_from_dict(embs_dict, self.gate_slots + cart_slot_ids)
        self.gate_input_dct["cart"] = tf.concat([ignore_grad(emb) for i, emb in enumerate(cart_gate_input)], axis=1)
        osp_gate_input = get_embs_from_dict(embs_dict, self.gate_slots + osp_slot_ids)
        self.gate_input_dct["osp"] = tf.concat([ignore_grad(emb) for i, emb in enumerate(osp_gate_input)], axis=1)
        mpp_gate_input = get_embs_from_dict(embs_dict, self.gate_slots + mpp_slot_ids)
        self.gate_input_dct["mpp"] = tf.concat([ignore_grad(emb) for i, emb in enumerate(mpp_gate_input)], axis=1)

    def scenario_cgc_gate_layer(self, phase):
        expert_input = phase["share_bottom_output"]
        scen_outputs = []
        print(f'scen_expert_input is {expert_input.shape}')
        # bundle-shared expert
        shared_expert_outputs = []
        for idx in range(self.scen_shared_expert_num):
            output = ego.DenseTower(name="{}_scen_shared_expert_{}".format(phase["name"], idx),
                                    output_dims=[256, 128],
                                    kernel_initializers=[self.param_initializer] * 2,
                                    bias_initializers=[self.param_initializer] * 2,
                                    activations=[tf.nn.relu, tf.nn.relu],
                                    norms=[False, False]
                                    )(expert_input)
            shared_expert_outputs.append(output)

        for bundle, bundle_idx in self.bundle_index_mapping.items():
            # bundle-specific expert
            task_expert_outputs = []
            for idx in range(self.scen_task_expert_num):
                output = ego.DenseTower(name="{}_scen_task_expert_{}_{}".format(phase["name"], bundle_idx, idx),
                                        output_dims=[256, 128],
                                        kernel_initializers=[self.param_initializer] * 2,
                                        bias_initializers=[self.param_initializer] * 2,
                                        activations=[tf.nn.relu, tf.nn.relu],
                                        norms=[False, False]
                                        )(expert_input)
                task_expert_outputs.append(output)
            scen_expert_num = self.scen_shared_expert_num + self.scen_task_expert_num
            expert_outputs = task_expert_outputs + shared_expert_outputs
            scen_expert_output = tf.stack(expert_outputs, axis=1)  # B x SCEN_EXPERT_NUM x 128
            print(f'{bundle} scen_expert_output is {scen_expert_output.shape}')
            # bundle-specific gate
            gate_input = phase["scen_gate_input"].get(bundle, phase["scen_gate_input"]["default"])
            print(f'{bundle} scen_gate_input is {gate_input.shape}')
            logit = ego.DenseTower(name="{}_scen_gate_{}".format(phase["name"], bundle_idx),
                                   output_dims=[scen_expert_num],
                                   kernel_initializers=[self.param_initializer],
                                   bias_initializers=[self.param_initializer],
                                   activations=[tf.nn.relu],
                                   norms=[False]
                                   )(gate_input)
            scen_gate_logit = tf.expand_dims(logit, name="{}_scen_gate_expand_{}".format(phase["name"], bundle_idx), axis=1)  # B x 1 x SCEN_EXPERT_NUM
            scen_gate_output = tf.nn.softmax(scen_gate_logit, name="{}_scen_gate_softmax_{}".format(phase["name"], bundle_idx))
            print(f'{bundle} scen_gate_output is {scen_gate_output.shape}')
            scen_output = tf.einsum('bij,bjk->bk', scen_gate_output, scen_expert_output)  # B x 128
            scen_outputs.append(scen_output)
        # scen_output B x NUM_BUNDLE x 128
        scen_output = tf.stack(scen_outputs, axis=1)
        print(f'scen_output shape is {scen_output.shape}')
        phase["scen_output"] = scen_output

    def build_network(self):
        tower1_input = tf.concat([self.feat_onehot_input, self.dense_norm_input, self.sparse_norm_input], axis=1)
        tower2_input = self.sparse_norm_input
        nn_inputs = [tower1_input, tower2_input]

        for i, phase in enumerate(self.phases):
            phase["nn_input"] = nn_inputs[i]
            phase["scen_gate_input"] = self.gate_input_dct
            # share bottom
            self.dense_layer(phase,
                             tower_name="share_bottom", dim=1024,
                             input_name="nn_input", output_name="share_bottom_output")
            # feature net
            self.dense_layer(phase,
                             tower_name="feat_net", dim=128,
                             input_name="share_bottom_output", output_name="feat_net_output")
            # scenario cgc gate
            self.scenario_cgc_gate_layer(phase)

            # mmoe for each bundle
            bundle_input_lst = tf.split(phase["scen_output"], num_or_size_splits=len(self.bundle_index_mapping), axis=1)
            for bundle, bundle_idx in self.bundle_index_mapping.items():
                bundle_input = tf.squeeze(bundle_input_lst[bundle_idx], axis=1)
                phase[f"{bundle}_bundle_input"] = tf.concat([bundle_input, phase["feat_net_output"]], axis=1)
                # bundle net
                self.dense_layer(phase,
                                 tower_name=f"{bundle}_bundle_net", dim=64,
                                 input_name=f"{bundle}_bundle_input", output_name=f"{bundle}_bundle_net_output")
                # bundle mmoe
                self.bundle_mmoe_layer(phase, bundle)
                # towers
                tower_input_lst = tf.split(phase[f"{bundle}_bundle_output"], num_or_size_splits=len(self.target_names), axis=1)
                for idx, target in enumerate(self.target_names):
                    tower_input = tf.squeeze(tower_input_lst[idx], axis=1)
                    tower_input = tf.concat([tower_input, phase[f"{bundle}_bundle_net_output"]], axis=1)
                    pred = ego.DenseTower(name="{}_{}_{}_tower".format(phase["name"], bundle, target),
                                          output_dims=[64, 1],
                                          kernel_initializers=[self.param_initializer] * 2,
                                          bias_initializers=[self.param_initializer] * 2,
                                          activations=[tf.nn.relu, tf.nn.sigmoid],
                                          norms=[False, False])(tower_input)
                    node = "{}_{}_{}".format(phase["name"], bundle, target)
                    output = tf.identity(pred, node)
                    label_idx = bundle_idx * len(self.target_names) * 2 + idx * 2
                    label, weight = ego.get_label_weight(target_name="{}_{}_{}_label_weight".format(phase["name"], bundle, target), label_idx=label_idx)
                    loss = cross_entropy_loss(label, output, target)

                    phase["nodes"].append(node)
                    phase["outputs"].append(output)
                    phase["labels"].append(label)
                    phase["weights"].append(weight)
                    phase["losses"].append(loss)

    def build_graph(self):
        self.build_inputs()
        self.build_network()
        self.build_targets()
        self.build_loss()
        return self.phases
