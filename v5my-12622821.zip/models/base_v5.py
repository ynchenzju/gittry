#!/usr/bin/env python
from itertools import zip_longest

import ego
import tensorflow as tf
from tools.func import convert_pooling, get_embs_from_dict
from tools.loss import cross_entropy_loss, multi_loss_func
import yaml, json
import sys
from itertools import chain

@tf.custom_gradient
def ignore_grad(x):
    def grad(upstream):
        return upstream * 0.0

    return x, grad

def get_shape(inputs):
    dynamic_shape = tf.shape(inputs)
    static_shape = inputs.get_shape().as_list()
    shape = []
    for i, dim in enumerate(static_shape):
        shape.append(dim if dim is not None else dynamic_shape[i])
    return shape


# 分region 搭建rankmixer
# gate中引入更多user info

class BaseModel:
    def __init__(self, fm, **kwargs):
        self.fm = fm
        self.cfg = self.read_train_cfg()

        self.shared_dense_dim = kwargs.get("shared_dense_dim", 53)
        self.iterable_dense_dim = kwargs.get("iterable_dense_dim", 39)
        self.shared_onehot_dim = kwargs.get("shared_onehot_dim", 13) # 7 + 6
        self.iterable_onehot_dim = kwargs.get("iterable_onehot_dim", 26)

        self.bundle_index_mapping = kwargs.get("bundle_index_mapping", {"cart": 0, "osp": 1, "buya": 2, "mpp": 3, "odp": 4})

        self.item_emb, self.item_emb_list, self.item_dims = self.fm.build_input('item_slot', ego.FeatureType.ITEM)
        self.img_emb, self.img_emb_list, self.img_dims = self.fm.build_input('target_item_query_img', ego.FeatureType.ITEM)
        self.title_emb, self.title_emb_list, self.title_dims = self.fm.build_input('target_item_query_title', ego.FeatureType.ITEM)
        self.sid_emb, self.sid_emb_list, self.sid_dims = self.fm.build_input('item_sid', ego.FeatureType.ITEM)
        # self.q_img = 'target_item_query_img'
        # self.q_title = 'target_item_query_title'
        self.online_emb, self.online_emb_list, self.online_dims = self.fm.build_input('item_online_fea', ego.FeatureType.ITEM)
        self.assign_slot_emb, self.item_cache_emb_list, self.item_cache_dims = self.fm.build_input('item_cache_slot', ego.FeatureType.ITEM, is_assign_slot = True)

        featuretype = ego.FeatureType.ITEM
        if not ego.is_training_mode():
            featuretype = ego.FeatureType.COMMON
        self.user_slot_emb, self.user_slot_emb_list, self.user_slot_dims = self.fm.build_input('user_slot', featuretype)

        self.user_emb, self.user_emb_list, self.user_dims = self.fm.build_input('indicator_user_fea', featuretype)
        self.ctx_emb, self.ctx_emb_list, self.ctx_dims = self.fm.build_input('indicator_ctx_fea', featuretype)
        # self.context_emb, self.context_emb_list, self.context_dims = self.fm.build_input('indicator_fea' ,featuretype)

        # ego.config_feature_admission_evict(slots=[2001, 8900,8901,12900,12901,12910,12911,12920,12921,12906,12907,8533,12347,12350,12352,12354], delete_threshold=0, delete_after_unseen_days=24*366)

        # seq attention
        user_group_names = {}
        self.seq_names = ["user_click_seq", "user_cart_seq", "user_order_seq", "user_click_long_seq", "user_order_long_seq"]
        for _k in self.seq_names:
            user_group_names[_k] = ego.FeatureType.COMMON
        del _k
        
        print(f"[seq_names]={self.seq_names}")

        self.group_input_map = {}
        for group_name in user_group_names:
            print(group_name, user_group_names[group_name])
            self.group_input_map[group_name] = fm.build_input(group_name, user_group_names[group_name])

        print(f"[group_input_map] {self.group_input_map}")

        # simtier (from cart_rr_l2_ot_long model_v1): 8900 img/title, use mcconf_v3 group names
        simtier_user_group_names = {}
        self.img_seq_names = ["user_click_img_seq", "user_cart_img_seq", "user_order_img_seq"]
        self.title_seq_names = ["user_click_title_seq", "user_cart_title_seq", "user_order_title_seq"]
        self.img_long_seq_names = ["user_click_img_long_seq", "user_order_img_long_seq"]
        self.q_img = 'target_item_query_img'
        self.q_title = 'target_item_query_title'
        for _k in self.img_seq_names + self.title_seq_names + self.img_long_seq_names:
            simtier_user_group_names[_k] = ego.FeatureType.COMMON
        for _k in [self.q_img, self.q_title]:
            simtier_user_group_names[_k] = ego.FeatureType.ITEM
        # simtier for 8533 sid (same pattern as 8900): item_sid + 12347/12350/12352/12354
        self.sid_map = {
                    "user_click_sid_long_seq": [12347, 8533, 500, 7, 6, ego.Pooling.TILE_NF],
                    "user_click_sid_seq": [12350, 8533, 50, 7, 6, ego.Pooling.TILE_NF],
                    "user_cart_sid_seq": [12352, 8533, 50, 7, 6, ego.Pooling.TILE_NF],
                    "user_order_sid_seq": [12354, 8533, 50, 7, 6, ego.Pooling.TILE_NF],
                    "item_sid": [8533, 8533, 1, 7, 6, ego.Pooling.SUM]
                }
        self.sid_layers = 6
        self.sid_num = 512
        self.sid_codebooks = [
             tf.get_variable(f'ssid_cb_{i}', shape=[self.sid_num, 64], initializer = tf.glorot_normal_initializer(), trainable = True) for i in range(self.sid_layers)
             ]

        # Process sid embeddings from sid_map
        sid_embeddings = {}
        self.simtier_group_input_map = {}
        for key, sid_info in self.sid_map.items():
            # Handle nested list case (e.g., user_cart_seq)
            if isinstance(sid_info[0], list):
                sid_info = sid_info[0]
            
            slot_id, hash_slot_id, length, dim, real_dim, pooling = sid_info
            print(f"[build_esmm] Processing sid for {key}: slot_id={slot_id}, hash_slot_id={hash_slot_id}, length={length}, dim={dim}, real_dim={real_dim}")
            
            self.simtier_group_input_map[key] = self.get_sid_emb(slot_id, hash_slot_id, length, dim, real_dim, pooling)

            # Reshape similar to gr_code.py: flatten last two dimensions
            # [B, length, real_dim, emb_dim] -> [B, length, real_dim * emb_dim]
            # shape = get_shape(sid_emb)
            # if key == "item_sid":
            #     # sid_emb_reshaped = tf.reshape(sid_emb, [shape[0], shape[1] * shape[2] * shape[3]])
            #     self.simtier_group_input_map[key] = (sid_emb_reshaped, [sid_emb_reshaped], [shape[1] * shape[2] * shape[3]])

            # else:
            #     sid_emb_reshaped = tf.reshape(sid_emb, [shape[0], shape[1], shape[2] * shape[3]])
            #     self.simtier_group_input_map[key] = (sid_emb_reshaped, [sid_emb_reshaped], [shape[1] * shape[2] * shape[3]])
            # print(f"[build_esmm] sid_emb_reshaped shape for {key}: {sid_emb_reshaped.get_shape()}")
            
            # self.simtier_group_input_map[key] = sid_emb_reshaped

        self.sid_seq_names = ["user_click_sid_seq", "user_cart_sid_seq", "user_order_sid_seq"]
        self.sid_long_seq_names = ["user_click_sid_long_seq"]
        self.q_sid = 'item_sid'
        # for _k in self.sid_seq_names + self.sid_long_seq_names:
        #     simtier_user_group_names[_k] = ego.FeatureType.COMMON
        # simtier_user_group_names[self.q_sid] = ego.FeatureType.ITEM
        # del _k

        print(f"[img_seq_names]={self.img_seq_names}, [title_seq_names]={self.title_seq_names}, [img_long_seq_names]={self.img_long_seq_names}, [sid_seq_names]={self.sid_seq_names}, [sid_long_seq_names]={self.sid_long_seq_names}")
        for group_name in simtier_user_group_names:
            print(group_name, simtier_user_group_names[group_name])
            self.simtier_group_input_map[group_name] = fm.build_input(group_name, simtier_user_group_names[group_name])

        print(f"[simtier_group_input_map]")
        for k,v in self.simtier_group_input_map.items():
            print(k, v)

        self.param_initializer = tf.initializers.glorot_normal(seed=42)
        self.target_names = "click,roi2_ctr,atc,order,roi2_cvr,roi2_single".split(',')
        self.phases = [{"name": "p0"}]
        self.init_phases()
        self.bundle_onehot_input, self.shared_dense_input, self.iterable_dense_input, self.shared_onehot_input, self.iterable_onehot_input = None, None, None, None, None


    def get_sid_emb(self, slot_id, hash_slot_id, length, dim, real_dim, pooling=ego.Pooling.TILE_NF):
        """
        Get sid embeddings similar to gr_code.py get_sid_emb function.
        
        Args:
            slot_id: The slot ID to get embeddings for
            hash_slot_id: The hash slot ID (determines which codebook to use)
            length: Sequence length
            dim: Total dimension
            real_dim: Real dimension to use (usually dim - 1)
            pooling: Pooling method (TILE_NF for sequences, others for non-sequences)
        
        Returns:
            sid_seq_emb: [B, length, emb_dim] tensor if TILE_NF, [B, emb_dim] otherwise
        """
        category_num = self.sid_num
        codebook = self.sid_codebooks
        
        merge_idx = 6
        merged_codebook = tf.concat(codebook[:merge_idx], axis=0)
        
        # Configure feature admission evict
        ego.config_feature_admission_evict(
            slots=[slot_id], 
            create_clk_prob=0, 
            create_nonclk_prob=0, 
            delete_after_unseen_days=24*93
        )
        
        # Get sid sequence raw data
        is_tile_nf = (pooling == ego.Pooling.TILE_NF)

        if is_tile_nf:
            sid_seq_raw, slot_len = ego.get_slots(
                name=str(slot_id),
                slots=[slot_id],
                dims=[(length, dim)],
                poolings=[pooling],
                feature_type=ego.FeatureType.COMMON
            )
            # Extract relevant part: (B, len, dim - 1) -> (B, len, real_dim)
            sid_seq_raw = tf.stop_gradient(sid_seq_raw[:, :, 1: 1 + real_dim])
            sid_seq_raw = tf.clip_by_value(tf.cast(sid_seq_raw, tf.int32), 0, category_num)
            sid_seq_raw = tf.cast(sid_seq_raw, tf.int32)
            
            # Create offsets and do embedding lookup
            offsets = tf.range(real_dim, dtype=sid_seq_raw.dtype) * category_num
            print(f"[get_sid_emb] offsets for slot {slot_id}: {offsets}")
            sid_seq_offset = sid_seq_raw + offsets[None, None, :]
            sid_seq_emb = tf.nn.embedding_lookup(merged_codebook, sid_seq_offset)
            shape = get_shape(sid_seq_emb)
            sid_emb_reshaped = tf.reshape(sid_seq_emb, [shape[0], shape[1], shape[2] * shape[3]])
            return (sid_emb_reshaped , slot_len)
        else:
            sid_raw = ego.get_slots(
                name=str(slot_id),
                slots=[slot_id],
                dims=[dim],
                poolings=[pooling],
                feature_type=ego.FeatureType.ITEM
            )
            # For non-TILE_NF: result is [B, dim - 1]
            sid_raw = tf.stop_gradient(sid_raw[:, 1: 1 + real_dim])
            sid_raw = tf.clip_by_value(tf.cast(sid_raw, tf.int32), 0, category_num)
            sid_raw = tf.cast(sid_raw, tf.int32)
            
            # Create offsets and do embedding lookup
            offsets = tf.range(real_dim, dtype=sid_raw.dtype) * category_num
            print(f"[get_sid_emb] offsets for slot {slot_id}: {offsets}")
            sid_offset = sid_raw + offsets[None, :]
            sid_emb = tf.nn.embedding_lookup(merged_codebook, sid_offset)
            # sid_seq_emb = tf.expand_dims(sid_seq_emb, axis=1)
            shape = get_shape(sid_emb)
            sid_emb_reshaped = tf.reshape(sid_emb, [shape[0], shape[1] * shape[2]])
            return sid_emb_reshaped, [sid_emb_reshaped], shape[1] * shape[2]



    def build_inputs(self):
        if len(self.fm.hash_slot_ids):
            ego.import_extra_slots(self.fm.hash_slot_ids, self.fm.hash_slot_dims)
        ego.config_feature_admission_evict(slots=list(self.fm.get_group_emb('item_cache_slot').keys()), delete_threshold=0, delete_after_unseen_days=self.cfg['unseen_days'], vec_create_threshold=0)

        self.shared_dense_input = ego.get_dense_feature(name="shared_dense", dim=self.shared_dense_dim, feature_type=ego.FeatureType.COMMON)
        self.iterable_dense_input = ego.get_dense_feature(name="iterable_dense", dim=self.iterable_dense_dim, feature_type=ego.FeatureType.ITEM)
        self.shared_onehot_input = ego.get_dense_feature(name="shared_onehot", dim=self.shared_onehot_dim, feature_type=ego.FeatureType.COMMON)
        self.iterable_onehot_input = ego.get_dense_feature(name="iterable_onehot", dim=self.iterable_onehot_dim, feature_type=ego.FeatureType.ITEM)
        self.bundle_onehot_input = tf.slice(self.shared_onehot_input, [0, 0], [-1, len(self.bundle_index_mapping)])
 
        self.shared_dense_input = tf.clip_by_value(ego.Normalization("shared_dense_input")(self.shared_dense_input), -5, 5)
        self.iterable_dense_input = tf.clip_by_value(ego.Normalization("iterable_dense_input")(self.iterable_dense_input), -5, 5)


        self.uid_emb = tf.clip_by_value(ego.Normalization("sparse_norm")(self.user_emb[:, 17:]), -5, 5)
        self.ctx_emb = tf.concat([tf.clip_by_value(ego.Normalization("sparse_norm")(self.ctx_emb), -5, 5), self.bundle_onehot_input], axis=-1)

        self.user_slot_emb = tf.concat([self.user_emb[:, :17], self.user_slot_emb], axis=-1)
        self.user_slot_emb = tf.clip_by_value(ego.Normalization("sparse_norm")(self.user_slot_emb), -5, 5)

        self.item_emb = tf.clip_by_value(ego.Normalization("sparse_norm")(self.item_emb), -5, 5)
        self.img_emb = tf.clip_by_value(ego.Normalization("sparse_norm")(self.img_emb), -5, 5)
        self.title_emb = tf.clip_by_value(ego.Normalization("sparse_norm")(self.title_emb), -5, 5)
        self.online_emb = tf.clip_by_value(ego.Normalization("sparse_norm")(self.online_emb), -5, 5)
        self.sid_emb = tf.clip_by_value(ego.Normalization("sparse_norm")(self.sid_emb), -5, 5)

    def read_train_cfg(self):
        cfg = {}
        if ego.is_training_mode():
            try:
                with open("ego-learner.yaml") as fh:
                    yaml_data = yaml.safe_load(fh)
                if 'my_train_config' in yaml_data:
                    for key in yaml_data['my_train_config']:
                        cfg[key] = yaml_data['my_train_config'][key]
            except Exception as e:
                print("here are some error", e)
        else:
            with open('online_compile_config.json') as f:
                cfg = json.load(f)
        print(cfg)
        return cfg

    def init_phases(self):
        for phase in self.phases:
            phase["nodes"], phase["outputs"], phase["labels"], phase["weights"], phase["losses"] = [], [], [], [], []
            phase["pred_nodes"], phase["pred_outputs"], phase["final_loss"] = [], [], []

    def build_targets(self):
        for phase in self.phases:
            for node, output, label, weight, loss in zip(phase["nodes"], phase["outputs"], phase["labels"], phase["weights"], phase["losses"]):
                ego.Target(name=node, pred=output, label=label, weight=weight, loss=loss, metric_type=ego.MetricType.GAUC)

        # if not ego.is_training_mode():
        item_cache_sum = tf.reduce_sum(tf.abs(tf.identity(self.assign_slot_emb)), axis = -1, keepdims=True)
        mode = float(self.mode)
        one_flag = tf.cast(tf.ones_like(item_cache_sum), dtype = tf.float32) - mode * 0.001
        zero_flag = tf.cast(tf.zeros_like(item_cache_sum), dtype = tf.float32)
        item_cache_flag = tf.where(item_cache_sum > 0.00001, one_flag, zero_flag)
        cache_label, cache_weight = ego.get_label_weight('cache_flag', label_idx=0)
        ego.Target(name='cache_flag', pred=item_cache_flag, label=cache_label, weight=cache_weight, loss=None)
            # self.build_online_target(self.phases[0])


    def build_loss(self):
        for phase in self.phases:
            phase["final_loss"] = multi_loss_func(phase["losses"], phase["weights"], phase["nodes"])

    def build_graph(self):
        self.build_inputs()
        self.build_network()
        self.build_targets()
        self.build_loss()
        return self.phases


