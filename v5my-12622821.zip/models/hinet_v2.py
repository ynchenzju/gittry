import ego
import tensorflow as tf
from models.base_v2 import BaseModel
from tools.loss import cross_entropy_loss
from utils.get_emb import get_item_embs 
from utils.get_emb import get_item_attention_embs
from utils.get_emb import get_item_long_seq_att_embs
from utils.sum_log import summary_vector
from utils.sum_log import summary_scalar
from utils.fat import FAT
from utils.fat import get_act_op
from utils.fat import get_init_op
from utils.get_emb import aggregator_function
from utils.onetrans_kv import Transformer
import math

# total nn layer size: 2792530

@tf.custom_gradient
def ignore_grad(x):
    def grad(upstream):
        return upstream * 0.0

    return x, grad

class HiNetModel(BaseModel):
    def __init__(self, fm, **kwargs):
        super().__init__(fm, **kwargs)
        self.num_blocks = 2
        self.debug_nodes = []
        self.scalar_tensor = []
        self.mode = ego.is_training_mode()
        ego.config_feature_admission_evict(slots=[8900,8901,12900,12901,12910,12911,12920,12921,12906,12907,8533,12347,12350,12352,12354], create_clk_prob=0, create_nonclk_prob=0, delete_after_unseen_days=24*366)
        self.fat_input_list = []

        # self.tower_dim = 64
        self.assign_slot_id = [8001]
        self.llm_len = 33
        self.group_fea = []
        self.tb = True
        self.scalar_tensor = []
        self.tokens = {}
        self.num_layers = 2
        self.d_model = 128
        self.num_heads = 4
        self.max_seq_len = 50
        self.action_types = ["user_order_long_seq", "user_order_seq", "user_cart_seq", "user_click_long_seq", "user_click_seq"]
        self.sequence_masks = {}

    def build_inputs(self):
        super().build_inputs()

    def _get_cache_emb(self, _emb, cache_name):
        item_cache_sum = tf.reduce_sum(tf.abs(_emb), axis = -1, keepdims=True)
        mode = float(self.mode)
        one_flag = tf.cast(tf.ones_like(item_cache_sum), dtype = tf.float32) - mode * 0.001
        zero_flag = tf.cast(tf.zeros_like(item_cache_sum), dtype = tf.float32)
        item_cache_flag = tf.where(item_cache_sum > 0.00001, one_flag, zero_flag)
        label, weight = ego.get_label_weight(cache_name, label_idx=0)
        ego.Target(name=cache_name, pred=item_cache_flag, label=label, weight=weight, loss=None)
        self.debug_nodes.append(cache_name)

    def get_tb_log(self, group_input_map):
        from utils.sum_log import summary_vector
        from utils.sum_log import summary_scalar

        ego.config_dump_tensor(with_sample_id=False)

        _scalar_tensor = []
        with tf.variable_scope(f"Group_EMBED"):
            for name in sorted(group_input_map.keys()):
                if not name.endswith("_seq"):
                    print(f"[item!!! {name}]", group_input_map[name])
                    res= summary_vector(group_input_map[name][0], name=name)
                else:
                    _, seq_len = group_input_map[name]
                    res = summary_scalar(seq_len, vals=[0, 10],  val_names=["eq0", "lt10"] , name=f"{name}_length", use_std=False, use_cv=False)
                _scalar_tensor.extend(res)

        print("*" * 10, f"len(_scalar_tensor) = {len(_scalar_tensor)}", "*" * 40)

        # scalar_tensor += _scalar_tensor

        return _scalar_tensor
    

    def get_seq_tb_log(self, group_input_map, seq_names_, att_wgts, seq_index=[0, 1, 2]):
        res_all = []
        for _idx, seq_name in enumerate(seq_names_):
                print(f"[{seq_name} USE_ATTENTION]", group_input_map[seq_name])
                seq_tensors, _ = group_input_map[seq_name]
                _din_weights = att_wgts[_idx]
                with tf.variable_scope(f"DIN_{seq_name}_attention_weights"):
                    for idx in seq_index:
                        tensor = _din_weights[:, idx]
                        res = summary_scalar(tensor, vals=[], val_names=[], name=f"seq{idx}_att_w", use_std=False, use_cv=False)
                        res_all.extend(res)

                with tf.variable_scope(f"DIN_{seq_name}_seq_embed"):
                    for idx in seq_index:
                        tensor_emb = seq_tensors[:, idx, :]
                        res = summary_vector(tensor=tensor_emb, name=f"seq{idx}_emb")
                        res_all.extend(res)
                del _din_weights
        return res_all


    def fuse_score(self, fuse_weight, scores):
        fuse_weight_dim = fuse_weight.get_shape().as_list()[1]
        scores_dim = scores.get_shape().as_list()[1]
        score = tf.reduce_sum(fuse_weight * scores, axis=-1, keepdims=True)
        return score

    def _get_cos(self, _emb, cache_name):
        label, weight = ego.get_label_weight(cache_name, label_idx=0)
        ego.Target(name=cache_name, pred=_emb, label=label, weight=weight, loss=None)
        self.debug_nodes.append(cache_name)

    def make_input_dim(self, emb, name, dim):
        rm_input = 2.0 * ego.DenseTower(name=f"{name}_dim_input_nn",
                                output_dims=[dim],
                                kernel_initializers=[self.param_initializer],
                                bias_initializers=[self.param_initializer],
                                activations=[tf.nn.leaky_relu],
                                norms=[True]
                                )(emb)
        return rm_input
    

    def norm_embs(self, fea_keys, op_name, use_l2_norm):
        feats = []
        for k in fea_keys:
            idx = self.feature_group_indexes[k]
            if use_l2_norm:
                feat = tf.nn.l2_normalize(self.group_fea[idx], axis=-1, name=f"{k}_l2_norm")
            else:
                feat = self.group_fea[idx]
            print(f"[get_item_embs] `{self.feature_group_indexes[k], k}`")
            feats.append(feat)
        return tf.concat(feats, axis=-1, name=op_name + "_concat")

    def avg_long_seq(self, fea, length, seq_len, cut_head, group_num, group_size):
        B = tf.shape(fea)[0]
        length = tf.cast(tf.squeeze(length, axis=1), tf.int32)  # [B]
        fea_cut = fea[:, cut_head:, :]                     # [B, 450, 64]
        length_cut = tf.maximum(length - cut_head, 0)     # [B]
        length_group = tf.cast(tf.math.ceil(tf.cast(length_cut, tf.float32) / group_size), tf.int32)  # [B]
        mask = tf.sequence_mask(length_cut, maxlen=seq_len - cut_head, dtype=fea.dtype)  # [B, 450]
        mask = mask[:, :, None]  # [B, 450, 1]
        fea_group = tf.reshape(fea_cut, [B, group_num, -1, fea_cut.shape[2]])   # [B, group_num, 50, 64]
        mask_group = tf.reshape(mask, [B, group_num, -1, 1])                     # [B, group_num, 50, 1]
        sum_fea = tf.reduce_sum(fea_group * mask_group, axis=2)   # [B, group_num, 64]
        cnt = tf.reduce_sum(mask_group, axis=2)                   # [B, group_num, 1]
        cnt = tf.maximum(cnt, 1.0)                                # 防止除 0
        fea_avg = sum_fea / cnt                                   # [B, group_num, 64]
        length_avg = tf.expand_dims(length_group, axis=1)         # [B, 1]expand_dims(length_group, axis=1)         # [B, 1]
        fea, length = fea_avg, length_avg

        return fea, length, group_num
    

    def build_network(self):
        for i, phase in enumerate(self.phases):
            self.ns_feas = []
            self.ns_fea_dim  = 128
            ctx_fat_input = self.make_input_dim(self.ctx_emb, "context", self.ns_fea_dim)
            self.ns_feas.append(ctx_fat_input) # sim like gate for uid and bundle

            uid_fat_input = self.make_input_dim(self.uid_emb, "uid", self.ns_fea_dim)
            self.ns_feas.append(uid_fat_input) # sim like gate for uid and bundle

            # online_fea_emb = self.make_input_dim(self.online_emb, "online_fea", self.ns_fea_dim)
            # self.ns_feas.append(online_fea_emb) # recall

            user_fea = tf.concat([self.shared_onehot_input, self.shared_dense_input, self.user_base_emb], axis=-1)
            user_base_emb = ego.DenseTower(name="user_{}_{}".format(phase["name"], 'shared_bottom'),
                                output_dims=[256, self.ns_fea_dim],
                                kernel_initializers=[self.param_initializer] * 2,
                                bias_initializers=[self.param_initializer] * 2,
                                activations=[tf.nn.leaky_relu] * 2,
                                norms=[False, True],
                                )(user_fea)
            self.ns_feas.append(user_base_emb) 

            user_prefer_emb = self.make_input_dim(self.user_prefer_emb, "user_prefer", self.ns_fea_dim)
            self.ns_feas.append(user_prefer_emb)

            user_click_bucket_emb = self.make_input_dim(self.user_click_bucket_emb, "user_click_bucket", self.ns_fea_dim)
            self.ns_feas.append(user_click_bucket_emb)

            user_cart_bucket_emb = self.make_input_dim(self.user_cart_bucket_emb, "user_cart_bucket", self.ns_fea_dim)
            self.ns_feas.append(user_cart_bucket_emb)

            user_order_bucket_emb = self.make_input_dim(self.user_order_bucket_emb, "user_order_bucket", self.ns_fea_dim)
            self.ns_feas.append(user_order_bucket_emb)


            # ------------------------------------- ITEM CACHE ---------------------------------
            item_vec = tf.concat([self.iterable_onehot_input, self.iterable_dense_input, self.item_emb, self.img_emb, self.title_emb, self.sid_emb, self.online_emb], axis=-1)
            if self.mode:
                item_tower_output = ego.DenseTower(
                    name='item_tower',
                    output_dims=[128, self.ns_fea_dim],
                    kernel_initializers=[self.param_initializer] * 2,
                    bias_initializers=[self.param_initializer] * 2,
                    activations=[tf.nn.leaky_relu, None],
                    norms=[True, False],
                    use_bias=True
                )(item_vec)
                if i == 0:
                    item_emb = ego.replace_gradient(item_tower_output, self.assign_slot_emb, item_tower_output) # cache做法
            else:
                item_emb = self.assign_slot_emb
            abs_val = tf.sqrt(tf.reduce_sum(abs(item_emb ** 2), axis=-1, keepdims=True))
            print("phrase {} abs val: dim {}".format(phase, abs_val.get_shape().as_list()))
            # ------------------------------------- ITEM CACHE ---------------------------------

            # ------------------------------------- Transformer ---------------------------------


            gr_seq_feas, masks_out = [], []
            self.action_len_dict = {}
            s_length = 0
            for action in self.action_types:
                fea, length = self.group_input_map[action]
                fea = self.make_input_dim(fea, action, self.d_model)

                avg_fea = tf.reduce_mean(fea, axis=1)
                self.ns_feas.append(avg_fea)

                print(action)
                with tf.variable_scope("action_sep_embs", reuse=tf.AUTO_REUSE):
                    sep_emb = tf.get_variable(
                        name='sep_embs_' + action,
                        shape=(1, 1, self.d_model),
                        initializer=self.param_initializer,
                        trainable=True,
                    )

                B_fea = tf.shape(fea)[0]
                sep_emb_tiled = tf.tile(sep_emb, [B_fea, 1, 1])
                max_seq_len = 50

                if action in ("user_click_long_seq", "user_order_long_seq"):
                    fea, length, max_seq_len = self.avg_long_seq(fea, length, seq_len=500, cut_head=50, group_num=9, group_size=50)

                length = tf.squeeze(length, axis=1)   # [B]

                mask = tf.sequence_mask(
                    lengths=length,
                    maxlen=max_seq_len,
                    dtype=tf.float32
                )

                part = tf.concat([sep_emb_tiled, fea], axis=1)
                gr_seq_feas.append(part)
                s_length += max_seq_len + 1
                print('debug info | seq mask of action {}: {}'.format(action, mask.get_shape()))
                sep_mask = tf.ones_like(mask[:, :1])

                masks_out += [tf.zeros_like(sep_mask), mask]

            print('gr_seq_feas', gr_seq_feas)
            s_fea = tf.concat(gr_seq_feas, axis=1)
            print('debug info | s_length: ', s_length)
            x_item = tf.expand_dims(item_emb, axis=1)


            ns_length = len(self.ns_feas)
            ns_fea = tf.stack(self.ns_feas, axis=1)
            print('debug info | ns_fea of shape: ', ns_fea.get_shape())

            s_out, ns_out, item_out = Transformer(num_layers = self.num_layers, d_model = self.d_model, num_heads = self.num_heads, ns_length = ns_length, 
                                        s_length = s_length)([s_fea, ns_fea, x_item, [None for _ in range(self.num_layers)]],
                                                                                                                        ego.is_training_mode())

            seq_masks_out = tf.expand_dims(tf.concat(masks_out, axis=1), axis=-1)
            epsilon = 1e-4
            denominator = tf.reduce_sum(seq_masks_out, axis=1, keepdims=True)
            denominator = tf.maximum(denominator + epsilon, 1.0)
            s_out_masked_mean = tf.reduce_sum(s_out * seq_masks_out, axis=1, keepdims=True) / denominator

            out = tf.concat([s_out_masked_mean, ns_out, item_out], axis=1)

            num_tks = 1 + ns_length + 1 
            print('debug info | transformer out: ', out.get_shape())
            share_bottom = tf.reshape(out, [-1, self.d_model * num_tks])
            print('debug info | share_bottom: ', share_bottom.get_shape())
            # ------------------------------------- Transformer ---------------------------------

            # add shallow features
            shallow_feas = []
            # for seq_fea in gr_seq_feas:
            #     shallow_feas.append(tf.reduce_mean(seq_fea, axis=1))
            
            for fea in self.ns_feas:
                shallow_feas.append(fea)

            shallow_feas.append(item_emb)

            pred_inp = tf.concat(shallow_feas + [share_bottom], axis=-1)

            print('debug info | pred_inp: ', pred_inp.get_shape())
            for idx, target in enumerate(self.target_names):
                target_name = "{}_{}_tower".format(phase["name"], target)
                pred = ego.DenseTower(
                                name=target_name,
                                output_dims=[128, 64, 1],
                                kernel_initializers=[self.param_initializer] * 3,
                                bias_initializers=[self.param_initializer] * 3,
                                activations=[tf.nn.leaky_relu, tf.nn.leaky_relu, tf.nn.sigmoid],
                                norms=[True, False, False])(pred_inp)


                node = "{}_{}".format(phase["name"], target)
                output = tf.identity(pred, node)
                label_idx = idx * 2
                label, weight = ego.get_label_weight(target_name="{}_{}_label_weight".format(phase["name"], target), label_idx=label_idx)
                loss = cross_entropy_loss(label, output, target)

                phase["nodes"].append(node)
                phase["outputs"].append(output)
                phase["labels"].append(label)
                phase["weights"].append(weight)
                phase["losses"].append(loss)

    def get_debug_nodes(self):
        print("[debug_nodes] =", self.debug_nodes)
        return self.debug_nodes

    def get_scalar_tensor(self):
        return self.scalar_tensor

    def build_graph(self):
        self.build_inputs()
        self.build_network()
        self.build_targets()
        self.build_loss()
        return self.phases
