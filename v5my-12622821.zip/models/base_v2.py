#!/usr/bin/env python
from itertools import zip_longest

import ego
import tensorflow as tf
from tools.func import convert_pooling, get_embs_from_dict
from tools.loss import cross_entropy_loss, multi_loss_func
import yaml, json
import sys
from itertools import chain

@tf.custom_gradient
def ignore_grad(x):
    def grad(upstream):
        return upstream * 0.0

    return x, grad


# 分region 搭建rankmixer
# gate中引入更多user info

class BaseModel:
    def __init__(self, fm, **kwargs):
        self.fm = fm
        self.cfg = self.read_train_cfg()

        self.shared_dense_dim = kwargs.get("shared_dense_dim", 53)
        self.iterable_dense_dim = kwargs.get("iterable_dense_dim", 39)
        self.shared_onehot_dim = kwargs.get("shared_onehot_dim", 13) # 7 + 6
        self.iterable_onehot_dim = kwargs.get("iterable_onehot_dim", 26)

        self.bundle_index_mapping = kwargs.get("bundle_index_mapping", {"cart": 0, "osp": 1, "buya": 2, "mpp": 3, "odp": 4})

        self.item_emb, self.item_emb_list, self.item_dims = self.fm.build_input('item_slot', ego.FeatureType.ITEM)
        self.img_emb, self.img_emb_list, self.img_dims = self.fm.build_input('target_item_query_img', ego.FeatureType.ITEM)
        self.title_emb, self.title_emb_list, self.title_dims = self.fm.build_input('target_item_query_title', ego.FeatureType.ITEM)
        self.sid_emb, self.sid_emb_list, self.sid_dims = self.fm.build_input('item_sid', ego.FeatureType.ITEM)
        # self.q_img = 'target_item_query_img'
        # self.q_title = 'target_item_query_title'
        self.online_emb, self.online_emb_list, self.online_dims = self.fm.build_input('item_online_fea', ego.FeatureType.ITEM)
        self.assign_slot_emb, self.item_cache_emb_list, self.item_cache_dims = self.fm.build_input('item_cache_slot', ego.FeatureType.ITEM, is_assign_slot = True)

        featuretype = ego.FeatureType.ITEM
        if not ego.is_training_mode():
            featuretype = ego.FeatureType.COMMON
        # self.shared_emb, self.shared_emb_list, self.shared_dims = self.fm.build_input('shared_slot', featuretype)
        self.user_base_emb, self.user_base_emb_list, self.user_base_dims = self.fm.build_input('user_base_slot', featuretype)
        self.user_prefer_emb, self.user_prefer_emb_list, self.user_prefer_dims = self.fm.build_input('user_prefer_slot', featuretype)
        self.user_click_bucket_emb, self.user_click_bucket_emb_list, self.user_click_bucket_dims = self.fm.build_input('user_click_bucket_slot', featuretype)
        self.user_cart_bucket_emb, self.user_cart_bucket_emb_list, self.user_cart_bucket_dims = self.fm.build_input('user_cart_bucket_slot', featuretype)
        self.user_order_bucket_emb, self.user_order_bucket_emb_list, self.user_order_bucket_dims = self.fm.build_input('user_order_bucket_slot', featuretype)

        self.user_emb, self.user_emb_list, self.user_dims = self.fm.build_input('indicator_user_fea', featuretype)
        self.ctx_emb, self.ctx_emb_list, self.ctx_dims = self.fm.build_input('indicator_ctx_fea', featuretype)
        # self.context_emb, self.context_emb_list, self.context_dims = self.fm.build_input('indicator_fea' ,featuretype)

        ego.config_feature_admission_evict(slots=[2001, 8900,8901,12900,12901,12910,12911,12920,12921,12906,12907,8533,12347,12350,12352,12354], delete_threshold=0, delete_after_unseen_days=24*366)

        # seq attention
        user_group_names = {}
        self.seq_names = ["user_click_seq", "user_cart_seq", "user_order_seq", "user_click_long_seq", "user_order_long_seq"]
        for _k in self.seq_names:
            user_group_names[_k] = ego.FeatureType.COMMON
        del _k
        
        print(f"[seq_names]={self.seq_names}")

        self.group_input_map = {}
        for group_name in user_group_names:
            print(group_name, user_group_names[group_name])
            self.group_input_map[group_name] = fm.build_input(group_name, user_group_names[group_name])

        print(f"[group_input_map] {self.group_input_map}")



        self.param_initializer = tf.initializers.glorot_normal(seed=42)
        self.target_names = "click,roi2_ctr,atc,order,roi2_cvr,roi2_single".split(',')
        self.phases = [{"name": "p0"}]
        self.init_phases()
        self.bundle_onehot_input, self.shared_dense_input, self.iterable_dense_input, self.shared_onehot_input, self.iterable_onehot_input = None, None, None, None, None

    def build_inputs(self):
        if len(self.fm.hash_slot_ids):
            ego.import_extra_slots(self.fm.hash_slot_ids, self.fm.hash_slot_dims)
        ego.config_feature_admission_evict(slots=list(self.fm.get_group_emb('item_cache_slot').keys()), delete_threshold=0, delete_after_unseen_days=self.cfg['unseen_days'])

        self.shared_dense_input = ego.get_dense_feature(name="shared_dense", dim=self.shared_dense_dim, feature_type=ego.FeatureType.COMMON)
        self.iterable_dense_input = ego.get_dense_feature(name="iterable_dense", dim=self.iterable_dense_dim, feature_type=ego.FeatureType.ITEM)
        self.shared_onehot_input = ego.get_dense_feature(name="shared_onehot", dim=self.shared_onehot_dim, feature_type=ego.FeatureType.COMMON)
        self.iterable_onehot_input = ego.get_dense_feature(name="iterable_onehot", dim=self.iterable_onehot_dim, feature_type=ego.FeatureType.ITEM)
        self.bundle_onehot_input = tf.slice(self.shared_onehot_input, [0, 0], [-1, len(self.bundle_index_mapping)])
 
        self.shared_dense_input = tf.clip_by_value(ego.Normalization("shared_dense_input")(self.shared_dense_input), -5, 5)
        self.iterable_dense_input = tf.clip_by_value(ego.Normalization("iterable_dense_input")(self.iterable_dense_input), -5, 5)


        self.uid_emb = tf.clip_by_value(ego.Normalization("sparse_norm")(self.user_emb[:, 17:]), -5, 5)
        self.ctx_emb = tf.concat([tf.clip_by_value(ego.Normalization("sparse_norm")(self.ctx_emb), -5, 5), self.bundle_onehot_input], axis=-1)

        # self.context_emb = tf.concat([tf.clip_by_value(ego.Normalization("sparse_norm")(self.shared_emb[:, -128:]), -5, 5), self.bundle_onehot_input], axis=-1)
        self.user_base_emb = tf.concat([self.user_emb[:, :17], self.user_base_emb], axis=-1)
        self.user_base_emb = tf.clip_by_value(ego.Normalization("sparse_norm")(self.user_base_emb), -5, 5)
        self.user_base_emb_list[-1] = tf.concat([self.user_emb_list[-1][:, :17], self.user_base_emb_list[-1]], axis=-1)
        self.user_base_dims[-1] += 17

        self.user_prefer_emb = tf.clip_by_value(ego.Normalization("sparse_norm")(self.user_prefer_emb), -5, 5)
        self.user_click_bucket_emb = tf.clip_by_value(ego.Normalization("sparse_norm")(self.user_click_bucket_emb), -5, 5)
        self.user_cart_bucket_emb = tf.clip_by_value(ego.Normalization("sparse_norm")(self.user_cart_bucket_emb), -5, 5)
        self.user_order_bucket_emb = tf.clip_by_value(ego.Normalization("sparse_norm")(self.user_order_bucket_emb), -5, 5)

        self.item_emb = tf.clip_by_value(ego.Normalization("sparse_norm")(self.item_emb), -5, 5)
        self.img_emb = tf.clip_by_value(ego.Normalization("sparse_norm")(self.img_emb), -5, 5)
        self.title_emb = tf.clip_by_value(ego.Normalization("sparse_norm")(self.title_emb), -5, 5)
        self.online_emb = tf.clip_by_value(ego.Normalization("sparse_norm")(self.online_emb), -5, 5)
        self.sid_emb = tf.clip_by_value(ego.Normalization("sparse_norm")(self.sid_emb), -5, 5)

    def read_train_cfg(self):
        cfg = {}
        if ego.is_training_mode():
            try:
                with open("ego-learner.yaml") as fh:
                    yaml_data = yaml.safe_load(fh)
                if 'my_train_config' in yaml_data:
                    for key in yaml_data['my_train_config']:
                        cfg[key] = yaml_data['my_train_config'][key]
            except Exception as e:
                print("here are some error", e)
        else:
            with open('online_compile_config.json') as f:
                cfg = json.load(f)
        print(cfg)
        return cfg

    def init_phases(self):
        for phase in self.phases:
            phase["nodes"], phase["outputs"], phase["labels"], phase["weights"], phase["losses"] = [], [], [], [], []
            phase["pred_nodes"], phase["pred_outputs"], phase["final_loss"] = [], [], []

    def build_targets(self):
        for phase in self.phases:
            for node, output, label, weight, loss in zip(phase["nodes"], phase["outputs"], phase["labels"], phase["weights"], phase["losses"]):
                ego.Target(name=node, pred=output, label=label, weight=weight, loss=loss, metric_type=ego.MetricType.GAUC)

        if not ego.is_training_mode():
            item_cache_sum = tf.reduce_sum(tf.abs(tf.identity(self.assign_slot_emb)), axis = -1, keepdims=True)
            one_flag = tf.cast(tf.ones_like(item_cache_sum), dtype = tf.float32)
            zero_flag = tf.cast(tf.zeros_like(item_cache_sum), dtype = tf.float32)
            item_cache_flag = tf.where(item_cache_sum > 0.00001, one_flag, zero_flag)
            ego.Target(name='cache_flag', pred=item_cache_flag, label=label, weight=weight, loss=None)
            # self.build_online_target(self.phases[0])


    def build_loss(self):
        for phase in self.phases:
            phase["final_loss"] = multi_loss_func(phase["losses"], phase["weights"], phase["nodes"])

    def build_graph(self):
        self.build_inputs()
        self.build_network()
        self.build_targets()
        self.build_loss()
        return self.phases


