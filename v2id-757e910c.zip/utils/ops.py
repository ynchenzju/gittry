#!/usr/bin/env python
# -*- coding: utf-8 -*-

import tensorflow as tf
import ego
import yaml
import numpy as np

local_param_initializer = tf.truncated_normal_initializer(stddev=0.001, dtype=tf.float32)

def get_shape(inputs):
    dynamic_shape = tf.shape(inputs)
    static_shape = inputs.get_shape().as_list()
    shape = []
    for i, dim in enumerate(static_shape):
        shape.append(dim if dim is not None else dynamic_shape[i])
    return shape


def load(path):
    f = open(path, "r")
    conf = yaml.safe_load(f)
    f.close()
    return conf


def safe_reduce_mean(tensor, axis=None, keepdims=False, name=None):
    return tf.cond(
        tf.math.greater(tf.size(tensor, out_type=tf.int32), tf.constant(0, tf.int32)),
        lambda: tf.reduce_mean(tensor, axis=axis, keepdims=keepdims, name=name),
        lambda: tf.constant(0.0, dtype=tensor.dtype),
    )


def in_batch_sampling_loss(x, y, weight):
    dot_product = tf.linalg.matmul(x, y, transpose_b=True)
    loss = tf.nn.sparse_softmax_cross_entropy_with_logits(
        labels=tf.range(tf.shape(dot_product)[0], dtype=tf.int32),
        logits=dot_product,
    )
    loss = tf.expand_dims(loss, axis=1) * weight
    loss = tf.reduce_sum(loss)
    return loss, dot_product


def training_monitor(dot_2d, label):
    order_idx = tf.where(tf.cast(label, tf.int32))[:, 0]
    order_dot2d = tf.gather(dot_2d, order_idx)
    pos_score =  tf.expand_dims(order_dot2d[:, 0], 1) # dot_2d[:, :1]
    neg_score = order_dot2d[:, 1:]
    cos_similarity_true = tf.reduce_sum(tf.reduce_sum(pos_score, axis=1), axis=0, name = "cos_pos")
    cos_similarity_false = tf.reduce_sum(tf.reduce_sum(neg_score, axis=1) / float(sample_cnt), axis=0, name = "cos_neg")

    order_num = tf.cast(tf.reduce_sum(tf.ones_like(order_idx)), tf.float32, 'order_num')
    p, mrr = rank_metrics(order_dot2d)
    label_mean = tf.reduce_mean(label, name='label_mean')
    return [cos_similarity_true, cos_similarity_false, order_num, p, mrr, label_mean]


def rank_metrics(dot_product, mask=None):
    max_idx = tf.argmax(dot_product, axis=1, output_type=tf.int32)
    label = tf.range(tf.shape(dot_product)[0], dtype=tf.int32)
    if mask is not None:
        max_idx = tf.boolean_mask(max_idx, mask)
        label = tf.boolean_mask(label, mask)
    p = safe_reduce_mean(tf.cast(tf.equal(max_idx, label), tf.float32))

    ranks = tf.argsort(dot_product, direction="DESCENDING")
    pos_ranks = tf.linalg.tensor_diag_part(ranks)
    if mask is not None:
        pos_ranks = tf.boolean_mask(pos_ranks, mask)
    mrr = safe_reduce_mean(1.0 / (1.0 + tf.cast(pos_ranks, tf.float32)))

    return p, mrr


def similarity_metrics(dot_product, mask=None):
    pos_scores = tf.linalg.tensor_diag_part(dot_product)
    neg_scores = dot_product - tf.linalg.diag(pos_scores)
    if mask is not None:
        pos_scores = tf.boolean_mask(pos_scores, mask)
        neg_scores = tf.boolean_mask(neg_scores, mask)
    pos_similarity = safe_reduce_mean(pos_scores)
    neg_similarity = tf.math.divide_no_nan(
        tf.reduce_sum(neg_scores),
        tf.math.count_nonzero(neg_scores, dtype=neg_scores.dtype),
    )
    return pos_similarity, neg_similarity


@tf.custom_gradient
def ignore_grad(x):
    def grad(upstream):
        return upstream * 0.0

    return x, grad


def local_neg_sample(match_size, local_samples, cnt, start_idx = 0):
    batch_size = get_shape(local_samples)[0]
    batch_neg_idx = tf.random.uniform([match_size, cnt], minval=start_idx, maxval=batch_size, dtype=tf.int32)
    return tf.gather(local_samples, batch_neg_idx) # (B, sample_cnt, 16)


def get_batch_neg_sample(item_emb, sample_cnt, batch_size):
    #output shape: (B, sample_cnt, dim)
    batch_neg_idx = tf.random.uniform([batch_size, sample_cnt], minval=0, maxval=batch_size, dtype=tf.int32)
    row_indices = tf.range(batch_size)
    row_indices = tf.expand_dims(row_indices, axis=1)
    row_same_indices = tf.cast(tf.equal(batch_neg_idx, row_indices), tf.int32)
    last_row = tf.multiply(row_same_indices[batch_size - 1], -(batch_size - 1))
    row_same_indices = tf.tensor_scatter_nd_update(row_same_indices, [[batch_size - 1]], [last_row])
    batch_neg_idx += row_same_indices
    return tf.gather(item_emb, batch_neg_idx)


def get_ego_layer(layername, dim):
    return ego.DenseTower(
                        name=layername,
                        output_dims=[dim],
                        kernel_initializers=[local_param_initializer] * 1,
                        bias_initializers=[local_param_initializer] * 1,
                        activations=[None],
                        norms=[False],
                        use_bias=True,
                    )


def positional_encoding(max_position, d_model):
    position = np.arange(max_position)[:, np.newaxis]
    div_term = np.exp(np.arange(0, d_model, 2) * -(np.log(10000.0) / d_model))

    sin_encoding = np.sin(position * div_term)
    cos_encoding = np.cos(position * div_term)

    pos_encoding = np.zeros((max_position, d_model))
    pos_encoding[:, 0::2] = sin_encoding
    pos_encoding[:, 1::2] = cos_encoding

    return tf.cast(pos_encoding, dtype=tf.float32)


def scaled_dot_product_attention(q, k, v, mask, causality):
    # (B, num_heads, q_seq, k_seq)
    matmul_qk = tf.matmul(q, k, transpose_b=True)
    dk = tf.shape(k)[-1]
    scaled_attention_logits = matmul_qk / tf.math.sqrt(tf.cast(dk, tf.float32))
    if mask is not None:
        # (B, k_seq)
        paddings = 1.0 - mask
        scaled_attention_logits += (paddings[:, tf.newaxis, tf.newaxis, :] * -1e5)

    if causality:
        id_matrix = tf.ones_like(scaled_attention_logits[0, 0, :, :])
        lower_tril = tf.linalg.LinearOperatorLowerTriangular(id_matrix).to_dense()
        mask = tf.linalg.set_diag(lower_tril, tf.zeros([tf.shape(lower_tril)[0]], dtype=lower_tril.dtype))
        scaled_attention_logits += (mask[tf.newaxis, tf.newaxis, ...] * -1e5)

    attention_weights = tf.nn.softmax(scaled_attention_logits, axis=-1)
    # (B, num_heads, q_seq, k_seq) (B, num_heads, k_seq, dim)
    output = tf.matmul(attention_weights, v) # (B, num_heads, q_seq, dim)
    return output, attention_weights


class MultiHeadAttention(tf.keras.layers.Layer):
    def __init__(self, d_model, num_heads, layer_idx):
        super(MultiHeadAttention, self).__init__()
        self.num_heads = num_heads
        self.d_model = d_model
        self.depth = d_model // self.num_heads
        self.wq = get_ego_layer("Q" + str(layer_idx), d_model)
        self.wk = get_ego_layer("K" + str(layer_idx), d_model)
        self.wv = get_ego_layer("V" + str(layer_idx), d_model)
        self.dense = get_ego_layer("O" + str(layer_idx), d_model)

    def split_heads(self, x, batch_size):
        x = tf.reshape(x, (batch_size, -1, self.num_heads, self.depth))
        return tf.transpose(x, perm=[0, 2, 1, 3])

    def call(self, v, k, q, mask, causality):
        batch_size = get_shape(q)[0]
        q = self.wq(q)
        k = self.wk(k)
        v = self.wv(v)

        q = self.split_heads(q, batch_size)
        k = self.split_heads(k, batch_size)
        v = self.split_heads(v, batch_size)

        attention_output, attention_weights = scaled_dot_product_attention(q, k, v, mask, causality)
        scaled_attention = tf.transpose(attention_output, perm=[0, 2, 1, 3])
        concat_attention = tf.reshape(scaled_attention, (batch_size, -1, self.d_model))
        output = self.dense(concat_attention)

        return output, attention_weights


class EncoderLayer(tf.keras.layers.Layer):
    def __init__(self, d_model, num_heads, layer_idx, rate=0.1):
        super(EncoderLayer, self).__init__()

        self.mha = MultiHeadAttention(d_model, num_heads, layer_idx)
        self.ffn = ego.DenseTower(
                        name="ffn" + str(layer_idx),
                        output_dims=[d_model * 4, d_model],
                        kernel_initializers=[local_param_initializer] * 2,
                        bias_initializers=[local_param_initializer] * 2,
                        activations=[tf.nn.leaky_relu, None],
                        norms=[False, False],
                        use_bias=True
                    )

        self.layernorm1 = tf.keras.layers.LayerNormalization(epsilon=1e-6)
        self.layernorm2 = tf.keras.layers.LayerNormalization(epsilon=1e-6)

        self.dropout1 = tf.keras.layers.Dropout(rate)
        self.dropout2 = tf.keras.layers.Dropout(rate)

    def call(self, x, training, mask, causality):
        attn_output, _ = self.mha(x, x, x, mask, causality)
        attn_output = self.dropout1(attn_output, training=training)
        out1 = self.layernorm1(x + attn_output)
        ffn_output = self.ffn(out1)
        ffn_output = self.dropout2(ffn_output, training=training)
        out2 = self.layernorm2(out1 + ffn_output)
        return out2


class Transformer(tf.keras.layers.Layer):
    def __init__(self, num_layers, d_model, num_heads, maximum_position_encoding = 50, rate=0.1):
        super(Transformer, self).__init__()

        self.d_model = d_model
        self.num_layers = num_layers
        self.maximum_position_encoding = maximum_position_encoding
        self.enc_layers = [EncoderLayer(d_model, num_heads, layer_idx, rate) for layer_idx in range(num_layers)]
        self.proj_layer = get_ego_layer("proj_layer", d_model)
        self.position_emb = self.add_weight(name='position', shape=(maximum_position_encoding, d_model),
                initializer=local_param_initializer, trainable=True)

    def call(self, x, training, mask, use_pos = True, causality = False):
        # pos_length = get_shape(x)[-1]
        x = self.proj_layer(x)
        if use_pos:
            x += self.position_emb

        for i in range(self.num_layers):
            x = self.enc_layers[i](x, training, mask, causality)

        return x


def multihead_target_attention_v2_auto_fold(
        queries,
        keys,
        values,
        num_units=None,
        num_output_units=None,
        activation_fn=None,
        num_heads=8,
        name="multihead_target_attention",
        key_masks=None,
):
    if num_units is None:
        num_units = queries.get_shape().as_list()[-1]
    query_len = queries.get_shape().as_list()[1]
    query_dim = queries.get_shape().as_list()[-1]
    key_len = keys.get_shape().as_list()[1]
    key_dim = keys.get_shape().as_list()[-1]
    value_dim = values.get_shape().as_list()[-1]

    queries_2d = tf.reshape(queries, [-1, query_dim])
    keys_2d = tf.reshape(keys, [-1, key_dim])
    values_2d = tf.reshape(values, [-1, value_dim])

    Q = ego.DenseTower(
        name="{}_ln_proj_q".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(queries_2d)
    Q = tf.reshape(Q, [-1, query_len, num_units])
    K = ego.DenseTower(
        name="{}_ln_proj_k".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(keys_2d)
    K = tf.reshape(K, [-1, key_len, num_units])
    V = ego.DenseTower(
        name="{}_ln_proj_v".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(values_2d)
    V = tf.reshape(V, [-1, key_len, num_units])

    key_masks_ = tf.tile(
        tf.reshape(key_masks, [-1, 1, 1, key_len]), [1, num_heads, query_len, 1]
    )


    Q_ = tf.stack(tf.split(Q, num_heads, axis=2), axis=1)
    K_ = tf.stack(tf.split(K, num_heads, axis=2), axis=1)
    V_ = tf.stack(tf.split(V, num_heads, axis=2), axis=1)

    Q_ = tf.keras.layers.LayerNormalization(axis=-1)(Q_)
    K_ = tf.keras.layers.LayerNormalization(axis=-1)(K_)


    feature_map = tf.matmul(Q_, K_, transpose_b=True)
    feature_map = feature_map * (num_units ** (-0.5))

    paddings = tf.fill(
        tf.shape(feature_map), tf.constant(-(2 ** 20) + 1, dtype=tf.float32)
    )
    feature_map = tf.where(key_masks_ > 0, feature_map, paddings)
    feature_map = tf.nn.softmax(feature_map)

    outputs = tf.matmul(feature_map, V_)
    outputs = tf.concat(tf.unstack(outputs, axis=1), axis=-1)
    return outputs, feature_map

def din_target_attention(
        queries,
        keys,
        values,
        num_units=None,
        activation_fn=None,
        name="din_target_attention",
        key_masks=None,
        weight_nn=None,
        infer=False,
        topk=0,
):
    if num_units is None:
        num_units = queries.get_shape().as_list()[-1]
    query_len = queries.get_shape().as_list()[1]
    query_dim = queries.get_shape().as_list()[-1]
    key_len = keys.get_shape().as_list()[1]
    key_dim = keys.get_shape().as_list()[-1]
    value_dim = values.get_shape().as_list()[-1]

    queries_2d = tf.reshape(queries, [-1, query_dim])
    keys_2d = tf.reshape(keys, [-1, key_dim])
    values_2d = tf.reshape(values, [-1, value_dim])

    Q = ego.DenseTower(
        name="{}_ln_proj_q".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(queries_2d)
    Q = tf.reshape(Q, [-1, query_len, num_units])
    K = ego.DenseTower(
        name="{}_ln_proj_k".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(keys_2d)
    K = tf.reshape(K, [-1, key_len, num_units])
    V = ego.DenseTower(
        name="{}_ln_proj_v".format(name),
        output_dims=[num_units],
        activations=[activation_fn]
    )(values_2d)
    V = tf.reshape(V, [-1, key_len, num_units])

    # (B, query_len, 1, num_units) (B, 1, key_len, num_units)
    Q_K_fea = Q[:, :, tf.newaxis, :] * K[:, tf.newaxis, :, :] + Q[:, :, tf.newaxis, :] + K[:, tf.newaxis, :, :]
    # (B, query_len, key_len)
    Q_K_weight = tf.squeeze(weight_nn(Q_K_fea), axis = -1)
    feature_map = Q_K_weight * key_masks[:, tf.newaxis, :]
    outputs = tf.matmul(feature_map, V) # (B, query_len, num_units)
    if infer == True:
        # (B, query_len)
        feature_map_sum = tf.reduce_sum(feature_map, axis = -1)
        # (B, topk)
        _, top_indices = tf.math.top_k(feature_map_sum, k = topk)

        # (B, 1, 1)
        row_indices = tf.range(tf.shape(outputs)[0])[:, tf.newaxis, tf.newaxis]
        # (B, topk, 1)
        row_indices = tf.tile(row_indices, [1, topk, 1])

        # (B, topk, 2)
        gather_indices = tf.concat([row_indices, top_indices[..., tf.newaxis]], axis=-1)

        # (B, topk, num_units)
        gather_outputs = tf.gather_nd(outputs, gather_indices)
        return gather_outputs, top_indices

    # # (B, query_len, key_len)
    # Q_K_weight = tf.matmul(Q, K, transpose_b=True)
    # feature_map = tf.math.sigmoid(Q_K_weight) * key_masks[:, tf.newaxis, :]

    return outputs, feature_map
