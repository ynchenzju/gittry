#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import tensorflow as tf
import ego
import json
from feature import fm
from utils.ops import *

embedding_dim = 64
sample_cnt = 40
random_cnt = 40
inbatch_cnt = 40
MAX_SEQ_LEN = 50
d_model = 64
beta = 4.0

# ego.config_dump_tensor(with_sample_id=False)

def importance_sample(dot_result):
    # dot_result (B, K)
    dot_result -= tf.reduce_max(dot_result, axis=1, keepdims=True)
    # (B, 1)
    ori_dot_pos = tf.expand_dims(dot_result[:, 0], axis=1)
    # (B, 1)
    pos = tf.exp(ori_dot_pos)
    # (B, K-1)
    neg = tf.exp(dot_result[:, 1:])
    # (B, K-1)
    imp = tf.exp(beta * dot_result[:, 1:] -  tf.reduce_max(beta * dot_result[:, 1:], axis = 1, keepdims = True))
    # (B, 1)
    reweight_neg = tf.reduce_sum(imp * neg, axis = -1, keepdims=True) / (tf.reduce_mean(imp, axis = -1, keepdims=True) + 1e-8)
    # (B, 1)
    stable_logsoftmax = ori_dot_pos - tf.log(pos + reweight_neg + 1e-8)
    return stable_logsoftmax, pos, neg, reweight_neg

param_initializer = tf.truncated_normal_initializer(stddev=0.001, dtype=tf.float32)

user_group_names = {'ub_click_seq': ego.FeatureType.UNDEFINED}


item_compress_layer = ego.DenseTower(
                        name='compress_layer',
                        output_dims=[embedding_dim],
                        kernel_initializers=[param_initializer] * 1,
                        bias_initializers=[param_initializer] * 1,
                        activations=[None],
                        norms=[False],
                        use_bias=False
                    )

item_tower_dnn = ego.DenseTower(
                        name='ItemTower1',
                        output_dims=[255, 127, embedding_dim],
                        kernel_initializers=[param_initializer] * 3,
                        bias_initializers=[param_initializer] * 3,
                        activations=[tf.nn.leaky_relu, tf.nn.leaky_relu, None],
                        norms=[True, False, False],
                        use_bias=True
                        )

group_input_map = {}
for group_name in user_group_names:
    group_input_map[group_name] = fm.build_input(group_name, user_group_names[group_name], MAX_SEQ_LEN)

seq_emb, seq_len = group_input_map['ub_click_seq']
seq_len = tf.squeeze(seq_len, axis=1)
mask = tf.cast(tf.sequence_mask(seq_len, MAX_SEQ_LEN), dtype = tf.float32) # (B, seq_len)
seq_emb = item_compress_layer(seq_emb)

trans_output = Transformer(num_layers = 2, d_model = d_model, num_heads = 1,
    maximum_position_encoding = MAX_SEQ_LEN)(seq_emb, ego.is_training_mode(), mask, True, True)
user_emb = tf.nn.l2_normalize(trans_output[:, 0, :], axis = -1, epsilon=1e-6)

if ego.is_training_mode():
    ego.config_nsc(use_nsc=True, sample_ratio=sample_cnt, share_batch=False)
    item_embs, _, _ = fm.build_target_item_input('target_item_query', True)

    item_input = tf.concat(item_embs, axis = 0) # (B * sample_cnt, dim)
    item_emb = tf.nn.l2_normalize(item_tower_dnn(item_input), axis=1, epsilon=1e-6, name='item_vec')

    user_batch_size = get_shape(seq_emb)[0]
    # (B, random_cnt, dim)
    random_uniform_neg_item = local_neg_sample(user_batch_size, item_emb, random_cnt, user_batch_size)
    # (B, inbatch_cnt, dim)
    batch_neg_item = get_batch_neg_sample(item_emb, inbatch_cnt, get_shape(seq_emb)[0])

    item_emb = tf.stack(tf.split(item_emb, num_or_size_splits=sample_cnt + 1, axis=0), axis = 1)
    # (B, 1 + sample_cnt + inbatch_cnt + random_cnt, dim)
    item_emb = tf.concat([item_emb, batch_neg_item, random_uniform_neg_item], axis=1)

    dot_result = tf.reduce_sum(tf.multiply(user_emb[:, tf.newaxis, :], item_emb), axis=-1, name='ip')

    stable_logsoftmax, pos, neg, reweight_neg = importance_sample(dot_result * 20)
    label, weight = ego.get_label_weight(target_name="label0", label_idx=0)
    loss_cvr = tf.multiply(label, -stable_logsoftmax, name='c_loss')

    # tmp_loss = tf.stop_gradient(tf.reduce_sum(tf.stack(monitor_var)))
    final_loss = tf.add(tf.reduce_sum(loss_cvr * -weight), 0, name = 'final_loss')
    ego.Target("pos", pos, label, weight, None)
    ego.Target("neg", tf.reduce_sum(neg, axis=-1, keepdims=True), label, weight, None)
    ego.Target("reweight_neg", reweight_neg, label, weight, None)

    round1 = ego.OfflineRound(name="train_round1",
                targets=['pos', 'neg', 'reweight_neg'],
                final_loss=final_loss,
                train_sparse=True)
    ego.compile(rounds=[round1])
else:
    item_input, target_item_slotids, dim_list = fm.build_target_item_input('target_item_query', False)
    try:
        with open('online_compile_config.json') as f:
            cfg = json.load(f)
        cfg_targets = cfg.get('targets', ['user_emb_output', 'item_emb_output'])
    except:
        cfg_targets = ['user_emb_output', 'item_emb_output']

    targets = []
    if 'user_emb_output' in cfg_targets:
        ego.import_extra_slots(target_item_slotids, dim_list)
        ego.Target("user_emb_output", user_emb, None, None, None, None)
        targets.append('user_emb_output')

    if 'item_emb_output' in cfg_targets:
        item_vec_normed = tf.nn.l2_normalize(item_tower_dnn(item_input), axis=1, epsilon=1e-6, name='item_vec_normed')
        ego.import_extra_slots(target_item_slotids, dim_list)
        ego.Target("item_emb_output", item_vec_normed, None, None, None, None)
        targets.append('item_emb_output')
    #logging.info('online_targets={targets}'.format(targets=targets))
    ego.compile(rounds=[
        ego.OnlineRound(name='online', targets=targets),
    ])

