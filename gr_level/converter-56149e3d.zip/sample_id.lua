function filter_fn(ext_info)
    local data_type = ext_info['DataType'] or ''
    if data_type == 'ads' or data_type == 'video' then
        return false
    end
    return true
end
