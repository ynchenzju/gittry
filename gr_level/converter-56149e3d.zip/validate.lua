function extension_fn(sample_id, ext_info)
    return {
        ORIGIN_FEATURE = ext_info['pb_msg'] or ''
    }
end
