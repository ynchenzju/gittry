# -*- coding: utf-8 -*-

from __future__ import print_function
import sys

target_key_list = ('country', 'ranker_name', 'ranker_version', 'rank_score', 'location', 'life_tag', 'pb_msg', 'checkout_no', 'skip_imp')
debug_info_dicts = dict.fromkeys(target_key_list)

def format_to_old(debug_info):
    split_debug_info = debug_info.split(':')
    # compatible with old format
    if len(split_debug_info) >= 1 and split_debug_info[0] != "DEBUG_INFO__v2":
        return debug_info

    for item in split_debug_info:
        # start with DEBUG_INFO__
        if item == "DEBUG_INFO__v2":
            continue
        # key,value pair
        key_value_pair = item.split(",")
        if len(key_value_pair) != 2:
            # skip amazing pair
            continue
        if key_value_pair[0] not in debug_info_dicts.keys():
            # skip keys solely for debug_info_v2
            continue
        debug_info_dicts[key_value_pair[0]] = key_value_pair[1]

    old_format_debug_info = f'{"DEBUG_INFO__"+debug_info_dicts["country"]}:{debug_info_dicts["ranker_name"]}:{debug_info_dicts["ranker_version"]}:{debug_info_dicts["rank_score"]}:{debug_info_dicts["location"]}'
    if debug_info_dicts.get('pb_msg', None):
        pb_part = debug_info_dicts['pb_msg']
        old_format_debug_info += f':{pb_part}'
    old_format_debug_info += f':life_tag:{debug_info_dicts["life_tag"]}:checkout_no:{debug_info_dicts["checkout_no"]}:location:{debug_info_dicts["location"]}:skip_imp:{debug_info_dicts["skip_imp"]}'
    return old_format_debug_info

for line in sys.stdin:
    sampleid, debug_info, action, dense, sparse = line.rstrip('\n').split('\t')
    ## Older DEBUG_INFO format:
    ## DEBUG_INFO__SG:dd_feav4_longterm@SG:1669425829:0.666630:92:[origin_feature:]life_tag:lifecycle_non_buyer:checkout_no:5:location:92:skip_imp:0
    ## Update DEBUG_INFO format:
    ## DEBUG_INFO__v2:country,SG:ranker_name,dd_feav4_longterm@SG:ranker_version,1669425829:rank_score,0.666630:location,92:life_tag,lifecycle_non_buyer:multitask_rank_scores,0.666628|0.537907|0.511607|0.312173:checkout_no,5:skip_imp,0

    old_debug_info = format_to_old(debug_info)
    print("\t".join([sampleid, old_debug_info, action, dense, sparse]))

