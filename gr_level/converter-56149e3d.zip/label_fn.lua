function exist(action_map, key)
    if (action_map[key] ~= nil and action_map[key] > 0.0)
    then
        return true
    end
    return false
end

-- todo verify labels
function label_fn(action_map, sample_id)
    local label={click=0, cart=0, order=0, place_order=0, ads_order=0}
    local weight={click=1, cart=0, order=0, place_order=0, ads_order=0}

    if exist(action_map, 'click') or exist(action_map, 'cart') or exist(action_map, 'cart_cnt') or exist(action_map, 'new_order_cnt') or exist(action_map, 'place_order') or exist(action_map, 'place_order_gmv') or exist(action_map, 'ads_org_direct_order_0_1d_cnt')
    then
        weight['click'], weight['cart'], weight['order'], weight['place_order'], weight['ads_order'] = 1, 1, 1, 1, 1
        label['click'], weight['click'] = 1, 8
        if exist(action_map, 'cart') or exist(action_map, 'cart_cnt')
        then
            label['cart'], weight['cart'] = 1, 8
        end
        if exist(action_map, 'new_order_cnt')
        then
            label['order'], weight['order'] = 1, 20
        end
        if exist(action_map, 'ads_org_direct_order_0_1d_cnt')
        then
            label['ads_order'], weight['ads_order'] = 1, 20
        end
        if exist(action_map, 'place_order') or exist(action_map, 'place_order_gmv')
        then
            label['place_order'], weight['place_order'] = 1, 20
        end
    end
    return label, weight
end

function show_click_fn(action_map)
    show = "1"
    click = "0"
    if exist(action_map, 'click') or exist(action_map, 'cart') or exist(action_map, 'cart_cnt') or exist(action_map, 'new_order_cnt') then
        click = "1"
    end
    return show, click
end
