#!/usr/bin/env python
# -*- coding: utf-8 -*-


import tensorflow as tf
import yaml, copy, os
import ego
from utils.fg_tool import FGConfV2

from models.rr_llm_madnnv2_dt_neg import BaseModelRR
ego.import_extra_slots([2001, 2004, 2011, 2002, 2010, 3317, 8000, 8001, 3190, 3191], [64, 8, 16, 16, 8, 8, 33, 33, 16, 16])
ego.config_feature_admission_evict(slots=[8002, 11610, 11611], delete_threshold=0, delete_after_unseen_days=9999)

print("ego training mode: {}".format(ego.is_training_mode()))
with open("configs/mcconf_madnnv2_dt.yaml", "r") as fh:
    mcyaml = yaml.safe_load(fh)
model = BaseModelRR(None, mcyaml, clipnorm=True, register_hanging_slot=False, dense_dim=0, onehot_dim=0)
p1 = model.build_graph()[0]

dense_slots = []
onehot_slots = []

export_conf = model.mcutil.to_export_yaml(onehot_slots=onehot_slots, dense_slots=dense_slots)
with open("configs/export.yaml", "w") as fh:
    yaml.safe_dump(export_conf, fh)

if ego.is_training_mode():
    # # for student
    eval = ego.OfflineRound(name="eval", targets= p1["predict_target_names"], dump_scalar_tensors_to_tensorboard=p1["scalar_tensor"], final_loss=None)
    r1_t = ego.OfflineRound(name="p1_t", targets=p1["target_names_t"], final_loss=p1["phase_loss_t"], train_sparse=True)
    r1_s = ego.OfflineRound(name="p1_s", targets=p1["target_names"], final_loss=p1["phase_loss"], train_sparse=True)
    ego.compile(rounds=[eval, r1_t, r1_s])
    # for teacher
    # eval = ego.OfflineRound(name="eval", targets= p1["predict_target_names"], dump_scalar_tensors_to_tensorboard=p1["scalar_tensor"], final_loss=None)
    # eval_s = ego.OfflineRound(name="eval_s", targets=p1["target_names"], final_loss=None)
    # r1_t = ego.OfflineRound(name="p1_t", targets=p1["target_names_t"], final_loss=p1["phase_loss_t"], train_sparse=True)
    # ego.compile(rounds=[eval, eval_s, r1_t])
else:
    r = ego.OnlineRound(name="online", targets=p1["online_target_names"])
    ego.compile(rounds=[r])

