#!/usr/bin/env python
# -*- coding: utf-8 -*-
import tensorflow as tf
import ego


__tf_version = tf.__version__
if __tf_version >= '2.0':
    tf2 = tf
    tf = tf.compat.v1


def get_shape(inputs):
    dynamic_shape = tf.shape(inputs)
    static_shape = inputs.get_shape().as_list()
    shape = []
    for i, dim in enumerate(static_shape):
        shape.append(dim if dim is not None else dynamic_shape[i])
    return shape


def cosine_similarity(a, b):
    print(f"norm_a={a}, norm_b={b}")
    dot_product = tf.reduce_sum(tf.multiply(a, b), axis=-1)
    return dot_product


def din_attention_cos(queries, keys, keys_length, return_weight=False, softmax_with_tau=False, tau=1.0, use_simtier=False, simtier_number=20, use_agg=True,
                      weight_only=False, name="din_attention_cos"):
    '''
        queries:     [B, H]
        keys:        [B, T, H]
        keys_length: [B]
    '''
    with tf.variable_scope(f"{name}"):
        queries = tf.nn.l2_normalize(queries, axis=-1, epsilon=1e-6, name=f'q_l2_norm')
        keys = tf.nn.l2_normalize(keys, axis=-1, epsilon=1e-6, name=f'key_l2_norm')
        seq_len = keys.get_shape().as_list()[1]
        queries = tf.expand_dims(queries, axis=1)
        raw_weights = cosine_similarity(queries, keys) # (B, T)
        if weight_only:
            return None, raw_weights, None

        if isinstance(simtier_number, (list, tuple)) and len(simtier_number) > 1 and use_simtier:
            assert len(simtier_number) == len(set(simtier_number))
            res = []
            for N in simtier_number:
                with tf.variable_scope(f"{name}_tier_{N}"):
                    # Assign tier to each score [B, S]
                    indices = tf.reshape(tf.cast((raw_weights + 1) / 2 * N, dtype=tf.int32), (-1, seq_len))
                    # Accumulate counts for each tier [B, N]
                    sim_weights = tf.equal(tf.reshape(tf.range(0, N + 1, 1), [1, N + 1, 1]),tf.expand_dims(indices, axis=1))
                    sim_tier = tf.reduce_mean(tf.cast(sim_weights, dtype=tf.float32), axis=2)
                    res.append(sim_tier)
            sim_tier = tf.concat(res, axis=1, name="multi_granul_tier_concat")
        else:
            if use_simtier:
                N = simtier_number[0] if isinstance(simtier_number, (list, tuple)) and len(simtier_number) == 1 else simtier_number
                # Assign tier to each score [B, S]
                indices = tf.reshape(tf.cast((raw_weights + 1) / 2 * N, dtype=tf.int32), (-1, seq_len))
                # Accumulate counts for each tier [B, N]
                sim_weights = tf.equal(tf.reshape(tf.range(0, N, 1), [1, N, 1]),tf.expand_dims(indices, axis=1))
                sim_tier = tf.reduce_mean(tf.cast(sim_weights, dtype=tf.float32), axis=2)

        if not use_agg and use_simtier:
            return None, raw_weights, sim_tier
        elif not use_agg and not use_simtier:
            return None, raw_weights, sim_tier

        ## use agg
        if softmax_with_tau:
            weights = tf.nn.softmax(raw_weights / tau, axis=-1, name="softmax_with_tau")
            weights = tf.expand_dims(weights, axis=1) # (B, 1, T)
        else:
            weights = tf.expand_dims(raw_weights, axis=1) # (B, 1, T)
        # Mask
        key_masks = tf.sequence_mask(keys_length, seq_len)   # [B, T]

        paddings = tf.zeros_like(weights) # (B, 1, T)
        weights = tf.where(key_masks, weights, paddings)  # [B, 1, T]
        outputs = tf.matmul(weights, keys)  # [B, 1, H]

        # Weighted sum
        print(f"[!] weights = {weights}")
        print(f"[!] raw_weights = {raw_weights}")
        print(f"[!] keys = {keys}")
        print(f"[!] outputs = {outputs}")
        if return_weight and use_simtier:
            return tf.squeeze(outputs, axis=1), raw_weights, sim_tier
        elif use_simtier:
            return tf.squeeze(outputs, axis=1), sim_tier
        elif return_weight:
            return tf.squeeze(outputs, axis=1), raw_weights
        else:
            return tf.squeeze(outputs, axis=1)


## https://github.com/zhougr1993/DeepInterestNetwork/blob/master/din/model_dice.py
def din_attention_mlp(queries, keys, keys_length, return_weight=False, use_l2_norm=True, qk_concat="default", output_dims=[80, 40, 1], name="din_layer_mlp"):
    '''
        queries:     [B, H]
        keys:        [B, T, H]
        keys_length: [B, 1]
    '''
    with tf.variable_scope(f"{name}"):
        if use_l2_norm:
            queries = tf.nn.l2_normalize(queries, axis=-1, epsilon=1e-6, name=f'q_l2_norm')
            keys = tf.nn.l2_normalize(keys, axis=-1, epsilon=1e-6, name=f'key_l2_norm')
        seq_len =  int(get_shape(keys)[1])
        queries = tf.expand_dims(queries, axis=1, name="q_expand_dims")
        queries = tf.tile(queries, [1, seq_len, 1], name="q_tile")
        if qk_concat == "default":
            din_all = tf.concat([queries, keys, queries-keys, queries*keys], axis=-1, name="q_k_concat")
        elif qk_concat == "qk":
            din_all = tf.concat([queries, keys], axis=-1, name="q_k_concat")
        elif qk_concat == "qk_i":
            din_all = tf.concat([ queries-keys, queries*keys], axis=-1, name="q_k_concat")
        else:
            raise RuntimeError

        param_initializer = tf.initializers.glorot_normal()
        bias_initializer = tf.zeros_initializer()

        d_layer_3_all = ego.DenseTower(name='f1_f2_f3_att',
                                       output_dims=output_dims,
                                       kernel_initializers=[param_initializer] * 3,
                                       bias_initializers=[bias_initializer] * 3,
                                       activations=[tf.nn.leaky_relu, tf.nn.leaky_relu, None],
                                       norms=[False, False, False],
                                       use_bias=True
                                       )(din_all)
        d_layer_3_all = tf.reshape(d_layer_3_all, [-1, 1, seq_len], name="logit_reshape")
        outputs = d_layer_3_all
        # Mask
        keys_length = tf.squeeze(keys_length, axis=1, name="key_sq")
        key_masks = tf.sequence_mask(keys_length, seq_len, name="key_mask")   # [B, T]
        key_masks = tf.expand_dims(key_masks, 1, name="key_expand_dims") # [B, 1, T]
        paddings = tf.ones_like(outputs) * (-2 ** 32 + 1)
        print("key_masks:", key_masks)
        print("outputs:", outputs)
        print("paddings:", paddings)
        outputs = tf.where(key_masks, outputs, paddings)  # [B, 1, T]

        # Scale
        # outputs = outputs / (keys.get_shape().as_list()[-1] ** 0.5)

        # Activation
        raw_weights = tf.nn.softmax(outputs, axis=-1, name="w_softmax")  # [B, 1, T]
        print("raw_weights:", raw_weights)
        # Weighted sum
        outputs = tf.matmul(raw_weights, keys)  # [B, 1, H]
        if return_weight:
            return tf.squeeze(outputs, axis=1, name="output_sq"), tf.squeeze(raw_weights, axis=1, name="weight_sq")
        return tf.squeeze(outputs, axis=1, name="output_sq")
