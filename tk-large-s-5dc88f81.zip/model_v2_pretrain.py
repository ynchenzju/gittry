#!/usr/bin/env python
# -*- coding: utf-8 -*-


import tensorflow as tf
import yaml, copy, os
import ego
from utils.fg_tool import FGConfV2

from models.rr_llm_madnn_v2_pretrain import BaseModelRR
ego.import_extra_slots([2001, 2004, 2011, 2002, 2010, 3317, 8000, 8001, 1001, 2001, 11001, 12001, 8904, 8905], [64, 8, 16, 16, 8, 8, 33, 33, 128, 80, 128, 80, 33, 33])
ego.config_feature_admission_evict(slots=[8002, 11610, 11611], delete_threshold=0, delete_after_unseen_days=9999)
ego.config_feature_admission_evict(slots=[8000, 8001, 1001, 2001], create_clk_prob=0, create_nonclk_prob=0, delete_after_unseen_days=24*366)

print("ego training mode: {}".format(ego.is_training_mode()))
with open("configs/mcconf_v2_pretrain.yaml", "r") as fh:
    mcyaml = yaml.safe_load(fh)
model = BaseModelRR(None, mcyaml, clipnorm=True, register_hanging_slot=False, dense_dim=0, onehot_dim=0)
p1 = model.build_graph()[0]

dense_slots = []
onehot_slots = []

export_conf = model.mcutil.to_export_yaml(onehot_slots=onehot_slots, dense_slots=dense_slots)
with open("configs/export.yaml", "w") as fh:
    yaml.safe_dump(export_conf, fh)

if ego.is_training_mode():
    eval = ego.OfflineRound(name="eval", targets= p1["predict_target_names"], final_loss=None)
    r1 = ego.OfflineRound(name="p1",
                          targets=p1["target_names"],
                          final_loss=p1["phase_loss"],
                          dump_scalar_tensors_to_tensorboard=p1["scalar_tensor"],
                          train_sparse=True)
    ego.compile(rounds=[eval, r1])
else:
    r = ego.OnlineRound(name="online", targets=p1["predict_target_names"])
    ego.compile(rounds=[r])

